
"""
Fitxer indexador de rutes globals de l'API.

Aquest fitxer importa les rutes definides a cada mòdul 
(api/core/urls.py, api/spampolicy/urls.py, ...) i les combina
en una sola llista perquè web.py pugui registrar-les fàcilment.
"""

# 📌 Importem les rutes de cada mòdul
from api.core.urls import urls as core_urls
from api.spampolicy.urls import urls as spampolicy_urls
from api.wblist.urls import urls as wblist_urls
from api.crud.urls import urls as crud_urls
from api.maillist.urls import urls as  maillist_urls
from api.greylist.urls import urls as greylisting_urls
from api.throttle.urls import urls as throttle_urls

# 📌 Llista global de rutes
urls = []

# 🧩 Afegim les rutes del mòdul "core"
urls += core_urls

# 🧩 Afegim les rutes del mòdul "spampolicy"
urls += spampolicy_urls

# 🧩 Afegir les rutes del mòdul "wblist"
urls += wblist_urls

# 🧩 Afegir les rutes del mòdul "crud"
urls += crud_urls

# 🧩 Afegim les rutes del mòdul "maillist"
urls += maillist_urls

# 🧩 Afegir les rutes del mòdul "greylist"
urls += greylisting_urls

# 🧩 Afegir les rutes del mòdul "throttle"
urls += throttle_urls

"""
Ara, al punt d'entrada principal de l'app, només caldrà fer:
    import web
    from api import urls as api_urls
    app = web.application(api_urls.urls, globals())
    
    ara tinc a iredbase.py:
    
    if settings.ENABLE_RESTFUL_API:
        from api.urls import urls as urls_api 
        urls += urls_api
    
"""
