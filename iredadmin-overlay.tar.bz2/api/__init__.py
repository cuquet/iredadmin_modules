# api/__init__.py
# 🎯 Punt d'entrada de l'API RESTful per a iRedAdmin
# $ journalctl -u iredadmin -n 50 --no-pager 
# depurar error 

import web

from .urls import urls

# Inicialitza l'aplicació
app = web.application(urls, globals())

# Per executar com a script independent
if __name__ == '__main__':
    app.run()