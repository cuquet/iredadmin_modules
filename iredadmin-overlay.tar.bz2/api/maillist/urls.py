# /api/maillist/urls.py
from libs.regxes import email as e, domain as d

urls = [
    '/api/mls/(%s)$' % d, 'api.maillist.controller.API_MailList',
    '/api/ml/(%s)$' % e, 'api.maillist.controller.API_MailList',
]
