# /api/maillist/controller.py
import web
from libs.m_crudlib import decorators
from libs.m_maillist import ml as lib_ml
from api.utils import _parse_api_payload, _check_privilege
from controllers.m_maillist import utils as ml_utils

class API_MailList:
    def _normalize_yes_no(self, value):
        v = str(value).strip().lower()
        return "yes" if v in ("yes", "true", "1", "active", "on") else ""

    @decorators.require_login
    @decorators.json_response
    def GET(self, account=None):
        ok, result = _check_privilege(account, None)
        if not ok:
            return (False, result)
        
        ok, payload = _parse_api_payload()
        if not ok:
            payload = {}
        form = web.input(email_only='no', subscriber='')
        params = {**dict(form), **payload}

        if result['account_type']!= 'domain' and result['account']:
            return lib_ml.MailList(mail=result['account']).get_profile()
        elif result['account_type']== 'domain' and result['account']:
            return lib_ml.MailList(domain=result['account'].lstrip('@')).list(
                subscriber=params.get('subscriber') or None,
                email_only=(params.get('email_only', 'no') == 'yes'),
            )

    @decorators.require_login
    @decorators.json_response
    def POST(self, mail):
        ok, payload = _parse_api_payload()
        if not ok:
            return (False, payload)

        mail = web.safestr(mail).strip().lower()
        domain = mail.split('@')[-1].strip()

        params = dict(payload)
        params['mail'] = mail
        params.setdefault('username', mail.split('@', 1)[0].strip().lower())
        params.setdefault('domainName', domain)

        # Normalize API field names
        if 'cn' in params and 'name' not in params:
            params['name'] = params.pop('cn')
        if 'newsletter_description' in params and 'description' not in params:
            params['description'] = params.pop('newsletter_description')

        # Normalize yes/no flags for API input
        yes_no_keys = {
            "is_newsletter", "close_list",
            "only_moderator_can_post", "only_subscriber_can_post",
            "disable_subscription", "disable_subscription_confirm",
            "disable_digest_subscription", "disable_digest_text",
            "disable_nomail_subscription", "moderated",
            "moderate_non_subscriber_post",
            "disable_retrieving_old_posts", "only_subscriber_can_get_old_posts",
            "disable_retrieving_subscribers", "disable_send_copy_to_sender",
            "notify_owner_when_sub_unsub", "notify_sender_when_moderated",
            "disable_archive", "moderate_subscription",
        }
        for k in yes_no_keys:
            if k in params:
                params[k] = self._normalize_yes_no(params[k])
        if "accountStatus" in params:
            v = str(params.get("accountStatus")).strip().lower()
            params["accountStatus"] = "on" if v in ("active", "enabled", "yes", "on", "1") else ""

        # Build payloads using shared maillist utils
        base = ml_utils._parse_ml_payload_to_db(params)
        general = ml_utils._parse_ml_payload_to_db(params, profile_type="general")
        owners = ml_utils._parse_ml_payload_to_db(params, profile_type="owners")
        newsletter = ml_utils._parse_ml_payload_to_db(params, profile_type="newsletter")

        internal_params = {**base, **general, **owners, **newsletter}

        # Pass-through list-type fields for create
        for key in (
            "extra_addresses", "subscription_moderators", "owner", "moderators",
            "custom_headers", "remove_headers", "subject_prefix", "footer_text",
            "footer_html", "max_message_size",
        ):
            if key in params and key not in internal_params:
                internal_params[key] = params[key]

        # Allow explicit override for posting restrictions if provided
        for key in ("only_moderator_can_post", "only_subscriber_can_post"):
            if key in params:
                internal_params[key] = self._normalize_yes_no(params[key]) or "no"

        return lib_ml.MailList(mail=mail, domain=domain).add(internal_params)

    @decorators.require_login
    @decorators.json_response
    def PUT(self, mail):
        ok, payload = _parse_api_payload()
        if not ok:
            return (False, payload)

        mail = web.safestr(mail).strip().lower()
        domain = mail.split('@')[-1].strip()

        form = web.input()
        params = {**dict(form), **payload}

        profile_type = params.get('profile_type')
        if not profile_type:
            if any(k in params for k in ('subscriber', 'addSubscriber', 'removeSubscriber')):
                profile_type = 'members'
            elif any(k in params for k in ('aliases', 'addAlias', 'removeAlias', 'shadowAddress')):
                profile_type = 'aliases'
            elif any(k in params for k in ('owner', 'owners', 'moderator', 'moderators', 'addOwner', 'removeOwner', 'addModerator', 'removeModerator')):
                profile_type = 'owners'
            elif any(k in params for k in ('is_newsletter', 'description')):
                profile_type = 'newsletter'
            else:
                profile_type = 'general'

        # Normalize API field names
        if 'cn' in params and 'name' not in params:
            params['name'] = params.pop('cn')
        if 'newsletter_description' in params and 'description' not in params:
            params['description'] = params.pop('newsletter_description')

        # Normalize yes/no flags for API input
        yes_no_keys = {
            "is_newsletter", "close_list",
            "only_moderator_can_post", "only_subscriber_can_post",
            "disable_subscription", "disable_subscription_confirm",
            "disable_digest_subscription", "disable_digest_text",
            "disable_nomail_subscription", "moderated",
            "moderate_non_subscriber_post",
            "disable_retrieving_old_posts", "only_subscriber_can_get_old_posts",
            "disable_retrieving_subscribers", "disable_send_copy_to_sender",
            "notify_owner_when_sub_unsub", "notify_sender_when_moderated",
            "disable_archive", "moderate_subscription",
        }
        for k in yes_no_keys:
            if k in params:
                params[k] = self._normalize_yes_no(params[k])
        if "accountStatus" in params:
            v = str(params.get("accountStatus")).strip().lower()
            params["accountStatus"] = "on" if v in ("active", "enabled", "yes", "on", "1") else ""

        internal_params = {}

        if profile_type == 'general':
            internal_params = ml_utils._parse_ml_payload_to_db(params, profile_type="general")

        elif profile_type == 'members':
            internal_params = ml_utils._parse_ml_payload_to_db(params, profile_type="members")

        elif profile_type == 'aliases':
            internal_params = ml_utils._parse_ml_payload_to_db(params, profile_type="aliases")

        elif profile_type == 'owners':
            internal_params = ml_utils._parse_ml_payload_to_db(params, profile_type="owners")

        elif profile_type == 'newsletter':
            internal_params = ml_utils._parse_ml_payload_to_db(params, profile_type="newsletter")

        return lib_ml.MailList(mail=mail, domain=domain).update(internal_params, profile_type)
    
    @decorators.require_login
    @decorators.json_response
    def DELETE(self, mail):
        ok, payload = _parse_api_payload()
        if not ok:
            return (False, payload)

        mail = web.safestr(mail).strip().lower()
        domain = mail.split('@')[-1].strip()

        archive = payload.get('archive', 'no')
        return lib_ml.MailList(mail=mail, domain=domain).delete(mails=[mail], archive=archive)
