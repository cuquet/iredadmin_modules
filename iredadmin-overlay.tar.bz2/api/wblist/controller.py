# api/wblist/controller.py
import web

from libs.m_amavisd import wblist as lib_wblist

from libs.m_crudlib import decorators
from controllers.m_amavisd.utils import (
    _normalize_inout_type,
    _normalize_list_type,
)
from api.utils import ( 
    _check_privilege, 
    _parse_api_payload, 
)

from libs.m_system import form_utils

class API_WbList():
    @decorators.require_login
    @decorators.json_response
    def GET(self, inout_type, list_type, account_type):
        wb = _normalize_list_type(list_type)
        direction = _normalize_inout_type(inout_type)
        ok, result = _check_privilege(account_type, None)
        if not ok:
            return False, result

        return lib_wblist.WbList(result['account'], inout_type=direction, list_type=wb).get_wblist()

    @decorators.require_login
    @decorators.json_response
    def PUT(self, inout_type, list_type, account_type):
        wb = _normalize_list_type(list_type)
        direction = _normalize_inout_type(inout_type)
                
        ok, result = _check_privilege(account_type, None)
        if not ok:
            return False, result
        
        ok, payload = _parse_api_payload()
        if not ok:
            return False, payload

        add_addrs = form_utils.get_multi_values_from_api(
            payload, "addAddresses", to_lowercase=True
        ) if payload.get("addAddresses") else []
        remove_addrs = form_utils.get_multi_values_from_api(
            payload, "removeAddresses", to_lowercase=True
        ) if payload.get("removeAddresses") else []

        key_map = {
            ("inbound", "whitelist"): "whitelistSender",
            ("inbound", "blacklist"): "blacklistSender",
            ("outbound", "whitelist"): "whitelistRecipient",
            ("outbound", "blacklist"): "blacklistRecipient",
        }
        wb_key = key_map.get((direction.value, wb.value))
        if not wb_key:
            return False, "INVALID_LIST_TYPE"

        wb_payload = {}
        if add_addrs or remove_addrs:
            wb_payload[wb_key] = {}
            if add_addrs:
                wb_payload[wb_key]["add"] = ",".join(add_addrs)
            if remove_addrs:
                wb_payload[wb_key]["remove"] = ",".join(remove_addrs)

        ok, msg, *rest = lib_wblist.update_wblist(result['account'], wb_payload)
        if not ok:
            return (False, msg, *rest)
        return {"_msg": msg}


    @decorators.require_login
    @decorators.json_response
    def DELETE(self,  inout_type, list_type, account_type):
        wb = _normalize_list_type(list_type)
        direction = _normalize_inout_type(inout_type)
        
        ok, result = _check_privilege(account_type, None)
        if not ok:
            return False, result
        wblist = lib_wblist.WbList(account=result['account'], inout_type=direction, list_type=wb)

        return wblist.bulk_remove_wblist()
