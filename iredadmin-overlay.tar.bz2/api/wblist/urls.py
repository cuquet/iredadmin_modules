from libs.regxes import email as e, domain as d

urls = [
    '/api/wblist/(inbound|outbound)/(whitelist|blacklist)/(global)', 'api.wblist.controller.API_WbList',
    '/api/wblist/(inbound|outbound)/(whitelist|blacklist)/(%s)' % d, 'api.wblist.controller.API_WbList',
    '/api/wblist/(inbound|outbound)/(whitelist|blacklist)/(%s)' % e, 'api.wblist.controller.API_WbList',
]