# api/core/decorators.py

import web
import settings
import json
import datetime
from functools import wraps

from libs import iredutils
from libs.logger import logger, log_activity

from libs.m_crudlib.admin import Admin as lib_admin

def _safe_session_kill(session):
    try:
        if session and hasattr(session, "kill"):
            session.kill()
    except Exception:
        pass

def _json_default_serializer(obj):
    """Serialitza tipus no natius de JSON per evitar errors 500 en respostes API."""
    if isinstance(obj, (datetime.datetime, datetime.date, datetime.time)):
        return obj.isoformat()

    # Helpers de files de web.py
    if isinstance(obj, web.storage):
        return dict(obj)
    if hasattr(web, "utils") and isinstance(obj, web.utils.Storage):
        return dict(obj)

    # Últim recurs: evita 500 per tipus no previstos en el payload.
    return str(obj)


def json_response(func):
    """
        ## 🛡️ Decorador per convertir el resultat d'una funció en una resposta JSON coherent.

        Funcionalitat:
        - Accepta que la funció retorni `dict`, `tuple`, `bool` o altres tipus bàsics.
        - Sempre inclou la clau `_success` al JSON retornat.
        - Pot incloure dades (`_data`), missatges (`_msg`) i metadades (`_meta`, `_extraN`).
        - Configura `Content-Type` a `application/json`.
        - Assigna el codi HTTP segons l’èxit o error.
        - Captura excepcions internes i les retorna com a error JSON.

        
        ### Codis HTTP
        - 200 OK → Operació correcta (`_success: true`)
        - 400 Bad Request → Retorn boolean `False` (error d'usuari)
        - 403 Forbidden → `tuple` amb `success=False` (error de permisos o denegació)
        - 500 Internal Server Error → Tipus de retorn no suportat o excepció no controlada

        ### 🧪 Exemple d’ús
        1. Retornant un `dict`:
            Entrada:
                `{"x": 1, "y": 2}`
            Sortida:
                `{"_success": true, "x": 1, "y": 2}`
            HTTP: 200

        1. Retornant una `tuple` (èxit amb dades):
            Entrada:
                `(True, [{"id": 1}, {"id": 2}])`
            Sortida:
                `{"_success": true, "_data": [{"id": 1}, {"id": 2}]}`
            HTTP: 200

        1. Retornant una `tuple` (èxit amb dades + metadades):
            Entrada:
                `(True, [{"id": 1}], {"total": 1, "page": 1})`
            Sortida:
                ```JSON 
                {
                    "_success": true,
                    "_data": [{"id": 1}],
                    "_meta": {"total": 1, "page": 1}
                }
                ```
            HTTP: 200

        1. Retornant una `tuple` (múltiples elements extra):
            Entrada:
                `(True, [{"id": 1}], {"total": 1}, "cached")`
            Sortida:
                ```JSON
                {
                    "_success": true,
                    "_data": [{"id": 1}],
                    "_meta": {"total": 1},
                    "_extra2": "cached"
                }
                ```
            HTTP: 200

        1. Retornant una `tuple` (error amb missatge i metadades):
            Entrada:
                `(False, "No tens permisos", {"role": "user"})`
            Sortida:
                ```JSON
                {
                    "_success": false,
                    "_msg": "No tens permisos",
                    "_meta": {"role": "user"}
                }
                ```
            HTTP: 200

        1. Retornant un `bool`:
            Entrada:
                `True`
            Sortida:
                `{"_success": true}`
            HTTP: 200

        1. Quan es produeix una excepció:
            Sortida:
                `{"_success": false, "_msg": "MISSATGE_ERROR"}`
            HTTP: 500
    """
    @wraps(func)
    def wrapper(*args, **kwargs):
        session = web.config.get('_session', {})
        try:
            result = func(*args, **kwargs)
            if isinstance(result, dict):
                d = dict(result)  # Copiem per no modificar l'original
                d.setdefault('_success', True)
                # Reordena el dict perquè '_success' sigui la primera clau
                d = {'_success': d['_success'], **{k: v for k, v in d.items() if k != '_success'}}
                status_code = 200
            elif isinstance(result, tuple):
                success, *rest = result
                d = {'_success': success}
                
                if success:
                    status_code = 200
                    if rest:
                        for idx, item in enumerate(rest):
                            if idx == 0:
                                d['_data'] = item if isinstance(item, (list, dict)) else None
                                if not isinstance(item, (list, dict)):
                                    d['_msg'] = str(item)
                            elif idx == 1:
                                d['_meta'] = item
                            else:
                                d[f'_extra{idx}'] = item
                else:
                    status_code = 200
                    if rest:
                        if isinstance(rest[0], str):
                            d['_msg'] = rest[0]
                        else:
                            d['_data'] = rest[0]


            elif isinstance(result, bool):
                d = {'_success': result}
                status_code = 200 if result else 400
            else:
                d = {'_success': False, '_msg': 'UNSUPPORTED_RETURN_TYPE'}
                status_code = 500

        except Exception as e:
            status_code = 500
            d = {'_success': False, '_msg': str(e)}
            log_activity(event="update", loglevel="error",
                admin= session.get("username"),
                msg=f"[json_response] Unhandled exception in {func.__module__}.{func.__name__}: {e}",
                )

        web.header('Content-Type', 'application/json')
        try:
            web.ctx.status = str(f'{status_code} {"OK" if status_code==200 else "Error"}')
        except AttributeError:
            pass

        try:
            return json.dumps(d, default=_json_default_serializer)
        except Exception as e:
            # NOTE: Si la serialització peta, retornem JSON controlat (no error HTML).
            try:
                web.ctx.status = '500 Error'
            except AttributeError:
                pass

            log_activity(event="update",
                admin=session.get("username"), loglevel="error",
                msg=f"[json_response] Error serialitzant resposta de {func.__module__}.{func.__name__}: {e}",
                )
            return json.dumps({'_success': False, '_msg': 'JSON_SERIALIZATION_ERROR'})
    
    return wrapper

def require_domain_access(func):
    def proxyfunc(*args, **kw):
        session = web.config.get('_session', {})
        if not (session.get('logged') is True) or not session.get('username'):
            _safe_session_kill(session)
            raise web.seeother('/login?msg=LOGIN_REQUIRED')

        # Global admin always allowed
        if session.get('is_global_admin'):
            return func(*args, **kw)

        username = session.get('username')
        target_mail = kw.get('mail')
        
        if not target_mail:
            for arg in args:
                if iredutils.is_email(arg):
                    target_mail = arg
                    break
        
        if not target_mail:
            log_activity(event="update", loglevel="error",
                msg=f"[require_domain_access] No target_mail found",
                admin=username,
                )
            raise web.seeother('/domains?msg=PERMISSION_DENIED')

        domain = target_mail.split('@', 1)[-1]        

        # Allow access to own account
        if username == target_mail:
            return func(*args, **kw)

        # Check whether is domain admin.
        if lib_admin().is_domain_admin(domain=domain, admin=username):
            return func(*args, **kw)
        
        # Deny
        log_activity(event="update", loglevel="error",
            msg=f"[require_domain_access] PERMISSION_DENIED user={username} accessing={target_mail}",
            admin=username,
            domain=domain,
            username=target_mail,
            )
        raise web.seeother('/domains?msg=PERMISSION_DENIED')

    return proxyfunc

def require_admin_login(func):
    def proxyfunc(*args, **kw):
        session = web.config.get('_session')
        if session.get('logged') is True:
            if session.get('is_global_admin') or session.get('is_user_admin') or session.get('is_mail_admin'):
                return func( *args, **kw)
            log_activity(event="update", loglevel="error",
                admin=session.get('username'),
                msg=f"[require_admin_login] Permission denied for user={session.get('username')}",
                )
            if session.get('is_mail_user'):
                raise web.seeother('/preferences?msg=PERMISSION_DENIED')
            else:
                raise web.seeother('/domains?msg=PERMISSION_DENIED')

        _safe_session_kill(session)
        raise web.seeother('/login?msg=LOGIN_REQUIRED')
    return proxyfunc

def require_user_login(func):
    def proxyfunc(*args, **kw):
        session = web.config.get('_session')
        if not (session.get('logged') is True):
            _safe_session_kill(session)
            raise web.seeother('/login?msg=LOGIN_REQUIRED')
        if session.get('is_mail_user'):
            return func(*args, **kw)
        log_activity(event="update", loglevel="error",
            msg=f"[require_user_login] Login required for accessing {func.__module__}.{func.__name__}",
            )

        _safe_session_kill(session)
        raise web.seeother('/login?msg=LOGIN_REQUIRED')
    return proxyfunc

def require_preference_access(preference):
    def proxyfunc1(func):
        def proxyfunc2(self, *args, **kw):
            return func(self, *args, **kw)
        return proxyfunc2
    
    session = web.config.get('_session')

    if session.get('is_global_admin') or session.get('is_user_admin'):
        return proxyfunc1

    if preference in session.get('disabled_user_preferences', []):
        log_activity(event="update", loglevel="error",
            username=session.get('username'),
            msg=f"[require_preference_access] Preference disabled: {preference}",
            )
        raise web.seeother('/preferences?msg=PERMISSION_DENIED')

    return proxyfunc1

def require_permission_create_domain(func):
    def proxyfunc(*args, **kw):
        session = web.config.get('_session')
        if session.get('is_global_admin') or session.get('create_new_domains'):
            return func(*args, **kw)

        log_activity(event="update", loglevel="error",
            admin=session.get('username'),
            msg=f"[require_permission_create_domain] Permission denied",
            )

        if session.get('is_user_admin'):
            raise web.seeother('/preferences?msg=PERMISSION_DENIED')
        else:
            raise web.seeother('/domains?msg=PERMISSION_DENIED')

    return proxyfunc
