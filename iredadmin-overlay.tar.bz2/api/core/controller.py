# api/core/controller.py
import web
import settings
import os

from libs import iredutils
from libs.logger import logger, log_activity
from libs.m_crudlib import decorators

from api.core import auth
from api.utils import _parse_api_payload

class Api_SessionInfo:
    @decorators.json_response
    @decorators.require_login
    def GET(self):
        session = web.config._session
        username = session.get('username')
        # 1. Mirem si el secret encara és a la sessió (durant el login)
        twofa_secret = session.get('2FA_required', None)
        
        # 2. Si NO hi és (perquè ja estem loguejats), el busquem a la DB
        if not twofa_secret:
            from libs.m_crudlib import security
            import settings
            # Anem al backend real
            qr = security.user_has_totp(username, settings.backend)
            if qr[0]:
                twofa_secret = qr[1] # Aquest és el secret encriptat (AES)

        return True, {
            'username': session.get('username'),
            'is_global_admin': session.get('is_global_admin', False),
            'is_domain_admin': session.get('is_domain_admin', False),
            'is_mail_admin': session.get('is_mail_admin', False),
            'is_user_admin': session.get('is_user_admin', False),
            '2FA_required': session.get('2FA_required', None),
        }

class API_OpenAPI:
    """
        OpenAPI/Swagger:
        - GET /api/openapi.json -> spec
        - GET /api/docs         -> Swagger UI
    """
    @decorators.require_admin_login
    def GET(self):
        path = web.ctx.path
        base_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
        spec_path = os.path.join(base_dir, "openapi.json")

        if path.endswith("/api/openapi.json"):
            if not os.path.exists(spec_path):
                web.ctx.status = "404 Not Found"
                return "OpenAPI spec not found."
            web.header("Content-Type", "application/json; charset=utf-8")
            with open(spec_path, "r", encoding="utf-8") as fh:
                return fh.read()

        if path.endswith("/api/docs"):
            web.header("Content-Type", "text/html; charset=utf-8")
            base = web.ctx.homepath or ""
            css_url = f"{base}/static/vendor/swagger-ui/swagger-ui.css"
            js_url = f"{base}/static/vendor/swagger-ui/swagger-ui-bundle.js"
            spec_url = f"{base}/api/openapi.json"
            html = """<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <title>API Docs</title>
    <link rel="stylesheet" href="__CSS_URL__"/>
    <style>
      body { margin: 0; background: #f6f7f9; }
      #swagger-ui { max-width: 1200px; margin: 0 auto; }
    </style>
  </head>
  <body>
    <div id="swagger-ui"></div>
    <script src="__JS_URL__"></script>
    <script>
      window.onload = function() {
        SwaggerUIBundle({
          url: '__SPEC_URL__',
          dom_id: '#swagger-ui',
          presets: [SwaggerUIBundle.presets.apis],
          layout: "BaseLayout"
        });
      };
    </script>
  </body>
</html>"""
            return (
                html.replace("__CSS_URL__", css_url)
                    .replace("__JS_URL__", js_url)
                    .replace("__SPEC_URL__", spec_url)
            )

        web.ctx.status = "404 Not Found"
        return "Not Found"

class API_Auth:
    @decorators.json_response
    def POST(self):
        path = web.ctx.path
        session = web.config._session
        if path == '/api/login':
            (success, payload) = _parse_api_payload()
            if not success:
                return (False, payload)

            username = web.safestr(payload.get('username', '').strip()).lower()
            password = str(payload.get('password', '').strip())

            if not iredutils.is_email(username):
                return (False, 'INVALID_USERNAME')

            if not password:
                return (False, 'EMPTY_PASSWORD')

            qr = auth.login_auth(username, password)
            if not qr[0]:
                session['failed_times'] += 1
                logger.warning(f"Login failed via API: client_address={web.ctx.ip}, username={username}")
                log_activity(msg="Login failed via API", admin=username, event='login', loglevel='error')
                return False, qr[1]
            
            if session.get('pending_2fa'):
                return {
                    '_success': True,
                    '_msg': '2FA_REQUIRED',
                    '_data': {
                        'username': session['username'],
                        'pending_2fa': True,
                        'session_id': session['session_id'],
                    }
                }
            session['logged'] = True
            return {
                '_success': True,
                '_msg': 'LOGIN_SUCCESS',
                '_data': {
                    'username': session['username'],
                    '2FA_required': session.get('2FA_required', None),
                    'pending_2fa': session.get('pending_2fa', False),
                    'session_id': session['session_id'],
                    'is_global_admin': session['is_global_admin'],
                    'is_user_admin': session['is_user_admin'],
                    'is_mail_admin': session['is_mail_admin'],
                    'is_domain_admin': session['is_domain_admin'],
                    'domain_admins': session['domain_admins'],
                }
            }
        elif path == '/api/2fa/verify':
            (success, payload) = _parse_api_payload()
            if not success:
                return False, payload

            totp_code = str(payload.get('totp_code', '')).strip()
            username = session.get('username')
            enc_secret = session.get('2FA_required')

            if not enc_secret or not username:
                return False, 'NO_PENDING_2FA_SESSION'

            if not totp_code:
                return False, 'EMPTY_TOTP_CODE'

            from libs.m_crudlib.security import verify_2fa_token
            if verify_2fa_token(enc_secret, totp_code, username):
                session['logged'] = True
                #session.pop('2FA_required', None)# Netejem per seguretat
                session.pop('pending_2fa', None)
                return {
                    '_success': True,
                    '_msg': '2FA_VERIFIED_SUCCESS',
                    '_data': {'username': username}
                }
            else:
                return False, 'INVALID_2FA_TOKEN'
        elif path == '/api/2fa/setup':
            if not session.get('logged'):
                return False, 'LOGIN_REQUIRED'
            from libs.m_crudlib.security import generate_2fa_setup, activate_2fa
            username = session.get('username')
            # 1️⃣ Generar nou secret i QR
            setup = generate_2fa_setup(username)
            new_secret = setup["secret"]
            # 2️⃣ Desa el secret xifrat al backend
            ok = activate_2fa(username, new_secret, backend=settings.backend)
            if ok:
                return {
                    '_success': True,
                    '_msg': '2FA_SETUP_SUCCESS',
                    '_data': setup
                }
            else:
                return False, 'FAILED_TO_ACTIVATE_2FA'
        elif path == '/api/2fa/show':
            # (success, payload) = _parse_api_payload()
            # if not success:
            #     return False, payload

            # totp_code = str(payload.get('totp_code', '')).strip()
            username = session.get('username')
            enc_secret = session.get('2FA_required')
            
            if not session.get('logged'):
                return False, 'LOGIN_REQUIRED'
            if not enc_secret:
                return False, '2FA_NO_CONFIGURED'

            from libs.m_crudlib.security import show_2fa_secret
            data = show_2fa_secret(
                enc_secret,
                session.get('username')
            )

            return {
                '_success': True,
                '_msg': '2FA_TOKEN_SUCCESS',
                '_data': data
            }

    @decorators.json_response
    def GET(self):
        path = web.ctx.path
        session = web.config._session
        if path == '/api/logout':
            try:
                session.kill()
                return True, 'LOGGED_OUT'
            except Exception as e:
                return False, str(e)
