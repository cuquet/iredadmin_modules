# api/core/urls.py
from libs.regxes import email as e, domain as d

urls = [
    '/api/openapi.json', 'api.core.controller.API_OpenAPI',
    '/api/docs', 'api.core.controller.API_OpenAPI',
    '/api/session-info', 'api.core.controller.Api_SessionInfo',
    '/api/login', 'api.core.controller.API_Auth',
    '/api/logout', 'api.core.controller.API_Auth',
    '/api/2fa/setup', 'api.core.controller.API_Auth',
    '/api/2fa/verify', 'api.core.controller.API_Auth',
    '/api/2fa/show', 'api.core.controller.API_Auth',
]
