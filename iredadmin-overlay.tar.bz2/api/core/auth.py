# api/core/auth.py
import web
import settings
from libs import iredutils, iredpwd
from libs.l10n import TIMEZONES

if settings.backend == "ldap":
    import ldap
    from libs.m_system.mixins import LDAPHelper
elif settings.backend in ["mysql", "pgsql"]:
    from libs.m_system.mixins import SQLHelper

from libs.m_system import utils
from libs.m_crudlib import domain

session = web.config.get('_session')
mapper = utils.KeyMap()

def login_auth(username, password):
    """
    Realitza l'inici de sessió complet.

    :param username: adreça de correu electrònic completa.
    :param password: contrasenya del compte.
    """

    if settings.backend == "ldap":
        def verify_bind_dn_pw(dn, password):
            dn = web.safestr(dn.strip())
            try:
                qr = conn.search_s(dn,
                                ldap.SCOPE_BASE,
                                '(objectClass=*)',
                                ['userPassword'])
                if not qr: # No such account.
                    return (False, 'INVALID_CREDENTIALS')

                _ldif = iredutils.bytes2str(qr[0][1])
                pw = _ldif.get('userPassword', [''])[0]
                if not iredpwd.verify_password_hash(pw, password):
                    return (False, 'INVALID_CREDENTIALS')
                return (True, )
            except Exception as e:
                return (False, repr(e))
                
        _wrap = LDAPHelper()
        ldap_lib = _wrap
        conn = ldap_lib.conn
        
        dn = ldap_lib.rdn_value_to_user_dn(username)
        search_filter = '(&(accountStatus=active)(|' + \
                        '(&(objectClass=mailUser)(enabledService=mail))' + \
                        '(&(objectClass=mailUser)(|(enabledService=domainadmin)(domainGlobalAdmin=yes)))' + \
                        '))'
        qr = verify_bind_dn_pw(dn, password)
        if not qr[0]:
            dn = ldap_lib.rdn_value_to_admin_dn(username)
            search_filter = '(&(accountStatus=active)(objectClass=mailAdmin))'
            qr = verify_bind_dn_pw(dn, password)
            if not qr[0]:
                return qr

        qr = ldap_lib.profile_get_by_dn(dn, query_filter=search_filter)
        if not qr[0]:
            return (False, 'INVALID_CREDENTIALS')
        profile=qr[1]['ldif']
    
        disabled_services = profile.get('disabledService', [])
        enabled_services = profile.get('enabledService', [])
        
    elif settings.backend in ["mysql", "pgsql"]:
        def verify_bind_dn_pw(table, password):
            qr = conn.select(
                table,
                vars={'username': username},
                where="username=$username AND active=1",
                what='password',
                limit=1,
            )
            if not qr:
                # Account not found.
                # Do NOT return msg like 'Account does not ***EXIST***', crackers
                # can use it to verify valid accounts.
                return (False, 'INVALID_CREDENTIALS')
            pw = str(qr[0].password)
            if not iredpwd.verify_password_hash(pw, password):
                return (False, 'INVALID_CREDENTIALS')
            return (True, table)
        
        sql_helper = SQLHelper()
        sql_lib = sql_helper 
        conn = sql_lib.conn 
        
        qr = verify_bind_dn_pw('mailbox', password)
        if not qr[0]:
            qr = verify_bind_dn_pw('admin', password)
            if not qr[0]:
                return qr
        attr = 'password, language, isadmin, isglobaladmin, settings'
        qr = sql_lib._get_profile(table=qr[1], key_val=username, key_col="username", attributes=attr)
        if not qr[0]:
            return (False, 'INVALID_CREDENTIALS')
        profile=qr[1]['ldif']
        utils.profile_define_adminType(profile)
    
    profile = {**mapper.remap_dict(profile, reverse=True)}
    
    session['username'] = username
    account_settings = profile.get('accountSetting', {})
    
    if (not profile['adminType']) and 'mail' in enabled_services:
        session['is_mail_user'] = True
        session['is_domain_admin'] = False
        session['domain_admins'] = [] 
    elif profile['adminType'] == 'globaladmin':
        session['is_global_admin'] = True
        session['is_domain_admin'] = False
        session['domain_admins'] = []
        
        if not iredutils.is_allowed_global_admin_login_ip(client_ip=web.ctx.ip):
            session.kill()
            raise web.seeother('/login?msg=NOT_ALLOWED_IP')
    elif profile['adminType'] in ['mailadmin', 'domainadmin'] and 'domainadmin' in enabled_services and 'domainadmin' not in disabled_services:
        session['is_domain_admin'] = True
        
        if profile['adminType'] == 'mailadmin':
            session['is_mail_admin'] = True
        else: #elif profile['adminType'] == 'domainadmin':
            session['is_user_admin'] = True

        session['grant_admin'] = "grant_admin" in enabled_services
        session['create_new_domains'] = "create_new_domains" in account_settings
        for k in ['disable_viewing_mail_log', 'disable_managing_quarantined_mails']:
            session[k] = (account_settings.get(k) == 'yes')
        
        domain_basic = domain.DomainBasic()
        success, managed_domains = domain_basic.get_managed_domains(names_only=True, admin=username)
        session['domain_admins'] = managed_domains if success else []     

    # Language
    session['lang'] = profile.get('preferredLanguage', settings.default_language)

    # per-account time zone
    tz_name = account_settings.get('timezone', '')
    if tz_name in TIMEZONES:
        session['timezone'] = TIMEZONES[tz_name]

    # INICI ---------- 2FA check ----------
    from libs.m_crudlib.security import user_has_totp
    qr = user_has_totp(username, settings.backend)
    if qr[0]:
        session['2FA_required'] = qr[1]
        session['pending_2fa'] = True
    # FINAL ---------- 2FA check ----------
    return (True, session['lang'])
