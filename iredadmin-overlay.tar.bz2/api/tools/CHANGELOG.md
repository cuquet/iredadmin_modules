# 📜 Changelog – iRedAPI CLI

All notable changes to this project will be documented in this file.

---
## 🔖 v0.1 – 🔖 v0.1: Import version v0.1 of iRedAPI CLI
- Basic CLI with login support
- Token handling and cookie storage

## 🔖 v0.2 – 🔖 v0.2: Import version v0.2 of iRedAPI CLI
- Automatic token and cookie saving
- Better login error messages

## 🔖 v0.3 – 🔖 v0.3: Import version v0.3 of iRedAPI CLI
- Can send GET requests to API endpoints
- Handles session token automatically

## 🔖 v0.4 – 🔖 v0.4: Import version v0.4 of iRedAPI CLI
- `call` command supports all HTTP verbs
- JSON body via `-d` argument

## 🔖 v0.5 – 🔖 v0.5: Import version v0.5 of iRedAPI CLI
- Centralized error and response handling
- Standardized status icons in console

## 🔖 v0.6 – 🔖 v0.6: Import version v0.6 of iRedAPI CLI
- Added `--raw` and `IREDAPI_RAW`
- Initial support for `.env` workflows

## 🔖 v0.7 – 🔖 v0.6: Import version v0.6 of iRedAPI CLI
- Support for `--insecure` and `IREDAPI_INSECURE`
- Improved argument parsing

## 🔖 v0.8 – 🔖 v0.8: Import version v0.8 of iRedAPI CLI
- Integrated colorized JSON using `rich`
- Added spinners for long-running actions

## 🔖 v0.9 – 🔖 v0.9: Import version v0.9 of iRedAPI CLI
- Added `token` and `session` subcommands
- Improved authentication persistence

## 🔖 v0.9.1 – 🔖 v0.9.1: Import version v0.9.1 of iRedAPI CLI
- Fixed typos and logging issues
- Compatibility with token-less requests

## 🔖 v0.10 – 🔖 v0.10: Import version v0.10 of iRedAPI CLI
- Enhanced session handling
- Improved error messages and fallback behavior

## 🔖 v0.11 – 🔖 v0.11: Import version v0.11 of iRedAPI CLI
- Completed CLI with login, API calls, logout, token/session inspection
- Support for `.env` and environment variables
- Improved JSON output with Unicode and color
- Final refinements and cleanup

## 🔖 v0.12 – Reorganized function print_json()

## 🔖 v0.13 – 🔖 v0.13: hide sensitive data

## 🔖 v0.13.1 – 🔖 v0.13: correct hide sensitive data. Some changes on spinner

## 🔖 v0.14 – 🔖 v0.14:  create JsonFormatter class. Update pending Logger msg

## 🔖 v0.14.1 Updated pending Logger.debug. Add some README examples

## 🔖 v.0.15 🔖 v0.15: Enhance session management and logging:
- Introduced log_debug function for improved logging.
- Updated JsonFormatter to handle messages and errors more effectively.
- Enhanced SessionManager with better cookie and token management.
- Improved error handling and user feedback during login and session operations.

## 🔖 🔖-v0.15.1 

🔖 v0.15.1: Refactor session management:
- Replace Logger calls with log_debug for improved logging consistency
- Add cookie_exists and is_session_valid methods

## 🔖 v0.15.1 🔖 v0.15.1: Refactor session management:
- Replace Logger calls with log_debug for improved logging consistency
- Add cookie_exists and is_session_valid methods

## 🔖 v0.16 🔖 v0.16 : Improve session handling with retry logic and enhance error logging in cmd_call

## 🔖 v0.17 🔖 v0.17  Enhance session management and logging:
- Refactor session handling methods to accept custom paths for token and cookie files.
- Improve error handling and logging consistency in session operations.
- Update README to reflect changes in logout functionality and session management.

## 🔖 v0.17.1 

Refactor error logging to use log_error function for consistency and clarity

## 🔖 v0.18 

Refactor session expiration check and improve JSON error handling in SessionManager

## 🔖 v0.19 

🔖 v0.19: Refactor request handling in SessionManager: consolidate header and data preparation into get_request_kwargs method

## 🔖 v0.19.1 

🔖 v0.19.1: Clarify session expiration detection logic in SessionManager: update comments and restrict status code check to 401 only
## 🔖 v0.19.2 

🔖 v0.19.2: Refactor JsonFormatter to streamline result processing and enhance key handling

## 🔖 v0.20 

🔖 v0.20: Update request handling in SessionManager to include new headers after login

## 🔖 v0.20.1 

🔖 v0.20.1: Implement 2FA setup and verification commands in iredapi_manager.py


