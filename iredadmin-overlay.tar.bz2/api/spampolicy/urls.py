from libs.regxes import email as e, domain as d

urls = [
    '/api/spampolicy/(global)', 'api.spampolicy.controller.API_SpamPolicy',
    '/api/spampolicy/(domain)/(%s)' % d, 'api.spampolicy.controller.API_SpamPolicy',
    '/api/spampolicy/(user)/(%s)' % e, 'api.spampolicy.controller.API_SpamPolicy',
    '/api/spampolicy/effective/(.+)', 'api.spampolicy.controller.API_SpamPolicyEffective',
]
