import web

from libs.m_amavisd import spampolicy as lib_spampolicy

from libs.logger import logger, log_activity

from libs.m_crudlib import decorators
from controllers.m_amavisd.utils import (
    _spampolicy_api_payload_to_db, 
    _spampolicy_api_db_to_payload
)
from api.utils import (
    _check_privilege, 
    _parse_api_payload
)

class API_SpamPolicy():
    @decorators.require_preference_access('spampolicy')
    @decorators.require_login
    @decorators.json_response
    def GET(self, account_type, account=None):
        ok, result = _check_privilege(account_type, account)
        if not ok:
            return False, result

        ok, records, *rest = lib_spampolicy.SpamPolicy(account=result['account']).get_spam_policy()
        if not ok:
            return (ok, records, *rest)
        if isinstance(records, str):
            if records == 'NO_SUCH_ACCOUNT':
                return (False, 'NO_SUCH_SPAMPOLICY')
            return (False, records)
        return (True, _spampolicy_api_db_to_payload(records), *rest)

    @decorators.require_preference_access('spampolicy')
    @decorators.require_login
    @decorators.json_response
    def PUT(self, account_type, account=None):
        ok, result = _check_privilege(account_type, account)
        if not ok:
            return False, result
        ok, payload = _parse_api_payload()
        if not ok:
            return False, payload
        
        db_payload = _spampolicy_api_payload_to_db(payload)
        ok, db_payload, *rest = lib_spampolicy.SpamPolicy(account=result['account']).update_spam_policy(db_payload)
        if not ok:
            return (ok, db_payload, *rest)
        return (True, _spampolicy_api_db_to_payload(db_payload), *rest)
        
    @decorators.require_preference_access('spampolicy')
    @decorators.require_login
    @decorators.json_response
    def POST(self, account_type, account=None):
        ok, result = _check_privilege(account_type, account)
        if not ok:
            return False, result

        ok, payload = _parse_api_payload()
        if not ok:
            return False, payload

        db_payload = _spampolicy_api_payload_to_db(payload)
        ok, db_payload, *rest =  lib_spampolicy.SpamPolicy(account=result['account']).create_spam_policy(db_payload)
        if not ok :
            return (ok, db_payload, *rest)
        return (ok, _spampolicy_api_db_to_payload(db_payload), *rest)


    @decorators.require_preference_access('spampolicy')
    @decorators.require_login
    @decorators.json_response
    def DELETE(self, account_type, account=None):
        ok, result = _check_privilege(account_type, account)
        if not ok:
            return False, result
        
        return lib_spampolicy.SpamPolicy(account=result['account']).delete_spam_policy()

class API_SpamPolicyEffective:
    @decorators.require_login
    @decorators.json_response
    def GET(self, account):
        account = web.safestr(account).lower() or None
        if '@' not in account:
            account = f"@{account}"

        ok, records, *rest = lib_spampolicy.SpamPolicy(account).get_policy_priority()
        if not ok:
            return (ok, records, *rest) 
        return (True, _spampolicy_api_db_to_payload(records), *rest)
