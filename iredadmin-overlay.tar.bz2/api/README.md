# iRedMail API _"personal"_ 
És una interfície web minimalista construïda amb web.py, pensada per exposar funcionalitats de sistemes de correu com iRedMail, iRedAPD i Amavis New a través d’una API RESTful lleugera i extensible.
Aquest projecte permet consultar i modificar configuracions relacionades amb:
- Llistes blanca i negra (whitelist/blacklist)
- Greylisting
- Throttling
- Polítiques d’enviament i recepció
## 🔗 Formats de petició
Les rutes accepten peticions tant en format `application/x-www-form-urlencoded` com en `application/json`, facilitant la integració amb scripts, sistemes de monitoratge o interfícies web.
## ⚙️ Requisits
- [__iRedmail__ ](https://www.iredmail.org/download.html) instal·lat. 
    - Python ≥ 3.6
    - web.py
    - ...
- disposar de llibreries per gestionar iRedAPD i Amavis 😉
la instal·ació donarà accés als fitxers o bases de dades gestionades per iRedMail/iRedAPD/Amavis. però cal fer _l'integració_.
### ✅ Integració a iRedAdmin
Al fitxer principal de rutes (p. ex. iredadmin.py) cal afegir:

```python
from api import urls as api_urls

app = web.application([
    # ... altres rutes
] + api_urls, globals())
```
## 🗃️ Estructura
```bash
api/
├── core/
│   ├── auth.py              🔒 Funcions d’autenticació: credencials i gestionar 2FA (Google Auth, etc.)
│   ├── controller.py        🧠 Funcions de sessió:
│   │                            - API_Auth: gestiona login (POST) i logout (GET)
│   │                            - API_SessionInfo: retorna informació de la sessió actual
│   ├── decorators.py        🧩 Decoradors com login_required
│   ├── urls.py              🔗 Rutes específiques del recurs `core`, per exemple:
│   │                            - POST /api/login
│   │                            - GET  /api/logout
│   │                            - GET  /api/session
│   │                            - POST /api/2fa/setup
│   │                            - POST /api/2fa/verify
│   └── __init__.py
├── crud/
│   ├── urls.py
│   ├── controller.py
│   └── __init__.py
├── maillist/
│   ├── urls.py
│   ├── controller.py
│   └── __init__.py
├── greylist/
│   ├── urls.py
│   ├── controller.py
│   └── __init__.py
├── spampolicy/
│   ├── urls.py
│   ├── controller.py
│   └── __init__.py
├── throttle/
│   ├── urls.py
│   ├── controller.py
│   └── __init__.py
├── wblist/
│   ├── urls.py
│   ├── controller.py
│   └── __init__.py
├── tools/
│   ├── CHANGELOG.md
│   ├── iredapi_manager.py   🚀 per gestionar la API desde la línia de comandes CLI
│   ├── LICENSE
│   ├── README.md
│   └── __init__.py
├── urls.py                  🔗 Punt central on s’ajunten totes les rutes
├── utils.py                 🔧 Funcions útils:
│                                - _parse_api_payload()
│                                - _check_privilege()
│                                - API <-> DB normalització de payloads()
│                                - normalització de ENUM()
│                                - ...
├── LICENSE
├── README.md
├── openapi.json             📘 Especificació OpenAPI
└── __init__.py
```

# 📘 OpenAPI / Swagger
- `GET /api/openapi.json` retorna l’especificació OpenAPI.
- `GET /api/docs` mostra Swagger UI (usa el fitxer `openapi.json`).
- Assets locals: `/static/vendor/swagger-ui/` (sense CDN).

# 🔌 Rutes API (CRUD)

## Domains
Rutes principals:
- `GET /api/domains`
- `GET /api/domain/<domain>`
- `GET /api/domain/<domain>/keep_mailbox_days/<days>`
- `POST /api/domain/<domain>` (creació)
- `PUT /api/domain/<domain>`
- `DELETE /api/domain/<domain>`
- `DELETE /api/domain/<domain>/keep_mailbox_days/<days>`

Paràmetres suportats a `PUT /api/domain/<domain>` (mapatge API → backend):
- `name` → `cn`
- `accountStatus` → `accountStatus`
- `language` → `defaultLanguage`
- `recipientBcc` → `domainRecipientBccAddress`
- `senderBcc` → `domainSenderBccAddress`
- `transport` → `mtaTransport`
- `backupmx` → `domainBackupMX` (`yes/true/1/active` → `yes`, la resta → `""`)
- `relay_without_verify_local_recipient` → `relay_without_verify_local_recipient`
- `quota` → `domainQuota`
- `defaultQuota` → `defaultQuota`
- `maxUserQuota` → `maxUserQuota`
- `numberOfUsers` → `numberOfUsers`
- `numberOfAliases` → `numberOfAliases`
- `numberOfLists` → `numberOfLists`
- `minPasswordLength` → `min_passwd_length`
- `maxPasswordLength` → `max_passwd_length`

Notes:
- Les quotes (`quota`, `defaultQuota`, `maxUserQuota`) s’interpreten en MB si no s’indica unitat.

## Users
Rutes principals:
- `GET /api/user/<mail>`
- `GET /api/users/<domain>`
- `POST /api/user/<mail>` (creació o accions)
- `POST /api/user/<mail>/change_email/<new_mail>`
- `POST /api/verify_password/user/<mail>`
- `PUT /api/user/<mail>`
- `DELETE /api/user/<mail>`
- `DELETE /api/user/<mail>/keep_mailbox_days/<days>`

Paràmetres suportats a `POST /api/user/<mail>`:
- `name` → `cn`
- `gn` → `givenName`
- `sn` → `sn`
- `employeeid` → `employeeNumber`
- `language` → `preferredLanguage` (i també `defaultLanguage` per compatibilitat LDAP)
- `transport` → `mtaTransport`
- `quota` → `mailQuota` (unitat per defecte `MB`)
- `password` → `newpw`/`confirmpw`
- `password_hash` (alternativa a `password`)
- `verify_password`: si la ruta és `/api/verify_password/user/<mail>`, cal enviar `password=<plain>`

Paràmetres suportats a `PUT /api/user/<mail>` (mapatge API → backend):
- `name` → `cn`
- `gn` → `givenName`
- `sn` → `sn`
- `employeeid` → `employeeNumber`
- `language` → `preferredLanguage`
- `transport` → `mtaTransport`
- `accountStatus` → `accountStatus` (`active/disabled` → `on/off`)
- `isGlobalAdmin` → `domainGlobalAdmin` (`yes/true/1/active` → `active`, la resta → `disabled`)
- `quota` → `mailQuota` (unitat per defecte `MB`)
- `password` → `newpw`/`confirmpw`
- `password_hash` (alternativa a `password`)
- `profile_type` opcional: `general`, `password`, `forwarding`, `aliases`, `services`
- `forwarding`: `forwarding`, `savecopy`, `mailForwardingAddress` (o `catchallAddress`)
- `aliases`: `aliases`/`alias`, `shadowAddress` (o `extra_address`)
- `services`: `enabledService`, `disabledService` (també `services`, `enabledServices`, `disabledServices`)

Notes:
- `password` i `password_hash` són incompatibles.
- `quota`/`mailQuota` s’interpreten en MB si no s’indica unitat.
- Si el `PUT` inclou camps de més d’un perfil especial (`forwarding`, `aliases`, `services`) i no es passa `profile_type`, retorna `AMBIGUOUS_PROFILE_TYPE`.
- A SQL, `services` admet: `forward`, `shadowaddress`, `domainadmin`, `domainGlobalAdmin`.

## Mailing Lists (ML)
Rutes principals:
- `GET /api/mls/<domain>`
- `GET /api/ml/<mail>`
- `POST /api/ml/<mail>`
- `PUT /api/ml/<mail>`
- `DELETE /api/ml/<mail>`

Paràmetres suportats a `POST /api/ml/<mail>`:
- `name` (o `cn`) → `name`
- `accessPolicy` (p. ex. `membersonly`, `moderatorsonly`)
- `accountStatus` (`active`/`disabled`)
- `is_newsletter` (`yes`/`no`)
- `newsletter_description` (text curt)
- `close_list`
- `only_moderator_can_post`
- `only_subscriber_can_post`
- `disable_subscription`
- `disable_subscription_confirm`
- `disable_digest_subscription`
- `disable_digest_text`
- `disable_nomail_subscription`
- `moderated`
- `moderate_non_subscriber_post`
- `disable_retrieving_old_posts`
- `only_subscriber_can_get_old_posts`
- `disable_retrieving_subscribers`
- `disable_send_copy_to_sender`
- `notify_owner_when_sub_unsub`
- `notify_sender_when_moderated`
- `disable_archive`
- `moderate_subscription`
- `extra_addresses` (coma separada)
- `subscription_moderators` (coma separada)
- `owner` (coma separada)
- `moderators` (coma separada)
- `max_message_size` (bytes)
- `subject_prefix`
- `custom_headers` (separat per `\n`)
- `remove_headers` (coma separada)
- `footer_text`
- `footer_html`

Paràmetres suportats a `PUT /api/ml/<mail>`:
- `profile_type` opcional: `general`, `members`, `aliases`, `owners`, `newsletter`
- `general`: `name`, `accessPolicy`, `accountStatus`
- `members`: `subscriber`, `addSubscriber`, `removeSubscriber`
- `aliases`: `aliases`, `addAlias`, `removeAlias`
- `owners`: `owner`/`owners`, `addOwner`, `removeOwner`, `moderator`/`moderators`, `addModerator`, `removeModerator`
- `newsletter`: `is_newsletter`, `description`

Notes:
- Si `profile_type` no es passa, s’infereix en funció dels paràmetres.

## Greylisting
Rutes principals:
- `GET /api/greylisting/global`
- `GET /api/greylisting/<domain>`
- `GET /api/greylisting/<mail>`
- `POST /api/greylisting/global` (`status=enable|disable|inherit`)
- `POST /api/greylisting/<domain>` (`status=enable|disable|inherit`)
- `POST /api/greylisting/<mail>` (`status=enable|disable|inherit`)
- `GET /api/greylisting/global/whitelists`
- `POST /api/greylisting/global/whitelists`
- `GET /api/greylisting/<domain>/whitelists`
- `POST /api/greylisting/<domain>/whitelists`
- `GET /api/greylisting/<mail>/whitelists`
- `POST /api/greylisting/<mail>/whitelists`
- `GET /api/greylisting/whitelist_spf_domains`
- `POST /api/greylisting/whitelist_spf_domains`

Paràmetres suportats:
- `/greylisting/global/whitelists`:
  - `senders`, `addSenders`, `removeSenders`
- `/greylisting/whitelist_spf_domains`:
  - `domains`, `addDomains`, `removeDomains`

Notes importants:
- **Alineat amb la UI oficial**: per a dominis/usuaris, `/greylisting/<x>/whitelists` treballa amb la llista SPF (taula amb comentaris) i accepta **aliases** `senders/addSenders/removeSenders` → `domains/addDomains/removeDomains`.
- Si envies **comentaris** (`# ...`), es conserven en la llista SPF.
- El comportament global (`/greylisting/global/whitelists`) es manté com a llista de dominis per SPF/MX (sense comentaris).

## Exemples CLI (`iredapi_manager.py`)
Actualitzar un domini:
```bash
./iredapi_manager.py call -e '/domain/melindro.org' -m PUT \
  -d 'name=Melindro&language=ca_ES&quota=10240&numberOfUsers=200'
```

Crear domini:
```bash
./iredapi_manager.py call -e '/domain/melindro.org' -m POST \
  -d 'name=Melindro&language=ca_ES&quota=10240&numberOfUsers=200'
```

Canviar el nom i idioma d’un usuari:
```bash
./iredapi_manager.py call -e '/user/baldufa8@melindro.org' -m PUT \
  -d 'name=Michael Jordon&language=es_CA'
```

Canviar password d’un usuari:
```bash
./iredapi_manager.py call -e '/user/baldufa8@melindro.org' -m PUT \
  -d 'password=u0tBF82cIV@vi8Gme'
```

Canviar quota i estat d’un usuari:
```bash
./iredapi_manager.py call -e '/user/baldufa8@melindro.org' -m PUT \
  -d 'quota=1024&accountStatus=active'
```

Crear usuari amb quota i idioma:
```bash
./iredapi_manager.py call -e '/user/baldufa8@melindro.org' -m POST \
  -d 'password=Es1l@2cl@u&language=es_CA&quota=2048'
```

Eliminar usuari:
```bash
./iredapi_manager.py call -e '/user/baldufa8@melindro.org' -m DELETE
```

Verificar password d’un usuari:
```bash
./iredapi_manager.py call -e '/verify_password/user/baldufa8@melindro.org' -m POST \
  -d 'password=u0tBF82cIV@vi8Gme'
```

Canviar email d’un usuari:
```bash
./iredapi_manager.py call -e '/user/baldufa8@melindro.org/change_email/baldufa18@melindro.org' -m POST
```

### MailList Suscribable

Crear una mailing list:
```bash
./iredapi_manager.py call -e '/ml/llista@melindro.org' -m POST \
  -d 'name=Llista General&accessPolicy=membersonly'
```

Afegir subscriptors a una mailing list:
```bash
./iredapi_manager.py call -e '/ml/llista@melindro.org' -m PUT \
  -d 'profile_type=members&addSubscriber=user1@melindro.org,user2@melindro.org'
```

Afegir alias a una mailing list:
```bash
./iredapi_manager.py call -e '/ml/llista@melindro.org' -m PUT \
  -d 'profile_type=aliases&addAlias=alias1@melindro.org,alias2@melindro.org'
```

### Greylisting
Afegir un domini global (SPF/MX):
```bash
./iredapi_manager.py call -e '/greylisting/global/whitelists' -m POST \
  -d 'addSenders=example.com'
```

Afegir un sender amb comentari a un domini:
```bash
./iredapi_manager.py call -e '/greylisting/melindro.org/whitelists' -m POST \
  -d 'addSenders=192.168.2.20 # Office IP'
```

Afegir SPF domains globals:
```bash
./iredapi_manager.py call -e '/greylisting/whitelist_spf_domains' -m POST \
  -d 'addDomains=example.com,example.org'
```



## Admins (Domain Admin standalone)
Rutes principals (només global admin):
- `GET /api/admin/<mail>`
- `POST /api/admin/<mail>`
- `PUT /api/admin/<mail>`
- `DELETE /api/admin/<mail>`
- `POST /api/verify_password/admin/<mail>`

Paràmetres suportats a `POST /api/admin/<mail>`:
- `name` → `cn`
- `gn` → `givenName`
- `sn` → `sn`
- `employeeid` → `employeeNumber`
- `language` → `defaultLanguage`
- `password` → `newpw`/`confirmpw`

Paràmetres suportats a `PUT /api/admin/<mail>`:
- `name` → `cn`
- `gn` → `givenName`
- `sn` → `sn`
- `employeeid` → `employeeNumber`
- `language` → `defaultLanguage`
- `accountStatus` → `accountStatus`
- `isGlobalAdmin` → `domainGlobalAdmin`
- `password` → `newpw`/`confirmpw`

Notes:
- `password_hash` no està suportat per admins.

Exemples CLI (admins):
```bash
./iredapi_manager.py call -e '/admin/admin1@external.tld' -m POST \
  -d 'name=Admin One&password=S3cureP@ss&language=en_US'
```

```bash
./iredapi_manager.py call -e '/admin/admin1@external.tld' -m PUT \
  -d 'accountStatus=active&language=ca_ES'
```

```bash
./iredapi_manager.py call -e '/verify_password/admin/admin1@external.tld' -m POST \
  -d 'password=S3cureP@ss'
```

## Domain Admins (assignació de dominis)
Rutes principals (només global admin):
- `PUT /api/domain/admins/<domain>`

Paràmetres suportats:
- `addAdmin` (coma separada)
- `removeAdmin` (coma separada)
- `removeAllAdmins` (sense valor)

Exemples CLI (assignar o treure dominis d’un admin):
```bash
./iredapi_manager.py call -e '/domain/admins/melindro.org' -m PUT \
  -d 'addAdmin=admin1@melindro.org,admin2@melindro.org'
```

```bash
./iredapi_manager.py call -e '/domain/admins/melindro.org' -m PUT \
  -d 'removeAdmin=admin2@melindro.org'
```

```bash
./iredapi_manager.py call -e '/domain/admins/melindro.org' -m PUT \
  -d 'removeAllAdmins='
```

## Exemples 2FA (activat)
### Login
```bash
./iredapi_manager.py login 
 ℹ️  [INFO]  🐛 [DEBUG] mode actiu
Usuari 👤 : baldufa@melindro.org
Contrasenya 🔑 : 
 🐛 [DEBUG] [ensure_credentials] 👤 Usuari: baldufa@melindro.org, 🔑 Contrasenya: ********
🚗 Cridant a l'API... | 🐛 [DEBUG] [load_cookie] Fitxer de cookies inexistent.
 🐛 [DEBUG] [cmd_call] 🌐 Iniciant crida url=https://localhost/iredadmin/api/login, method=POST, headers={'Accept': 'application/json', 'Content-Type': 'application/json'}, internal=True...
 🐛 [DEBUG] [cmd_call] 🔁 Intent 1/2
 🐛 [DEBUG] [cmd_call] 🌐 Resposta HTTP OK: 200 OK
 🐛 [DEBUG] [cmd_call] 🌐 Resposta: 200 OK
🏁 Fet!
 🐛 [DEBUG] [cmd_login] 🌐 Resposta: <Response [200]>
 ℹ️  [INFO] 🔐 Seguretat: Codi 2FA requerit.
Introdueix el codi OTP 🔑 : 182408
🏁 Verificat!
 🐛 [DEBUG] [save_cookie] 🍪 Cookies carregades o guardades
 🐛 [DEBUG] [save_cookie] └─ iRedAdmin-LDAP = 2d7ad88b271cd6a1e5a08579ea90ef844a284d8f (domini: localhost.local)
 ✅ Login correcte (2FA_VERIFIED_SUCCESS). Sessió guardada.
```
### 2FA Check
```bash
./iredapi_manager.py 2fa-check
 ℹ️  [INFO]  🐛 [DEBUG] mode actiu
 🐛 [DEBUG] [load_cookie] 🍪 Cookies carregades o guardades
 🐛 [DEBUG] [load_cookie] └─ iRedAdmin-LDAP = 2d7ad88b271cd6a1e5a08579ea90ef844a284d8f (domini: localhost.local)
 🐛 [DEBUG] [cmd_call] 🌐 Iniciant crida url=https://localhost/iredadmin/api/2fa/show, method=POST, headers={'Accept': 'application/json'}, internal=True...
 🐛 [DEBUG] [cmd_call] 🔁 Intent 1/2
 🐛 [DEBUG] [cmd_call] 🌐 Resposta HTTP OK: 200 OK
 🐛 [DEBUG] [cmd_call] 🌐 Resposta: 200 OK
 ✅ 2FA actiu
Vols mostrar el secret? (y/N): y

🔑 Secret: KRTXEGJS3MGUVJ5LXPQUXXKSW22AIKCW
🔗 URI: otpauth://totp/iRedMail:baldufa%40melindro.org?secret=KRTXEGJS3MGUVJ5LXPQUXXKSW22AIKCW&issuer=iRedMail

█████████████████████████████████████████████████
█████████████████████████████████████████████████
████ ▄▄▄▄▄ █ ▄▄  ▄▀▄▄▀▄ ▄▀ ▀██▄█▄ █▀▄█ ▄▄▄▄▄ ████
████ █   █ █▀  ▀█▀▄  █  ▀  █▀▀█▀▀▀  ██ █   █ ████
████ █▄▄▄█ ██▀█▄▄ ▄▀▀▀  ▀███▄▀█▄ ▀  ▀█ █▄▄▄█ ████
████▄▄▄▄▄▄▄█ ▀▄▀ █ █▄▀▄▀ █▄█▄█ █ ▀ █▄█▄▄▄▄▄▄▄████
████ ▀▄ ▀   █▄█ █ ▄▀▀▄  ▄▀█▀████▀▄▀▀█▀ ▀█ ▀▄ ████
████▀█▄█ █▄ ▀▄ ██ █▄███▀ ▄▄▄  ▄██▄ █▄███▄▄██ ████
█████▀▄▀ █▄▄▄█ ▄ ▄▀▄▀ █▄█▀▀▀█   ▄ █ ▀  ▀█  █▀████
████▀ █▀▄▄▄▄█ ▄█    ▄▄▀▀▀ ▄█ ▀▄ ▄▀▄█▀▄▄▄▀ ██▄████
████ ▄ ▄██▄█▀▀ ▀▀█▄   █ █▄▀▄ ▀ ▀ ▄ ▀▄ █▀▄ █▄▄████
████▄█▀  ▄▄▄▄▄▄   ███▄█ ▄▄▀ ▀▄ ▀ ▄▄▄ ▀█ ▄▄▀██████
████▀▀▀ █▄▄▀ ▄   ▄▄ ▄█ ▀▀█    ██  █▀▀█ ▄▄▄▀ ▀████
████▄  ▀▄▀▄ ▀▄▀ █▄▀▀ ██▀▀█▄   ▀▀██ ▀▄█▄▄   ▄█████
████▀ █▀█▄▄▄█▄  █ █ ▀ █▀█▀▄▄   ▀ ▄▀▀  █▀▀  ▀▀████
████▀▀█  █▄ ▀▄▄  ▄▄▀██▄▄▄ ▀▀▀█ █▀█ ▄███ ▄ ██ ████
████▄▀█▄ ▀▄▄ █▀▀▄▄ ▄▄▀  █▄▄▄▀ ▄  ▀▄▄█▀▀ ▄▄█ █████
████▄█▀▄█▄▄▀▄ ██▀  ▀▄▀▄█  █▄ ▄ ▀▀▀▀ █████ ▀▄█████
█████▄▄▄▄█▄█▀   █▀▀ ▀██▄▀██ ▄▄█▀▄▄ ▀ ▄▄▄ ▄▄  ████
████ ▄▄▄▄▄ █  ██▄▄▀ █▄▀    ▀ ▀▄▄ ██  █▄█  ▀ ▀████
████ █   █ █▀█ █▀ █ ▀▀  █▄▄▄ ▀▀ ▀ ▄   ▄  ▄█ ▀████
████ █▄▄▄█ █▄▄█▄▀█ ▄▄█▄    ▀█▄▀▀██   ██▄▀█▀▀▄████
████▄▄▄▄▄▄▄█▄██▄█▄██▄█▄█▄▄▄█▄██▄██▄█▄██▄█▄█▄█████
█████████████████████████████████████████████████
▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀▀


------------------------------

Vols provar un codi OTP? (y/N): y
Codi 🔑 : 803474
🏁 Verificat!
 ✅ Codi correcte!
```

# 📦 Llicència
Aquest projecte s’ofereix sota la llicència [MIT](https://choosealicense.com/licenses/mit/). Pots modificar-lo, distribuir-lo i integrar-lo lliurement.

## 🤝 Contribucions
Les contribucions són benvingudes! Si tens idees, millores o correccions, obre un issue o envia un pull request.
[![PayPal - Donate](https://img.shields.io/badge/PayPal-Donate-005EA6?logo=paypal&logoColor=white)](https://www.paypal.me/cuquet74)
