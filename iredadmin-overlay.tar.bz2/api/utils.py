import web
import settings
import json

from libs.iredutils import is_domain, is_email


def _parse_api_payload():
    """
        💡 Solució: acceptar JSON i formularis (x-www-form-urlencoded)
        Llegeix i retorna el payload de la petició HTTP, suportant JSON i x-www-form-urlencoded.
        Retorna (True, dict) si tot va bé, o (False, error_string) si hi ha problemes.
        | Escenari | Content-Type | Codi HTTP | Resultat |
        |----------|--------------|-----------|----------|
        | JSON vàlid | application/json | 200 OK | True, {dades} |
        | JSON mal formatat | application/json | 400 Bad Request | False, "INVALID_PAYLOAD..." |
        | Formulari estàndard | x-www-form-urlencoded | 200 OK | True, {dades} |
        | Trucada GET buida | (cap) | 200 OK | True, {} |
        | Format no permès | text/xml, image/png | 415 Unsupported Media Type | False, "UNSUPPORTED..." |
    """
    content_type = web.ctx.env.get('CONTENT_TYPE', '').lower()

    try:
        if 'application/json' in content_type:
            data = web.data()
            return True, json.loads(data)
        elif 'application/x-www-form-urlencoded' in content_type:
            return True, dict(web.input()) # 👈 converteix Storage a dict
        elif not content_type:
            return True, {}
        else:
            web.ctx.status = '415 Unsupported Media Type'
            return False, f'UNSUPPORTED_CONTENT_TYPE: {content_type}'
    except Exception as e:
        web.ctx.status = '400 Bad Request'
        return False, f'INVALID_PAYLOAD: {str(e)}'


def _check_privilege(account_type, account):
    """
    🧪 Comprova permisos segons tipus i compte.
    - Si account_type és 'global', comprova admin global.
    - Si account_type sembla un domini o email, s'interpreta com a compte i es reassigna el tipus.
    - Després comprova permisos segons tipus final i comptes.
    """
    session = web.config.get('_session')
    account = web.safestr(account).lower() or None  # neteja si ve com a string buit
    
    if account_type == 'all':
        if not session.get('is_global_admin'):
            return False, 'PERMISSION_DENIED'
        return True, {'account': 'all', 'account_type': 'all'}
    
    if account_type == 'global':
        if not session.get('is_global_admin'):
            return False, 'PERMISSION_DENIED'
        return True, {'account': '@.', 'account_type': 'global'}
    if is_domain(account_type):
        domain = account_type
        account = domain
        account_type = 'domain'
    if is_email(account_type):
        domain = account_type.split('@')[-1]
        account = account_type
        account_type = 'user'

    if account_type == 'domain':
        domain = account
        if session.get('is_global_admin'):
            return True, {'account': f'@{domain}', 'account_type': 'domain'}
        if session.get('is_domain_admin') and domain in session.get('domain_admins', []):
            return True, {'account': f'@{domain}', 'account_type': 'domain'}
        return False, 'PERMISSION_DENIED'

    elif account_type == 'user':
        domain = account.split('@')[-1]
        if session.get('is_global_admin'):
            return True, {'account': account, 'account_type': 'user'}
        if session.get('is_domain_admin') and domain in session.get('domain_admins', []):
            return True, {'account': account, 'account_type': 'user'}
        return False, 'PERMISSION_DENIED'

    return False, 'INVALID_ACCOUNT'


def _parse_api_payload_to_db(payload: dict, profile_type: str = None) -> dict:
    """
    NOTE:
    Reutilitza el mateix pipeline de normalització/remap del CRUD de UI
    per mantenir coherència entre formularis i API.
    """
    if not isinstance(payload, dict):
        return {}

    from controllers.m_crud.utils import _parse_crud_payload_to_db

    return _parse_crud_payload_to_db(payload, profile_type=profile_type)


def _parse_api_db_to_payload(data):
    """
    NOTE:
    Converteix dades de backend cap a payload canònic API (claus CRUD),
    però només quan la forma de dades és compatible amb el remap.
    """
    from controllers.m_crud.utils import _parse_crud_db_to_payload

    if isinstance(data, dict):
        return _parse_crud_db_to_payload(data)

    if isinstance(data, list):
        if not data:
            return data
        if all(isinstance(item, dict) for item in data):
            return _parse_crud_db_to_payload(data)
        return data

    return data


def _parse_api_result_to_payload(result):
    """
    NOTE:
    Helper per tuples de resposta `(ok, payload, *meta)` retornades per libs CRUD.
    """
    if not isinstance(result, tuple) or not result:
        return result

    if not result[0]:
        return result

    if len(result) == 1:
        return result

    payload = _parse_api_db_to_payload(result[1])
    if len(result) == 2:
        return (True, payload)

    return (True, payload, *result[2:])
