# api/greylist/controller.py
import web
import settings

from libs.m_iredapd import greylist as lib_greylist
from libs.m_crudlib import decorators
from api.utils import _check_privilege, _parse_api_payload
from controllers.m_iredapd.utils import _normalize_status

class API_Greylist_Settings(object):
    @decorators.require_login
    @decorators.json_response
    # @decorators.require_domain_access
    def GET(self, account_type, account=None):
        """
            ## 🧩 Exemples de peticions `curl`:        
            curl -X GET -i -b cookie.txt https://<server>/api/greylisting/global
            curl -X GET -i -b cookie.txt https://<server>/api/greylisting/<domain>
            curl -X GET -i -b cookie.txt https://<server>/api/greylisting/<mail>
            
            ## 🧩 Exemples amb `ìredapi_manager.py`:
                ./iredapi_manager.py call -e '/greylisting/global'
                ./iredapi_manager.py call -e '/greylisting/<domain>'
                ./iredapi_manager.py call -e '/greylisting/<domain>'
            """
        ok, result = _check_privilege(account_type, account)
        if not ok:
            return False, result
        
        greylist = lib_greylist.Greylisting(account=result['account'])
        return greylist.get_greylist_setting()
    
    @decorators.require_login
    @decorators.json_response
    def POST(self, account_type, account=None):
        """
            📦 Set greylisting setting.

            ## 🧩 Exemples de peticions `curl`:
            curl -X POST -i -b cookie.txt -d "status=enable" https://<server>/api/greylisting/global
            curl -X POST -i -b cookie.txt -d "status=enable" https://<server>/api/greylisting/<domain>
            curl -X POST -i -b cookie.txt -d "status=enable" https://<server>/api/greylisting/<mail>
            
            ## 🧩 Exemples amb `ìredapi_manager.py`:
            ./iredapi_manager.py call -e '/greylisting/baldufa@melindro.org' -m POST -d '{"status":"disable"}'
            ./iredapi_manager.py call -e '/greylisting/baldufa@melindro.org' -m POST -d 'status=disable'
            ./iredapi_manager.py call -e '/greylisting/baldufa@melindro.org' -m POST -d 'status=inherit'
            """
        # 1️⃣ Validar privilegis
        ok, result = _check_privilege(account_type, account)
        if not ok:
            return False, result
        
        # 2️⃣ Llegir paràmetres POST
        ok, payload = _parse_api_payload()
        if not ok:
            return False, payload
        
        # 3️⃣ Comprovar conflictes
        action = _normalize_status(payload.get("status", ""))
        if not action:
            web.ctx.status = "400 Bad Request"
            return False, f"Invalid value for status: {payload.get('status')}"
        
        # 4️⃣ Instanciar gestió greylisting
        greylist = lib_greylist.Greylisting(account=result['account'])
        if action == "inherit":
            return greylist.delete_greylist_setting()
        else:
            enable = (action == "enable")
            return greylist.enable_disable_greylist_setting(enable=enable)

    @decorators.require_login
    @decorators.json_response
    def DELETE(self, account_type, account=None):
        ok, result = _check_privilege(account_type, account)
        if not ok:
            return False, result

        greylist = lib_greylist.Greylisting(account=result['account'])
        return greylist.delete_greylist_setting()


class API_Greylist_Whitelists(object):
    @decorators.require_login
    @decorators.json_response
    @decorators.require_domain_access
    def GET(self, account_type, account=None):
        """
            📦 Obté els remitents que estan a la llista blanca del servei de greylisting.
            Aquest endpoint permet consultar les entrades whitelisted a nivell global, per domini o per adreça de correu.

            ## 🧩 Exemples de peticions `curl`:
                • 🌐 Global:
                    curl -X GET -i -b cookie.txt https://<servidor>/api/greylisting/global/whitelists

                • 🏷️ Per domini:
                    curl -X GET -i -b cookie.txt https://<servidor>/api/greylisting/<domini>/whitelists

                • 📧 Per correu electrònic:
                    curl -X GET -i -b cookie.txt https://<servidor>/api/greylisting/<correu>/whitelists
            
            ## 🧩 Exemples amb `ìredapi_manager.py`:
                ./iredapi_manager.py call -e '/greylisting/global/whitelists'
                ./iredapi_manager.py call -e '/greylisting/<domini>/whitelists'
                ./iredapi_manager.py call -e '/greylisting/<correu>/whitelists' 
            """
        ok, result = _check_privilege(account_type, account)
        if not ok:
            return False, result
        # Nota: aquest endpoint es manté per global/all (dominis simples, sense comentaris).
        # Per a domini/usuari, /greylisting/<x>/whitelists es redirigeix a
        # API_Greylist_Whitelists_SPF_Domain per alinear amb la UI oficial.
        account_type = result.get('account_type')
        greylist = lib_greylist.Greylisting(account=result['account'])
        return greylist.get_greylist_whitelists(account_type)
    
    @decorators.require_login
    @decorators.json_response
    def POST(self, account_type, account=None):
        """
            📦 Configura els paràmetres globals del servei de greylisting.
            
            ## 🧩 Exemple de petició `curl`:
                curl -X POST -i -b cookie.txt -d "var=valor&var2=valor2" https://<servidor>/api/greylisting/global/whitelists

            ## 🧩 Exemples amb `ìredapi_manager.py`:
                ./iredapi_manager.py call -e '/greylisting/global/whitelists' -m POST -d '{"senders":"192.168.1.0/24,@example.com,user@example.com"}'
                ./iredapi_manager.py call -e '/greylisting/global/whitelists' -m POST -d '{"addSenders":"192.168.74.0/24"}'

            ## 📌 Paràmetres opcionals:

                • 📨 @senders  
                Reinicia els remitents a la llista blanca del servei global de greylisting amb els indicats.  
                ➕ Les adreces múltiples s’han de separar amb comes.  
                ⚠️ En conflicte amb `addSenders` i `removeSenders`.

                • ➕ @addSenders  
                Afegeix nous remitents a la llista blanca global del servei de greylisting.  
                ➕ Les adreces múltiples s’han de separar amb comes.  
                ⚠️ En conflicte amb `senders`.

                • ➖ @removeSenders  
                Elimina remitents existents de la llista blanca global del servei de greylisting.  
                ➕ Les adreces múltiples s’han de separar amb comes.  
                ⚠️ En conflicte amb `senders`.
            """
        
        # 1️⃣ Validar privilegis
        ok, result = _check_privilege(account_type, account)
        if not ok:
            return False, result
                
        # 2️⃣ Llegir paràmetres POST
        # data = web.input(senders=None, addSenders=None, removeSenders=None)
        ok, payload = _parse_api_payload()
        if not ok:
            return False, payload
        
        senders      = payload.get('senders')
        add_senders  = payload.get('addSenders')
        remove_senders = payload.get('removeSenders')
        
        # 3️⃣ Comprovar conflictes
        if senders and (add_senders or remove_senders):
            return False, "Parameter 'senders' cannot be used with 'addSenders' or 'removeSenders'."

        # 4️⃣ Instanciar gestió greylisting
        greylist = lib_greylist.Greylisting(account=result['account'])
        
        try:
            if senders is not None:
                # Reset complet amb nova llista
                sender_list = [s.strip() for s in senders.split(',') if s.strip()]
                return greylist.reset_greylist_whitelists(account_type, sender_list)

            elif add_senders is not None:
                sender_list = [s.strip() for s in add_senders.split(',') if s.strip()]
                return greylist.add_greylist_whitelists(account_type, sender_list)

            elif remove_senders is not None:
                sender_list = [s.strip() for s in remove_senders.split(',') if s.strip()]
                return greylist.remove_greylist_whitelists(account_type, sender_list)

            return False, "Missing parameters: senders, addSenders, or removeSenders."

        except Exception as e:
            return False, str(e)


class API_Greylist_Whitelists_SPF_Domain(object):
    """
        📦 
        
        ## 🧩 Exemples de peticions `curl`:
            ```
            curl -X POST -i -b cookie.txt -d "var=value&var2=value2" https://<servidor>/api/greylisting/whitelist_spf_domains
            ```
            ```
            curl -X POST -i -b cookie.txt https://<servidor>/api/greylisting/whitelist_spf_domains \
                -H "Content-Type: application/json" \
                -H "Accept: application/json" \
                -d '{"removeDomains": "value,value2"}'
            ```
            ```
            curl -k -X POST https://<servidor>/api/greylisting/whitelist_spf_domains \
                -H "Content-Type: application/x-www-form-urlencoded" \
                -H "Accept: application/json" \
                -d "removeDomains=value,value2"
            ```
        
        ## 🧩 Exemples amb `ìredapi_manager.py`:
            ./iredapi_manager.py call -e '/greylisting/whitelist_spf_domains' -m POST -d 'addDomains=exemple.tv,exemple.mobi'
            ./iredapi_manager.py call -e '/greylisting/whitelist_spf_domains' -m POST -d 'removeDomains=exemple.tv,exemple.mobi'
            
        ## 📥 Paràmetres acceptats:

            • domains (_llista_): 🔄 Reemplaça completament els dominis remitent a la llista blanca del servei global de greylisting.
                ⚠️ No es pot combinar amb `addDomains` ni `removeDomains`.
                Exemple: domains=iredmail.org,gmail.com

            • addDomains (_llista_): ➕ Afegeix nous dominis remitent a la llista blanca del servei global de greylisting.
                ⚠️ No es pot combinar amb `domains`.
                Exemple: addDomains=iredmail.org,gmail.com

            • removeDomains (_llista_): ➖ Elimina dominis remitent existents de la llista blanca del servei global de greylisting.
                ⚠️ No es pot combinar amb `domains`.
                Exemple: removeDomains=iredmail.org,gmail.com
        """
    # Nota (CA):
    #  - La UI oficial edita la llista amb comentaris (taula SPF) també per a domini/usuari.
    #  - Per això, /greylisting/<domain>/whitelists i /greylisting/<user>/whitelists apunten aquí.
    #  - Acceptem senders/addSenders/removeSenders com a alias de domains/addDomains/removeDomains.
    @decorators.require_login
    @decorators.json_response
    def GET(self, account_type=None, account=None):
        if account_type:
            ok, result = _check_privilege(account_type, account)
            if not ok:
                return False, result
            greylist = lib_greylist.Greylisting(account=result['account'])
        else:
            greylist = lib_greylist.Greylisting(account='@.')
        return greylist.get_greylist_whitelists_spf_domain()
    
    @decorators.require_login
    @decorators.json_response
    def POST(self, account_type=None, account=None):
        ok, payload = _parse_api_payload()

        if not ok:
            return False, payload

        if account_type:
            ok, result = _check_privilege(account_type, account)
            if not ok:
                return False, result
            greylist = lib_greylist.Greylisting(account=result['account'])
        else:
            greylist = lib_greylist.Greylisting(account='@.')

        domains = payload.get('domains')
        add_domains = payload.get('addDomains')
        remove_domains = payload.get('removeDomains')

        senders = payload.get('senders')
        add_senders = payload.get('addSenders')
        remove_senders = payload.get('removeSenders')

        # Evitem barrejar paràmetres "domains" i "senders"
        has_domains = any(v is not None for v in (domains, add_domains, remove_domains))
        has_senders = any(v is not None for v in (senders, add_senders, remove_senders))
        if has_domains and has_senders:
            return False, "Parameters domains/addDomains/removeDomains cannot be mixed with senders/addSenders/removeSenders."

        # Alias senders -> domains (alineat amb UI oficial)
        if not has_domains and has_senders:
            domains = senders
            add_domains = add_senders
            remove_domains = remove_senders

        def _to_list(value):
            if value is None:
                return None
            if isinstance(value, list):
                return [str(s).strip() for s in value if str(s).strip()]
            return [s.strip() for s in str(value).split(',') if s.strip()]
        
        try:
            if domains is not None:
                domain_list = _to_list(domains)
                return greylist.reset_greylist_whitelists_spf_domain(domain_list)

            elif add_domains is not None:
                domain_list = _to_list(add_domains)
                return greylist.add_greylist_whitelists_spf_domain(domain_list)

            elif remove_domains is not None:
                domain_list = _to_list(remove_domains)
                return greylist.remove_greylist_whitelists_spf_domain(domain_list)

            return False, "Missing parameters: domains/addDomains/removeDomains (or senders/addSenders/removeSenders)."

        except Exception as e:
            return False, str(e)
