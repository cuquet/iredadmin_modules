
import settings
from libs.regxes import email as e, domain as d

urls = [
    # Greylisting
    '/api/greylisting/(all|global)', 'api.greylist.controller.API_Greylist_Settings',
    '/api/greylisting/(%s)' % d, 'api.greylist.controller.API_Greylist_Settings',
    '/api/greylisting/(%s)' % e, 'api.greylist.controller.API_Greylist_Settings',
    '/api/greylisting/(global)/whitelists', 'api.greylist.controller.API_Greylist_Whitelists',
    # Nota: domini/usuari → usem llista SPF amb comentaris (alineat amb la UI oficial)
    '/api/greylisting/(%s)/whitelists' % d, 'api.greylist.controller.API_Greylist_Whitelists_SPF_Domain',
    '/api/greylisting/(%s)/whitelists' % e, 'api.greylist.controller.API_Greylist_Whitelists_SPF_Domain',
    '/api/greylisting/whitelist_spf_domains', 'api.greylist.controller.API_Greylist_Whitelists_SPF_Domain',
]
