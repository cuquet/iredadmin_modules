# api/crud/controller.py
import web
import settings
from libs.m_crudlib import decorators
from libs.m_crudlib import (
    domain as lib_domain,
    user as lib_user,
    admin as lib_admin
    )
from api.utils import (
    _parse_api_payload,
    _check_privilege,
    _parse_api_payload_to_db,
    _parse_api_db_to_payload,
    _parse_api_result_to_payload,
)

from libs.m_system import form_utils, utils

class API_Domain:
    @decorators.require_login
    @decorators.json_response
    def GET(self, domain=None):
        ok, payload = _parse_api_payload()
        if not ok:
            return False, payload

        form = web.input(names_only='no', disabled_only='no') 
        params = {**dict(form), **payload}

        domain_str = web.safestr(domain or "").lower().strip()# Converteix None en "" en lloc de "None"
        domain_lib = lib_domain.Domain(domain_str if domain_str else None)

        if not domain_str:
            qr = domain_lib.list(
                names_only=(params.get('names_only', 'no') == 'yes'),
                disabled_only=(params.get('disabled_only', 'no') == 'yes'),
                current_page=0
            )
            return _parse_api_result_to_payload(qr)

        return _parse_api_result_to_payload(domain_lib.get_profile())

    @decorators.require_login
    @decorators.json_response
    def POST(self, domain=None):
        domain = web.safestr(domain).lower()
        ok, payload = _parse_api_payload()
        if not ok:
            return (False, payload)

        # 1. Normalització del nom del domini (prioritat URL)
        if domain:
            payload['domainName'] = domain.lstrip('@')
        elif 'domain' in payload:
            payload['domainName'] = payload.pop('domain').lstrip('@')

        # 2. Traducció de noms 
        # La doc diu 'name', la lib sol voler 'cn'
        if 'name' in payload and 'cn' not in payload:
            payload['cn'] = payload.pop('name')
        payload.setdefault('cn', payload.get('domainName'))
        
        # 3. Preparació de account_settings (el diccionari intern)
        # Aquí posem tot el que a LDAP va dins de l'atribut 'accountSetting'
        # o a SQL dins de la columna 'settings'
        acc_settings = {}
        map_settings = {
            'quota': 'domainQuota',
            'defaultQuota': 'defaultQuota',
            'maxUserQuota': 'maxUserQuota',
            'language': 'defaultLanguage',
            'numberOfUsers': 'numberOfUsers',
            'numberOfAliases':	'numberOfAliases',
            'numberOfLists': 'numberOfLists',
        }
        for api_key, internal_key in map_settings.items():
            if api_key in payload:
                val = payload.pop(api_key)
                if 'quota' in api_key.lower():
                    val = form_utils.quota_transformation(
                        api_key,
                        {api_key: val, f"{api_key}Unit": "MB"},
                    )
                acc_settings[internal_key] = val
        payload['accountSetting'] = acc_settings
        
        return lib_domain.Domain().add(payload)

    @decorators.require_login
    @decorators.json_response
    def PUT(self, domain):
        domain = web.safestr(domain).lower()
        ok, payload = _parse_api_payload()
        if not ok:
            return (False, payload)
        
        # 1. Mapeig de noms de l'API oficial
        api_to_payload_map = {
            'name': 'cn',
            'accountStatus': 'accountStatus',
            'language': 'defaultLanguage',
            'recipientBcc':'domainRecipientBccAddress',
            'senderBcc': 'domainSenderBccAddress',
            'transport': 'mtaTransport',
            'backupmx': 'domainBackupMX',
            'relay_without_verify_local_recipient': 'relay_without_verify_local_recipient',
            'quota': 'domainQuota',
            'defaultQuota': 'defaultQuota',
            'maxUserQuota': 'maxUserQuota',
            'numberOfUsers': 'numberOfUsers',
            'numberOfAliases': 'numberOfAliases',
            'numberOfLists': 'numberOfLists',
            'minPasswordLength': 'min_passwd_length',
            'maxPasswordLength': 'max_passwd_length',
        }
        # 2. Normalització de dades específica per a l'API
        internal_payload = {}
        for k, v in payload.items():
            internal_key = api_to_payload_map.get(k, k)
            if internal_key == 'domainBackupMX':
                _v = str(v).strip().lower()
                v = 'yes' if _v in ('yes', 'true', '1', 'active') else ''
            if k in ['quota', 'defaultQuota', 'maxUserQuota'] or 'quota' in internal_key.lower():
                v = form_utils.quota_transformation(
                    k,
                    {k: v, f"{k}Unit": "MB"},
                )
            internal_payload[internal_key] = v

        return lib_domain.Domain(domain).update(internal_payload)

    @decorators.require_login
    @decorators.json_response
    def DELETE(self, domain, days=0):
        try:
            days = max(0, int(days))
        except (ValueError, TypeError):
            days = 0
        return lib_domain.Domain().delete(domain=domain.lstrip('@'), keep_mailbox_days=days)

class API_User:
    @decorators.require_login
    @decorators.json_response
    def GET(self, account=None):
        ok, result = _check_privilege(account, None)
        if not ok:
            return False, result

        ok, payload = _parse_api_payload()
        if not ok:
            payload = {}
        form = web.input(names_only='no', disabled_only='no') 
        params = {**dict(form), **payload}

        if result['account_type']== 'user' and result['account']:
            qr = lib_user.User(mail=result['account']).get_profile()
            return _parse_api_result_to_payload(qr)
        elif result['account_type']== 'domain' and result['account']:
            domain_name = result['account'].lstrip('@')
            qr = lib_user.User(domain=domain_name).list(
                email_only=(params.get('names_only', 'no') == 'yes'),
                disabled_only=(params.get('disabled_only', 'no') == 'yes')
            )
            if qr and qr[0] and isinstance(qr[1], list):
                serializable = []
                for item in qr[1]:
                    if isinstance(item, dict):
                        serializable.append(item)
                    else:
                        try:
                            serializable.append(dict(item))
                        except Exception:
                            serializable.append(item)
                serializable = _parse_api_db_to_payload(serializable)
                return (True, serializable, *qr[2:])
            return _parse_api_result_to_payload(qr)

    @decorators.require_login
    @decorators.json_response
    def POST(self, mail=None, new_mail=None):
        ok, payload = _parse_api_payload()
        if not ok:
            return (False, payload)

        if 'verify_password' in web.ctx.path:
            password = payload.get('password')
            if not password:
                return (False, 'MISSING_PASSWORD')
            return lib_user.User(mail=mail).verify_password(password)
        if mail and new_mail:
            # Opcional: Verificar privilegis sobre l'email origen i el destí
            # ok, result = _check_privilege(mail, new_mail)
            return lib_user.User(mail=mail).rename(new_mail.lower())

        # Crear usuari
        if not mail:
            mail = payload.get('mail')
        if not mail:
            return (False, 'MISSING_MAIL')

        if payload.get('password') and payload.get('password_hash'):
            return (False, 'CONFLICT_PASSWORD_AND_HASH')

        # Mapatge de camps segons API oficial -> formulari CRUD
        params = dict(payload)
        params['mail'] = mail
        params.setdefault('username', mail.split('@', 1)[0].strip().lower())

        api_to_payload_map = {
            'gn': 'givenName',
            'sn': 'sn',
            'name': 'cn',
            'employeeid': 'employeeNumber',
            'language': 'preferredLanguage',
            'transport': 'mtaTransport',
            'quota': 'mailQuota',
        }

        internal_params = {}
        for k, v in params.items():
            internal_key = api_to_payload_map.get(k, k)
            internal_params[internal_key] = v

        # LDAP add() uses defaultLanguage; keep both for compatibility.
        if 'preferredLanguage' in internal_params:
            internal_params.setdefault('defaultLanguage', internal_params.get('preferredLanguage'))

        params = internal_params

        if 'password' in params:
            pwd = params.pop('password')
            params.setdefault('newpw', pwd)
            params.setdefault('confirmpw', pwd)

        if 'mailQuota' in params:
            params.setdefault('mailQuotaUnit', 'MB')

        db_payload = _parse_api_payload_to_db(params)

        if 'password_hash' in params:
            db_payload['password_hash'] = params['password_hash']

        return lib_user.User(mail=mail, domain=mail.split('@')[-1].strip()).add(db_payload)

    @decorators.require_login
    @decorators.json_response
    def PUT(self, mail):
        ok, payload = _parse_api_payload()
        if not ok:
            payload = {}

        form = web.input()
        params = {**dict(form), **payload}

        if params.get('password') and params.get('password_hash'):
            return (False, 'CONFLICT_PASSWORD_AND_HASH')

        # NOTE: Alias de compatibilitat de payload API.
        if "services" in params and "enabledService" not in params:
            params["enabledService"] = params.get("services")
        if "enabledServices" in params and "enabledService" not in params:
            params["enabledService"] = params.get("enabledServices")
        if "disabledServices" in params and "disabledService" not in params:
            params["disabledService"] = params.get("disabledServices")
        if "extraAddress" in params and "extra_address" not in params:
            params["extra_address"] = params.get("extraAddress")
        if "mailForwardingAddress" in params and "catchallAddress" not in params:
            params["catchallAddress"] = params.get("mailForwardingAddress")

        def _is_enabled(value):
            return str(value).strip().lower() in {'yes', 'true', '1', 'active', 'enabled', 'on'}

        profile_type = params.get('profile_type')
        if not profile_type:
            if 'password' in params or 'password_hash' in params:
                profile_type = 'password'
            else:
                has_forwarding = any(k in params for k in {'forwarding', 'savecopy', 'mailForwardingAddress', 'catchallAddress'})
                has_aliases = any(k in params for k in {'aliases', 'alias', 'shadowAddress', 'extra_address', 'extraAddress'})
                has_services = any(k in params for k in {'enabledService', 'disabledService', 'services', 'enabledServices', 'disabledServices'})

                selected_profiles = []
                if has_forwarding:
                    selected_profiles.append('forwarding')
                if has_aliases:
                    selected_profiles.append('aliases')
                if has_services:
                    selected_profiles.append('services')

                if len(selected_profiles) > 1:
                    return (False, {
                        'AMBIGUOUS_PROFILE_TYPE': selected_profiles,
                        'HINT': "Passa explícitament 'profile_type' (forwarding|aliases|services).",
                    })

                profile_type = selected_profiles[0] if selected_profiles else 'general'
        else:
            profile_type = web.safestr(profile_type).strip().lower()

        # Mapatge de camps segons API oficial -> formulari CRUD
        api_to_payload_map = {
            'gn': 'givenName',
            'sn': 'sn',
            'name': 'cn',
            'employeeid': 'employeeNumber',
            'accountStatus': 'accountStatus',
            'isGlobalAdmin': 'domainGlobalAdmin',
            'transport': 'mtaTransport',
            'language': 'preferredLanguage',
            'mailForwardingAddress': 'catchallAddress',
            'extraAddress': 'extra_address',
            'shadowAddress': 'extra_address',
            'services': 'enabledService',
            'enabledServices': 'enabledService',
            'disabledServices': 'disabledService',
            'aliases': 'aliases',
            'alias': 'alias',
        }

        internal_params = {}
        for k, v in params.items():
            internal_key = api_to_payload_map.get(k, k)

            if internal_key == 'accountStatus':
                status = str(v).strip().lower()
                v = 'on' if status in ('active', 'enabled', 'yes', 'on', '1') else 'off'
            elif internal_key == 'domainGlobalAdmin':
                val = str(v).strip().lower()
                v = 'active' if val in ('yes', 'true', '1', 'active') else 'disabled'
            elif internal_key in {'forwarding', 'savecopy', 'aliases', 'alias', 'domainadmin'}:
                if not isinstance(v, (dict, list, tuple, set)):
                    v = 'active' if _is_enabled(v) else 'disabled'

            internal_params[internal_key] = v

        params = internal_params

        if profile_type == 'aliases':
            # NOTE: Paritat SQL/LDAP:
            # - SQL consumeix `aliases` + `extra_address`.
            # - LDAP consumeix `shadowaddress` + `shadowAddress`.
            if "aliases" in params and "shadowaddress" not in params:
                params["shadowaddress"] = params.get("aliases")
            if "alias" in params and "shadowaddress" not in params:
                params["shadowaddress"] = params.get("alias")

            if "extra_address" in params and "shadowAddress" not in params:
                raw_extra = params.get("extra_address")
                if isinstance(raw_extra, dict):
                    params["shadowAddress"] = raw_extra
                else:
                    params["shadowAddress"] = {"add": raw_extra, "remove": ""}

            if "shadowAddress" in params and "extra_address" not in params:
                raw_shadow = params.get("shadowAddress")
                if isinstance(raw_shadow, dict):
                    params["extra_address"] = raw_shadow.get("add")
                else:
                    params["extra_address"] = raw_shadow

        if profile_type in {'forwarding', 'aliases', 'services'}:
            return lib_user.User(mail=mail).update(profile_type=profile_type, payload=params)

        if 'password' in params:
            pwd = params.pop('password')
            params.setdefault('newpw', pwd)
            params.setdefault('confirmpw', pwd)

        if 'quota' in params and 'mailQuota' not in params:
            params['mailQuota'] = params.pop('quota')
            params.setdefault('mailQuotaUnit', 'MB')
        if 'mailQuota' in params:
            params.setdefault('mailQuotaUnit', 'MB')

        db_payload = _parse_api_payload_to_db(params, profile_type)

        if 'password_hash' in params:
            db_payload['password_hash'] = params['password_hash']

        return lib_user.User(mail=mail).update(profile_type, db_payload)

    @decorators.require_login
    @decorators.json_response
    def DELETE(self, mail, days=0):
        mail = web.safestr(mail).strip().lower()
        try:
            days = max(0, int(days))
        except (ValueError, TypeError):
            days = 0
        return lib_user.User(mail=mail).delete(keep_mailbox_days=days)

class API_DomainAdmins:
    @decorators.require_global_admin
    @decorators.json_response
    def PUT(self, domain):
        ok, payload = _parse_api_payload()
        if not ok:
            payload = {}

        domain = web.safestr(domain or "").lower().strip()
        # NOTE:
        # Evitem dobles parsejos i normalitzem de forma tolerant (str o llista).
        # Amb això esquivem errors de parsing tipus "'NoneType' object has no attribute 'split'".
        params = payload if isinstance(payload, dict) else {}

        raw_add = params.get("addAdmin", "")
        raw_remove = params.get("removeAdmin", "")
        raw_remove_all = params.get("removeAllAdmins", "")

        add_admins = utils._normalize_list_mails(raw_add)
        remove_admins = utils._normalize_list_mails(raw_remove)
        remove_all = str(raw_remove_all).strip().lower() in {"1", "yes", "true", "on", "active"}

        return lib_user.User().update_domain_admins(
            domain=domain,
            add_admins=add_admins,
            remove_admins=remove_admins,
            remove_all=remove_all,
        )

class API_Admin:
    @decorators.require_global_admin
    @decorators.json_response
    def GET(self, mail=None):
        if not mail:
            return (False, "MISSING_MAIL")
        return _parse_api_result_to_payload(lib_admin.Admin(mail=mail).get_profile())

    @decorators.require_global_admin
    @decorators.json_response
    def POST(self, mail=None):
        ok, payload = _parse_api_payload()
        if not ok:
            return (False, payload)

        if 'verify_password' in web.ctx.path:
            password = payload.get('password')
            if not password:
                return (False, 'MISSING_PASSWORD')
            return lib_admin.Admin(mail=mail).verify_password(password)

        if not mail:
            mail = payload.get('mail')
        if not mail:
            return (False, 'MISSING_MAIL')

        if payload.get('password') and payload.get('password_hash'):
            return (False, 'CONFLICT_PASSWORD_AND_HASH')
        if payload.get('password_hash'):
            return (False, 'UNSUPPORTED_PASSWORD_HASH')

        params = dict(payload)
        params['mail'] = mail

        api_to_payload_map = {
            'gn': 'givenName',
            'sn': 'sn',
            'name': 'cn',
            'employeeid': 'employeeNumber',
            'language': 'defaultLanguage',
        }

        internal_params = {}
        for k, v in params.items():
            internal_key = api_to_payload_map.get(k, k)
            internal_params[internal_key] = v

        params = internal_params

        if 'password' in params:
            pwd = params.pop('password')
            params.setdefault('newpw', pwd)
            params.setdefault('confirmpw', pwd)

        return lib_admin.Admin(mail=mail).add(params)

    @decorators.require_global_admin
    @decorators.json_response
    def PUT(self, mail):
        ok, payload = _parse_api_payload()
        if not ok:
            payload = {}

        form = web.input()
        params = {**dict(form), **payload}

        if params.get('password') and params.get('password_hash'):
            return (False, 'CONFLICT_PASSWORD_AND_HASH')
        if params.get('password_hash'):
            return (False, 'UNSUPPORTED_PASSWORD_HASH')

        profile_type = params.get('profile_type')
        if not profile_type:
            profile_type = 'password' if ('password' in params or 'password_hash' in params) else 'general'

        api_to_payload_map = {
            'gn': 'givenName',
            'sn': 'sn',
            'name': 'cn',
            'employeeid': 'employeeNumber',
            'language': 'defaultLanguage',
            'accountStatus': 'accountStatus',
            'isGlobalAdmin': 'domainGlobalAdmin',
        }

        internal_params = {}
        for k, v in params.items():
            internal_key = api_to_payload_map.get(k, k)

            if internal_key == 'accountStatus':
                status = str(v).strip().lower()
                if settings.backend in ("mysql", "pgsql"):
                    if status in ('active', 'enabled', 'yes', 'on', '1'):
                        internal_params['accountStatus'] = 'on'
                    else:
                        # Leave it out to disable in SQL update()
                        continue
                else:
                    internal_params['accountStatus'] = 'active' if status in ('active', 'enabled', 'yes', 'on', '1') else 'disabled'
                continue

            if internal_key == 'domainGlobalAdmin':
                val = str(v).strip().lower()
                v = 'active' if val in ('yes', 'true', '1', 'active') else 'disabled'

            internal_params[internal_key] = v

        params = internal_params

        if 'password' in params:
            pwd = params.pop('password')
            params.setdefault('newpw', pwd)
            params.setdefault('confirmpw', pwd)

        return lib_admin.Admin(mail=mail).update(profile_type, params)

    @decorators.require_global_admin
    @decorators.json_response
    def DELETE(self, mail):
        if not mail:
            return (False, "MISSING_MAIL")
        return lib_admin.Admin().delete(mails=[mail])
