# api/crud/urls.py
from libs.regxes import email as e, domain as d

urls = [
    '/api/domains', 'api.crud.controller.API_Domain',
    '/api/domain/admins/(%s$)' % d, 'api.crud.controller.API_DomainAdmins',
    '/api/domain/(%s)/keep_mailbox_days/(\d+)' % d, 'api.crud.controller.API_Domain',
    '/api/domain/(%s)' % d, 'api.crud.controller.API_Domain',
    '/api/user/(%s)/keep_mailbox_days/(\d+)' % e, 'api.crud.controller.API_User',
    '/api/user/(%s)/change_email/(%s$)' % (e, e), 'api.crud.controller.API_User',
    '/api/user/(%s)$' % e, 'api.crud.controller.API_User',
    '/api/users/(%s)$' % d, 'api.crud.controller.API_User',
    '/api/verify_password/user/(%s)$' % e, 'api.crud.controller.API_User',
    '/api/admin/(%s)$' % e, 'api.crud.controller.API_Admin',
    '/api/verify_password/admin/(%s)$' % e, 'api.crud.controller.API_Admin'
    # '/api/aliases/(%s)$' % d, 'api.crud.controller.API_Alias',
    # '/api/alias/(%s)$' % e, 'api.crud.controller.API_Alias',
]
