# api/throttle/controller.py
import web

from libs.m_iredapd import throttle as lib_throttle
from libs.m_crudlib import decorators
from controllers.m_iredapd.utils import (
    _throttle_api_payload_to_db, 
    _throttle_api_db_to_payload,
    _normalize_inout_type
)
from api.utils import  (
    _check_privilege, 
    _parse_api_payload
)

class API_Throttle(object):
    @decorators.require_login
    @decorators.json_response
    # @decorators.require_domain_access
    def GET(self, account, inout_type):
        """
            Consulta configuració de throttle.
            GET: retorna settings o enable=false si no existeixen.
        """
        ok, result = _check_privilege(account, None)
        if not ok:
            return False, result

        throttle = lib_throttle.Throttle(result['account'], {}, inout_type)
        ok, records, *rest  = throttle.get_throttle_settings()
        if not ok:
            return (ok, records, *rest)

        if not records:
            return (False, "ACCOUNT_NOT_EXIST", *rest)

        return (True, _throttle_api_db_to_payload(records), *rest)
    
    @decorators.require_login
    @decorators.json_response
    def POST(self, account, inout_type):
        """
            🔧 Actualitza la configuració de throttling via API.
            * Si enable=false → només desactiva (period=0) però no elimina.
            * Si enable=true i venen límits → els aplica.
            * Si enable=true i NO venen límits → assigna defaults.
            * period: sempre >=0, si no → es força a 86400.

        """
        direction = _normalize_inout_type(inout_type)

        ok, result = _check_privilege(account, None)
        if not ok:
            return False, result
        
        ok, payload = _parse_api_payload()
        if not ok:
            return False, payload
        
        db_payload = _throttle_api_payload_to_db(payload, inout_type)
        
        # NOTE: Fem servir el compte normalitzat de _check_privilege (ex: global -> @., domini -> @domini)
        # per mantenir consistència entre POST (write) i GET (read).
        return lib_throttle.Throttle(result['account'], db_payload, direction).update_throttle_settings()
