from libs.regxes import email as e, domain as d

urls = [
    # Throttling
    '/api/throttle/(global)/(inbound|outbound)', 'api.throttle.controller.API_Throttle',
    '/api/throttle/(%s)/(inbound|outbound)' % d, 'api.throttle.controller.API_Throttle',
    '/api/throttle/(%s)/(inbound|outbound)' % e, 'api.throttle.controller.API_Throttle',
]
