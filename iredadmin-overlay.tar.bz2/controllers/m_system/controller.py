# controllers/m_system/controller.py
import web
from urllib.parse import urlsplit

from libs.iredutils import (
    get_settings_from_db, 
    store_settings_in_db
)
from libs.panel import LOG_EVENTS

from libs.m_crudlib import decorators
from libs.m_system.jinja_filters import SYMBOLS
from controllers.m_system import utils

from libs.m_system.mixins import ExporterFactory, LOG_EXPORT_SCHEMA
from libs.m_system.domain_ownership import DomainOwnershipManager
from libs.m_system import log as lib_log
from libs.m_iredapd import (
    wblist_rdns as lib_wblist_rdns,
    greylist as lib_greylist,
    throttle as lib_throttle
    )
from libs.m_amavisd import (
    spampolicy as lib_spampolicy,
    wblist as lib_wblist
    )


session = web.config.get('_session', {})

BASE_URL= "/system"


class SwitchSkin(object):
    def GET(self, skin):
        normalize = getattr(web, "normalize_skin_name", None)
        if callable(normalize):
            selected_skin = normalize(skin)
        else:
            selected_skin = str(skin or "").strip().lower()

        session["skin"] = selected_skin

        form = web.input(next=None, _method="GET")
        next_path = web.safestr(form.get("next", "")).strip()
        if next_path.startswith("/"):
            raise web.seeother(next_path)

        # NOTE: Fallback to local referer when `next` is not provided.
        referer = web.ctx.env.get("HTTP_REFERER", "")
        if referer:
            try:
                parsed = urlsplit(referer)
                _path = parsed.path or ""
                if parsed.query:
                    _path = _path + "?" + parsed.query

                # Convert absolute app path to relative web.py path.
                if _path.startswith(web.ctx.homepath + "/"):
                    _path = _path[len(web.ctx.homepath):]

                if _path.startswith("/"):
                    raise web.seeother(_path)
            except Exception:
                pass

        raise web.seeother("/dashboard")

class VerifyOwnership(object):
    BASE_URL="/verify/domain_ownership"
    @decorators.require_login
    @decorators.require_admin_login
    def GET(self):
        form = web.input(
            verified="all",
            domain="alldomains",
            page=1, 
            msg=None, 
            _unicode=False
        )
        cur_page = max(1, int(form.page))
        form_verified = web.safestr(form.verified).lower()
        form_domain = web.safestr(form.domain)

        ok, sl, *rest = DomainOwnershipManager().list_domains_ownership_verification(status=form_verified, domain=form_domain, current_page=cur_page)
        if not ok:
            raise web.seeother(utils._redirect_url(self.BASE_URL, msg=sl))

        return web.render(
            'panel/domain_ownership.html',
            sl=sl,
            verify_data=sl['records'],
            total=sl['total'],
            domain=form_domain,
            domains= sl['managed_domains'],
            verified=form_verified,
            cur_page=sl['current_page'],
            msg=web.input().get('msg', ''))

    @decorators.require_login
    @decorators.require_admin_login
    @decorators.csrf_protected
    def POST(self):
        form = web.input(
            id=[],
            _unicode=False
            )
        list_id = form.get("id", [])
        action =  (form.get("action", "")).lower()

        if action not in {'verify','enable_without_verification', 'restart_verification'}:
            raise web.seeother(utils._redirect_url(self.BASE_URL, msg="INVALID_ACTION"))

        if action == 'verify':
            qr = DomainOwnershipManager().verify_domains_with_ownership_verification(list_id)
            raise web.seeother(utils._redirect_url(self.BASE_URL, msg='DOMAIN_VERIFIED' if qr[0] else qr[1]))
        elif action == 'enable_without_verification':
            if not session.get('is_global_admin'):
                raise web.seeother(utils._redirect_url(self.BASE_URL, msg='PERMISSION_DENIED'))
            qr = DomainOwnershipManager().enable_domains_without_ownership_verification(list_id)
            raise web.seeother(utils._redirect_url(self.BASE_URL, msg='DOMAIN_VERIFIED' if qr[0] else qr[1]))
        elif action == 'restart_verification':
            if not session.get('is_global_admin'):
                raise web.seeother(utils._redirect_url(self.BASE_URL, msg='PERMISSION_DENIED'))
            qr = DomainOwnershipManager().restart_domains_ownership_verification(list_id)
            raise web.seeother(utils._redirect_url(self.BASE_URL, msg='VERIFICATION_RESTARTED' if qr[0] else qr[1]))

        else:
            raise web.seeother(utils._redirect_url(
                    self.BASE_URL, 
                    domain=form.get('domain'),
                    verified=form.get('verified'),
                    )
                )

class SystemSettings(object):
    @decorators.require_global_admin
    @decorators.require_login
    def GET(self, profile_type):
        settings= get_settings_from_db()
        return web.render(
            'panel/settings.html',
            settings=settings,
            profile_type=profile_type,
            msg=web.input().get('msg', None)
        )

    @decorators.require_global_admin
    @decorators.require_login
    def POST(self, profile_type):
        errors={}
        form = web.input(
            global_admin_ip_list=[], 
            admin_login_ip_list=[],
            restful_api_clients=[],
        )
        db_payload = utils._settings_form_payload_to_db(form)

        try:
            store_settings_in_db(db_payload, account="global")
        except Exception as e:
            errors.setdefault(profile_type, []).append(str(e))
        if errors:
            msg= utils._format_errors(errors)
            raise web.seeother(utils._redirect_url(BASE_URL, profile_type, msg=msg))
        raise web.seeother(utils._redirect_url(BASE_URL, profile_type, msg="UPDATED"))

class SystemSpampolicy():
    @decorators.require_preference_access('spampolicy')
    @decorators.require_global_admin
    @decorators.require_login
    def GET(self, profile_type, account="@."):
        ok, spam_data = lib_spampolicy.get_spam_policy(account=account)
        if not ok:
            errors = spam_data.get("errors") or spam_data
            msg = utils._format_errors(errors)
            raise web.seeother(utils._redirect_url(BASE_URL, profile_type, msg=msg))

        return web.render(
            'amavisd/spampolicy.html',
            profile_type=profile_type,
            spam_data= spam_data,
            size_symbols=SYMBOLS,
            msg=web.input().get('msg', None)
        )

    @decorators.require_preference_access('spampolicy')
    @decorators.require_global_admin
    @decorators.require_login
    @decorators.csrf_protected
    def POST(self, profile_type):
        form = web.input(
            banned_rulenames=[],
        )
        
        payload = utils._spampolicy_form_payload_to_db(form)

        policy_lib = lib_spampolicy.SpamPolicy(account="@.")
        ok, data, *rest = policy_lib.update_spam_policy(payload)

        if not ok:
            raise web.seeother(utils._redirect_url(BASE_URL, profile_type, msg=data))
        raise web.seeother(utils._redirect_url(BASE_URL, profile_type, msg="UPDATED"))

class SystemWBlist():
    @decorators.require_global_admin
    @decorators.require_login
    def GET(self, profile_type, tab=None ):
        cur_tab= tab or "wb"

        ok, rdns_data, *rest  = lib_wblist_rdns.WblistRDNS().get_wblist_rdns()
        if not ok:
            raise web.seeother(utils._redirect_url(BASE_URL, profile_type, msg=rdns_data))

        ok, wb_data = lib_wblist.get_wblist('@.')
        if not ok:
            errors = wb_data.get("errors") or wb_data
            msg = utils._format_errors(errors)
            raise web.seeother(utils._redirect_url(BASE_URL, profile_type, msg=msg))

        return web.render(
            'amavisd/wblist.html',
            wb_data=wb_data,
            rdns_data=rdns_data,
            profile_type=profile_type,
            tab = cur_tab,
            msg=web.input().get('msg', None),
        )

    @decorators.require_global_admin
    @decorators.require_login
    @decorators.csrf_protected
    def POST(self, profile_type, tab):
        errors= []
        account = '@.'

        form = web.input(
            rdns_whitelist=[],
            old_rdns_whitelist=[],
            add_rdns_whitelist=[],
            rdns_blacklist=[],
            old_rdns_blacklist=[],
            add_rdns_blacklist=[],
            whitelistSender=[],
            old_whitelistSender=[],
            add_whitelistSender=[],
            blacklistSender=[],
            old_blacklistSender=[],
            add_blacklistSender=[],
            whitelistRecipient=[],
            old_whitelistRecipient=[],
            add_whitelistRecipient=[],
            blacklistRecipient=[],
            old_blacklistRecipient=[],
            add_blacklistRecipient=[],
        )

        if tab == 'rdns':
            payload = utils._rdns_form_payload_to_db(form)

            lib_rdns =lib_wblist_rdns.WblistRDNS()
            
            def _process_list(key):
                # pot ser [], None o ['x']
                values = payload.get(key, [])
                if not values:
                    return None
                new_items = lib_rdns._normalize_list_domains_ips(values.get("add")) if values.get("add") else []
                remove_items = lib_rdns._normalize_list_domains_ips(values.get("remove")) if values.get("remove") else []
                if new_items or remove_items:
                    return new_items
                return None

            ok, result , *rest = lib_wblist_rdns.WblistRDNS().reset_wblist_rdns(
                whitelists=_process_list("rdns_whitelist"), 
                blacklists=_process_list("rdns_blacklist")
                )
            if not ok: 
                errors.append(f"Error {profile_type} {tab}: {result}")
        elif tab == 'wb':
            payload = utils._wblist_form_payload_to_db(form)

            ok, result , *rest = lib_wblist.update_wblist(account, payload)
            if not ok:
                errors.append(f"Error {profile_type} {tab}: {result}")

        if errors:
            msg = utils._format_errors(errors)
            raise web.seeother(utils._redirect_url(BASE_URL, profile_type, tab, msg=msg))
        return web.seeother(utils._redirect_url(BASE_URL, profile_type, tab, msg="UPDATED"))

class SystemGreylisting():
    @decorators.require_global_admin
    @decorators.require_login
    def GET(self, profile_type):
        errors= []

        ok, gl_data = lib_greylist.get_greylisting(account='@.')
        if not ok:
            raise web.seeother(utils._redirect_url(BASE_URL, profile_type, msg=gl_data))
        return web.render(
            'iredapd/greylist.html',
            profile_type=profile_type,
            gl_data=gl_data,
            msg=web.input().get('msg')
        )

    @decorators.require_global_admin
    @decorators.require_login
    @decorators.csrf_protected
    def POST(self, profile_type):
        form = web.input(
            whitelists=[],
            old_whitelists=[],
            add_whitelists=[], 
            whitelist_domains=[],
            old_whitelist_domains=[],  
            add_whitelist_domains=[],  
            )
        payload = utils._greylist_form_payload_to_db(form)

        ok, msg, *rest  = lib_greylist.update_greylisting("@.", payload)

        raise web.seeother(utils._redirect_url(BASE_URL, profile_type, msg=msg))

class SystemThrottle():
    @decorators.require_global_admin
    @decorators.require_login
    def GET(self, profile_type):
        ok, th_data = lib_throttle.get_throttle_setting('@.')
        if not ok:
            msg = utils._format_errors([
                f"Error obtaining throttling settings: {th_data.get('errors')}"
            ])
            raise web.seeother(utils._redirect_url(BASE_URL, profile_type, msg=msg))

        return web.render(
            'iredapd/throttle.html',
            th_data=th_data,
            profile_type=profile_type,
            size_symbols=SYMBOLS,
            msg=web.input().get('msg'))

    @decorators.require_global_admin
    @decorators.require_login
    @decorators.csrf_protected
    def POST(self, profile_type):
        form = web.input()
        account = form.get('account', '@.').strip().lower()
        errors = []

        payload = utils._throttle_form_payload_to_db(form)

        def _apply_throttle(direction_key, direction_enum):
            throttle_data = payload.get(direction_key, {})
            throttle = lib_throttle.Throttle(account, throttle_data, direction_enum)
            if throttle_data:
                ok, msg, *rest = throttle.update_throttle_settings()
                action = "updating"
            else:
                throttle.remove_throttle_tracking()
                ok, msg, *rest = throttle.remove_throttle_settings()
                action = "removing"

            if not ok:
                errors.append(
                    f"⚠️ Error {action} throttle {direction_enum} for {account}: {msg}"
                )

        _apply_throttle('throttle_inb', 'inbound')
        _apply_throttle('throttle_out', 'outbound')
        
        if errors:
            msg = utils._format_errors(errors)
            raise web.seeother(utils._redirect_url(BASE_URL, profile_type, msg=msg))
        raise web.seeother(utils._redirect_url(BASE_URL, profile_type, msg="UPDATED"))

class SystemLog:
    @decorators.require_global_admin
    @decorators.require_login
    def GET(self):
        form = web.input(
            page = 1, 
            msg=None, 
            _unicode=False
        )

        cur_page = int(form.page or 1) or 1
        payload = {
            "query_string": web.safestr(form.get('query_string','')),
            "event": web.safestr(form.get('event', 'all')),
            "domain": web.safestr(form.get('domain', 'all')),
            "admin": web.safestr(form.get('admin', 'all'))
        }

        ok, data, *rest = lib_log.Log().list_logs(payload=payload, page=cur_page)
        if not ok:
            raise web.seeother(utils._redirect_url(BASE_URL, "log", page=1, msg=data))

        return web.render(
            'panel/log.html',
            event=payload['event'],
            domain=payload['domain'],
            admin=payload['admin'],
            query_string=payload['query_string'],
            log_events=LOG_EVENTS,
            cur_page= data['page'],
            total=data['total'],
            entries=data['records'],
            all_domains=data['all_domains'],
            all_admins=data['all_admins'],
            msg=form.get('msg')
        )

    @decorators.require_global_admin
    @decorators.require_login
    @decorators.csrf_protected
    def POST(self):
        form = web.input(
            id=[],
            page = 1,
            _unicode=False
        )
        cur_page = int(form.page or 1) or 1

        ids = form.get('id', [])
        action = form.get('action', 'delete')
        delete_all = form.get('action') == 'deleteAll'

        if action in {'delete', 'deleteAll'}:
            if delete_all or ids:
                ok, data, *rest = lib_log.Log().delete_logs(ids=ids, delete_all=delete_all)
            else:
                data = 'INVALID_ACTION'

            raise web.seeother(
                utils._redirect_url(BASE_URL, "log", 
                    domain=form.get('domain'),
                    admin=form.get('admin'),
                    event=form.get('event'),
                    query_string=form.get('query_string'),
                    page=1 if delete_all else cur_page, 
                    msg=data,
                )
            )

class SystemLogExport(object):
    @decorators.require_login
    @decorators.require_domain_access
    def GET(self):
        return self._handle_export()

    @decorators.csrf_protected
    @decorators.require_login
    @decorators.require_domain_access
    def POST(self):
        return self._handle_export()

    def _handle_export(self):
        form = web.input(
            format='xls',
            query_string=None,
            event = "all",
            domain = "all",
            admin = "all",
            zip=None,
            msg=None, 
            _unicode=False
        )

        payload = {
            k: v for k, v in {
                "query_string": form.get("query_string"),
                "event": web.safestr(form.get('event', 'all')),
                "domain": web.safestr(form.get('domain', 'all')),
                "admin": web.safestr(form.get('admin', 'all'))
            }.items() if v not in (None, "")
        }

        has_filters = bool(
            payload.get("query_string") or
            payload.get("event") not in (None, "all") or
            payload.get("domain") not in (None, "all") or
            payload.get("admin") not in (None, "all")
        )

        ok, data, *rest = lib_log.Log().list_logs(page=0, payload=payload)
        if not ok:
            raise web.seeother(utils._redirect_url(BASE_URL, "log", page=1, msg=data))

        exporter = ExporterFactory.from_SQL(
            format=form.get('format', 'xls'),
            schema=LOG_EXPORT_SCHEMA,
            title=f"Admin Logs",
            zip=bool(form.get('zip')),
        )

        exporter.apply_headers(
            web,
            base_filename="log_filtered" if has_filters else "log_all"
        )

        return exporter.export(data.get('records', []))
