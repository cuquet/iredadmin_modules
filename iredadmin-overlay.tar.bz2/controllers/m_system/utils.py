# controllers/m_system/utils.py
import web
from urllib.parse import urlencode, quote
from typing import Union, List, Tuple, Dict, Set

from libs.iredutils import (
    setting_kvs_map,
    is_boolean,
    is_integer,
    is_positive_integer,
    is_not_negative_integer, 
)
from controllers.m_amavisd.utils import _spampolicy_form_payload_to_db, _wblist_form_payload_to_db
from controllers.m_iredapd.utils import _throttle_form_payload_to_db, _greylist_form_payload_to_db, _rdns_form_payload_to_db
from libs.m_system import form_utils

session = web.config.get('_session', {})

def _redirect_url(base:str ="/", *args: str, **kwargs: str) -> str:
    """
        Construeix una URL amb path dinàmic (via *args) i paràmetres de query (via **kwargs**).

        Aquesta funció combina parts de camí (path) i paràmetres GET de manera segura per formar
        una URL final. Els valors dels paràmetres s'escapen amb `web.urlquote()` per garantir
        la codificació correcta dels caràcters especials.

        Args:
            base (str, optional): Path base inicial (p. ex. "/users"). Per defecte és "/".
            *args (str): Parts addicionals del path (p. ex. "example.org", "john.doe", "profile").
            **kwargs (str): Paràmetres de query (p. ex. page=2, msg="OK"). Els valors amb `None` s'ignoren.

        Returns:
            str: La URL final combinada amb path i query string.

        Example:
            >>> _redirect_url("/users", "example.org", "john.doe", "profile", page=2, msg="OK")
            '/users/example.org/john.doe/profile?page=2&msg=OK'

        Notes:
            - Aquesta implementació fa servir `web.urlquote()` per coherència amb web.py
            i per evitar dependències externes.
            - Alternativament, es podria fer servir `urllib.parse.urlencode()` per una codificació
            segons l'estàndard RFC 3986 i suport de llistes de valors (amb `doseq=True`).

            Exemple equivalent amb `urlencode()`::

                from urllib.parse import urlencode

                def _redirect_url(base="/", *args, **kwargs):
                    path_parts = [base] + [str(part).strip("/") for part in args if part]
                    base_url = "/".join(path_parts)

                    params = {k: v for k, v in kwargs.items() if v is not None}
                    return f"{base_url}?{urlencode(params)}" if params else base_url
    """
    # Construcció del path
    path_parts = [base.rstrip("/") ] + [str(part).strip("/") for part in args if part]
    base_url = "/".join(path_parts) or "/"

    # Construcció dels paràmetres
    params = {}
    for k, v in kwargs.items():
        if v is None:
            continue
        v = str(v).strip()
        if v == "":
            continue
        params[k] = web.urlquote(v)

    if params:
        query_string = "&".join(f"{k}={v}" for k, v in params.items())
        return f"{base_url}?{query_string}"

    return base_url

def _canonical_redirect(path: str, params: dict, safe: str = "/:@.,") -> Dict:
    """
    Redirigeix a la URL canònica si el path o la query no coincideixen.
    Elimina paràmetres buits automàticament.
    """
    canonical_path = quote(path, safe=safe)
    
    clean_params = {k: v for k, v in params.items() if v not in (None, "", [])}
    target_query = urlencode(sorted(clean_params.items()))
    
    current_query = web.ctx.query.lstrip('?')
    if current_query:
        current_query = urlencode(sorted(web.input(_unicode=False).items()))

    if web.ctx.path != canonical_path or current_query != target_query:
        url = canonical_path 
        if target_query:
            url += '?' + target_query
        raise web.seeother(url)

    return clean_params

def _format_errors(errors: Union[List, Dict, Set, Tuple, None]) -> str:
    """
        Concatena missatges d'error en un sol string i els fa URL-safe.
        Accepta tant llistes, dicts com conjunts o tuples.
    """
    if not errors:
        return ""
    
    # Si és un dict → "clau: valor"
    if isinstance(errors, dict):
        parts = [f"{str(k)}: {str(v)}" for k, v in errors.items() if v]

    # Si és iterable (llista, tuple, set)
    elif isinstance(errors, (list, tuple, set)):
        parts = [str(e) for e in errors if e]

    # Altres tipus inesperats (una cadena sola, etc.)
    else:
        parts = [str(errors).strip()]

    return web.urlquote("; ".join(parts))

def _settings_form_payload_to_db(form: Dict) -> dict:
    """
        Converteix el payload rebut del formulari (web.input())
        → dict apte per passar directament a store_settings_in_db.
    """
    db_data = {}

    for key, raw in form.items():
        if raw == "on":
            db_data[key] = True
            continue

        if raw in ("", None):
            db_data[key] = None
            continue

        if isinstance(raw, list):
            # Netegem llistes (ex: textareas processades per web.input amb [])
            cleaned = []
            for val in raw:
                for line in str(val).splitlines():
                    line = line.strip()
                    if line:
                        cleaned.append(line)
            db_data[key] = cleaned if cleaned else None
            continue

        # Si té salts de línia → llista
        if "\n" in raw:
            db_data[key] = [line.strip() for line in raw.splitlines() if line.strip()]
            continue
        
        # Per defecte: queda com string
        db_data[key] = raw.strip()

    # 🔎 Normalitza segons validators de settings_kvs_map
    for key, value in list(db_data.items()):
        validators = setting_kvs_map.get(key, {}).get("validators", [])

        if is_boolean in validators:
            # qualsevol valor present → True, sinó False
            db_data[key] = bool(value)
        elif any(vf in validators for vf in [is_integer, is_positive_integer, is_not_negative_integer]):
            try:
                db_data[key] = int(value)
            except Exception:
                db_data[key] = 0  # o None, segons vulguis
        # si és llista ja la tenim neta
        # si és text → queda tal qual

    # 🔎 Assegura que tots els booleans existents queden representats
    for key, opts in setting_kvs_map.items():
        if is_boolean in opts.get("validators", []) and key not in db_data:
            db_data[key] = False

    return db_data
