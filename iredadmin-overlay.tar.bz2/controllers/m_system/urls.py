# controllers/m_system/urls.py
urls = [
    '/switch/skin/([a-z0-9_-]+)', 'controllers.m_system.controller.SwitchSkin',
    '/system/(settings)', 'controllers.m_system.controller.SystemSettings',
    '/system/(spampolicy)', 'controllers.m_system.controller.SystemSpampolicy',
    '/system/(wblist)(?:/(wb|rdns))?', 'controllers.m_system.controller.SystemWBlist',
    '/system/(throttle)', 'controllers.m_system.controller.SystemThrottle',
    '/system/(greylisting)', 'controllers.m_system.controller.SystemGreylisting',
    '/system/log/export', 'controllers.m_system.controller.SystemLogExport',
    '/system/log', 'controllers.m_system.controller.SystemLog',
    '/activities/system/log/export', 'controllers.m_system.controller.SystemLogExport',
    '/activities/system/log', 'controllers.m_system.controller.SystemLog',
    '/system', 'controllers.m_system.controller.SystemLog',
    '/verify/domain_ownership', 'controllers.m_system.controller.VerifyOwnership',
]
