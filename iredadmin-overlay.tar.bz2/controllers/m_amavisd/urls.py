# controllers/m_amavisd/urls.py
from libs.regxes import email as e, domain as d

urls = [
    # Search activity logs.
    '/activities/search', 'controllers.m_amavisd.controller.SearchLog',

    # Amavisd export
    '/activities/(received|sent)/export', 'controllers.m_amavisd.controller.UrlInOutExport',
    '/activities/(received|sent)/export/(user)/(%s)' % e, 'controllers.m_amavisd.controller.UrlInOutExport',
    '/activities/(received|sent)/export/(domain)/(%s)' % d, 'controllers.m_amavisd.controller.UrlInOutExport',

    # View log of received-send mails.
    '/activities/(received|sent)', 'controllers.m_amavisd.controller.UrlInOut',
    '/activities/(received|sent)/(user)/(%s)' % e, 'controllers.m_amavisd.controller.UrlInOut',
    '/activities/(received|sent)/(domain)/(%s)' % d, 'controllers.m_amavisd.controller.UrlInOut',

    # Quarantined Mails export
    '/activities/quarantined/export', 'controllers.m_amavisd.controller.QuarantinedMailsExport',
    '/activities/quarantined/export/(spam|virus|banned|badheader|clean|all)', 'controllers.m_amavisd.controller.QuarantinedMailsExport',
    '/activities/quarantined/export/(spam|virus|banned|badheader|clean|all)/(user)/(%s)' % e, 'controllers.m_amavisd.controller.QuarantinedMailsExport',
    '/activities/quarantined/export/(spam|virus|banned|badheader|clean|all)/(domain)/(%s)' % d, 'controllers.m_amavisd.controller.QuarantinedMailsExport',

    # Quarantined Mails
    '/activities/quarantined', 'controllers.m_amavisd.controller.QuarantinedMails',
    '/activities/quarantined/(spam|virus|banned|badheader|clean|all)', 'controllers.m_amavisd.controller.QuarantinedMails',
    '/activities/quarantined/(spam|virus|banned|badheader|clean|all)/(user)/(%s)' % e, 'controllers.m_amavisd.controller.QuarantinedMails',
    '/activities/quarantined/(spam|virus|banned|badheader|clean|all)/(domain)/(%s)' % d, 'controllers.m_amavisd.controller.QuarantinedMails',

    # Get RAW message of quarantined mail by mail_id.
    '/activities/quarantined/raw/(.*)', 'controllers.m_amavisd.controller.GetRawMessageOfQuarantinedMail',

    # Per-user preferences: wblist, spam control
    #'/preferences/(wblist)', 'controllers.m_amavisd.wblist.Profile',
    #'/preferences/(spampolicy)', 'controllers.m_amavisd.spampolicy.Profile',
]

