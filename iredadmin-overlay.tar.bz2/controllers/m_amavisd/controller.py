# controllers/m_amavisd/controller.py
import web
from collections.abc import Iterable
from typing import Any, Union, Dict

from libs.iredutils import is_domain, is_email

from controllers.m_amavisd import utils
from libs.m_system.mixins import ExporterFactory, AMAVISD_LOG_EXPORT_SCHEMA, QUARANTINE_EXPORT_SCHEMA
from libs.m_crudlib import decorators
from libs.m_amavisd import log as lib_amavisd, quarantine as lib_quarantine

session = web.config.get('_session')

DEFAULT_LOG_TYPE = "all"
BASE_URL_LOG = "/activities"
BASE_URL_Q = f"{BASE_URL_LOG}/quarantined/"

def _enforce_mail_user_scope(account_type: Union[str, None], account: Union[str, None]) -> None:
    """
        Restricció d'accés per a mail users:
        - admins (global/user/mail) passen sempre.
        - mail_user només pot accedir al seu propi compte (account_type == 'user').
    """
    if session.get("is_global_admin") or session.get("is_user_admin") or session.get("is_mail_admin"):
        return

    if session.get("is_mail_user"):
        if account_type == "user" and account and str(account).lower() == session.get("username"):
            return
        raise web.seeother("/preferences?msg=PERMISSION_DENIED")

    # via alternativa: sessió sense rol vàlid
    raise web.seeother("/login?msg=LOGIN_REQUIRED")

def _parse_records(raw_records: Any, username: str) -> list[dict[str, Union[str, None]]]:
    """
        Converteix una llista de cadenes en registres estructurats amb `mail_id` i `secret_id`.

        Aquesta funció processa una o més cadenes del tipus `"mailid+secretid"` (separades per comes)
        i retorna una llista de diccionaris amb claus `mail_id`, `secret_id` i `requested_by`.

        Args:
            raw_records (Any): Pot ser una cadena (ex. `"abc123+xyz,def456+uvw"`) o un iterable de cadenes.
                - Si és una cadena, es divideix automàticament per comes.
                - Si no és iterable, es retorna una llista buida.
            username (str): Nom d’usuari que es desarà al camp `"requested_by"` de cada registre.

        Returns:
            list[dict[str, str | None]]: Llista de registres amb els camps:
                - `"mail_id"`: Identificador principal del missatge.
                - `"secret_id"`: Clau secreta associada (pot ser `None`).
                - `"requested_by"`: Usuari que ha fet la petició.

        Example:
            >>> _parse_records("a1b2c3+def,g4h5i6+jkl", "admin@example.org")
            [
                {'mail_id': 'a1b2c3', 'secret_id': 'def', 'requested_by': 'admin@example.org'},
                {'mail_id': 'g4h5i6', 'secret_id': 'jkl', 'requested_by': 'admin@example.org'}
            ]

            >>> _parse_records(["x1+y1", "x2+y2"], "user@domain.tld")
            [
                {'mail_id': 'x1', 'secret_id': 'y1', 'requested_by': 'user@domain.tld'},
                {'mail_id': 'x2', 'secret_id': 'y2', 'requested_by': 'user@domain.tld'}
            ]

        Notes:
            - Si una cadena no conté el caràcter `'+'`, el camp `secret_id` serà `None`.
            - Els espais abans/després de cada element s'eliminen automàticament.
    """
    if isinstance(raw_records, str):
        raw_records = raw_records.split(",")
    elif isinstance(raw_records, Iterable):
        # Aplanem tots els elements que puguin contenir múltiples parells separats per comes
        flattened = []
        for item in raw_records:
            if isinstance(item, str):
                flattened.extend(item.split(","))
        raw_records = flattened
    else:
        return []
    
    records = []
    for r in raw_records:
        pair = r.strip()
        if not pair:
            continue
        mail_id, secret_id = (pair.split("+", 1) + [None])[:2]
        records.append({
            "mail_id": mail_id,
            "secret_id": secret_id,
            "requested_by": username,
        })
    return records

class UrlInOut:
    @decorators.require_login
    def GET(self, log_type=None, account_type=None, account=None):
        form = web.input(
            page=1,
            msg=None,
            query_string=None,
            date_from=None,
            date_to=None, 
            _unicode=False
        )

        cur_page = int(form.page or 1) or 1
        _enforce_mail_user_scope(account_type, account)

        errors: Dict[str, str] = {}
        if account_type == "domain" and account and not is_domain(account):
            errors["account"] = "INVALID_DOMAIN_NAME"
        elif account_type == "user" and account and not is_email(account):
            errors["account"] = "INVALID_MAIL"

        log_lib = lib_amavisd.Log(
            log_type,
            account_type,
            account,
            page=cur_page, 
            is_global_admin=session.get("is_global_admin")
        )

        filters = {
            "query_string": form.query_string or "",
            "date_from": form.date_from or "",
            "date_to": form.date_to or "",
            "page":cur_page,
        }
        clean_filters = utils._canonical_redirect(
            path=web.ctx.path,
            params=filters
        )

        ok, data, *rest = log_lib.get_inout_mails(payload=clean_filters)
        if not ok:
            errors["get_inout_mails"] = str(data)
        
        # Si tenim errors, fem redirect amb tots concatenats
        if errors:
            msg = utils._format_errors(errors)
            raise web.seeother(
                utils._redirect_url(BASE_URL_LOG, log_type, account_type, account, page=cur_page, msg=msg)
            )

        return web.render(
            'amavisd/inout.html',
            log_type=log_type,
            account_type=account_type,
            account=account,
            data=data,
            msg=web.input().get('msg')
        )

    @decorators.csrf_protected
    @decorators.require_login
    def POST(self, log_type=None, account_type=None, account=None):
        form = web.input(
            record=[],
            page=1,
            _unicode=False
        )
        cur_page = int(form.page or 1) or 1
        _enforce_mail_user_scope(account_type, account)
        action = str(form.get('action', ''))

        records = _parse_records(form.get("record", []), session.get("username"))     

        log_lib = lib_amavisd.Log(log_type, account_type, account, cur_page, session.get("is_global_admin"))

        msg = ""
        ok = False
        actions = {
            "delete": lambda: log_lib.delete_records_by_mailid(records),
            "deleteall": lambda: log_lib.delete_records_all() if session.get("is_global_admin") else (False, "PERMISSION_DENIED"),
        }

        if not records and action != "deleteall":
            ok, msg = False, "INVALID_MAILID"
        elif action in actions:
            ok, msg, *rest = actions[action]()
        else:
            ok, msg = False, "INVALID_ACTION"

        raise web.seeother(utils._redirect_url(BASE_URL_LOG, log_type, account_type, account, page=cur_page, msg=msg))

class UrlInOutExport(object):
    @decorators.require_login
    def GET(self, log_type=None, account_type=None, account=None):
        _enforce_mail_user_scope(account_type, account)
        return self._handle_export(log_type, account_type, account)

    @decorators.csrf_protected
    @decorators.require_login
    def POST(self, log_type=None, account_type=None, account=None):
        _enforce_mail_user_scope(account_type, account)
        return self._handle_export(log_type, account_type, account)

    def _handle_export(self, log_type, account_type, account):
        form = web.input(
            format='xls',
            query_string=None,
            date_from=None,
            date_to=None,
            zip=None,
            _unicode=False
        )

        payload = {
            k: v for k, v in {
                "query_string": form.get("query_string"),
                "date_from": form.get("date_from"),
                "date_to": form.get("date_to"),
            }.items() if v not in (None, "")
        }

        log_lib = lib_amavisd.Log(
            log_type,
            account_type,
            account,
            page=0,
            is_global_admin=session.get("is_global_admin"),
        )

        ok, data, *rest = log_lib.get_inout_mails(payload=payload)
        if not ok:
            raise web.seeother(
                utils._redirect_url(
                    BASE_URL_LOG, log_type, account_type, account, page=1, msg=data
                )
            )

        has_filters = bool(payload)

        exporter = ExporterFactory.from_SQL(
            format=form.get('format', 'xls'),
            schema=AMAVISD_LOG_EXPORT_SCHEMA,
            title=f"Amavisd {log_type.upper()} logs",
            zip=bool(form.get('zip')),
        )

        parts = ["amavisd", log_type]
        if account_type and account:
            parts.append(f"{account_type}_{account}")
        if has_filters:
            parts.append("filtered")
        base_filename = "_".join(parts)

        exporter.apply_headers(
            web,
            base_filename=base_filename
        )

        return exporter.export(data.get("records", []))

class QuarantinedMails:
    def _normalize_log_type(self, log_type: Union[str, None]) -> str:
        return log_type or DEFAULT_LOG_TYPE

    @decorators.require_login
    def GET(self, log_type=None, account_type=None, account=None):
        log_type = self._normalize_log_type(log_type)
        form = web.input(
            page=1, 
            msg=None,
            query_string=None,
            date_from=None,
            date_to=None,
            _unicode=False
        )
        cur_page = int(form.page or 1) or 1
        _enforce_mail_user_scope(account_type, account)

        errors: Dict[str, str] = {}
        filters = {
            "query_string": form.query_string or "",
            "date_from": form.date_from or "",
            "date_to": form.date_to or "",
            "page": cur_page,
        }
        clean_filters = utils._canonical_redirect(
            path=web.ctx.path,
            params=filters
        )
        
        lib_q = lib_quarantine.Quarantine(
            content_type=log_type,
            account_type=account_type,
            account=account,
            page=cur_page,
            is_global_admin=session.get("is_global_admin"),
        )

        ok, counts, *rest = lib_q.count_quarantined_mails(payload=clean_filters)
        if not ok:
            errors["counts"] = counts

        ok, data, *rest = lib_q.get_quarantined_mails(payload=clean_filters)
        if not ok:
            errors["records"] = data
        
        if errors:
            msg = utils._format_errors(errors)
            raise web.seeother(
                utils._redirect_url(
                    BASE_URL_Q,
                    log_type,
                    account_type,
                    account,
                    page=cur_page,
                    query_string=clean_filters.get("query_string"),
                    date_from=clean_filters.get("date_from"),
                    date_to=clean_filters.get("date_to"),
                    msg=msg
                )
            )

        return web.render(
            "amavisd/quarantined.html",
            account=account,
            account_type=account_type,
            content_type=log_type,
            data=data,
            msg=form.msg,
        )

    @decorators.csrf_protected
    @decorators.require_login
    def POST(self, log_type=None, account_type=None, account=None):
        log_type = self._normalize_log_type(log_type)
        form = web.input(
            record=[], 
            action=None, 
            page=1,
            query_string=None,
            date_from=None,
            date_to=None
        )
        action = (form.get("action", "")).lower()
        cur_page = int(form.page or 1) or 1
        _enforce_mail_user_scope(account_type, account)
        
        errors: Dict[str, str] = {}
        records = _parse_records(form.get("record", []), session.get("username"))

        lib_q = lib_quarantine.Quarantine(
            content_type=log_type,
            account_type=account_type,
            account=account,
            is_global_admin=session.get("is_global_admin")
        )

        msg = ""
        ok = False
        actions = {
            "release": lambda: lib_q.release_quarantined_mails(records=records),
            "release_whitelist_sender": lambda: lib_q.release_quarantined_with_whitelist(records, scope="sender"),
            "release_whitelist_sender_domain": lambda: lib_q.release_quarantined_with_whitelist(records, scope="sender_domain"),
            "release_whitelist_sender_subdomain": lambda: lib_q.release_quarantined_with_whitelist(records, scope="sender_subdomain"),
            "delete": lambda: lib_q.delete_records_by_mailid(records),
            "delete_blacklist_sender": lambda: lib_q.delete_quarantined_with_blacklist(records, scope="sender"),
            "delete_blacklist_sender_domain": lambda: lib_q.delete_quarantined_with_blacklist(records, scope="sender_domain"),
            "delete_blacklist_sender_subdomain": lambda: lib_q.delete_quarantined_with_blacklist(records, scope="sender_subdomain"),
            "deleteall": lambda: (
                lib_q.delete_quarantined_all() if session.get("is_global_admin")
                else (False, "PERMISSION_DENIED")
            ),
        }

        if not records and action not in ("deleteall"):
            ok, msg = (False, "INVALID_MAILID")
        elif action in actions:
            ok, msg, *rest = actions[action]()
        else:
            ok, msg = (False, "INVALID_ACTION")

        if not ok:
            errors[action or "action"] = msg
            msg = utils._format_errors(errors)

        raise web.seeother(
            utils._redirect_url(
                BASE_URL_Q,
                log_type,
                account_type,
                account,
                page=cur_page,
                query_string=form.get("query_string"),
                date_from=form.get("date_from"),
                date_to=form.get("date_to"),
                msg=msg
            )
        )

class QuarantinedMailsExport(object):
    @decorators.require_login
    def GET(self, log_type=None, account_type=None, account=None):
        _enforce_mail_user_scope(account_type, account)
        return self._handle_export(log_type, account_type, account)

    @decorators.csrf_protected
    @decorators.require_login
    def POST(self, log_type=None, account_type=None, account=None):
        _enforce_mail_user_scope(account_type, account)
        return self._handle_export(log_type, account_type, account)

    def _handle_export(self, log_type, account_type, account):
        log_type = log_type or DEFAULT_LOG_TYPE

        form = web.input(
            format="xls",
            zip=None,
            query_string=None,
            date_from=None,
            date_to=None,
            _unicode=False
        )

        payload = {
            k: v for k, v in {
                "query_string": form.get("query_string"),
                "date_from": form.get("date_from"),
                "date_to": form.get("date_to"),
            }.items() if v not in (None, "")
        }

        lib_q = lib_quarantine.Quarantine(
            content_type=log_type,
            account_type=account_type,
            account=account,
            page=0,
            is_global_admin=session.get("is_global_admin"),
        )

        ok, data, *rest = lib_q.get_quarantined_mails(payload=payload)
        if not ok:
            raise web.seeother(
                utils._redirect_url(
                    BASE_URL_Q,
                    log_type,
                    account_type,
                    account,
                    page=1,
                    query_string=payload.get("query_string"),
                    date_from=payload.get("date_from"),
                    date_to=payload.get("date_to"),
                    msg=data
                )
            )

        exporter = ExporterFactory.from_SQL(
            format=form.get("format", "xls"),
            schema=QUARANTINE_EXPORT_SCHEMA,
            title=f"Quarantined mails ({log_type})",
            zip=bool(form.get('zip')),
        )

        parts = ["amavisd", "quarantine", log_type]
        if account_type and account:
            parts.append(f"{account_type}_{account}")
        if payload:
            parts.append("filtered")

        base_filename = "_".join(parts)

        exporter.apply_headers(
            web,
            base_filename=base_filename
        )

        return exporter.export(data.get("records", []))

class GetRawMessageOfQuarantinedMail:
    @decorators.require_admin_login
    def GET(self, mail_id):
        form = web.input(_unicode=False)
        record_tokens = form.get('record_tokens')
        ok, data, *rest = lib_quarantine.Quarantine().get_quarantined_raw_mail(mail_id)

        if not ok:
            raise web.seeother(utils._redirect_url(BASE_URL_Q, msg=data))
        return web.render(
            'amavisd/quarantined_raw.html',
            mail=data,
            mail_id=mail_id,
            record_tokens=record_tokens
        )

    @decorators.require_admin_login
    def POST(self, mail_id):
        form = web.input()
        action = (form.get("action", "")).lower()
        record_tokens = form.get('record_tokens')

        records = _parse_records(record_tokens, session.get("username"))
        q = lib_quarantine.Quarantine(is_global_admin=session.get("is_global_admin"))

        actions = {
            "release": lambda: q.release_quarantined_mails(records),
            "delete": lambda: q.delete_records_by_mailid(records),
        }

        ok, msg, *rest = (actions[action]() if action in actions else (False, "INVALID_ACTION"))

        raise web.seeother(utils._redirect_url(BASE_URL_Q, msg=msg) if ok else utils._redirect_url(BASE_URL_Q, mail_id, msg=msg))

class SearchLog:
    @decorators.csrf_protected
    @decorators.require_admin_login
    def POST(self):
        '''
            log_type = next((lt for lt in ("received", "sent", "quarantined") if i.get(lt)), "sent")
            
            és equivalent a :

                if form.get("received"):
                    logType = "received"
                elif form.get("sent"):
                    logType = "sent"
                elif form.get("quarantined"):
                    logType = "quarantined"
                else:
                    logType = "sent"  # valor per defecte
            
            1. tuple base: ("received", "sent", "quarantined")
            2. Generador (generator expression): (lt for lt in (...) if form.get(lt))
                — Itera per cada lt (log type) i comprova si form.get(lt) té algun valor truthy (no buit, no None, etc.).
                — Només emet (yield) els lt que compleixen la condició.
            3. next(...): next(generator, "sent")
                — Agafa el primer element produït pel generador.
                — Si el generador no produeix res (és a dir, cap form.get(lt) és cert), retorna el valor per defecte "sent".
        '''
        form = web.input(_unicode=False)
        account = form.get('account', '')
        log_type = form.get('log_type', 'sent')
        if is_email(account):
            account_type = 'user'
        elif is_domain(account):
            account_type = 'domain'
        else:
            msg = "INVALID_ACCOUNT"
            raise web.seeother(utils._redirect_url(BASE_URL_LOG, log_type, msg=msg))

        base_args = (BASE_URL_LOG, log_type)
        extra_args = ("all", account_type, account) if log_type == "quarantined" else (account_type, account)

        raise web.seeother(utils._redirect_url(*base_args, *extra_args))
