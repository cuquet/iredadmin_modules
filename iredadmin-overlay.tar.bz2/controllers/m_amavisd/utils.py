# controllers/m_amavisd/utils.py
import web
from typing import Dict

import settings

from libs.m_system.mixins import Direction, ListType
from libs.m_amavisd.spampolicy import (
    DEFAULT_DB_SPAMPOLICY,
    DEFAULT_DB_SPAMPOLICY_SYSTEM_OVERRIDE,
    DEFAULT_SPAM_TAG_LEVEL,
    DEFAULT_SPAM_TAG2_LEVEL,
    DEFAULT_SPAM_KILL_LEVEL,
    BAN_RULES_LIST
)
from libs.m_system import form_utils


MAP_SPAMPOLICY_PAYLOAD_TO_DB = {
    'policy_name': 'policy_name',
    'effectivebypriority':'effectivebypriority',
    'enable_spam_checks': 'bypass_spam_checks',
    'enable_virus_checks': 'bypass_virus_checks',
    'enable_banned_checks': 'bypass_banned_checks',
    'enable_header_checks': 'bypass_header_checks',
    'quarantine_spam': 'spam_quarantine_to',
    'quarantine_virus': 'virus_quarantine_to',
    'quarantine_banned': 'banned_quarantine_to',
    'quarantine_bad_header': 'bad_header_quarantine_to',
    'prefix_spam_in_subject': 'spam_subject_tag2',
    'always_insert_x_spam_headers': 'always_insert_x_spam_headers',
    'spam_score': 'spam_tag2_level',
    'spam_kill_level': 'spam_kill_level',
    'spam_tag_level': 'spam_tag_level',
    'banned_rulenames':'banned_rulenames',
    'message_size_limit':'message_size_limit',
    }

MAP_WB_PAYLOAD_TO_DB = {
    "whitelistSender":"whitelistSender",
    "blacklistSender":"blacklistSender",
    "whitelistRecipient":"whitelistRecipient",
    "blacklistRecipient":"blacklistRecipient",
    }

def _redirect_url(*args, **kwargs):
    from controllers.m_system import utils as u
    return u._redirect_url(*args, **kwargs)

def _canonical_redirect(*args, **kwargs):
    from controllers.m_system.utils import _canonical_redirect as _canonical_r
    return _canonical_r(*args, **kwargs)

def _format_errors(*args, **kwargs):
    from controllers.m_system import utils as u
    return u._format_errors(*args, **kwargs)

def _normalize_inout_type(value: str) -> Direction:
    try:
        return Direction(value.lower())
    except ValueError:
        raise web.BadRequest(f"Invalid direction: {value}")

def _normalize_list_type(value: str) -> ListType:
    try:
        return ListType(value.lower())
    except ValueError:
        raise web.BadRequest(f"Invalid list type: {value}")


def _wblist_form_payload_to_db(form: Dict) -> Dict:
    wb_data={}
    for payload_key, db_key in MAP_WB_PAYLOAD_TO_DB.items():
        _ok, _val = form_utils.populate_form_list_filtered(form, payload_key)
        if _ok:
            wb_data[db_key] = _val

    return wb_data


def _spampolicy_form_payload_to_db(form: dict) -> dict:
    db_data = DEFAULT_DB_SPAMPOLICY.copy()
    if form.get('policy_name') == "@.":
        db_data.update(DEFAULT_DB_SPAMPOLICY_SYSTEM_OVERRIDE)
        
    found = False
    for payload_key, db_key in MAP_SPAMPOLICY_PAYLOAD_TO_DB.items():
        if payload_key not in form:
            continue
        
        found = True
        val = form.get(payload_key)

        if payload_key.startswith('enable_'):
            # enable_* és l’oposat: yes → N (no bypass), no → Y (bypass)
            db_data[db_key] = 'N' if (val.lower() == 'yes' or val.lower() == payload_key) else 'Y'

        elif payload_key.startswith('quarantine_'):
            if val.lower() == 'yes' or val.lower() == payload_key:
                db_data[db_key] = db_key.replace('_quarantine_to', '') + '-quarantine'
            else:
                db_data[db_key] = None

        elif payload_key == 'prefix_spam_in_subject':
            db_data[db_key] = settings.AMAVISD_SPAM_SUBJECT_PREFIX if val.lower() == 'yes' else None

        elif payload_key == 'spam_score':
            db_data[db_key] = float(val) if val and val.strip() else None 

        elif payload_key == 'always_insert_x_spam_headers':
            if val.lower() == 'yes':
                db_data['spam_tag_level']  = -999
                db_data['spam_tag2_level'] = 5.0
                db_data['spam_kill_level'] = 6.5
            else:
                db_data['spam_tag_level']  = DEFAULT_SPAM_TAG_LEVEL
                db_data['spam_tag2_level'] = DEFAULT_SPAM_TAG2_LEVEL
                db_data['spam_kill_level'] = DEFAULT_SPAM_KILL_LEVEL

        elif payload_key == 'policy_name':
            db_data[db_key] = str(val)
        
        elif payload_key =='banned_rulenames':
            valid_rule_names = {k for k, *_ in BAN_RULES_LIST}
            rules = [v for v in (val or []) if v in valid_rule_names]
            db_data[db_key] = ",".join(rules)

        elif payload_key == 'message_size_limit':
            n = form_utils.quota_transformation(payload_key, form)
            if n not in ("", None):
                db_data[db_key] = n

        else:
            if val not in ("", None):
                db_data[db_key] = val
            # valid_db_keys = set(DEFAULT_DB_SPAMPOLICY.keys())
            # if val is not None and str(val).strip() != '' and db_key in valid_db_keys:
            #     db_data[db_key] = val

    if not found:
        return {}

    # ajustar enable_* que NO han vingut al form → per defecte = NO → bypass = Y
    for payload_key, db_key in MAP_SPAMPOLICY_PAYLOAD_TO_DB.items():
        if payload_key.startswith("enable_") and payload_key not in form:
            db_data[db_key] = "Y"

    # ajustar lovers segons quarantines
    db_data['spam_lover']         = 'N' if db_data.get('spam_quarantine_to')         else 'Y'
    db_data['virus_lover']        = 'N' if db_data.get('virus_quarantine_to')        else 'Y'
    db_data['banned_files_lover'] = 'N' if db_data.get('banned_quarantine_to')       else 'Y'
    db_data['bad_header_lover']   = 'N' if db_data.get('bad_header_quarantine_to')   else 'Y'

    return db_data

def _spampolicy_form_db_to_payload(db_data: dict) -> dict:
    payload_data = {}

    for payload_key, db_key in MAP_SPAMPOLICY_PAYLOAD_TO_DB.items():
        val = db_data.get(db_key)

        if payload_key.startswith('enable_'):
            payload_data[payload_key] = 'yes' if val == 'N' else 'no'

        elif payload_key.startswith('quarantine_'):
            payload_data[payload_key] = 'yes' if val else 'no'

        elif payload_key == 'prefix_spam_in_subject':
            payload_data[payload_key] = val or None

        elif payload_key == 'spam_score':
            payload_data[payload_key] = float(val) if val else DEFAULT_SPAM_TAG2_LEVEL
        
        elif payload_key == 'always_insert_x_spam_headers':
            if (
                db_data.get('spam_tag_level') == -999
                and db_data.get('spam_tag2_level') == 5.0
                and db_data.get('spam_kill_level') == 6.5
            ):
                payload_data[payload_key] = 'yes'
            else:
                payload_data[payload_key] = 'no'
        
        elif payload_key == 'policy_name':
            payload_data[payload_key] = str(val)
        
        elif db_key == 'banned_rulenames':
            payload_data[payload_key] = val.split(',') if val else []

        else:
            if val is not None:
                payload_data[payload_key] = val

    return payload_data


def _spampolicy_api_payload_to_db(api_data: dict) -> dict:
    db_data = DEFAULT_DB_SPAMPOLICY.copy()

    for api_key, db_key in MAP_SPAMPOLICY_PAYLOAD_TO_DB.items():
        if api_key not in api_data:
            continue
        val = api_data[api_key]

        if api_key.startswith('enable_'):
            # enable_* és l’oposat: yes → N (no bypass), no → Y (bypass)
            db_data[db_key] = 'N' if val.lower() == 'yes' else 'Y'

        elif api_key.startswith('quarantine_'):
            if val.lower() == 'yes':
                db_data[db_key] = db_key.replace('_quarantine_to', '') + '-quarantine'
            else:
                db_data[db_key] = None

        elif api_key == 'prefix_spam_in_subject':
            db_data[db_key] = settings.AMAVISD_SPAM_SUBJECT_PREFIX if val.lower() == 'yes' else ''

        elif api_key == 'spam_score':
            db_data[db_key] = float(val)

        elif api_key == 'always_insert_x_spam_headers':
            if val.lower() == 'yes':
                db_data['spam_tag_level']  = -999
                db_data['spam_tag2_level'] = 5.0
                db_data['spam_kill_level'] = 6.5
            else:
                db_data['spam_tag_level']  = DEFAULT_SPAM_TAG_LEVEL
                db_data['spam_tag2_level'] = DEFAULT_SPAM_TAG2_LEVEL
                db_data['spam_kill_level'] = DEFAULT_SPAM_KILL_LEVEL
        
        elif api_key == 'policy_name':
            db_data[db_key] = str(val)
        
        else:
            if val is not None and db_key in DEFAULT_DB_SPAMPOLICY or db_key == 'policy_name':
                db_data[db_key] = val

    # ajustar lovers segons quarantines
    db_data['spam_lover']         = 'N' if db_data.get('spam_quarantine_to')         else 'Y'
    db_data['virus_lover']        = 'N' if db_data.get('virus_quarantine_to')        else 'Y'
    db_data['banned_files_lover'] = 'N' if db_data.get('banned_quarantine_to')       else 'Y'
    db_data['bad_header_lover']   = 'N' if db_data.get('bad_header_quarantine_to')   else 'Y'
    return db_data

def _spampolicy_api_db_to_payload(db_data: dict) -> dict:
    api_data = {}

    for api_key, db_key in MAP_SPAMPOLICY_PAYLOAD_TO_DB.items():
        val = db_data.get(db_key)

        if api_key.startswith('enable_'):
            api_data[api_key] = 'yes' if val == 'N' else 'no'

        elif api_key.startswith('quarantine_'):
            api_data[api_key] = 'yes' if val else 'no'

        elif api_key == 'prefix_spam_in_subject':
            api_data[api_key] = 'yes' if val else 'no'

        elif api_key == 'spam_score':
            api_data[api_key] = float(val) if val else DEFAULT_DB_SPAMPOLICY['spam_tag2_level']
        
        elif api_key == 'always_insert_x_spam_headers':
            if (
                db_data.get('spam_tag_level') == -999
                and db_data.get('spam_tag2_level') == 5.0
                and db_data.get('spam_kill_level') == 6.5
            ):
                api_data[api_key] = 'yes'
            else:
                api_data[api_key] = 'no'
        
        elif api_key == 'policy_name':
            api_data[api_key] = str(val or '')

        else:
            if val is not None:
                api_data[api_key] = val

    return api_data
