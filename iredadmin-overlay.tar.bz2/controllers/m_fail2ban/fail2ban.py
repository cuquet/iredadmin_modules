# controllers/m_fail2ban/fail2ban.py
import web

from libs.iredutils import ired_gettext

from controllers.m_system.utils import _format_errors, _redirect_url, _canonical_redirect
from libs.m_fail2ban.fail2ban import F2BManager
from libs.m_crudlib import decorators

BASE_URL = "/activities/fail2ban"

class f2bView:
    @decorators.require_admin_login
    def GET(self, mode="jails"):
        form = web.input(
            page=1, 
            query_string=None, 
            date_from=None
            )
        try:
            cur_page = max(1, int(form.page))
        except (TypeError, ValueError):
            cur_page = 1

        # Validació de seguretat
        if mode not in ("jails", "banned"):
            mode = "jails"

        filters = {
            "query_string": (form.query_string or "").strip(),
            "date_from": (form.date_from or "").strip(),
            "page": cur_page if cur_page > 1 else None,
            "msg": (form.get("msg") or "").strip() or None,
        }
        clean_filters = _canonical_redirect(
            path=f"{BASE_URL}/{mode}",
            params=filters,
        )

        cur_page = int(clean_filters.get("page", 1) or 1)
        payload = {
            "query_string": clean_filters.get("query_string", ""),
            "date_from": clean_filters.get("date_from", ""),
        }

        fm = F2BManager()

        # Obtenim les dades de les DUES coses per alimentar els comptadors, 
        # però la paginació només s'aplica a la llista activa.
        jails_res = fm.list_jails(
            page=(cur_page if mode == "jails" else 1)
            )
        banned_res = fm.list_banned(
            page=(cur_page if mode == "banned" else 1),
            payload=payload,
            )

        return web.render(
            'fail2ban/fail2ban.html',
            active_tab=mode,
            jails=jails_res,
            banned=banned_res,
            counts=fm.get_counts(days=1),
            cur_page=cur_page,
            msg=clean_filters.get('msg')
        )

    @decorators.require_admin_login
    @decorators.csrf_protected
    def POST(self, mode):
        # Afegim 'id' i 'single_id' que és el que enviem des de la plantilla
        form = web.input(
            id=[],
            single_id=None,
            jail=[],
            action=None,
            bulk_action=None,
            cur_page=1)

        try:
            cur_page = max(1, int(form.cur_page))
        except (TypeError, ValueError):
            cur_page = 1

        action = form.action or form.bulk_action
        action = (action or "").lower()
        fm = F2BManager()
        errors = []

        if mode == "banned" and action == "unban":
            # Recollim IDs de checkboxes o botó individual
            target_ids = [form.single_id] if form.single_id else form.id
            target_ids = [int(i) for i in target_ids if str(i).isdigit()]

            if target_ids:
                unban_errors = fm.unban_by_ids(target_ids)
                if isinstance(unban_errors, str):
                    errors.append(unban_errors)
                elif unban_errors:
                    errors.extend(unban_errors)
            else:
                errors.append("No s'han seleccionat IPs.")

        elif mode == "jails":
            jails = [j.strip() for j in form.jail if j.strip()]
            if action == "reload":
                if not fm.reload_jails():
                    errors.append("FAIL2BAN_RELOAD_FAILED")
            elif action == "disable" and jails:
                if not fm.disable_jail(jails):
                    errors.append("FAIL2BAN_DISABLE_FAILED")
            elif action == "enable" and jails:
                if not fm.enable_jail(jails):
                    errors.append("FAIL2BAN_ENABLE_FAILED")
            else:
                errors.append("INVALID_PARAMETERS")

        msg = "SUCCESS" if not errors else _format_errors(errors)
        raise web.seeother(_redirect_url(BASE_URL, mode, page=cur_page, msg=msg))

class f2bViewLog:
    @decorators.require_admin_login
    def GET(self, ip_id=None):
        if not ip_id:
            return "ID no vàlid"
        
        fm = F2BManager()
        row = fm.get_log(ip_id)
        
        if not row:
            return "No s'han trobat dades."
        
        return f"""
        <pre class="code-snippet">
            <code>{row.get('loglines') or ired_gettext('No records')}</code>
        </pre>
        """
