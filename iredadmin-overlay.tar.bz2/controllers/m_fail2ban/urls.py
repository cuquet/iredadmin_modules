# controllers/m_fail2ban/urls.py

urls = [
    '/activities/fail2ban/(jails|banned)', 'controllers.m_fail2ban.fail2ban.f2bView',
    '/activities/fail2ban/log/(.*)', 'controllers.m_fail2ban.fail2ban.f2bViewLog',
]
