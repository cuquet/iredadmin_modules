# controllers/m_maillist/utils.py
import web
from typing import Dict, Optional

from libs.m_system import utils, form_utils
from controllers.m_system.utils import _redirect_url

session = web.config.get('_session')

mapper = utils.KeyMap()

def _normalize_ml_payload(form: Dict, profile_type: Optional[str] = None) -> Dict:
    payload: Dict = {}
    def yes_no(value) -> str:
        return "yes" if value else "no"
    
    if profile_type==None:
        for k, opts in [
            ('username', {'to_lowercase': True}),
            ('accessPolicy', {'to_lowercase': True}),
            ('domainName', {'to_lowercase': True, 'is_domain': True }),
            ('name', {}),
        ]:
            payload[k] = form_utils.get_single_value(form=form, input_name=k, **opts)
 
        for k, v in form.items():
            if k in {"mail"}: 
                payload[k] = form_utils.get_multi_values(form, k, is_email=True, to_lowercase=True, to_string=True)
            elif k in {"action"}:
                payload[k] = form_utils.get_single_value(form, k, to_lowercase=True)
                
    elif profile_type == "general":
        SIMPLE_FIELDS = {"cn", "subject_prefix", "footer_html", "footer_text", "name"}
        for k in SIMPLE_FIELDS:
            if k in form:
                payload[k] = form_utils.get_single_value(form, k)

        if "accountStatus" in form:
            _status = form_utils.get_single_value(form, "accountStatus", to_lowercase=True, to_string=True)
            payload["accountStatus"] = ("active" if _status.strip() == "on" else "disabled")

        if "max_message_size" in form:
            payload["max_message_size"] = form_utils.quota_transformation(
                "max_message_size", form
            )

        if "accessPolicy" in form:
            _ap = form_utils.get_single_value(
                form, "accessPolicy", to_lowercase=True, default_value="public"
            )
            payload["accessPolicy"] = _ap
            payload["only_moderator_can_post"] = yes_no("moderatorsonly" in _ap)
            payload["only_subscriber_can_post"] = yes_no("membersonly" in _ap)

        TOGGLES = {
            "disable_archive", "disable_send_copy_to_sender", "close_list",
            "disable_subscription", "disable_subscription_confirm", "moderated",
            "disable_notify_when_subscriber_only", "disable_notify_when_moderator_only",
            "disable_notify_subscription_moderated",
            "disable_notify_when_exceeding_max_mail_size",
            "notify_sender_when_moderated", "notify_owner_when_sub_unsub",
        }
        for k in TOGGLES:
            payload[k] = yes_no(form.get(k))

    elif profile_type == "aliases":
        if "extra_address" in form:
            ok, data = form_utils.populate_form_list_filtered(form, "extra_address")
            if ok:
                payload["extra_address"] = data

    elif profile_type == "members":
        if "subscriber" in form:
            ok, data = form_utils.populate_form_list_filtered(form, "subscriber")
            if ok:
                payload["subscriber"] = data
        else:
            # Els clients de l'API acostumen a enviar `addSubscriber` / `removeSubscriber`.
            # Convertim aquest format al contracte intern `subscriber={add,remove}`.
            add_vals = ",".join(utils._normalize_list_mails(form.get("addSubscriber", "")))
            remove_vals = ",".join(utils._normalize_list_mails(form.get("removeSubscriber", "")))
            if add_vals or remove_vals:
                payload["subscriber"] = {
                    "add": add_vals,
                    "remove": remove_vals,
                }

    elif profile_type == "owners":
        if "moderate_subscription" in form:
            payload["moderate_subscription"] = yes_no(form.get("moderate_subscription"))

        for key in {"owner", "moderator", "subscription_moderator"}:
            if key in form:
                ok, data = form_utils.populate_form_list_filtered(form, key)
                if ok:
                    payload[key] = data

                if key == "subscription_moderator":
                    payload["moderate_subscription"] = yes_no(
                        len(payload["subscription_moderator"]["add"]) > 0
                    )

    elif profile_type == "newsletter":
        for key in {"description", "is_newsletter"}:
            if key in form:
                payload[key] = form_utils.get_single_value(form, key)

    return payload

def _parse_ml_payload_to_db(form: Dict, profile_type: Optional[str] = None) -> Dict:
    """
        Flux complet: normalitza + remapeja claus segons backend (ldap/sql)
    """
    normalized = _normalize_ml_payload(form, profile_type)
    mapped = mapper.remap_dict(normalized, reverse=False)
    return mapped

def _parse_ml_db_to_payload(data: Dict ) -> Dict:
    """
        Converteix dades de DB -> payload aplicant `mapper.remap_dict`.

        - Si `data` és un dict -> retorna un dict remapejat.
        - Si `data` és una llista de dicts -> retorna una llista de dicts remapejats.

        Args:
            data (dict | list[dict]): Dades originals.

        Returns:
            dict | list[dict]: Dades convertides.
    """
    if isinstance(data, dict):
        return mapper.remap_dict(data, reverse=True)
    if isinstance(data, list):
        return [
            mapper.remap_dict(item, reverse=True)
            for item in data if isinstance(item, dict)
        ]

    raise TypeError(f"Input ha de ser dict o list[dict], rebut: {type(data).__name__}")
