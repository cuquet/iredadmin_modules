import settings
from libs.regxes import email as e, domain as d, mailing_list_id as m

urls = [
    # | Patró          | Correcte? | Significat                         | Exemple vàlid            |
    # | -------------- | --------- | ---------------------------------- | ------------------------ |
    # | `'/ml/(%s$)'`  | ❌ No      | `$` dins del grup — regex trencada | (cap fiable)             |
    # | `'/ml/(%s)$'`  | ✅ Sí      | Final de cadena fora del grup      | `/ml/test`               |
    # | `'/ml/(%s)/?'` | ✅ Sí      | Opcional `/` al final              | `/ml/test/` o `/ml/test` |
    '/ml/(%s)$' % d, 'controllers.m_maillist.controller.List',
    '/profile/ml/(general|aliases|members|owners|newsletter)/(%s$)' % e, 'controllers.m_maillist.controller.Profile',
    '/create/ml/(%s$)' % d, 'controllers.m_maillist.controller.Create',
    '/create/ml', 'controllers.m_maillist.controller.Create',
    '/profile/ml/queue/(%s$)' % e, 'controllers.m_maillist.controller.NewsletterQueue',
    settings.NEWSLETTER_BASE_URL + '/(subscribe|unsubscribe)/(%s$)' % m , 'controllers.m_maillist.controller.NewsletterSubscription',
    settings.NEWSLETTER_BASE_URL + '/confirm', 'controllers.m_maillist.controller.NewsletterConfirm'
    
]
