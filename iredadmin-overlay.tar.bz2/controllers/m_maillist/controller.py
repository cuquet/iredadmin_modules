# controllers/m_maillist/controller.py
import web

import settings
from libs import iredutils

from controllers.m_maillist import utils
from libs.m_system.jinja_filters import SYMBOLS
from libs.m_crudlib import decorators
from libs.m_crudlib import domain as lib_domain
from libs.m_maillist import ml as lib_maillist
from libs.m_system import form_utils

session = web.config.get('_session')

BASE_URL = "/ml"

class List:
    @decorators.require_login
    @decorators.require_domain_access
    def GET(self, domain):
        form = web.input(
            page=1, 
            msg=None,
            _unicode=False
        )
        cur_page = int(form.page or 1) or 1
        domain = web.safestr(domain).lower()

        ok, sl, *rest = lib_maillist.MailList(domain=domain).list(current_page=cur_page)
        if not ok:
            raise web.seeother(utils._redirect_url(BASE_URL, domain, page=cur_page, msg=sl))

        account_profiles= utils._parse_ml_db_to_payload(sl['account_profiles'])

        return web.render(
            'maillist/list.html',
            cur_page=cur_page,
            cur_domain=domain,
            total=sl['total'],
            account_profiles= account_profiles,
            msg=form.get('msg'))

    @decorators.require_login
    @decorators.require_domain_access
    @decorators.csrf_protected
    def POST(self, domain):
        form = web.input(
            mail=[],
            msg=None,
            _unicode=False
        )
        cur_page = int(form.cur_page or 1) or 1
        domain = web.safestr(domain).lower()
        
        payload = utils._parse_ml_payload_to_db(form)
        
        mails = [ v for v in payload.get('mail', [])
            if str(v).endswith(f'@{domain}')
        ]
        if not mails:
            raise web.seeother(utils._redirect_url(BASE_URL, domain, page=cur_page, msg='NO_ACCOUNT_SELECTED'))

        ml_lib = lib_maillist.MailList(domain=domain)

        action_map = {
            "delete": lambda m: ml_lib.delete(mails=m),
            "delete_without_archiving": lambda m: ml_lib.delete(mails=m, archive="no"),
            "enable": lambda m: ml_lib.enable_or_disable_accounts(mails=m, action="enable"),
            "disable": lambda m: ml_lib.enable_or_disable_accounts(mails=m, action="disable"),
        }

        func = action_map.get(payload.get("action"))
        if not func:
            ok, msg = False, "INVALID_ACTION"
        else:
            ok, msg = func(mails)
        
        raise web.seeother(utils._redirect_url(BASE_URL, domain, page=cur_page, msg=msg))    

class Profile:
    @decorators.require_domain_access
    @decorators.require_login
    def GET(self, profile_type, mail):
        form = web.input(
            msg=None,
            _unicode=False
        )
        mail = web.safestr(mail).lower()
        cur_domain = mail.split('@', 1)[-1] 
        profile_type = web.safestr(profile_type)

        if not iredutils.is_domain(cur_domain):
            raise web.seeother(utils._redirect_url('/domains', msg='INVALID_DOMAIN'))

        qr = lib_maillist.MailList(domain = cur_domain, mail = mail).get_profile()

        if not qr[0]:
            raise web.seeother(utils._redirect_url('/profile/ml/general', mail, msg=qr[1]))

        return web.render('maillist/profile.html',
            profile_type=profile_type,
            cur_domain=cur_domain,
            mail=mail,
            profile=qr[1]['ldif'],
            account_setting=qr[1]['account_setting'],
            members = qr[1]['subscribers'],
            queue = qr[1]['queue'],
            size_symbols=SYMBOLS,
            newsletter_url = web.ctx.homedomain + settings.NEWSLETTER_BASE_URL,
            msg=form.get('msg'))

    @decorators.require_login
    @decorators.require_domain_access
    @decorators.csrf_protected
    def POST(self, profile_type, mail):
        profile_type = web.safestr(profile_type)
        mail = web.safestr(mail).strip().lower()
        cur_domain = mail.split('@', 1)[-1]

        form = web.input(
            _unicode=False,
            extra_address=[],
            old_extra_address=[],
            subscriber=[],
            old_subscriber=[],
            owner=[],
            old_owner=[],
            moderator=[],
            old_moderator=[], 
            subscription_moderator=[],
            old_subscription_moderator=[],
        )
        maillist_lib = lib_maillist.MailList(domain=cur_domain, mail=mail)

        payload = utils._parse_ml_payload_to_db(form, profile_type)

        ok, msg = maillist_lib.update(payload, profile_type)

        raise web.seeother(utils._redirect_url('/profile/ml', profile_type, mail, msg=msg))

class Create:
    @decorators.require_login
    def GET(self, domain = None):
        form = web.input()
        if not domain:
            cur_domain = ''
        else:
            cur_domain = web.safestr(domain)
        
        domain_lib = lib_domain.Domain(cur_domain)
        
        ok, all_domains, *rest = domain_lib.get_all_domains(names_only=True)
        if ok and not cur_domain and all_domains:
            raise web.seeother(f'/create/ml/{str(all_domains[0])}')
        
        ok, qr, *rest = domain_lib.get_profile()
        if not ok:
            raise web.seeother(utils._redirect_url('/domains', msg=qr))
        
        qr_domain_settings = domain_lib.get_domain_account_settings()
        account_settings = qr_domain_settings[1] if qr_domain_settings[0] else {}
        num_max = int(account_settings.get('numberOfLists', '0'))
        num_cur = domain_lib.num_maillists_under_domain()
        num_spare = num_max - num_cur
        
        create_enabled = not (
            num_max in (-1, 0) or (num_max > 0 and num_spare <= 0)
        )

        return web.render(
            'maillist/create.html',
            cur_domain=cur_domain,
            allDomains=all_domains,
            numberOfAccountsLimit=num_max,
            numberOfSpareAccounts=num_spare,
            createNewAccount=create_enabled,
            msg=form.get('msg')
        )

    @decorators.csrf_protected
    @decorators.require_domain_access
    def POST(self, domain):
        form = web.input()
        username = web.safestr(form.get('username'))
        domain_name = form.get("domainName")
        
        if domain != domain_name or not domain_name:
            raise web.seeother(utils._redirect_url('/create/ml', domain_name, msg='PERMISSION_DENIED'))

        payload = utils._parse_ml_payload_to_db(form)

        ok, msg = lib_maillist.MailList(domain=domain).add(payload)
        if ok:
            raise web.seeother(utils._redirect_url('/profile/ml/general', f'{username}@{domain_name}', msg=msg))
        raise web.seeother(utils._redirect_url('/create/ml', domain_name, msg=msg))

class NewsletterSubscription:
    def GET(self, kind: str, ml_id):
        form = web.input()
        kind = kind.lower()
        alt_kind = "unsubscribe" if kind == "subscribe" else "subscribe"
        
        ok, result , *rest = lib_maillist.MailList().get_newsletter_subscription(ml_id)
        if not ok:
            data = {}
            msg = result
        else:
            data = result
            msg = form.get("msg")

        return web.render(
            'maillist/newsletter_join.html',
            languagemaps=iredutils.get_language_maps(),
            profile = kind,
            name = data.get("name", ""),
            newsletter_enabled = data.get("newsletter_enabled", False),
            description = data.get("description", ""),
            url= f"{settings.NEWSLETTER_BASE_URL}/{kind}/{ml_id}",
            alt_url = f"{settings.NEWSLETTER_BASE_URL}/{alt_kind}/{ml_id}",
            msg=msg) 

    def POST(self, kind: str, ml_id):
        form = web.input()
        kind = kind.lower()
        subscriber = form_utils.get_single_value(form=form, input_name='subscriber', to_lowercase=True, is_email=True)
        result = lib_maillist.MailList().post_newsletter_subscription(subscriber, kind, ml_id)
        return result

class NewsletterConfirm:
    def GET(self):
        form = web.input(token=None)
        token = form.token
        if not token:
            return "Invalid confirmation link."

        record = lib_maillist.ConfirmManager.get_by_token(token)

        if not record:
            return web.render(
                'maillist/newsletter_confirm.html',
                languagemaps=iredutils.get_language_maps(),
                status='error',
                error='Invalid or expired token.'
            )
        
        api = lib_maillist.MailList_API(
            domain=record.mail.split('@', 1)[-1],
            mail=record.mail
        )

        _, info = api.info()
        name = dict(info).get("name")

        # Acció principal
        action = record.kind
        subscribers = [record.subscriber]

        actions = {
            "subscribe": api.add_subscribers,
            "unsubscribe": api.remove_subscribers,
        }
        ok, *rest = actions.get(record.kind, lambda _: (False, "INVALID_ACTION"))([record.subscriber])
        if ok:
            lib_maillist.ConfirmManager.mark_expired(token)
            status, error = 'ok', None
        else:
            status, error = 'error', rest[0] if rest else "Unknown error"

        return web.render(
            'maillist/newsletter_confirm.html',
            languagemaps=iredutils.get_language_maps(),
            status=status,
            action=record.kind,
            name=name,
            mlid=record.mlid,
            error=error,
        )

class NewsletterQueue:
    @decorators.csrf_protected
    @decorators.require_global_admin
    def POST(self, mail):
        mail = web.safestr(mail).lower()
        form = web.input(action=None, record=[])
        action = form.get('action')
        record_ids = form.get('record')
        if isinstance(record_ids, str):
            record_ids = [record_ids]
        
        actions = {
            "delete": lambda: lib_maillist.ConfirmManager.delete_by_ids(record_ids),
            "deleteall": lambda: lib_maillist.ConfirmManager.delete_all(mail),
            "deleteexpired": lambda: lib_maillist.ConfirmManager.delete_expired(mail),
            "post": lambda: lib_maillist.ConfirmManager.post_records(
                lib_maillist.ConfirmManager.get_by_ids(record_ids)),
            "postall": self._post_all,
        }

        handler = actions.get(action, lambda: (False, f"Unknown action: {action}"))
        ok, msg = handler()

        raise web.seeother(utils._redirect_url('/profile/ml', "newsletter", mail, msg=msg))

    def _post_all(self, mail):
        ok, queue = lib_maillist.ConfirmManager.get_queue_by_mail(mail)
        if not ok:
            return (False, queue)
        return lib_maillist.ConfirmManager.post_records(queue)
