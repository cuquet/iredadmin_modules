# controllers/m_crud/urls.py
from libs.regxes import email as e, domain as d

urls = [
    # Fem que la URL amb o sense '/' final vagi a la mateixa classe.
    '/(.*)/', 'controllers.utils.Redirect',

    '/', 'controllers.m_crud.basic.Login',
    '/login', 'controllers.m_crud.basic.Login',
    '/logout', 'controllers.m_crud.basic.Logout',
    '/dashboard', 'controllers.m_crud.basic.Dashboard',

    # Search.
    '/search',                                  'controllers.m_crud.basic.Search',


    # Visualitza i descarrega dades LDIF.    
    '/export/ldif/(domain|catchall)/(%s$)' % d,      'controllers.m_crud.basic.LdifExport',
    '/export/ldif/(admin|user|maillist)/(%s$)' % e,  'controllers.m_crud.basic.LdifExport',
    '/export/ldif',                                  'controllers.m_crud.basic.LdifExport',


    # Domain related.
    '/domains', 'controllers.m_crud.domain.List',
    # List disabled accounts.
    '/domains/disabled', 'controllers.m_crud.domain.ListDisabled',
    # Profiles
    '/profile/domain/(general|relay|bcc|catchall|aliases|throttle|greylisting|wblist|spampolicy|backupmx|advanced)/(%s$)' % d,  'controllers.m_crud.domain.Profile',
    '/profile/domain/(%s)' % d, 'controllers.m_crud.domain.Profile',
    '/create/domain', 'controllers.m_crud.domain.Create',

    # Admin related.
    '/admins', 'controllers.m_crud.admin.List',
    '/profile/admin/(general|password|2fa)/(%s$)' % e, 'controllers.m_crud.admin.Profile',
    '/create/admin', 'controllers.m_crud.admin.Create',
    # Internal domain admins
    '/admins/(%s)$' % d, 'controllers.m_crud.admin.ListAdmin',

    '/create/(user)', 'controllers.m_crud.user.CreateDispatcher',

    # User related
    # Llista usuaris i elimina usuaris del mateix domini.
    '/users/(%s$)' % d, 'controllers.m_crud.user.List',
    # List disabled accounts.
    '/users/(%s)/disabled' % d, 'controllers.m_crud.user.ListDisabled',
    # Create user.
    '/create/user/(%s$)' % d, 'controllers.m_crud.user.Create',
    # Profile pages.
    '/profile/user/(general|members|forwarding|bcc|relay|aliases|throttle|greylisting|wblist|spampolicy|password|advanced|rename|2fa)/(%s$)' % e,      'controllers.m_crud.user.Profile',
    # Preferences vinculades a session['username']
    '/preferences',                         'controllers.m_crud.user.Preferences',
    '/preferences/(general|forwarding|wblist|spampolicy|password|2fa)',   'controllers.m_crud.user.Preferences',
    '/self-service/mls',                    'controllers.m_crud.user.SelfServiceMailLists',
]
