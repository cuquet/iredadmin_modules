# controllers/m_crud/domain.py
import web

import settings
from libs import iredutils
from libs.l10n import TIMEZONES

from controllers.m_crud import utils
from libs.m_system.jinja_filters import SYMBOLS
from libs.m_crudlib import decorators
from libs.m_crudlib import domain as lib_domain
from libs.m_crudlib import admin as lib_admin
from libs.m_maillist import ml as lib_ml
from libs.m_amavisd import wblist as lib_wblist, spampolicy as lib_spampolicy
from libs.m_iredapd import throttle as lib_throttle, greylist as lib_greylist

session = web.config.get('_session')

BASE_URL = "/domains"

class List:
    @decorators.require_admin_login
    @decorators.require_login
    def GET(self, disabled_only=False):
        form = web.input(
            page=1,
            disabled_only=None,
            msg=None,
            _unicode=False
        )
        cur_page = int(form.page or 1) or 1

        if form.disabled_only is not None:
            disabled_only = form.disabled_only in ("1", "true", "yes")

        first_char = None
        if 'starts_with' in form:
            first_char = form.get('starts_with')[:1].upper()
            if not iredutils.is_valid_account_first_char(first_char):
                first_char = None

        # Get first characters of all domains
        all_first_chars = lib_domain.Domain().domains_get_first_char_of_all()

        ok, sl, *rest = lib_domain.Domain().list(disabled_only=disabled_only, starts_with=first_char, current_page=cur_page)
        if not ok:
            raise web.seeother(utils._redirect_url(BASE_URL, msg=sl))

        account_profiles= utils._parse_crud_db_to_payload(sl['account_profiles'])
        
        days_to_keep_removed_mailbox = (
            settings.DAYS_TO_KEEP_REMOVED_MAILBOX_FOR_GLOBAL_ADMIN
            if session.get('is_global_admin')
            else settings.DAYS_TO_KEEP_REMOVED_MAILBOX
        )

        return web.render(
            'crud/domain/list.html',
            cur_page=cur_page,
            total=sl['total'],
            account_profiles=account_profiles,
            local_transports=settings.LOCAL_TRANSPORTS,
            first_char=first_char,
            all_first_chars=all_first_chars,
            disabled_only=disabled_only,
            days_to_keep_removed_mailbox=days_to_keep_removed_mailbox,
            statistics = lib_admin.Admin().statistics(),
            msg=form.get('msg', None))

    @decorators.require_admin_login
    @decorators.require_login
    @decorators.csrf_protected
    def POST(self):
        form = web.input(
            domainName=[],
            _unicode=False
        )
        cur_page = int(form.cur_page or 1) or 1

        payload = utils._parse_crud_payload_to_db(form)
        
        domains = payload.get("domainName") or []
        if not domains:
            raise web.seeother(utils._redirect_url(BASE_URL, msg='INVALID_DOMAIN_NAME'))

        domain_lib = lib_domain.Domain()

        def cap_keep_days(requested_days):
            _max_days = max(settings.DAYS_TO_KEEP_REMOVED_MAILBOX)
            if session.get('is_global_admin'):
                _max_days = max(settings.DAYS_TO_KEEP_REMOVED_MAILBOX_FOR_GLOBAL_ADMIN)
            return min(requested_days, _max_days)

        action_map = {
                "delete": lambda d: domain_lib.delete_domains(
                    d,
                    keep_mailbox_days=cap_keep_days(payload.get("keep_mailbox_days", 0))
                ),
                "disable": lambda d: domain_lib.enable_disable_domains(d, "disable"),
                "enable":  lambda d: domain_lib.enable_disable_domains(d, "enable"),
            }

        func = action_map.get(payload.get("action"))
        if not func:
            ok, msg = False, "INVALID_ACTION"
        else:
            ok, msg, *rest = func(domains)

        raise web.seeother(utils._redirect_url(BASE_URL, page=cur_page, msg=msg))

class ListDisabled:
    @decorators.require_global_admin
    def GET(self):
        _list = List()
        return _list.GET(disabled_only=True)

class Profile:
    @decorators.require_admin_login
    @decorators.require_login
    def GET(self, profile_type, domain):
        profile_type = web.safestr(profile_type).lower()
        domain = web.safestr(domain).lower()

        form = web.input(
            msg=None, 
            _unicode=False
            )

        qr = lib_domain.Domain(domain).get_profile()
        if not qr[0]:
            raise web.seeother(utils._redirect_url(BASE_URL,msg=qr[1]))

        profile = utils._parse_crud_db_to_payload(qr[1])
        # NOTE: En SQL `disclaimer` pot venir com a NULL; a la UI volem cadena buida.
        profile["disclaimer"] = profile.get("disclaimer") or ""

        errors = []

        # Mantenim valors per defecte neutrals de backend per evitar errors de plantilla en entorn SQL.
        gl_data = {"setting": "", "spf_domains": []}
        th_data = {}
        spam_data = {}
        wb_data = {}
        all_ml = []

        global_db_settings = iredutils.get_settings_from_db(params=['min_passwd_length', 'max_passwd_length'])
        db_settings = iredutils.get_settings_from_db(['min_passwd_length', 'max_passwd_length'], domain)

        # --------------- iRedAPD 
        if session.get('enable_iredapd'):
            # Greylisting
            ok, gl_data = lib_greylist.get_greylisting(account=f'@{str(domain).lower()}')
            if not ok:
                msg=gl_data.get("errors") or gl_data
                errors.append([f"Error obtenint configuració greylisting: {msg}"])

            # Throttling
            ok, th_data = lib_throttle.get_throttle_setting(account=f'@{str(domain).lower()}')
            if not ok:
                errors.append([f"Error obtaining throttling settings: {th_data.get('errors')}"])
        
        # --------------- amavisd
        # spampolicy
        if session.get('amavisd_enable_policy_lookup'):
            ok, spam_data = lib_spampolicy.get_spam_policy(account=f'@{str(domain).lower()}')
            if not ok:
                # NOTE:
                # `NO_SUCH_SPAMPOLICY` és un estat esperat quan el domini encara no
                # té política explícita a amavisd. No volem soroll d'alertes a UI.
                is_expected_missing_policy = (
                    isinstance(spam_data, dict)
                    and spam_data.get('spam_policy') == 'NO_SUCH_SPAMPOLICY'
                )
                if is_expected_missing_policy:
                    spam_data = dict(spam_data)
                    spam_data.pop("errors", None)
                else:
                    error = spam_data.get("errors") if isinstance(spam_data, dict) else spam_data
                    errors.append([f"Failed spampolicy: {error}"])

        # white/blacklists
        ok, wb_data = lib_wblist.get_wblist(f'@{domain}')
        if not ok:
            # NOTE:
            # En alguns dominis nous amavisd encara no té registre `users` per @domini.
            # `ACCOUNT_NOT_EXIST` / `NO_SUCH_ACCOUNT` / `NO_ENTRIES_FOUND` són estats
            # esperats i no s'han de mostrar com a errors a la UI.
            expected_tokens = ('ACCOUNT_NOT_EXIST', 'NO_SUCH_ACCOUNT', 'NO_ENTRIES_FOUND')
            wb_errors = wb_data.get("errors") if isinstance(wb_data, dict) else []
            only_expected = bool(wb_errors) and all(
                any(token in str(item) for token in expected_tokens) for item in wb_errors
            )

            if only_expected:
                wb_data = dict(wb_data)
                wb_data.pop("errors", None)
            else:
                errors.append([f"Failed WBlist: {wb_data}"])
            
        creation_limits = lib_admin.Admin().get_creation_limits(mail=session.get('username'))

        #ml
        qr_all_ml = lib_ml.MailList(domain=domain).list()
        if not qr_all_ml[0]:
            errors.append([f"Failed [MailList().list]: {qr_all_ml[1]}"])
        elif isinstance(qr_all_ml[1], list):
            all_ml = [
                (e["mail"][0], e["cn"][0])
                for e in qr_all_ml[1]
                if isinstance(e, dict) and "mail" in e and "cn" in e
            ]

        if errors:
            error_msg = utils._format_errors(errors)
        else:
            error_msg = form.get('msg', None)

        return web.render(
            'crud/domain/profile.html',
            cur_domain=domain,
            profile=profile,
            # allDomains=managed_domains,
            profile_type=profile_type,
            timezones=TIMEZONES,
            size_symbols=SYMBOLS,
            default_mta_transport=settings.default_mta_transport,
            languagemaps=iredutils.get_language_maps(),
            creation_limits= creation_limits, 
            # iRedAPD: greylisting, throttle
            gl_data=gl_data,
            th_data=th_data,
            # Amavisd: spam policy, wblist
            spam_data=spam_data,
            wb_data=wb_data,
            # DB settings
            global_db_settings=global_db_settings,
            db_settings=db_settings,
            # ml
            ml_all=all_ml,
            ml_default=[],
            msg=error_msg,
        )

    @decorators.require_admin_login
    @decorators.require_login
    @decorators.csrf_protected
    def POST(self, profile_type, domain):
        profile_type = web.safestr(profile_type)
        domain = web.safestr(domain).lower()

        form = web.input(
            enabledService=[],
            domainadmin=[],
            defaultList=[],
            disabledUserPreference=[], 
            disabledUserProfile=[],
            disabledMailService=[],
            disabledDomainProfile=[],
            domainAliasName=[], 
            old_domainAliasName=[],
            whitelists=[],
            old_whitelists=[],
            add_whitelists=[],
            whitelistSender=[],
            old_whitelistSender=[],
            add_whitelistSender=[],
            blacklistSender=[],
            old_blacklistSender=[],
            add_blacklistSender=[],
            whitelistRecipient=[],
            old_whitelistRecipient=[],
            add_whitelistRecipient=[],
            blacklistRecipient=[],
            old_blacklistRecipient=[],
            add_blacklistRecipient=[], 
            banned_rulenames=[],
        )
        BASE_URL = '/profile/domain/'
        if domain != web.safestr(form.get('domainName', None)).lower():
            raise web.seeother(utils._redirect_url(BASE_URL,profile_type, domain))

        payload = utils._parse_crud_payload_to_db(form, profile_type)

        ok, msg, *rest = lib_domain.Domain(domain=domain).update(payload)
        if not ok:
            msg = utils._format_errors(msg)
            
        raise web.seeother(utils._redirect_url(BASE_URL,profile_type, domain, msg=msg))

class Create:
    @decorators.require_permission_create_domain
    @decorators.require_login
    def GET(self):
        form = web.input(
            _unicode=False
        )
        return web.render(
            'crud/domain/create.html',
            preferred_language=settings.default_language,
            languagemaps=iredutils.get_language_maps(),
            timezones=TIMEZONES,
            msg=form.get('msg',None))

    @decorators.require_global_admin
    @decorators.csrf_protected
    def POST(self):
        form = web.input(
            domainName='',
            _unicode=False
        )

        domain = web.safestr(form.get("domainName", "")).strip().lower()
        if not iredutils.is_domain(domain):
            raise web.seeother(utils._redirect_url('/create/domain', msg='INVALID_DOMAIN_NAME'))

        payload = utils._parse_crud_payload_to_db(form)
        # NOTE: Domain().add() (especialment en SQL) espera `domainName` canònic.
        payload["domainName"] = domain

        ok, msg, *rest = lib_domain.Domain().add(payload)
        if not ok:
            raise web.seeother(utils._redirect_url('/create/domain', msg=msg))

        raise web.seeother(utils._redirect_url('/profile/domain/general', domain, msg=msg))
