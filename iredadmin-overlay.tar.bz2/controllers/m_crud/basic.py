# controllers/m_crud/basic.py
import web
import requests

import settings
from libs import __version__
from libs import iredutils, sysinfo
from libs.l10n import TIMEZONES
from libs.logger import logger, log_activity

from controllers.m_crud import utils
from libs.m_system.search import SearchEngine
from libs.m_crudlib import auth, decorators
from libs.m_crudlib import admin as lib_admin
from libs.m_crudlib import domain as lib_domain

if settings.backend == "ldap":
    from libs.m_system.mixins import ExporterFactory
    from libs.m_system.mixins.ldap.ldap_ldif_mixin import ldif_fetch
elif settings.backend in ["mysql", "pgsql"]:
    pass

session = web.config.get('_session')

def _get_captcha_provider():
    provider = str(getattr(settings, "CAPTCHA_PROVIDER", "friendly") or "friendly").strip().lower()
    if provider not in ("friendly", "google"):
        provider = "friendly"
    return provider


def _get_captcha_config():
    provider = _get_captcha_provider()
    if provider == "google":
        site_key = str(getattr(settings, "RECAPTCHA_PUBLIC_KEY", "") or "").strip()
        secret_key = str(getattr(settings, "RECAPTCHA_API_KEY", "") or "").strip()
    else:
        site_key = str(getattr(settings, "FRIENDLY_CAPTCHA_PUBLIC_KEY", "") or "").strip()
        secret_key = str(getattr(settings, "FRIENDLY_CAPTCHA_API_KEY", "") or "").strip()

    return {
        "provider": provider,
        "site_key": site_key,
        "secret_key": secret_key,
        "enabled": bool(site_key and secret_key),
    }

def verify_captchav2(solution: str):
    url = "https://global.frcapi.com/api/v2/captcha/siteverify"
    headers = {
        "X-API-Key": settings.FRIENDLY_CAPTCHA_API_KEY 
    }
    data = {
        "response": solution,
        "sitekey": settings.FRIENDLY_CAPTCHA_PUBLIC_KEY
    }
    try:
        response = requests.post(url, json=data, headers=headers, timeout=5)
        response.raise_for_status()
        result = response.json()
        return result.get("success", False), result
    except requests.RequestException as e:
        return False, repr(e)

def verify_recaptcha_v2(solution: str, remote_ip: str = ""):
    payload = {
        "secret": str(getattr(settings, "RECAPTCHA_API_KEY", "") or "").strip(),
        "response": solution,
    }
    if remote_ip:
        payload["remoteip"] = remote_ip

    try:
        response = requests.post(
            "https://www.google.com/recaptcha/api/siteverify",
            data=payload,
            timeout=5,
        )
        response.raise_for_status()
        result = response.json()
    except requests.RequestException as e:
        return False, repr(e)

    return bool(result.get("success", False)), result

def verify_selected_captcha(solution: str, provider: str):
    if provider == "google":
        return verify_recaptcha_v2(solution, remote_ip=web.ctx.ip)
    return verify_captchav2(solution)

class Login:
    def GET(self):
        if not session.get('logged'):
            form = web.input(_unicode=False)

            if not iredutils.is_allowed_admin_login_ip(client_ip=web.ctx.ip):
                return web.render(
                    'error_without_login.html',
                    error='NOT_ALLOWED_IP'
                )
            # NOTE: Inicialitza intents fallits si no existeix
            if 'failed_times' not in session:
                session['failed_times'] = 0

            captcha = _get_captcha_config()
            show_captcha = (session['failed_times'] > 2) and captcha["enabled"]
            show_2fa = False

            # NOTE: Show login page.
            return web.render(
                'login.html',
                languagemaps=iredutils.get_language_maps(),
                webmaster=session.get('webmaster'),
                captcha_key=captcha["site_key"],
                captcha_provider=captcha["provider"],
                msg=form.get('msg'),
                show_captcha=show_captcha,
                show_2fa=show_2fa)
        else:
            if session.get('is_global_admin') or session.get('is_user_admin') or session.get('is_mail_admin'):
                if settings.REDIRECT_TO_DOMAIN_LIST_AFTER_LOGIN:
                    raise web.seeother('/domains')
                else:
                    raise web.seeother('/dashboard?checknew')
            else:
                utils.self_service_login_redirect(session['username'])

    def POST(self):
        form = web.input(_unicode=False)
        username = web.safestr(form.get('username', '').strip()).lower()
        password = str(form.get('password', '').strip())
        totp_code = form.get('totp_code', '').strip()
        current_lang = web.safestr(form.get('lang', '')).strip()

        captcha = _get_captcha_config()
        captcha_required = (session.get('failed_times', 0) > 2) and captcha["enabled"] and (not session.get('2FA_required'))
        if captcha_required:
            response_field = 'g-recaptcha-response' if captcha["provider"] == "google" else 'frc-captcha-response'
            captcha_solution = str(form.get(response_field, '')).strip()
            captcha_check = verify_selected_captcha(captcha_solution, captcha["provider"]) if captcha_solution else (False, "missing captcha token")
            if not captcha_check[0]:
                raise web.seeother('/login?msg=CAPTCHA_INCORRECT')

        if not session.get('2FA_required'):
            if not iredutils.is_email(username):
                raise web.seeother('/login?msg=INVALID_USERNAME')
            if not password:
                raise web.seeother('/login?msg=EMPTY_PASSWORD')

            auth_result = auth.login_auth(username, password)

            if not auth_result[0]:
                session['failed_times'] = session.get('failed_times', 0) + 1
                logger.warning("Web login failed: client_address={}, username={}".format(web.ctx.ip, username))
                log_activity(event='login', username=username,  msg="Login failed.", loglevel='error')
                raise web.seeother('/login?msg=INVALID_CREDENTIALS')

            if auth_result[1] and not current_lang: 
                current_lang = auth_result[1]

        # NOTE: 2FA ---------- INICI check ----------
        if session.get('2FA_required'): 
            if not totp_code :
                return web.render(
                    'login.html',
                    languagemaps=iredutils.get_language_maps(),
                    webmaster=session.get('webmaster'),
                    msg='2FA_TOKEN_REQUIRED',
                    lang = current_lang,
                    captcha_provider=captcha["provider"],
                    show_2fa=True)
            elif totp_code:
                from libs.m_crudlib import security
                enc_secret = session.get('2FA_required') 
                validate_2fa = security.verify_2fa_token(enc_secret, totp_code, username)
                if not validate_2fa:
                    session['failed_times'] = session.get('failed_times', 0) + 1
                    if session['failed_times'] > 3:
                        session.kill()
                        raise web.seeother('/login?msg=2FA_TOKEN_INCORRECT')
                    return web.render(
                        'login.html',
                        languagemaps=iredutils.get_language_maps(),
                        webmaster=session.get('webmaster'),
                        msg='2FA_TOKEN_INCORRECT',
                        captcha_provider=captcha["provider"],
                        show_2fa=True)
                session.pop('2FA_required', None)
        # NOTE: 2FA ---------- FINAL check ----------

        logger.info("Login success: username={}, client_address={}".format(session.get('username'), web.ctx.ip))
        log_activity(event='login', username=session.get('username'), msg="User login success")

        domain = session.get('username').split('@', 1)[-1]
        if not session.get('timezone'):
            qr = lib_domain.Domain(domain).get_filtered_account_setting('timezone') or settings.LOCAL_TIMEZONE
            if qr[0] and qr in TIMEZONES:
                session['timezone'] = TIMEZONES[qr]
            
        if not session.get('lang'):
            qr = lib_domain.Domain(domain).get_filtered_account_setting('preferredLanguage')
            session['lang'] = qr[0] if qr else settings.default_language

        # NOTE: Salvar lenguatge seleccionat
        selected_language = str(form.get('lang', '')).strip()
        if selected_language != web.ctx.lang and \
            selected_language in iredutils.get_language_maps():
            session['lang'] = selected_language

        # NOTE: Desem `logged` al final; si fallen els paràmetres anteriors, evitem redireccions en bucle.
        session['logged'] = True
        web.config.session_parameters['cookie_name'] = 'iRedAdmin'
        web.config.session_parameters['ignore_expiry'] = False
        web.config.session_parameters['ignore_change_ip'] = settings.SESSION_IGNORE_CHANGE_IP

        if session.get('is_global_admin') or session.get('is_user_admin') or session.get('is_mail_admin'):
            if settings.REDIRECT_TO_DOMAIN_LIST_AFTER_LOGIN:
                raise web.seeother('/domains')
            else:
                raise web.seeother('/dashboard?checknew')
        else:
            utils.self_service_login_redirect(session.get('username'))

class Logout:
    def GET(self):
        try:
            session.kill()
        except:
            pass

        raise web.seeother('/login')

class Dashboard:
    @decorators.require_admin_login
    def GET(self):
        form = web.input(_unicode=False)
        _check_new_version = ('checknew' in form)

        # NOTE: Comprova si hi ha una versió nova.
        if session.get('is_global_admin') and _check_new_version:
            (_status, _info) = sysinfo.check_new_version()
            session['new_version_available'] = _status
            if not _status:
                session['new_version_check_error'] = _info  # if _status is False
            else:
                session['new_version'] = _info      # if _status is True

        return web.render(
            'dashboard.html',
            version=__version__,
            iredmail_version=sysinfo.get_iredmail_version(),
            hostname=sysinfo.get_hostname(),
            uptime=sysinfo.get_server_uptime(),
            loadavg=sysinfo.get_system_load_average(),
            netif_data=sysinfo.get_nic_info(),
            statistics = lib_admin.Admin().statistics(),
        )

class LdifExport(object):
    @decorators.require_global_admin
    def GET(self, account_type=None, value=None):
        if settings.backend != "ldap":
            raise web.seeother(utils._redirect_url('/domains', msg='NOT_SUPPORTED_BACKEND'))

        # NOTE: Sense paràmetres → mostrar arbre complet
        fulltree = (account_type is None and value is None)
        qr = ldif_fetch(value=value, account_type=account_type, fulltree=fulltree)
        if not qr[0]:
            raise web.seeother(utils._redirect_url('/domains', msg=qr[1]))

        records = qr[1]

        exporter = ExporterFactory.from_LDIF(format='html')
        exporter.apply_headers(web, value or "root")
        return exporter.export(records)
    
    @decorators.csrf_protected
    def POST(self, account_type=None, value=None):
        if settings.backend != "ldap":
            raise web.seeother(utils._redirect_url('/domains', msg='NOT_SUPPORTED_BACKEND'))

        # NOTE: Sense paràmetres → mostrar arbre complet
        fulltree = (account_type is None and value is None)
        qr = ldif_fetch(value=value, account_type=account_type, fulltree=fulltree)
        if not qr[0]:
            raise web.seeother(utils._redirect_url('/domains', msg=qr[1]))

        records = qr[1]
        form = web.input(format='ldif', zip=None)
        fmt = str(form.format).strip().lower()

        exporter = ExporterFactory.from_LDIF(
            format=fmt,
            zip=bool(form.get('zip')),
            inner_name=f"{value or 'root'}.{fmt}",
        )
        exporter.apply_headers(web, value or "root")
        return exporter.export(records)

class Search:
    @decorators.require_login
    def GET(self):
        # NOTE: Endpoint: /search?q=text&type=user,alias
        form = web.input(q=None, type=None, status=None)
        q = (form.q or '').strip()
        # NOTE: analitza els tipus com a cadenes separades per comes, filtre permès
        allowed = {'domain', 'admin', 'user', 'maillist'}
        if form.type:
            types = [t.strip() for t in form.type.split(',') if t.strip() in allowed]
            if not types:
                types = list(allowed)
        else:
            types = list(allowed)

        # NOTE: estat com a cadena única: active | disabled | all
        status_raw = (form.status or "all").strip().lower()
        if status_raw not in ("active", "disabled", "all"):
            status_raw = "all"

        engine = SearchEngine()
        results = {"total": 0, "users": [], "domains": [], "admins": [], "maillists": []}
        if q:
            results = engine.run(text=q, types=types, status=status_raw)
        
        return web.render(
            'crud/search.html',
            q=q,
            type=(form.type or ""),
            status=status_raw,
            results=results,
        )
