# controllers/m_crud/admin.py
import web
import settings
from libs import iredutils
from libs.l10n import TIMEZONES

from controllers.m_crud import utils
from libs.m_system import utils as system_utils
from libs.m_crudlib import decorators
from libs.m_crudlib import admin as lib_admin

from libs.m_crudlib import security

session = web.config.get('_session')


class List:
    @decorators.require_global_admin
    def GET(self, domain=None ):
        domain = web.safestr(domain).lower() if domain else None

        form = web.input(
            page=1, 
            msg=None, 
            _unicode=False
        )
        cur_page = int(form.page or 1) or 1

        first_char = None
        if 'starts_with' in form:
            first_char = form.get('starts_with')[:1].upper()
            if not iredutils.is_valid_account_first_char(first_char):
                first_char = None

        admin_lib = lib_admin.Admin(domain=domain)

        ok, sl, *rest = admin_lib.list(current_page=cur_page)
        if not ok:
            raise web.seeother(utils._redirect_url('/domains', msg=sl))

        account_profiles = utils._parse_crud_db_to_payload(sl['account_profiles'])
        
        return web.render(
            'crud/admin/list.html',
            cur_page=cur_page,
            cur_domain=domain,
            total=sl['total'],
            account_profiles= account_profiles,
            msg=form.get('msg')
        )


    @decorators.require_global_admin
    @decorators.csrf_protected
    def POST(self, domain=None):
        form = web.input(
            admin_id=[], 
            msg=None, 
            _unicode=False
        )
        cur_page = int(form.cur_page or 1) or 1
        domain = web.safestr(domain).lower() if domain else None
        
        payload = utils._parse_crud_payload_to_db(form)

        admin_lib= lib_admin.Admin()

        action_map = {
            'delete':  lambda m: admin_lib.delete(
                mails=system_utils._normalize_list_mails([
                    str(v).split(":", 1)[0].strip().lower()
                    for v in m
                ])
            ),
            'disable': lambda m: admin_lib.enable_disable_accounts(m, "disable"),
            'enable':  lambda m: admin_lib.enable_disable_accounts(m, "enable"),
        }

        func = action_map.get(payload.get("action"))
        if not func:
            raise web.seeother(utils._redirect_url("/admins", domain, page=cur_page, msg="INVALID_ACTION"))
        
        ok, msg, *rest = func(payload["admin_id"])

        raise web.seeother(utils._redirect_url("/admins", domain, page=cur_page, msg=msg))

class ListAdmin(List):
    @decorators.require_domain_access
    def GET(self, domain):
        return super().GET(domain)

    @decorators.require_domain_access
    def POST(self, domain):
        return super().POST(domain)

class Profile:
    @decorators.require_global_admin
    def GET(self, profile_type, mail):
        form = web.input()
        mail = web.safestr(mail).lower()
        profile_type = web.safestr(profile_type)

        if not (session.get('is_global_admin') or session.get('username') == mail):
            # NOTE: No permetre veure/actualitzar el perfil d'altres administradors.
            raise web.seeother(utils._redirect_url('/profile/admin/general', session.get('username'), msg='PERMISSION_DENIED'))

        qr = lib_admin.Admin(mail = mail).get_profile()
        if not qr[0]:
            raise web.seeother('/admins?msg=' + qr[1])
        profile = utils._parse_crud_db_to_payload(qr[1])
        
        pwd_settings = iredutils.get_settings_from_db(params=['min_passwd_length', 'max_passwd_length'])
        pwd_data = {
            **{k: (v[next(iter(v))] if isinstance(v, dict) and v else v) for k, v in pwd_settings.items()},
            "passwd_policies": iredutils.get_password_policies(),
            "store_password_in_plain_text":settings.STORE_PASSWORD_IN_PLAIN_TEXT
        }  

        # NOTE: 2FA
        account_settings = profile.get('accountSetting', {})
        twofa = security.show_2fa_secret(account_settings.get('2fa_secret'), mail)

        return web.render(
            'crud/admin/profile.html',
            mail=mail,
            profile_type=profile_type,
            profile=profile,
            languagemaps=iredutils.get_language_maps(),
            timezones=TIMEZONES,
            pwd_data=pwd_data,
            twofa = twofa,
            msg=form.get('msg', None),
        )

    @decorators.csrf_protected
    @decorators.require_global_admin
    def POST(self, profile_type, mail):
        form = web.input()
        mail = web.safestr(mail).lower()
        profile_type = web.safestr(profile_type).lower()
        msg=None

        if not (session.get('is_global_admin') or session.get('username') == mail):
            # NOTE: No permetre veure/actualitzar el perfil d'altres administradors.
            raise web.seeother(utils._redirect_url('/profile/admin/general', session.get('username'), msg='PERMISSION_DENIED'))
        payload= utils._parse_crud_payload_to_db(form, profile_type=profile_type)
        
        if str(payload.get("2fa_renew")) == "1":
            # NOTE: 1. Generar nou secret i QR
            setup = security.generate_2fa_setup(mail)
            new_secret = setup["secret"]

            # NOTE: 2. Desa el secret xifrat al backend
            ok = security.activate_2fa(mail, new_secret, backend=settings.backend)
            if not ok:
                msg = "2FA_ERROR_RENEW"
            else:
                payload["2fa_secret"] = new_secret
                msg = "2FA_RENEWED"

        elif payload.get("2fa_token_verify"):
            if payload.get("2fa_secret"):
                ok = security.verify_2fa_token(payload.get("2fa_secret"), payload.get("2fa_token_verify"), mail)
                if not ok:
                    msg = "2FA_INCORRECT"
                else:
                    msg = "2FA_CORRECT"
        
        else:
            ok, msg, *rest = lib_admin.Admin(mail=mail).update(profile_type=profile_type, payload=payload)

        raise web.seeother(
            utils._redirect_url('/profile/admin', profile_type, mail, msg=msg)
        )

class Create:
    @decorators.require_global_admin
    def GET(self):
        form = web.input()

        pwd_settings = iredutils.get_settings_from_db(params=['min_passwd_length', 'max_passwd_length'])
        pwd_data = {
            **{k: (v[next(iter(v))] if isinstance(v, dict) and v else v) for k, v in pwd_settings.items()},
            "passwd_policies": iredutils.get_password_policies(),
            "store_password_in_plain_text":settings.STORE_PASSWORD_IN_PLAIN_TEXT
        }  

        return web.render(
            'crud/admin/create.html',
            languagemaps=iredutils.get_language_maps(),
            default_language=settings.default_language,
            pwd_data=pwd_data,
            msg=form.get('msg'))

    @decorators.require_global_admin
    @decorators.csrf_protected
    def POST(self):
        form = web.input()
        mail = web.safestr(form.get('mail'))
        msg=None

        payload = utils._parse_crud_payload_to_db(form)

        ok, msg, *rest = lib_admin.Admin(mail=mail).add(payload)
        if not ok:
            raise web.seeother(utils._redirect_url('/create/admin', msg=msg))

        raise web.seeother(utils._redirect_url('/profile/admin/general', mail, msg=msg))
