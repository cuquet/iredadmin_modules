# controllers/m_crud/utils.py
import web
from typing import Dict

import settings
if settings.backend == "ldap":
    from libs.ldaplib import attrs

from libs.m_system import utils
from controllers.m_system.utils import _format_errors, _redirect_url
from controllers.m_amavisd.utils import _spampolicy_form_payload_to_db, _wblist_form_payload_to_db
from controllers.m_iredapd.utils import _throttle_form_payload_to_db, _greylist_form_payload_to_db
from libs.iredutils import get_language_maps
from libs.m_system import form_utils

session = web.config.get('_session')

mapper = utils.KeyMap()

def _normalize_payload(form: Dict, profile_type:str=None) -> Dict:
    payload = {}

    if profile_type==None:
        for k, v in form.items():
            if k in {"domainName"}:
                raw_domain = form.get(k)
                if isinstance(raw_domain, (list, tuple, set)):
                    payload[k] = form_utils.get_multi_values(
                        form,
                        k,
                        is_domain=True,
                        to_lowercase=True,
                        to_string=True,
                    )
                else:
                    single_domain = form_utils.get_single_value(
                        form,
                        k,
                        is_domain=True,
                        to_lowercase=True,
                        to_string=True,
                    )
                    payload[k] = [single_domain] if single_domain else []
            elif k in {"mail"}: 
                payload[k] = form_utils.get_multi_values(form, k, is_email=True, to_lowercase=True, to_string=True)
            elif k in {"admin_id"}: # NOTE: no podem is_email=True perquè admins utilitza un camp combinat {{ mail }}:{{profile.adminType}}
                payload[k] = form_utils.get_multi_values(form, k,to_lowercase=True, to_string=True)
            elif k in {"action"}:
                payload[k] = form_utils.get_single_value(form, k, to_lowercase=True)
            elif k in {"keep_mailbox_days"}:
                payload[k] = form_utils.get_single_value(form, k, default_value=0, is_integer=True)
            elif k in {"cn"}:
                payload[k] = form_utils.get_single_value(form, k)
            elif k in {"username"}:
                payload[k] = form_utils.get_single_value(form, k, to_lowercase=True, to_string=True)
            elif k in {"newpw", "confirmpw", "password_hash"}:
                payload[k] = web.safestr(form.get(k,""))
            elif k in {"preferredLanguage"}:
                default_language = form_utils.get_single_value(form, input_name=k, to_string=True)
                normalized_lang = default_language if default_language in get_language_maps() else ""
                # NOTE: Mantenim les dues claus per compatibilitat entre backends:
                #  - `defaultLanguage` usat per alguns camins de domini/admin
                #  - `preferredLanguage` esperat per l'actualitzador SQL d'usuaris
                payload['defaultLanguage'] = normalized_lang
                payload['preferredLanguage'] = normalized_lang
            elif k in {"mailQuota"}:
                payload[k] = form_utils.quota_transformation(k, form)
            elif k in {"mailboxFormat"}:
                payload[k] = form_utils.get_single_value(form, k, to_lowercase=True, to_string=True)
            elif k in {"mailboxFolder"}:
                payload[k] = form_utils.get_single_value(form, k, to_string=True)
            elif k in {"maildir"}:
                payload[k] = form_utils.get_single_value(form, k, to_lowercase=True, to_string=True)

    elif profile_type in {'general'}:
        for k, v in form.items():
            if k in {"accountStatus"}:
                payload[k] = 'active' if form_utils.get_single_value(form, k, to_lowercase=True, to_string=True).strip().lower() == "on" else 'disabled'
            elif k in {"cn", "disclaimer"}:
                payload[k] = form_utils.get_single_value(form, k)
            # NOTE: específic usuari
            elif k in {"givenName", "sn", "employeeNumber" }:
                payload[k] = form_utils.get_single_value(form, k)
            elif settings.backend == "ldap" and k == "mobile":
                payload[k] = form_utils.get_single_value(form, k)
            elif settings.backend == "ldap" and k in {"telephoneNumber", "title"}:
                payload[k] = form_utils.normalize_text_multivalue(form, k)
            elif k in {"preferredLanguage"}:
                default_language = form_utils.get_single_value(form, input_name=k, to_string=True)
                normalized_lang = default_language if default_language in get_language_maps() else ""
                payload['defaultLanguage'] = normalized_lang
                payload['preferredLanguage'] = normalized_lang
            elif k in {"timezone"}:
                tz = form_utils.get_timezone(form)
                payload["timezone"] = tz if tz else ""
            elif k in {"mailQuota", "create_max_quota"}:
                payload[k] = form_utils.quota_transformation(k, form)
            elif k in {"mtaTransport", "mailboxFormat", "mailboxFolder"}:
                payload[k] = form_utils.get_single_value(form, k, to_string=True)
            elif k in {"maildir"}:
                payload[k] = form_utils.get_single_value(form, k, to_lowercase=True, to_string=True)
            elif k in {"domainGlobalAdmin", "domainadmin", "grant_admin", "disable_view_mail_log", "disable_manage_quarantined_mails", "create_new_domains"}:
                payload[k] = 'active' if form_utils.get_single_value(form, k, to_lowercase=True, to_string=True).strip().lower() == "on" else 'disabled'
            elif k in {"create_max_domains", "create_max_users", "create_max_aliases"}:
                number = form_utils.get_single_value(form, k, default_value='0', is_integer=True)
                if number == -1 or (isinstance(number, int) and number > 0):
                    payload[k] = number
            elif k in {"domainNames", "subscribed_ml"}:
                _qr =  form_utils.populate_form_list_filtered(form, k)
                if _qr[0]:
                    payload[k]= _qr[1]

        if settings.backend == "ldap":
            if "mobile" in form:
                payload["mobile"] = form_utils.get_single_value(form, "mobile")

            for multi_key in ("telephoneNumber", "title"):
                has_multivalue = (
                    multi_key in form
                    or any(web.safestr(name).startswith(f"{multi_key}[") for name in form.keys())
                )
                if has_multivalue:
                    payload[multi_key] = form_utils.normalize_text_multivalue(form, multi_key)

    elif profile_type in {'bcc'}:
        for k, v in form.items():
            if k in {"domainRecipientBccAddress", "domainSenderBccAddress"}:
                payload[k] = form_utils.get_single_value(form, k, is_email=True, to_lowercase=True)

    elif profile_type in {'relay'}:
        for k, v in form.items():
            if k in {"transport"}:
                payload[k] = form_utils.get_single_value(form, k, default_value=settings.default_mta_transport)
            elif k in {"relay_without_verify_local_recipient"}:
                payload[k] = 'active' if form_utils.get_single_value(form, k, to_lowercase=True, to_string=True).strip().lower() == "on" else 'disabled'
            elif k in {"relayhost"}:
                payload[k] = form_utils.get_single_value(form, k)

    elif profile_type in {'aliases'}:
        if form.get("add_extra_address_username"):
            _username=form_utils.get_single_value(form, "add_extra_address_username")
            _domain=form_utils.get_single_value(form, "add_extra_address_domain")
            form["add_extra_address"] = f"{_username}@{_domain}"

        for k, v in form.items():
            if k in {"domainalias"}:
                payload[k] = 'active' if form_utils.get_single_value(form, k, to_lowercase=True, to_string=True).strip().lower() == "on" else 'disabled'
            elif k in {"aliases"}:
                payload[k] = 'active' if form_utils.get_single_value(form, k, to_lowercase=True, to_string=True).strip().lower() == "on" else 'disabled'
            elif k in {"old_domainAliasName", "add_domainAliasName"}:
                payload[k] = form_utils.get_multi_values(form, k )
            elif k in {"domainAliasName"}:
                _qr =  form_utils.populate_form_list_filtered(form, k)
                if _qr[0]:
                    payload[k]= _qr[1]
            # NOTE: especific usuaris
            elif k in {"extra_address"}:
                _qr =  form_utils.populate_form_list_filtered(form, k)
                if _qr[0]:
                    payload[k]= _qr[1]

    elif profile_type in {'catchall'}:
        for k, v in form.items():
            if k in {"catchall_addresses"}:
                payload[k] = form_utils.get_multi_values_from_textarea(form, k, is_email=True)

    elif profile_type in {'backupmx'}:
        for k, v in form.items():
            if k in {"backupmx"}:
                payload[k] = 'active' if form_utils.get_single_value(form, k, to_lowercase=True, to_string=True).strip().lower() == "on" else 'disabled'
            elif k in {"primary_mx"}:
                payload[k] = form_utils.get_single_value(form, k, to_string=True)        

    elif profile_type in {'2fa'}:
        for k, v in form.items():
            if k in {"2fa_secret","2fa_renew", "2fa_token_verify"}:
                payload[k] = web.safestr(form.get(k,""))
            if k in {"2fa_enabled"}:
                payload[k] = 'active' if form_utils.get_single_value(form, k, to_lowercase=True, to_string=True).strip().lower() == "on" else 'disabled'

    elif profile_type in {'password'}:
        for k, v in form.items():
            if k in {"oldpw", "newpw", "confirmpw"}:
                payload[k] = web.safestr(form.get(k,""))

    elif profile_type in {'forwarding'}:
        for k, v in form.items():
            if k in {"catchall_addresses"}:
                _qr =  form_utils.populate_form_list_filtered(form, k)
                if _qr[0]:
                    payload[k]= _qr[1]
            if k in {"forwarding", "savecopy"}:
                payload[k] = 'active' if form_utils.get_single_value(form, k, to_lowercase=True, to_string=True).strip().lower() == "on" else 'disabled'

    elif profile_type in {'throttle'}:
        # iredapd:
        throttle_data = _throttle_form_payload_to_db(form)
        if throttle_data:
            payload.update(throttle_data)

    elif profile_type in {'greylisting'}:
        # iredapd:
        greylist_data = _greylist_form_payload_to_db(form)
        if greylist_data:
            payload.update(greylist_data)

    elif profile_type in {'spampolicy'}:
        # amavisd New: configuració spampolicy
        spampolicy_data = _spampolicy_form_payload_to_db(form)
        if spampolicy_data:
            payload.update(spampolicy_data)

    elif profile_type in {'wblist'}:
        # amavisd New: configuració wb
        wb_data = _wblist_form_payload_to_db(form)
        if wb_data:
            payload.update(wb_data)

    elif profile_type in {'advanced'}:
        for k, v in form.items():
            if k in {"domainName"}:
                payload[k] = form_utils.get_single_value(form, k, is_domain=True, to_lowercase=True, to_string=True)
            elif k in {"defaultQuota", "domainQuota", "maxUserQuota"}:
                payload[k] = form_utils.quota_transformation(k, form) or 0
            elif k in {"defaultRecipientBccAddress", "defaultSenderBccAddress"}:
                payload[k] = form_utils.get_single_value(form, k, is_email=True, to_lowercase=True) or ""
            elif k in {"min_passwd_length", "max_passwd_length"}:
                number = form_utils.get_single_value(form, k, default_value=0, is_integer=True) 
                payload[k] = number
            elif k in {"numberOfUsers", "numberOfLists"}:
                number = form_utils.get_single_value(form, k, default_value=0, is_integer=True) or '0'
                # if number == -1 or (isinstance(number, int) and number > 0):
                payload[k] = number
            elif k in {"disabledUserPreference", "disabledUserProfile", "disabledMailService", "disabledDomainProfile"}:
                value = form_utils.get_form_dict(form, k, multi_values = True, to_lowercase = True )
                payload[k] = value.get(k, [])
            elif k in {"enabledService"}:
                payload[k] = [ v for v in form_utils.get_multi_values(form, k ) if v in attrs.DOMAIN_ENABLED_SERVICE]
            elif k in {"preferredLanguage"}:
                default_language = form_utils.get_single_value(form, input_name=k, to_string=True)
                payload['defaultLanguage'] = default_language if default_language in get_language_maps() else ""
            elif k in {"timezone"}:
                tz = form_utils.get_timezone(form)
                payload["timezone"] = tz if tz else ""
            else:
                continue
                # payload[k] = v

    return payload


def _parse_crud_payload_to_db(form: Dict, profile_type:str=None) -> Dict:
    """
    Flux complet: normalitza + remapeja claus segons backend (ldap/sql)
    """
    normalized = _normalize_payload(form, profile_type)
    mapped = mapper.remap_dict(normalized, reverse=False)

    # NOTE: Contracte canònic de domini: la capa de lib treballa amb
    # NOTE: `maxUserQuota` i `defaultQuota` (independentment del backend).
    # NOTE: En SQL el keymap pot remapejar temporalment a claus de columna
    # NOTE: (`maxquota`, `default_user_quota`), i aquí ho re-unifiquem.
    if settings.backend in {"mysql", "pgsql"}:
        if "maxquota" in mapped and "maxUserQuota" not in mapped:
            mapped["maxUserQuota"] = mapped.pop("maxquota")
        if "default_user_quota" in mapped and "defaultQuota" not in mapped:
            mapped["defaultQuota"] = mapped.pop("default_user_quota")

    return mapped

def _parse_crud_db_to_payload(data: Dict ) -> Dict:
    """
        Converteix dades de DB -> payload aplicant `mapper.remap_dict`.

        - Si `data` és un dict -> retorna un dict remapejat.
        - Si `data` és una llista de dicts -> retorna una llista de dicts remapejats.

        Args:
            data (dict | list[dict]): Dades originals.

        Returns:
            dict | list[dict]: Dades convertides.
    """
    def _prepare_item_for_reverse_map(item: Dict) -> Dict:
        """
        NOTE:
        En SQL la taula `mailbox` usa `username` (no `address`) com a login.
        El key_map actual remapeja `mail <- address`, així que, si només arriba
        `username`, fem un alias intern abans del remap per evitar `mail=None`
        a plantilles i controladors.
        """
        if not isinstance(item, dict):
            return item

        if settings.backend in {"mysql", "pgsql"}:
            if not item.get("address") and item.get("username"):
                _item = dict(item)
                _item["address"] = str(_item.get("username", "")).lower()
                return _item

        return item

    if isinstance(data, dict):
        prepared = _prepare_item_for_reverse_map(data)
        return mapper.remap_dict(prepared, reverse=True)
    if isinstance(data, list):
        return [
            mapper.remap_dict(_prepare_item_for_reverse_map(item), reverse=True)
            for item in data if isinstance(item, dict)
        ]

    raise TypeError(f"Input ha de ser dict o list[dict], rebut: {type(data).__name__}")


def self_service_login_redirect(username):
    # NOTE: Possible redirect pages: preferences, quarantined, received, wblist, spampolicy.
    if settings.SELF_SERVICE_DEFAULT_PAGE == 'preferences':
        raise web.seeother('/preferences')
    elif settings.SELF_SERVICE_DEFAULT_PAGE == 'quarantined':
        raise web.seeother('/activities/quarantined/user/' + username)
    elif settings.SELF_SERVICE_DEFAULT_PAGE == 'received':
        raise web.seeother('/activities/received/user/' + username)
    elif settings.SELF_SERVICE_DEFAULT_PAGE == 'wblist':
        raise web.seeother('/preferences/wblist')
    elif settings.SELF_SERVICE_DEFAULT_PAGE == 'spampolicy':
        raise web.seeother('/preferences/spampolicy')
    else:
        raise web.seeother('/preferences')
