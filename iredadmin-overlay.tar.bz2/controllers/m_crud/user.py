# controllers/m_crud/user.py
import web

import settings
from libs import iredutils
from libs.l10n import TIMEZONES

from controllers.m_crud import utils
from libs.m_system.jinja_filters import SYMBOLS
from libs.m_crudlib import decorators
from libs.m_crudlib import domain as lib_domain
from libs.m_crudlib import user as lib_user
from libs.m_amavisd import wblist as lib_wblist, spampolicy as lib_spampolicy
from libs.m_maillist import ml as lib_ml

from libs.m_crudlib import security

session = web.config.get('_session')

BASE_URL = "/users"

class List:
    @decorators.require_domain_access
    def GET(self, domain, disabled_only=False):
        domain = web.safestr(domain).lower()
        
        form = web.input(
            page=1,
            disabled_only=None,
            msg=None,
            _unicode=False
        )
        cur_page = int(form.page or 1) or 1

        if form.disabled_only is not None:
            disabled_only = form.disabled_only in ("1", "true", "yes")

        first_char = None
        if 'starts_with' in form:
            first_char = form.get('starts_with')[:1].upper()
            if not iredutils.is_valid_account_first_char(first_char):
                first_char = None

        user_lib = lib_user.User(domain=domain)

        ok, all_first_chars, *rest = user_lib.users_get_first_char_of_all()
        if not ok:
            raise web.seeother(utils._redirect_url("/domains", msg=all_first_chars))
        
        ok, sl, *rest = user_lib.list(disabled_only=disabled_only, starts_with=first_char, current_page=cur_page)
        if not ok:
            raise web.seeother(utils._redirect_url("/domains", msg=sl))

        account_profiles= utils._parse_crud_db_to_payload(sl['account_profiles'])

        days_to_keep_removed_mailbox = (
            settings.DAYS_TO_KEEP_REMOVED_MAILBOX_FOR_GLOBAL_ADMIN
            if session.get('is_global_admin')
            else settings.DAYS_TO_KEEP_REMOVED_MAILBOX
        )

        return web.render(
            'crud/user/list.html',
            cur_page=cur_page,
            total=sl['total'],
            account_profiles=account_profiles,
            cur_domain=domain,
            all_first_chars=all_first_chars,
            first_char=first_char,
            disabled_only=disabled_only,
            days_to_keep_removed_mailbox=days_to_keep_removed_mailbox,
            msg=form.get('msg'))

    @decorators.require_domain_access
    @decorators.csrf_protected
    def POST(self, domain):
        domain = web.safestr(domain).lower()

        form = web.input(
            mail=[],
            msg=None,  
            _unicode=False
            )
        cur_page = int(form.cur_page or 1) or 1

        payload = utils._parse_crud_payload_to_db(form)
        
        mails = [ v for v in payload.get('mail', [])
            if str(v).endswith(f'@{domain}')
        ]
        if not mails:
            raise web.seeother(utils._redirect_url(BASE_URL, domain, page=cur_page, msg="NO_ACCOUNT_SELECTED"))

        user_lib = lib_user.User(domain=domain)

        action_map = {
            "delete": lambda m: user_lib.delete_users(m, payload.get("keep_mailbox_days")),
            "enable": lambda m: user_lib.enable_disable_accounts(m, "enable"),
            "disable": lambda m: user_lib.enable_disable_accounts(m, "disable"),
            "markasglobaladmin": lambda m: user_lib.users_mark_unmark_as_globaladmin(m, "markasglobaladmin"),
            "unmarkasglobaladmin": lambda m: user_lib.users_mark_unmark_as_globaladmin(m, "unmarkasglobaladmin"),
        }

        func = action_map.get(payload.get("action"))
        if not func:
            ok, msg = False, "INVALID_ACTION"
        else:
            ok, msg, *rest = func(mails)

        raise web.seeother(utils._redirect_url(BASE_URL, domain, page=cur_page, msg=msg))

class ListDisabled:
    @decorators.require_global_admin
    def GET(self, domain):
        _users = List()
        return _users.GET(domain=domain, disabled_only=True)

class Profile:
    @decorators.require_domain_access
    def GET(self, profile_type, mail):
        profile_type = web.safestr(profile_type).lower()
        mail = web.safestr(mail).lower() or session.get('username')
        
        form = web.input(
            _unicode=False
            )

        cur_domain = mail.split('@', 1)[-1]

        def _first(value):
            if isinstance(value, list):
                return value[0] if value else ''
            return value or ''

        def _domain_choice(entry):
            if not isinstance(entry, dict):
                return None
            domain_name = _first(entry.get("domainName")) or _first(entry.get("domain"))
            label = _first(entry.get("cn")) or _first(entry.get("description")) or _first(entry.get("desc")) or domain_name
            if not domain_name:
                return None
            return (domain_name, label)

        def _mail_choice(entry):
            if isinstance(entry, str):
                addr = entry.strip().lower()
                # NOTE: Quan la lib retorna error (string), no volem mapar text lliure com a correu.
                return (addr, addr) if (addr and iredutils.is_email(addr)) else None
            if not isinstance(entry, dict):
                return None
            addr = _first(entry.get("mail")) or _first(entry.get("address"))
            name = _first(entry.get("cn")) or _first(entry.get("name")) or addr
            if not addr:
                return None
            return (addr, name)

        domain_lib = lib_domain.Domain(cur_domain)

        qr = lib_user.User(mail=mail).get_profile()
        if not qr[0]:
            raise web.seeother(utils._redirect_url(BASE_URL, cur_domain, msg=qr[1]))

        profile = utils._parse_crud_db_to_payload(qr[1])

        errors= []

        # NOTE: Per-domain account settings
        # El backend SQL no exposa `domainCurrentQuotaSize` com a columna,
        # així que allà usem el perfil complet i mantenim la consulta LDAP optimitzada.
        if settings.backend == 'ldap':
            qr = domain_lib.get_profile(attributes=['domainCurrentQuotaSize'])
        else:
            qr = domain_lib.get_profile()

        if not qr[0]:
            errors.append([f"Error [Domain().get_profile(domainCurrentQuotaSize)]: {qr[1]}"])
            domainUsedQuota = 0
        else:
            profile_domain = utils._parse_crud_db_to_payload(qr[1])
            domainUsedQuota = profile_domain.get('domainCurrentQuotaSize', 0) or 0

        qr_domain_settings = domain_lib.get_domain_account_settings()
        if not qr_domain_settings[0]:
            errors.append([f"Error [Domain().get_domain_account_settings]: {qr_domain_settings[1]}"])
            domainAccountSettings = {}
        else:
            domainAccountSettings = qr_domain_settings[1]

        pwd_data = domain_lib.get_domain_pwd_data()

        # NOTE: Obté tots els dominis.
        qr_all_domains = lib_domain.Domain().get_all_domains()
        if not qr_all_domains[0]:
            errors.append([f"Error [Domain().get_all_domains]: {qr_all_domains[1]}"])
        all_domains = [opt for opt in (_domain_choice(e) for e in qr_all_domains[1]) if opt]

        # NOTE: Obté tots els noms de domini i d'àlies de domini per a possibles àlies d'usuari.
        qr_alias_domain = domain_lib.get_domain_aliases()
        if not qr_alias_domain[0]:
            errors.append([f"Error [Domain().get_domain_aliases]: {qr_alias_domain[1]}"])
            all_domain_alias = [cur_domain]
        else:
            all_domain_alias = list(dict.fromkeys(qr_alias_domain[1] + [cur_domain]))
        
        # NOTE: Obté els dominis sota control.
        qr_managed_domains = lib_domain.Domain().get_managed_domains(admin=mail)
        if not qr_managed_domains[0]:
            errors.append([f"Error [Domain().get_managed_domains]: {qr_managed_domains[1]}"])
        managed_domains = [opt for opt in (_domain_choice(e) for e in qr_managed_domains[1]) if opt]

        # NOTE: mailling list
        qr_all_ml = lib_ml.MailList(domain=cur_domain).list()
        if not qr_all_ml[0]:
            errors.append([f"Error [MailList().list]: {qr_all_ml[1]}"])
        all_ml = [opt for opt in (_mail_choice(e) for e in qr_all_ml[1]) if opt]

        qr_subscribed_ml = lib_ml.MailList(domain=cur_domain).list(subscriber=mail)
        if not qr_subscribed_ml[0]:
            errors.append([f"Error [MailList().list(subscriber={mail})]: {qr_subscribed_ml[1]}"])
        subscribed_ml = [opt for opt in (_mail_choice(e) for e in qr_subscribed_ml[1]) if opt]
        
        # --------------- amavisd
        # spampolicy
        spam_data = {}
        if session.get('amavisd_enable_policy_lookup'):
            ok, spam_data = lib_spampolicy.get_spam_policy(account=mail)
            if not ok:
                spam_data={}
                # error = spam_data.get("errors") or spam_data
                # errors.append([f"Failed spampolicy: {error}"])
            # if spam_data.get('spam_policy') == 'NO_SUCH_SPAMPOLICY':
            #     errors.append(spam_data.get('spam_policy'))

        # white/blacklists
        wb_data = {}
        ok, wb_data = lib_wblist.get_wblist(mail)
        if not ok:
            wb_data={}
            # errors.append([f"Failed WBlist: {wb_data}"])

        # @NOTE: 2FA
        account_settings = profile.get('accountSetting', {})
        secret = account_settings.get('2fa_secret')
        twofa = security.show_2fa_secret(secret, mail)

        if errors:
            error_msg = utils._format_errors(errors)
        else:
            error_msg = form.get('msg', None)

        return web.render(
            'crud/user/profile.html',
            mail=mail,
            profile_type=profile_type,
            profile=profile,
            defaultStorageBaseDirectory=settings.storage_base_directory,
            timezones=TIMEZONES,
            size_symbols=SYMBOLS,
            pwd_data = pwd_data,
            used_quota_bytes=domainUsedQuota,
            domainAccountSettings=domainAccountSettings,
            languagemaps=iredutils.get_language_maps(),
            all_domains=all_domains,
            managed_domains=managed_domains,
            all_domain_alias=all_domain_alias,  
            all_ml=all_ml,
            subscribed_ml=subscribed_ml,
            spam_data=spam_data,
            wb_data=wb_data,
            twofa=twofa,
            msg=error_msg,
        )

    @decorators.require_domain_access
    @decorators.csrf_protected
    def POST(self, profile_type, mail):
        profile_type = web.safestr(profile_type).lower()
        mail = web.safestr(mail).lower()
        msg = None

        form = web.input(
            domainNames=[],
            old_domainNames=[],
            subscribed_ml=[],
            old_subscribed_ml=[],
            enabledService=[],
            mobile=[],
            title=[],
            telephoneNumber=[],
            extra_address=[],
            old_extra_address=[],
        )
        payload = utils._parse_crud_payload_to_db(form, profile_type)

        if str(payload.get("2fa_renew")) == "1":
            # NOTE: 1. Generar nou secret i QR
            setup = security.generate_2fa_setup(mail)
            new_secret = setup["secret"]

            # NOTE: 2. Desa el secret xifrat al backend
            ok = security.activate_2fa(mail, new_secret, backend=settings.backend)
            if not ok:
                msg = "2FA_ERROR_RENEW"
            else:
                payload["2fa_secret"] = new_secret
                msg = "2FA_RENEWED"

        elif payload.get("2fa_token_verify"):
            if payload.get("2fa_secret"):
                ok = security.verify_2fa_token(payload.get("2fa_secret"), payload.get("2fa_token_verify"), mail)
                if not ok:
                    msg = "2FA_INCORRECT"
                else:
                    msg = "2FA_CORRECT"
        
        else:
            ok, msg, *rest = lib_user.User(mail=mail).update(profile_type=profile_type, payload=payload)
            if not ok:
                msg = utils._format_errors(msg)
        
        raise web.seeother(utils._redirect_url('/profile/user', profile_type, mail, msg=msg))

class Create:
    @decorators.require_permission_create_domain
    @decorators.require_login
    def GET(self, domain):
        domain = web.safestr(domain).lower()
        form = web.input(
            _unicode=False
        )
        
        qr = lib_domain.Domain().get_all_domains()
        if not qr[0]:
            raise web.seeother(
                utils._redirect_url('/domains', msg=qr[1])
                )
        allDomains = utils._parse_crud_db_to_payload(qr[1])
        
        domain_lib =lib_domain.Domain(domain)
        qr = domain_lib.get_domain_account_settings()
        domainAccountSetting = qr[1] if qr[0] else {}

        defaultUserQuota = domainAccountSetting.get('defaultQuota', 0)
        maxUserQuota = domainAccountSetting.get('maxUserQuota', 0)

        pwd_data = domain_lib.get_domain_pwd_data()

        num_acc_max = domainAccountSetting.get('numberOfUsers',0)
        num_acc_cur = domain_lib.num_users_under_domain()
        num_acc_spare=num_acc_max-num_acc_cur
        createNewAccount = True
        if num_acc_max == -1:
            createNewAccount = False
        elif num_acc_max > 0 and num_acc_spare <= 0:
            createNewAccount = False

        return web.render(
            'crud/user/create.html',
            size_symbols=SYMBOLS,
            cur_domain=domain,
            allDomains=allDomains,
            default_user_quota=defaultUserQuota,
            max_user_quota=maxUserQuota,
            domain_settings=domainAccountSetting,
            pwd_data=pwd_data, 
            numberOfSpareAccounts=num_acc_spare,
            numberOfAccountsLimit=num_acc_max,
            createNewAccount=createNewAccount,
            languagemaps=iredutils.get_language_maps(),
            msg=form.get('msg')
        )

    @decorators.require_permission_create_domain
    @decorators.csrf_protected
    @decorators.require_login
    def POST(self, domain):
        domain = web.safestr(domain).strip().lower()
        form = web.input(
            domainName=[],
            _unicode=False
            )

        domain_in_form = form.get('domainName', [])
        if domain not in domain_in_form or not domain_in_form:
            raise web.seeother(utils._redirect_url('/users', domain, msg='PERMISSION_DENIED'))

        payload = utils._parse_crud_payload_to_db(form)

        ok, result, *rest = lib_user.User(domain=domain).add(payload)
        if not ok:
            raise web.seeother(utils._redirect_url('/create/user', domain, msg=result))

        raise web.seeother(utils._redirect_url('/profile/user/general', result, msg='CREATED'))

class CreateDispatcher:
    @decorators.require_global_admin
    def GET(self, account_type):
        account_type=web.safestr(account_type).lower()
        qr = lib_domain.Domain().get_all_domains(names_only=True)
        if not qr[0]:
            raise web.seeother(utils._redirect_url('/domains', msg=qr[1]))
        
        all_domains = qr[1]
        if all_domains:
            # Crea un compte nou al primer domini, de manera que puguem
            # obtenir la configuració del compte per domini, com ara el nombre de
            # límit de comptes, el control de la longitud de la contrasenya, etc.   
            raise web.seeother(utils._redirect_url('/create', account_type, all_domains[0]))
        else:
            raise web.seeother(utils._redirect_url('/domains', msg='NO_DOMAIN'))

class SelfServiceMailLists:
    @staticmethod
    def _normalize_mail_list(values):
        mails = []
        for item in values or []:
            if isinstance(item, dict):
                val = item.get("mail") or item.get("address")
                if isinstance(val, list):
                    val = val[0] if val else ""
            else:
                val = item

            if isinstance(val, bytes):
                val = val.decode(errors="ignore")

            val = web.safestr(val).strip().lower() if val else ""
            if iredutils.is_email(val):
                mails.append(val)

        return sorted(set(mails))

    @decorators.require_user_login
    def GET(self):
        form = web.input(msg=None, _unicode=False)
        mail = web.safestr(session.get('username', '')).strip().lower()
        cur_domain = mail.split('@', 1)[-1] if mail else ''

        if not iredutils.is_email(mail):
            raise web.seeother('/login?msg=LOGIN_REQUIRED')

        ok_domain, domain_lists, *rest = lib_ml.MailList(domain=cur_domain).list(
            current_page=0,
            email_only=True,
        )
        if not ok_domain:
            raise web.seeother('/preferences?msg={}'.format(web.urlquote(str(domain_lists))))

        ok_subscribed, subscribed_lists, *rest = lib_ml.MailList(domain=cur_domain).list(
            current_page=0,
            subscriber=mail,
            email_only=True,
            all_domains=True,
        )
        if not ok_subscribed:
            raise web.seeother('/preferences?msg={}'.format(web.urlquote(str(subscribed_lists))))

        ml_options = sorted(set(
            self._normalize_mail_list(domain_lists) + self._normalize_mail_list(subscribed_lists)
        ))

        return web.render(
            'crud/user/self-service_mls.html',
            mail=mail,
            cur_domain=cur_domain,
            ml_options=[(i, i) for i in ml_options],
            subscribed_ml=self._normalize_mail_list(subscribed_lists),
            msg=form.get('msg'),
        )

    @decorators.require_user_login
    @decorators.csrf_protected
    def POST(self):
        mail = web.safestr(session.get('username', '')).strip().lower()
        if not iredutils.is_email(mail):
            raise web.seeother('/login?msg=LOGIN_REQUIRED')

        form = web.input(
            subscribed_ml=[],
            old_subscribed_ml=[],
            _unicode=False
        )
        payload = utils._parse_crud_payload_to_db(form, profile_type='general')

        ok, msg, *rest = lib_user.User(mail=mail).update(profile_type='general', payload=payload)
        if not ok:
            msg = utils._format_errors(msg)

        raise web.seeother('/self-service/mls?msg={}'.format(web.urlquote(str(msg))))

class Preferences:
    @decorators.require_user_login
    def GET(self, profile_type='general'):
        mail = session.get('username')
        domain = mail.split('@', 1)[-1] if mail else None
        domain_lib = lib_domain.Domain(domain)

        form = web.input(
            enabledService=[],
            telephoneNumber=[],
            _unicode=False
            )

        if not iredutils.is_email(mail):
            raise web.seeother('/domains?msg=INVALID_USER')

        qr = lib_user.User(mail=mail).get_profile()

        if not qr[0]:
            raise web.seeother('/preferences/{}?msg={}'.format(profile_type, web.urlquote(qr[1])))

        profile = utils._parse_crud_db_to_payload(qr[1])

        # NOTE: Per-domain account settings
        qr = domain_lib.get_profile(attributes=['domainCurrentQuotaSize'])
        if qr[0]:
            profile_domain = utils._parse_crud_db_to_payload(qr[1])
            domainUsedQuota = profile_domain.get('domainCurrentQuotaSize', 0) or 0
        else:
            domainUsedQuota = 0
        qr_domain_settings = domain_lib.get_domain_account_settings()
        domainAccountSettings = qr_domain_settings[1] if qr_domain_settings[0] else {}

        # NOTE: --------------- amavisd
        # spampolicy
        if session.get('amavisd_enable_policy_lookup'):
            ok, spam_data = lib_spampolicy.get_spam_policy(account=mail)
            if not ok:
                spam_data={}

        # white/blacklists
        ok, wb_data = lib_wblist.get_wblist(mail)
        if not ok:
            wb_data={}

        # NOTE: Obté la quota utilitzada del compte.
        accountUsedQuota = {}
        if settings.SHOW_USED_QUOTA:
            accountUsedQuota = lib_user.User(mail=mail).get_account_used_quota(mail)

        pwd_data = domain_lib.get_domain_pwd_data()
        
        # NOTE: 2FA
        account_settings = profile.get('accountSetting', {})
        secret = account_settings.get('2fa_secret')
        twofa = security.show_2fa_secret(secret, mail)

        return web.render(
            'crud/user/self-service_preferences.html',
            mail=mail,
            profile_type=profile_type,
            profile=profile,
            pwd_data=pwd_data,
            password_policies=pwd_data.get("passwd_policies"),
            timezones=TIMEZONES,
            size_symbols=SYMBOLS,
            used_quota=accountUsedQuota,
            used_quota_bytes=domainUsedQuota,
            domainAccountSettings=domainAccountSettings,
            spam_data=spam_data,
            wb_data=wb_data,
            twofa=twofa,
            languagemaps=iredutils.get_language_maps(),
            msg=form.get('msg', None),
        )

    @decorators.require_user_login
    @decorators.csrf_protected
    def POST(self, profile_type='general'):
        mail = session.get('username')

        form = web.input(
            enabledService=[],
            mailForwardingAddress=[],
            domainName=[],
        )
        payload = utils._parse_crud_payload_to_db(form, profile_type)
        result = lib_user.User(mail=mail).update(profile_type=profile_type, payload=payload)

        if result[0]:
            raise web.seeother('/preferences/{}?msg=UPDATED'.format(profile_type))
        else:
            raise web.seeother('/preferences/{}?msg={}'.format(profile_type, web.urlquote(result[1])))
