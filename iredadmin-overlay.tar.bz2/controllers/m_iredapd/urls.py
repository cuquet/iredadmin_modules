# controllers/m_iredapd/urls.py
from libs.regxes import email as e, domain as d

urls = [
    # GREYLISTING EXPORT
    r'/activities/greylisting/export$', 'controllers.m_iredapd.controller.GreylistingTrackingDataExport',
    r'/activities/greylisting/export/(%s|%s|all)$' % (e, d), 'controllers.m_iredapd.controller.GreylistingTrackingDataExport',

    # GREYLISTING TRACKING
    r'/system/greylisting/tracking$', 'controllers.m_iredapd.controller.GreylistingTrackingData',
    r'/system/greylisting/tracking/(%s|%s|all)$' % (e, d), 'controllers.m_iredapd.controller.GreylistingTrackingData',
    r'/activities/greylisting$', 'controllers.m_iredapd.controller.GreylistingTrackingData',
    r'/activities/greylisting/(%s|%s|all)$' % (e, d), 'controllers.m_iredapd.controller.GreylistingTrackingData',

    # SMTP EXPORT
    r'/activities/smtp/sessions/export$', 'controllers.m_iredapd.controller.smtpSessionsExport',
    r'/activities/smtp/sessions/export/(outbound|rejected|all)$', 'controllers.m_iredapd.controller.smtpSessionsExport',

    # SMTP
    r'/activities/smtp/sessions$', 'controllers.m_iredapd.controller.smtpSessions',
    r'/activities/smtp/sessions/(outbound|rejected|all)$', 'controllers.m_iredapd.controller.smtpSessions',
]

