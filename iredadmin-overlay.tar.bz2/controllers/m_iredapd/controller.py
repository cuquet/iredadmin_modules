# controllers/m_iredapd/controller.py
import web
from typing import Optional

from controllers.m_iredapd import utils
from libs.m_system.mixins import ExporterFactory, GREYLISTING_EXPORT_SCHEMA, SMTP_SESSIONS_EXPORT_SCHEMA
from libs.m_crudlib import decorators
from libs.m_iredapd import greylist as lib_greylist, smtp as lib_smtp

def _normalize_target_from_url(param: Optional[str]) -> str:
    """
        Converteix el paràmetre d'URL al format esperat per Greylisting:
        - None o 'all' → '@.'      (catch-all)
        - 'domain.com' → '@domain.com'
        - 'user@dom'   → 'user@dom'
    """
    if not param:
        return '@.'

    param = param.strip().lower()
    if param == 'all':
        return '@.'
    if '@' in param:
        return param

    return '@' + param


class GreylistingTrackingData(object):
    @decorators.require_login
    @decorators.require_domain_access
    def GET(self, target=None):
        """
            Mostra registres de greylisting.
            target pot ser:
                - None                     -> catch-all
                - 'all'                    -> catch-all
                - 'example.com'            -> domini
                - 'user@example.com'       -> email
        """
        form = web.input(
            page=1,
            query_string="",
            date_from="",
            date_to="",
            passed="all",
            msg=None,
            _unicode=False
        )
        cur_page = max(1, int(form.page))
        filters = {
            "query_string": form.get("query_string"),
            "date_from": form.get("date_from"),
            "date_to": form.get("date_to"),
            "passed": None if form.get("passed") == "all" else form.get("passed"),
            "page": cur_page if cur_page > 1 else None,
        }

        clean_filters = utils._canonical_redirect(
            path=web.ctx.path,
            params=filters
        )

        target_raw = web.safestr(target) if target is not None else "all"

        ok, data, *rest = lib_greylist.Greylisting(account=_normalize_target_from_url(target_raw)).get_tracking_data(
            page=cur_page,
            payload=clean_filters
        )
        if not ok:
            raise web.seeother(utils._redirect_url('/system/greylisting', page=cur_page, msg=data))

        return web.render(
            'iredapd/greylisting_tracking_records.html',
            data=data,
            account=target_raw,
            filters=filters,
            )

    @decorators.csrf_protected
    @decorators.require_login
    @decorators.require_domain_access
    def POST(self, target=None):
        """
            Mostra registres de greylisting.
            target pot ser:
                - None                     -> catch-all
                - 'all'                    -> catch-all
                - 'example.com'            -> domini
                - 'user@example.com'       -> email
        """
        payload={}
        form = web.input(
            page=1,
            query_string="",
            date_from="",
            date_to="",
            record=[],
            msg=None,
            _unicode=False
        )
        cur_page = max(1, int(form.page))
        cur_q = web.safestr(form.get("query_string", None))
        cur_date_from = web.safestr(form.get("date_from", None))
        cur_date_to = web.safestr(form.get("date_to", None))
        filters={
            k: v for k, v in {
                "query_string": cur_q,
                "date_from": cur_date_from,
                "date_to": cur_date_to,
            }.items() if v not in (None, "")
        }

        action = form.get('action', 'delete')
        delete_all = form.get('action') == 'deleteAll'
        payload['id']=form.get('record') or []

        target_raw = web.safestr(target) if target is not None else None

        if action in {'delete', 'deleteAll'}:
            ok, data, *rest = lib_greylist.Greylisting(account=_normalize_target_from_url(target_raw)).delete_tracking_data(
                payload=payload,
                delete_all=delete_all
            )
            if not ok:
                raise web.seeother(utils._redirect_url('/system/greylisting',page=cur_page, msg=data))

        raise web.seeother(utils._redirect_url('/system/greylisting/tracking', target_raw, msg=data, **filters))

class GreylistingTrackingDataExport(object):
    @decorators.require_login
    @decorators.require_domain_access
    def GET(self, target=None):
        return self._handle_export(target)

    @decorators.csrf_protected
    @decorators.require_login
    @decorators.require_domain_access
    def POST(self, target=None):
        return self._handle_export(target)

    def _handle_export(self, target):
        form = web.input(
            format='xls',
            query_string=None,
            date_from=None,
            date_to=None,
            passed=None,
            zip=None,
            _unicode=False
        )
        payload = {
            k: v for k, v in {
                "query_string": form.get("query_string"),
                "date_from": form.get("date_from"),
                "date_to": form.get("date_to"),
                "passed": form.get("passed"),
            }.items() if v not in (None, "")
        }

        target_raw = web.safestr(target) if target is not None else "all"

        ok, data, *rest = lib_greylist.Greylisting(account=_normalize_target_from_url(target_raw)).get_tracking_data(page=0, payload=payload)
        if not ok:
            raise web.seeother(utils._redirect_url('/system/greylisting', page=1, msg=data))

        exporter = ExporterFactory.from_SQL(
            format=form.get('format', 'xls'),
            schema=GREYLISTING_EXPORT_SCHEMA,
            title=f"Greylisting – {target_raw}",
            zip=bool(form.get('zip')),
        )
        
        exporter.apply_headers(
            web,
            base_filename=f"greylisting_{target_raw}"
        )

        return exporter.export(data.get('records', []))

class smtpSessions:
    @decorators.require_login
    @decorators.require_domain_access
    def GET(self, session_type='all'):
        """
            Gestiona la visualització de les sessions SMTP.
            session_type pot ser: 'all', 'outbound', 'rejected'.
        """
        form = web.input(
            page=1, 
            query_string="", 
            date_from="",
            session_type=None,
            msg=None, 
            _unicode=False
        )

        cur_page = max(1, int(form.page))

        target_type = (form.session_type or session_type).lower()
        if target_type not in {'all', 'outbound', 'rejected'}:
            target_type = 'all'

        filters = {
            "query_string": (form.query_string or "").strip(),
            "date_from": (form.date_from or "").strip(),
            "page": cur_page if cur_page > 1 else None
        }

        clean_filters = utils._canonical_redirect(
            path=f'/activities/smtp/sessions/{target_type}',
            params=filters
        )

        payload = {
            "session_type": target_type,
            "query_string": clean_filters.get('query_string', ''),
            "date_from": clean_filters.get('date_from', '')
        }

        smtp_lib = lib_smtp.SMTPStats()
        
        ok, data, *rest = smtp_lib.list(page=cur_page, payload=payload)
        if not ok:
            raise web.seeother(utils._redirect_url('activities/smtp/sessions', target_type, page=cur_page, msg=data))

        return web.render(
            'iredapd/smtp.html',
            data=data,
            session_type=target_type,
            filters=payload, 
            cur_page=cur_page,
            msg=form.get('msg')
        )

class smtpSessionsExport(object):
    @decorators.require_login
    @decorators.require_domain_access
    def GET(self, session_type='all'):
        return self._handle_export(session_type)

    @decorators.csrf_protected
    @decorators.require_login
    @decorators.require_domain_access
    def POST(self, session_type='all'):
        return self._handle_export(session_type)

    def _handle_export(self, session_type='all'):
        form = web.input(
            format='xls',
            query_string=None,
            date_from=None,
            zip=None,
            _unicode=False
        )
        payload = {
            k: v for k, v in {
                "query_string": form.get("query_string"),
                "date_from": form.get("date_from"),
                "session_type": session_type
            }.items() if v not in (None, "")
        }

        smtp_lib = lib_smtp.SMTPStats()
        ok, data, *rest = smtp_lib.list(page=0, payload=payload)
        if not ok:
            raise web.seeother(utils._redirect_url('/activities/smtp/sessions', session_type, page=1, msg=data))

        exporter = ExporterFactory.from_SQL(
            format=form.get('format', 'xls'),
            schema=SMTP_SESSIONS_EXPORT_SCHEMA,
            title=f"SMTP Sessions – {session_type}",
            zip=bool(form.get('zip')),
        )

        exporter.apply_headers(
            web,
            base_filename=f"smtp_sessions_{session_type}"
        )

        return exporter.export(data.get('records', []))
