# controllers/m_iredapd/utils.py
from typing import Dict

from libs.m_iredapd.throttle import DEFAULT_DB_THROTTLE
from libs.m_system.mixins import Direction
from libs.m_system import form_utils

MAP_GREYLIST_PAYLOAD_TO_DB = {
    "whitelists": "whitelists",
    "whitelist_domains": "whitelist_domains",
    "rdns_whitelist": "rdns_whitelist",
    "rdns_blacklist": "rdns_blacklist",
    "greylisting": "greylisting",
    }

MAP_THROTTLE_PAYLOAD_TO_DB = {
    "period": "period",
    "max_msgs": "max_msgs",
    "max_quota": "max_quota",
    "msg_size": "msg_size",
    "max_rcpts": "max_rcpts",
    }

MAP_RDNS_PAYLOAD_TO_DB = {
    "rdns_whitelist": "rdns_whitelist",
    "rdns_blacklist": "rdns_blacklist",
    }

def _redirect_url(*args, **kwargs):
    from controllers.m_system.utils import _redirect_url as _r_url
    return _r_url(*args, **kwargs)

def _format_errors(*args, **kwargs):
    from controllers.m_system.utils import _format_errors as _f_errors
    return _f_errors(*args, **kwargs)

def _canonical_redirect(*args, **kwargs):
    from controllers.m_system.utils import _canonical_redirect as _canonical_r
    return _canonical_r(*args, **kwargs)

def _normalize_inout_type(value:str) -> Direction:
    from controllers.m_amavisd.utils import _normalize_inout_type as normalize_inout_type
    return normalize_inout_type(value)


def _to_int_safe(value, default:int = -1) -> int:
    try:
        ivalue = int(value)
        return ivalue if ivalue >= 0 else default
    except (TypeError, ValueError):
        return default

def _normalize_status(value: str) -> str:
    value = str(value).strip().lower()
    if value in ("enable", "1", "true", "on", "yes"):
        return "enable"
    elif value in ("disable", "0", "false", "off", "no"):
        return "disable"
    elif value == "inherit":
        return "inherit"
    else:
        return None


def _rdns_form_payload_to_db(form: Dict) -> Dict:
    rdns_data={}
    for payload_key, db_key in MAP_RDNS_PAYLOAD_TO_DB.items():
        _ok, _val = form_utils.populate_form_list_filtered(form, payload_key)
        if _ok:
            rdns_data[db_key] = _val

    return rdns_data

def _greylist_form_payload_to_db(form: Dict) -> Dict:
    greylist_data = {}
    
    for payload_key, db_key in MAP_GREYLIST_PAYLOAD_TO_DB.items():
        raw = form.get(payload_key)

        # greylisting → enable|disable|inherit
        if payload_key == "greylisting":
            greylist_data[db_key] = (
                raw if raw in ("enable", "disable") else "inherit"
            )
            continue

        # processar list fields
        _ok, _val = form_utils.populate_form_list_filtered(form, payload_key)
        if _ok:
            greylist_data[db_key] = _val

    return greylist_data

def _throttle_form_payload_to_db(form: Dict) -> Dict:
    throttle_data = {}

    for inout in ("inbound", "outbound"):
        enabled = form.get(f"{inout}_throttling_status") != "off"
        prefix = f"{inout}_"
        custom_prefix = f"custom_{inout}_"

        db_data = {}
        ##  si busquem persistència aquest és l'enfocament
        # if enabled not in form:
        #     continue
        if enabled:
            for payload_key, db_key in MAP_THROTTLE_PAYLOAD_TO_DB.items():
                raw = form.get(f"{prefix}{payload_key}", "")
                custom = form.get(f"{custom_prefix}{payload_key}", "")
                value = _to_int_safe(raw)
                if value in (0, -1) and custom:
                    if payload_key in ("max_quota", "msg_size"):
                        value = form_utils.quota_transformation(f"{custom_prefix}{payload_key}", form)
                    else:
                        value = _to_int_safe(custom)
                db_data[db_key] = value

        throttle_data[f"throttle_{inout[0:3]}"] = db_data

    return throttle_data


def _throttle_api_payload_to_db(payload_data: dict, kind: str) -> dict:
    """
        Converteix payload API → format per a la DB (iredapd.throttle).
    """
    db_data: Dict = {}

    # map de claus
    for payload_key, db_key in MAP_THROTTLE_PAYLOAD_TO_DB.items():
        if payload_key in payload_data:
            db_data[db_key] = _to_int_safe(payload_data.get(payload_key))

    # Validacions bàsiques
    # normalitzar period
    status = _normalize_status(payload_data.get("enable"))
    if status in ("enable", "disable"):
        db_data["period"] = DEFAULT_DB_THROTTLE["period"] if status == "enable" else 0
    else:
        # si hi ha algun límit definit (> -1), period = 86400 per defecte 
        has_limits = any(
            db_data.get(k, -1) > -1
            for k in ["max_msgs", "max_quota", "msg_size"] + (["max_rcpts"] if kind == "outbound" else [])
        )
        if has_limits:
            db_data["period"] = _to_int_safe(payload_data.get("period"), DEFAULT_DB_THROTTLE["period"])
        else:
            # Només cal respectar valors i defaults
            for payload_key, db_key in MAP_THROTTLE_PAYLOAD_TO_DB.items():
                if payload_key not in payload_data:
                    db_data.setdefault(db_key, DEFAULT_DB_THROTTLE.get(db_key, -1))
            
    return db_data

def _throttle_api_db_to_payload(record: dict) -> dict:
    """
        Converteix un registre de throttle de la DB → format API (JSON friendly).
        - És tolerant a rebre (ok, record, *rest) i en treu només el dict.
        - enable=false → sempre period=0 (config guardada però no activa).
        - enable=true amb límits → period = valor de l’API o 86400 si no arriba.
        - enable=true sense límits → s’apliquen defaults (en lloc d’error).
    """

    # Si ens passen (ok, result, *rest)
    db_data = record[1] if isinstance(record, tuple) and len(record) >= 2 and isinstance(record[1], dict) else record
    payload_data = {}

    # Mapeig directe (és simètric a API_TO_DB_THROTTLE_MAP)
    for payload_key, db_key in MAP_THROTTLE_PAYLOAD_TO_DB.items():
        if db_key in db_data:
            payload_data[payload_key] = _to_int_safe(db_data.get(db_key))

    # camps generals
    payload_data["kind"] = db_data.get("kind")
    payload_data["account"] = db_data.get("account")
    payload_data["period"] = _to_int_safe(db_data.get("period"), 0)

    # inferir enable des de period
    payload_data["enable"] = "yes" if payload_data["period"] > 0 else "no"

    return payload_data
