# libs/m_amavisd/spampolicy.py
from typing import Tuple, Dict, Any

import settings

from libs.m_amavisd import AmavisdWarp, wblist as lib_wb
from libs.m_system.mixins import AmavisNewMixin
from libs.m_system.decorators import LibDecorators

# https://amavis.org/README.sql-mysql.txt
# https://docs.iredmail.org/iredadmin-pro.custom.ban.rules.html

DEFAULT_SPAM_TAG_LEVEL = 2.0
DEFAULT_SPAM_TAG2_LEVEL = 6.0
DEFAULT_SPAM_KILL_LEVEL = 6.9
DEFAULT_BAN_RULES = {
    'ALLOW_MS_OFFICE': 'Allow all Microsoft Office documents.',
    'ALLOW_MS_WORD': 'Allow Microsoft Word documents (.doc, .docx).',
    'ALLOW_MS_EXCEL': 'Allow Microsoft Excel documents (.xls, .xlsx).',
    'ALLOW_MS_PPT': 'Allow Microsoft PowerPoint documents (.ppt, .pptx).'
}

# Combina DEFAULT_BAN_RULES amb AMAVISD_BAN_RULES (si n’hi ha)
BAN_RULES = DEFAULT_BAN_RULES.copy()
if isinstance(settings.AMAVISD_BAN_RULES, dict):
    BAN_RULES.update(settings.AMAVISD_BAN_RULES)
# Converteix a llista de tuples ordenada per clau (opcional)
BAN_RULES_LIST = sorted(BAN_RULES.items())
# [
#     ("banned_rulenames", value, key)
#     for key, value in sorted(BAN_RULES.items())
# ]#s

# defaults per DB
DEFAULT_DB_SPAMPOLICY = {
    'bypass_virus_checks': 'N',
    'virus_quarantine_to': 'virus-quarantine',
    'virus_lover': 'Y',

    'bypass_spam_checks': 'N',
    'spam_quarantine_to': None,
    'spam_lover': 'Y',

    'bypass_banned_checks': 'N',
    'banned_quarantine_to': 'banned-quarantine',
    'banned_files_lover': 'N',

    'bypass_header_checks': 'N',
    'bad_header_quarantine_to': None,
    'bad_header_lover': 'Y',

    'spam_tag2_level': None,
    'spam_tag_level': None,
    'spam_kill_level': None,
    'spam_subject_tag2': None,

    'banned_rulenames': None,

    'message_size_limit': None,
}

DEFAULT_DB_SPAMPOLICY_SYSTEM_OVERRIDE = {
    'bypass_virus_checks': None,
    'bypass_spam_checks': None,
    'virus_quarantine_to': None,
    'virus_lover': None,
    'spam_lover': None,
    'banned_files_lover': None,
    'bad_header_lover': None,
}

# Wrappers simples
def get_spam_policy(account: str) -> Tuple[bool, Dict[str, Any]]:
    from controllers.m_amavisd.utils import _spampolicy_form_db_to_payload

    errors = []
    policy_lib = SpamPolicy(account=account)

    def _fetch(fn, label):
        ok, data, *rest = fn()
        if ok:
            return data
        errors.append(f"Failed spampolicy {label}: {data}")
        return None

    ok, db_raw, *rest = policy_lib.get_spam_policy(create_if_missing=False)

    # 🔹 Cas explícit: no existeix política
    if db_raw == 'NO_SUCH_ACCOUNT':
        spam_data = 'NO_SUCH_SPAMPOLICY'
    else:
        spam_data = (
            _spampolicy_form_db_to_payload(db_raw)
            if db_raw is not None
            else None
        )

    result = {
        "spam_policy":            spam_data,
        "global_spam_score":      _fetch(policy_lib.get_global_spam_score, "global_spam_score"),
        "global_spam_kill_score": _fetch(policy_lib.get_global_kill_score, "global_spam_kill_score"),
        "ban_rules":              BAN_RULES_LIST,
        "spam_policy_exists":     spam_data != 'NO_SUCH_SPAMPOLICY'
    }

    if errors:
        result["errors"] = errors
        return (False, result)

    return (True, result)

class SpamPolicy(AmavisdWarp, AmavisNewMixin):
    def __init__(self, account='@.'):
        super().__init__()
        self.account = self.safe_lower(account)
        self.account_type = self.is_valid_amavisd_address(self.account)
        if self.account_type == 'domain' and not self.account.startswith('@'):
            self.account = f'@{self.account}'
        self.sql_where = ''
        self.func_init()

    def func_init(self):
        if not self.account_type:
            return (False, 'INVALID_INOUT_TYPE')
        self.sql_where = 'users.policy_id=policy.id AND users.email = UNHEX(HEX($account))'

    def get_policy_priority(self):
        """
            Retorna la política de spam efectiva segons la prioritat:
            user > domain > global > default
        """
        def _is_policy(p):
            return isinstance(p, dict) and bool(p)

        def fetch(account, label=None):
            ok, policy, *rest = SpamPolicy(account).get_spam_policy()
            if ok and _is_policy(policy):
                if label:
                    policy['effectivebypriority'] = label
                return ok, policy, *rest
            return False, None

        # NOTE: Si és una adreça d'usuari
        if self.account_type == 'email':
            # NOTE: 1. Política d'usuari
            ok, policy, *rest = self.get_spam_policy()
            if ok and _is_policy(policy):
                return ok, policy, *rest

            # NOTE: Si falla,
            # NOTE: 2. Política de domini
            domain_account = f"@{self.account.split('@')[-1]}"
            ok, policy, *rest = fetch(domain_account, 'domain')
            if ok:
                return ok, policy, *rest

        # NOTE: Si és una adreça de domini, subdomini, TLD o catchall
        elif self.account_type in ('domain', 'subdomain', 'tld_domain', 'catchall'):
            ok, policy, *rest = self.get_spam_policy()
            if ok and _is_policy(policy):
                return ok, policy, *rest

        # NOTE: Altres tipus (IP, CIDR, wildcard...)
        else:
            ok, policy, *rest = self.get_spam_policy()
            if ok and _is_policy(policy):
                return ok, policy, *rest

        # NOTE: Retorn global per defecte (sempre el mateix)
        return fetch('@.', 'global')

    def get_global_spam_score(self) -> Tuple[bool, float]:
        original = self.account
        try:
            self.account = '@.'
            ok, policy, *rest = self.get_spam_policy()

            def to_float(x, default):
                try:
                    return float(x)
                except (TypeError, ValueError):
                    return float(default)

            return ok, to_float(policy.get('spam_tag2_level'), DEFAULT_SPAM_TAG2_LEVEL)

        finally:
            self.account = original

    def get_global_kill_score(self):
        original_account = self.account

        try:
            self.account = '@.'
            ok, policy, *rest = self.get_spam_policy()
            def to_float(x, default):
                try:
                    return float(x)
                except (TypeError, ValueError):
                    return float(default)

            return (ok, to_float(policy.get('spam_kill_level'), DEFAULT_SPAM_KILL_LEVEL))

        finally:
            self.account = original_account

    @LibDecorators.safe_sql_method
    def delete_spam_policy(self):
        # Primer elimina la política
        self.db.delete(
            'policy',
            vars={'account': self.account},
            where='id = (SELECT policy_id FROM users WHERE email = UNHEX(HEX($account)))'
        )

        # Després elimina l'usuari
        self.db.delete(
            'users',
            vars={'account': self.account},
            where='email = UNHEX(HEX($account))'
        )
        return (True,'DELETED')

    @LibDecorators.safe_sql_method
    def get_spam_policy(self, create_if_missing=False):

        policy = {}

        qr = self.db.select(
            ['policy', 'users'],
            vars={'account': self.account},
            what='policy.*, users.id AS users_id',
            where=self.sql_where,
            limit=1)
        if qr:
            policy = list(qr)[0]
        else:
            if create_if_missing:
                qr = self.create_spam_policy(DEFAULT_DB_SPAMPOLICY)
                if qr[0]:
                    policy = qr[1]
            else:
                return True, 'NO_SUCH_ACCOUNT'

        if policy:
            # hi ha un camp que sobra del get_spam_policy, 
            # és `user_id` de la taula users, d'aqui el junk
            for junk in ('users_id',):
                if junk in policy:
                    policy.pop(junk, None)

            return True, policy

        return True, 'NO_SUCH_ACCOUNT'

    @LibDecorators.safe_sql_method
    def create_spam_policy(self, new_payload):
        """
            Crea una política nova respectant:
                user > domain > system override > default
        """
        # 1) Carreguem la política efectiva actual (respectant la jerarquia)
        ok, base_policy, *rest = self.get_policy_priority()
        if not ok or not base_policy:
            base_policy = DEFAULT_DB_SPAMPOLICY.copy()

        # 2) Preparem un payload complet: base + nous valors
        # Eliminem camps que venen del SELECT de DB
        base_policy.pop("id", None)
        base_policy.pop("users_id", None)
        base_policy.pop("effectivebypriority", None)

        # 3) System override @. — té defaults diferents
        if self.account == "@.":
            # part comuna del sistema (igual a iRedAdmin-Pro)
            for k, v in DEFAULT_DB_SPAMPOLICY_SYSTEM_OVERRIDE.items():
                base_policy[k] = v

        # 4) NOMÉS actualitzem els camps enviats pel formulari
        #    No apliquem DEFAULTS aquí (igual que iRedAdmin-Pro)
        merged = base_policy.copy()
        for k, v in (new_payload or {}).items():
            if k in DEFAULT_DB_SPAMPOLICY:
                merged[k] = v

        # 5) Fixem policy_name segons compte
        merged["policy_name"] = self.account

        # 6) Inserim nova política
        policy_id = self.db.insert("policy", **merged)

        # 7) Enllaçar la política amb l'usuari
        qr = self.link_policy_to_user(policy_id)
        if not qr[0]:
            return qr

        return (True, merged)

    @LibDecorators.safe_sql_method
    def link_policy_to_user(self, policy_id):
        qr = lib_wb.WbList(self.account).get_user_record(create_if_missing=True)
        if not qr[0]:
            return qr
        user_id = qr[1]

        self.db.update(
            'users',
            vars={'id': user_id},
            policy_id=policy_id,
            where='id=$id')
        return True,

    @LibDecorators.safe_sql_method
    def update_spam_policy(self, payload):
        if not self.account_type:
            return False, 'INVALID_ACCOUNT'

        qr = self.get_spam_policy(create_if_missing=True)
        if not qr[0]:
            return qr

        policy = qr[1]
        policy_id = policy['id']
        
        # Camps no aplicables del SELECT
        policy.pop("id", None)
        policy.pop("users_id", None)
        policy.pop("effectivebypriority", None)

        # System override
        if self.account == "@.":
            for k, v in DEFAULT_DB_SPAMPOLICY_SYSTEM_OVERRIDE.items():
                policy[k] = v

        # Només actualitzem claus enviades
        clean_payload = {}
        for k, v in (payload or {}).items():
            if k in DEFAULT_DB_SPAMPOLICY:
                clean_payload[k] = v

        # Merge: solament els camps enviats
        for k, v in clean_payload.items():
            policy[k] = v

        # Desa canvis
        self.db.update(
            'policy',
            where="id=$id",
            vars={'id': policy_id},
            **policy
        )

        # Actualitza compatibilitat per spam_tag3 / spam_subject_tag3
        extra_updates = {
            'spam_tag3_level': policy.get('spam_tag2_level'),
            'spam_subject_tag3': policy.get('spam_subject_tag2'),
        }

        self.db.update(
            'policy',
            vars={'id': policy_id},
            where='id=$id',
            **extra_updates
        )

        return (True, policy)       
