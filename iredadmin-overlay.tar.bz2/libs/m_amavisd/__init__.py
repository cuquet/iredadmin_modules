# libs/m_amavisd/__init__.py
import web
from libs.logger import log_traceback 

# Initialize session object.
import settings

session = web.config.get('_session')

class AmavisdWarp(object):
    def __del__(self):
        try:
            self.db.ctx.db.close()
        except:
            pass

    def __init__(self):
        session_dbn = 'mysql'
        if settings.backend in ['pgsql']:
            session_dbn = 'postgres'
        try:
            self.db = web.database(
                host=settings.amavisd_db_host,
                port=int(settings.amavisd_db_port),
                dbn=session_dbn,
                db=settings.amavisd_db_name,
                user=settings.amavisd_db_user,
                pw=settings.amavisd_db_password,
            )
            self.db.supports_multiple_insert = True
        except Exception as e:
            log_traceback()

        self.db.supports_multiple_insert = True
