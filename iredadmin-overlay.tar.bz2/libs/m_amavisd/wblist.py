# libs/m_amavisd/wblist.py
import web
from typing import Tuple, Optional

from libs.m_amavisd import AmavisdWarp
from libs.m_system.mixins import AmavisNewMixin, Direction, ListType
from libs.m_system.decorators import LibDecorators

session = web.config.get('_session')

def update_wblist(account: str, payload: dict) -> Tuple[bool, str]:
    """
        🔧 Actualitza totes les wblist (inbound/outbound, white/black) per un compte.

        Args:
            account (str): Compte d’usuari o domini.
            payload (dict): Diccionari amb claus opcionals:
                - "inbound_whitelist": {"add": "a@b.com,c@d.com", "remove": "..."}
                - "inbound_blacklist": {"add": "...", "remove": "..."}
                - "outbound_whitelist": {"add": "...", "remove": "..."}
                - "outbound_blacklist": {"add": "...", "remove": "..."}

        Returns:
            tuple: (True/False, missatge, detalls)
    """
    wb = WbList(account=account)
    account_type = wb.is_valid_amavisd_address(account)
    if not account_type in ['email', 'domain', 'catchall']:
        return (False, 'INVALID_ACCOUNT', {})

    errors = []

    # 👇 Helper per processar cada tipus de llista
    def _process_list(name, setter, remover, values):
        if not values:
            return
        # Normalitzar strings o llistes
        new_items = wb._normalize_list_wblist(values.get("add")) if values.get("add") else []
        remove_items = wb._normalize_list_wblist(values.get("remove")) if values.get("remove") else []
        
        if new_items:
            ok, msg, *rest = setter(new_items)
            if not ok:
                errors.append(f"⚠️ Error afegint {name}: {msg}")
        if remove_items:
            ok, msg, *rest = remover(remove_items)
            if not ok:
                errors.append(f"⚠️ Error eliminant {name}: {msg}")

    # 1️⃣ inbound whitelist
    _process_list("whitelist", wb.set_whitelist, wb.remove_whitelist, payload.get("whitelistSender"))

    # 2️⃣ inbound blacklist
    _process_list("blacklist", wb.set_blacklist, wb.remove_blacklist, payload.get("blacklistSender"))

    # 3️⃣ outbound whitelist
    _process_list("outbound_whitelist", wb.set_outbound_whitelist, wb.remove_outbound_whitelist, payload.get("whitelistRecipient"))

    # 4️⃣ outbound blacklist
    _process_list("outbound_blacklist", wb.set_outbound_blacklist, wb.remove_outbound_blacklist, payload.get("blacklistRecipient"))

    if errors:
        return (False, f'Update_wblist(account={account}): ' + ' | '.join(errors))
    return (True, "UPDATED")

def get_wblist(account: str) -> Tuple[bool, str]:
    """
        Retorna totes les llistes wl/bl inbound/outbound per un compte.

        Retorna:
            (ok: bool, data: dict)
            on data és:
            {
                "whitelist":            [...],
                "blacklist":            [...],
                "outbound_whitelist":   [...],
                "outbound_blacklist":   [...],
                "errors": [ ... ]       # opcional
            }
    """
    errors = []
    def _fetch(direction:Direction, list_type:ListType):
        wb = WbList(account, inout_type=direction, list_type=list_type)
        ok, data, *rest = wb.get_wblist()

        if not ok:
            if data != 'NO_ENTRIES_FOUND':
                errors.append(f"Failed wblist {direction.value} {list_type.value}: {data}")
            return []        # No hi ha res → buit

        # extreiem directament sender_address
        return [item["sender_address"] for item in data]

    result = {
        "whitelist":  _fetch(Direction.INBOUND,  ListType.WHITELIST),
        "blacklist":  _fetch(Direction.INBOUND,  ListType.BLACKLIST),
        "outbound_whitelist": _fetch(Direction.OUTBOUND, ListType.WHITELIST),
        "outbound_blacklist": _fetch(Direction.OUTBOUND, ListType.BLACKLIST),
    }
    if errors:
        result["errors"] = errors
        return (False, result)
    
    return (True, result)

class UsersRegistryMixin:
    @LibDecorators.safe_sql_method
    def create_user_record(self, policy_id=0) -> Tuple[bool, Optional[int]]:
        """
            Crea un registre nou a la taula `users` si no existeix.
            Retorna True i l'id si s'ha creat correctament.
        """
        self.db.insert(
            'users',
            policy_id=policy_id,
            email=web.SQLLiteral(f"UNHEX(HEX('{self.account}'))"),
            priority=self.get_account_priority(self.account),
            fullname=self.account
        )
        qr = self.db.select(
            'users',
            vars={'account': self.account},
            what='id',
            where='email = UNHEX(HEX($account))',
            limit=1
        )
        if qr:
            return (True, qr[0]['id'])
        return (False, None)

    @LibDecorators.safe_sql_method
    def get_user_record(self, create_if_missing=True) -> Tuple[bool, Optional[int]]:
        """
        Obté l'id del registre `users` per l'adreça donada.
        Si no existeix i `create_if_missing` és True, el crea.
        """
        qr = self.db.select(
            'users',
            vars={'account': self.account},
            what='id',
            where='email = UNHEX(HEX($account))',
            limit=1
        )
        if qr:
            return (True, qr[0]['id'])

        if create_if_missing:
            return self.create_user_record(policy_id=0)

        return (False, None)

class MailaddrRegistryMixin:
    @LibDecorators.safe_sql_method(on_error_pass=True)
    def get_mailaddr_record(self, sender_email: str, create_if_missing=True) -> Tuple[bool, Optional[int]]:
        """
        Obté l'id del registre `mailaddr` per l'adreça donada.
        Si no existeix i `create_if_missing` és True, el crea.
        """
        qr = self.db.select(
            'mailaddr',
            vars={'email': sender_email},
            what='id',
            where='email = $email',
            limit=1
        )
        if qr:
            return (True, qr[0]['id'])

        if create_if_missing:
            try:
                sender_id = self.db.insert('mailaddr', email=sender_email)
                return (True, sender_id)
            except Exception as e:
                return (False, f'INSERT_FAILED: {e}')

        return (False, None)

class WbList(AmavisdWarp, AmavisNewMixin, UsersRegistryMixin, MailaddrRegistryMixin):
    def __init__(self, account='@.', inout_type =None, list_type=ListType.WHITELIST):
        super().__init__()
        self.account = self.safe_lower(account)
        self.account_type = self.is_valid_amavisd_address(self.account)
        
        self.vars = {'account': self.account}
        if inout_type is None:
            inout_type = Direction.INBOUND
        self.inout_type = self.validate_enum_flexible(inout_type, Direction)
        self.list_type = self.validate_enum_flexible(list_type, ListType) or None
        self.sql_where = ''
        self.func_init()

    def func_init(self):
        if not self.account_type:
            return (False, 'INVALID_ACCOUNT')
        if not self.inout_type:
            return (False, 'INVALID_INOUT_TYPE')

    def _build_where(self, inout_type=None, list_type=None):
        inout_type = self.validate_enum_flexible(inout_type , Direction) or self.inout_type
        list_type = self.validate_enum_flexible(list_type , ListType) or self.list_type

        # Construïm la relació SQL segons la direcció
        if inout_type == Direction.INBOUND:
            table = "wblist"
            sql = (
                "users.email = UNHEX(HEX($account)) "
                "AND users.id = wblist.rid "
                "AND wblist.sid = mailaddr.id"
            )
        elif inout_type == Direction.OUTBOUND:
            table = "outbound_wblist"
            sql = (
                "users.email = UNHEX(HEX($account)) "
                "AND users.id = outbound_wblist.sid "
                "AND outbound_wblist.rid = mailaddr.id"
            )
        else:
            raise ValueError(f"inout_type ha de ser {Direction.INBOUND.value} o {Direction.OUTBOUND.value}")

        # Afegeix condició de whitelist/blacklist
        if list_type is not None:
            sql += f" AND {table}.wb = '{list_type.to_db()}'"
        # Si list_type és None → no afegim res

        return sql, table, self.vars

    @LibDecorators.safe_sql_method
    def get_wblist(self):
        """
        Retorna registres de wl/bl per a l'account actual.
        """
        ok, user_id, *rest = self.get_user_record(create_if_missing=False)
        if not ok:
            return (False, 'ACCOUNT_NOT_EXIST')

        sql_where, table, sql_vars = self._build_where()

        # Construïm la consulta amb JOINs explícits
        rows = self.db.select(
            ["mailaddr", "users", table],
            what=f"LOWER(CONVERT(mailaddr.email USING utf8)) AS sender_address, {table}.wb AS list_type",
            where=sql_where,
            vars=sql_vars,
        )

        # Convertim a llista de dicts
        data = [dict(r) for r in rows]
        if not data:
            return (False, 'NO_ENTRIES_FOUND')
        return (True, data)

    @LibDecorators.safe_sql_method
    def bulk_remove_wblist(self) -> Tuple[bool, str]:
        """
        Elimina totes les entrades de la llista (wl/bl) per a l'account actual
        segons la direcció (inbound/outbound) i el tipus (W/B).
        """
        # Obtenim l'ID del compte
        ok, user_id, *rest = self.get_user_record(create_if_missing=False)
        if not ok:
            return (False, 'NO_SUCH_ACCOUNT')

        # Determinem la taula i els camps segons la direcció
        table = 'wblist' if self.inout_type == Direction.INBOUND else 'outbound_wblist'
        field = 'rid' if self.inout_type == Direction.INBOUND else 'sid'

        # Eliminem totes les entrades que coincideixin
        deleted = self.db.delete(
            table,
            where=f"{field}=$user_id AND wb=$wb",
            vars={'user_id': user_id, 'wb': self.list_type.to_db()}
        )

        return (True, f'{deleted} entries removed') if deleted else (False, 'NO_ENTRIES_FOUND')


    @LibDecorators.safe_sql_method
    def add_wblist_entry(self, sender_email, list_type):
        """
            Afegeix una entrada a la llista (whitelist/blacklist) per a l'account actual.
        """
        try:
            list_type_enum = self.validate_enum_flexible(list_type, ListType)
        except ValueError:
            return (False, 'INVALID_LIST_TYPE')

        # Obtenim l'ID del compte (users.id)
        ok, user_id, *rest = self.get_user_record(create_if_missing= True)
        if not ok:
            return (False, 'NO_SUCH_ACCOUNT')

        sender_email_normalized = self._normalize_list_wblist(sender_email)
        if sender_email_normalized:
            ok, sender_id, *rest = self.get_mailaddr_record(sender_email_normalized, create_if_missing=True)
            if not ok:
                return (False, 'NO_SENDER_FOUND')

        # Determinem la taula i els camps segons el tipus
        table = 'wblist' if self.inout_type == Direction.INBOUND else 'outbound_wblist'
        sid, rid = (sender_id, user_id) if self.inout_type == Direction.INBOUND else (user_id, sender_id)

        # Comprovem si ja existeix
        exists = self.db.select(table, where='sid=$sid AND rid=$rid', vars={'sid': sid, 'rid': rid})
        if exists:
            return (False, 'ALREADY_EXISTS')

        # Inserim
        self.db.insert(table, sid=sid, rid=rid, wb=list_type_enum.to_db())
        return (True, 'ENTRY_ADDED')

    @LibDecorators.safe_sql_method(on_error_pass=True)
    def remove_wblist_entry(self, sender_email: str) -> Tuple[bool, str]:
        """
            Elimina una entrada de la llista (wl/bl) per a l'account actual.
        """
        ok, user_id, *rest = self.get_user_record(create_if_missing=False)
        if not ok:
            return (False, 'NO_SUCH_ACCOUNT')

        ok, sender_id, *rest = self.get_mailaddr_record(sender_email, create_if_missing=False)
        if not ok:
            return (False, 'NO_SENDER_FOUND')

        table = 'wblist' if self.inout_type == Direction.INBOUND else 'outbound_wblist'
        sid, rid = (sender_id, user_id) if self.inout_type == Direction.INBOUND else (user_id, sender_id)

        deleted = self.db.delete(table, where='sid=$sid AND rid=$rid', vars={'sid': sid, 'rid': rid})
        return (True, 'REMOVED_ENTRY') if deleted else (False, 'NO_ENTRIES_FOUND')

    # @LibDecorators.safe_sql_method
    def bulk_set_wblist_entries(self, sender_list: list[str], list_type: ListType) -> Tuple[bool, list[str]]:
        """
            Afegeix múltiples entrades a la llista wl/bl amb validació i deduplicació.
            Retorna True i una llista d'adreces afegides.
        """
        try:
            list_type_enum = self.validate_enum_flexible(list_type, ListType)
        except ValueError:
            return (False, 'INVALID_LIST_TYPE')

        ok, user_id, *rest = self.get_user_record(create_if_missing=True)
        if not ok:
            return (False, 'NO_SUCH_ACCOUNT')

        table = 'wblist' if self.inout_type == Direction.INBOUND else 'outbound_wblist'

        sender_list_normalized = self._normalize_list_wblist(sender_list)
        added = []

        for sender_email in sender_list_normalized:
            ok, sender_id, *rest = self.get_mailaddr_record(sender_email, create_if_missing=True)
            if not ok:
                continue

            sid, rid = (sender_id, user_id) if self.inout_type == Direction.INBOUND else (user_id, sender_id)
            exists = self.db.select(table, where='sid=$sid AND rid=$rid', vars={'sid': sid, 'rid': rid})
            if not exists:
                self.db.insert(table, sid=sid, rid=rid, wb=list_type_enum.to_db())
                added.append(sender_email)

        return (True, added)

    @LibDecorators.safe_sql_method
    def bulk_remove_wblist_entries(self, sender_list: list[str], list_type: ListType ) -> Tuple[bool, list[str]]:
        """
            Elimina múltiples entrades concretes de wl/bl (inbound/outbound).
        """
        ok, user_id, *rest = self.get_user_record(create_if_missing=False)
        if not ok:
            return (False, 'NO_SUCH_ACCOUNT')

        table = 'wblist' if self.inout_type == Direction.INBOUND else 'outbound_wblist'
        removed = []

        for sender_email in sender_list:
            ok, sender_id, *rest = self.get_mailaddr_record(sender_email, create_if_missing=False)
            if not ok:
                continue

            sid, rid = (sender_id, user_id) if self.inout_type == Direction.INBOUND else (user_id, sender_id)

            deleted = self.db.delete(
                table,
                where='sid=$sid AND rid=$rid AND wb=$wb',
                vars={'sid': sid, 'rid': rid, 'wb': list_type.to_db()},
            )
            if deleted:
                removed.append(sender_email)

        return (True, removed)

    def set_whitelist(self, sender_list: list[str]) -> Tuple[bool, list[str]]:
        self.inout_type = Direction.INBOUND
        return self.bulk_set_wblist_entries(sender_list, ListType.WHITELIST)

    def set_blacklist(self, sender_list: list[str]) -> Tuple[bool, list[str]]:
        self.inout_type = Direction.INBOUND
        return self.bulk_set_wblist_entries(sender_list, ListType.BLACKLIST)

    def set_outbound_whitelist(self, receiver_list: list[str]) -> Tuple[bool, list[str]]:
        self.inout_type = Direction.OUTBOUND
        return self.bulk_set_wblist_entries(receiver_list, ListType.WHITELIST)

    def set_outbound_blacklist(self, receiver_list: list[str]) -> Tuple[bool, list[str]]:
        self.inout_type = Direction.OUTBOUND
        return self.bulk_set_wblist_entries(receiver_list, ListType.BLACKLIST)

    def remove_whitelist(self, sender_list: list[str]) -> Tuple[bool, list[str]]:
        self.inout_type = Direction.INBOUND
        return self.bulk_remove_wblist_entries(sender_list, ListType.WHITELIST)

    def remove_blacklist(self, sender_list: list[str]) -> Tuple[bool, list[str]]:
        self.inout_type = Direction.INBOUND
        return self.bulk_remove_wblist_entries(sender_list, ListType.BLACKLIST)

    def remove_outbound_whitelist(self, receiver_list: list[str]) -> Tuple[bool, list[str]]:
        self.inout_type = Direction.OUTBOUND
        return self.bulk_remove_wblist_entries(receiver_list, ListType.WHITELIST)

    def remove_outbound_blacklist(self, receiver_list: list[str]) -> Tuple[bool, list[str]]:
        self.inout_type = Direction.OUTBOUND
        return self.bulk_remove_wblist_entries(receiver_list, ListType.BLACKLIST)
