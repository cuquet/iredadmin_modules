# libs/m_amavisd/quarantine.py
import socket
import web
from typing import Any, Dict, List, Tuple, Union, Optional

import settings

from libs.m_system.mixins.mail.mailparser import parse_from_bytes
from libs.m_amavisd.log import Log
from libs.m_amavisd.wblist import WbList as lib_wblist
from libs.m_system.mixins import SQLWhereBuilder, LogType, MsgsContentType, MsgsQuarType, Direction
from libs.m_system.decorators import LibDecorators

# If msgs.quar_type != 'Q' (SQL), we can't get mail body.

class Quarantine(Log):
    def __init__(
        self, 
        content_type: Optional[str] = 'all', 
        account_type: Optional[str] = None, 
        account: Optional[str] = None,
        page: int = 0, 
        is_global_admin = False):
        super().__init__(log_type=LogType.RECEIVED,
                        account_type=account_type, 
                        account=account,
                        page = page,
                        is_global_admin= is_global_admin)

        self.content_type_key = str(content_type).lower().strip()

        # Mapa declaratiu
        content_map = {
            'spam': MsgsContentType.spam_types(),
            'virus': MsgsContentType.virus_types(),
            'banned': [MsgsContentType.BANNED.value],
            'badheader': [MsgsContentType.BADHEADER.value],
            'clean': [MsgsContentType.CLEAN.value],
            'quarantined': MsgsContentType.quarentable_types(),
            'removable': MsgsContentType.removable_types(),
            'all': MsgsContentType.all_values(),
        }

        self.content_type = content_map.get(self.content_type_key, MsgsContentType.all_values())

    LibDecorators.safe_sql_method
    def count_quarantined_mails(self, days: Optional[int] = None, payload=None) -> Tuple[bool, int]:
        """
            📦 Compta correus en quarantena filtrats per tipus de contingut i temps.

            Utilitza:
                - `self.content_type`: llista de valors de `MsgsContentType` segons el mapa de la classe.
                content_type (Union[List[str], MsgsContentType, None]):
                    - Llista de tipus de contingut (p.ex. MsgsContentType.quarentable_types())
                    - Un sol valor de MsgsContentType
                    - None = qualsevol quarantena
                - `MsgsQuarType.all_values()`: per assegurar que només comptem correus amb quarantena.

            Parameters:
                days (int, optional): Temps en DIES per limitar la cerca.

            Returns:
                Tuple[bool, Union[int, str]]:
                    (True, count) si correcte
                    (False, error_msg) si hi ha error
        """

        payload = payload or {}
        q = payload.get("query_string")
        date_from = payload.get("date_from")
        date_to = payload.get("date_to")

        _builder = SQLWhereBuilder()
        # 1️⃣ 🎯 Condicions base
        _builder = self._build_sql_where(log_type=LogType.RECEIVED, days = days, builder=_builder)

        # 2️⃣ 🎯 Limitem per tipus de contingut (si s'especifica)
        if self.content_type:
            _builder.add_in("msgs.content", self.content_type)
        # # Busquem només missatges de spam
        # builder.add_in("content", MsgsContentType.spam_types())
        # # O, si vull un sol tipus
        # builder.add_equals("content", MsgsContentType.VIRUS.value)
        
        # 🎯 Filtre per tipus de quarantena
        _builder.add_in("msgs.quar_type", MsgsQuarType.all_values())

        _builder = self._apply_free_text_search(_builder, q)
        _builder = self._apply_date_filter(_builder, date_from, date_to)
        
        sql_where, sql_vars = _builder.build()
        
        query = f'''
            SELECT COUNT(*) AS cnt FROM (
                SELECT
                    msgs.subject, msgs.time_iso,
                    msgs.content, msgs.size, msgs.spam_level, msgs.quar_type
                FROM msgs
                LEFT JOIN msgrcpt ON msgs.mail_id = msgrcpt.mail_id
                LEFT JOIN maddr AS sender ON sender.id = msgs.sid
                LEFT JOIN maddr AS recip ON msgrcpt.rid = recip.id
                WHERE {sql_where}
                GROUP BY msgs.subject, msgs.time_iso, msgs.size
            ) AS grouped_mails
        '''

        result = list(self.db.query(query, vars=sql_vars))
        return True, int(result[0].cnt)

    @LibDecorators.safe_sql_method(no_hex=True)
    def get_quarantined_mails(self, days: Optional[int] = None, payload=None) -> Tuple[bool, Dict[int, List[Dict[str, Any]]]]:
        """
            📦 Recupera els correus en quarantena, amb o sense paginació.

            Paràmetres:
                - `days`: límit temporal en dies (opcional).
                - `page`: si és 0 → retorna tots els correus; si és >0 → aplica paginació.

            Retorna:
                - Tuple: (True, (total, llista de correus)) si correcte.
                - False si hi ha error.
        """
        # 1️⃣ Comptem el total de correus en quarantena
        payload = payload or {}
        q = payload.get("query_string")
        date_from = payload.get("date_from")
        date_to = payload.get("date_to")

        ok, total_count, *rest = self.count_quarantined_mails(days=days, payload=payload)
        if not ok:
            return False, (0, [])

        # 2️⃣ Construïm condicions SQL
        builder = SQLWhereBuilder()
        builder = self._build_sql_where(log_type=LogType.RECEIVED, days=days, builder=builder)

        # Filtre per tipus de contingut
        if self.content_type:
            builder.add_in("msgs.content", self.content_type)

        # Filtre per tipus de quarantena
        builder.add_in("msgs.quar_type", MsgsQuarType.all_values())

        builder = self._apply_free_text_search(builder, q)
        builder = self._apply_date_filter(builder, date_from, date_to)
        
        sql_where, sql_vars = builder.build()

        # 3️⃣ Construïm la consulta
        offset = (self.cur_page - 1) * self.limit
        limit_clause = f"LIMIT {self.limit} OFFSET {offset}" if self.cur_page > 0 else ""

        query = f"""
            SELECT
                msgs.mail_id, msgs.secret_id, msgs.subject, msgs.time_iso,
                msgs.content, msgs.size, msgs.spam_level, msgs.quar_type,
                sender.email AS sender_email,
                GROUP_CONCAT(DISTINCT recip.email SEPARATOR ',') AS recip_emails,
                GROUP_CONCAT(DISTINCT msgs.mail_id SEPARATOR ',') AS mail_ids,
                GROUP_CONCAT(DISTINCT msgs.secret_id SEPARATOR ',') AS secret_ids,
                GROUP_CONCAT(DISTINCT CONCAT(msgs.mail_id, '+', msgs.secret_id) SEPARATOR ',') AS record_tokens
            FROM msgs
            LEFT JOIN msgrcpt ON msgs.mail_id = msgrcpt.mail_id
            LEFT JOIN maddr AS sender ON sender.id = msgs.sid
            LEFT JOIN maddr AS recip ON msgrcpt.rid = recip.id
            WHERE {sql_where}
            GROUP BY msgs.subject, msgs.time_iso, msgs.size, msgs.quar_type, sender.email
            ORDER BY msgs.time_iso DESC
            {limit_clause};
        """

        records = list(self.db.query(query, vars=sql_vars))

        # 4️⃣ Convertim quar_type a nom llegible
        for r in records: 
            raw_type = r.get("quar_type")
            r["quar_type_readable"] = MsgsQuarType(raw_type).name if raw_type in MsgsQuarType._value2member_map_ else "UNKNOWN"

        return True, {
                "total": total_count,
                "records": records,
                "page": self.cur_page,
                "filters": payload,
                "remove_quarantined_in_days": settings.AMAVISD_REMOVE_QUARANTINED_IN_DAYS,
            }

    @LibDecorators.safe_sql_method
    def delete_quarantined_older_than_days(self, days: int = 0) -> Tuple[bool, str]:
        """
            🗑️ Elimina correus en quarantena segons les condicions configurades 
            (usuari, domini, o tots).

            Ús:
                - Si self.account_type == 'domain' ➝ només d’aquell domini
                - Si self.account_type == 'user'   ➝ només d’aquell usuari
                - Si cap account_type              ➝ tots
        """
        builder = SQLWhereBuilder()
        # 1️⃣ Construïm condicions base amb el mètode genèric
        builder = self._build_sql_where(
            log_type=LogType.RECEIVED, 
            days=days*86400,
            older=True,
            builder=builder
        )

        # 2️⃣ Afegim condició de quarantena
        builder.add_in("msgs.quar_type", MsgsQuarType.all_values())

        # 3️⃣ Combinar condicions i variables
        conditions, vars_all = builder.build()

        with self.db.transaction():
            # 🔹 A . Elimina entrades relacionades a msgrcpt
            self.db.delete(
                "msgrcpt", 
                where=f"mail_id IN (SELECT mail_id FROM msgs WHERE {conditions})", 
                vars=vars_all
            )

            # 🔹 B. Elimina entrades relacionades a quarantine
            self.db.delete(
                "quarantine", 
                where=f"mail_id IN (SELECT mail_id FROM msgs WHERE {conditions})", 
                vars=vars_all
            )

            # 🔹 C. Finalment, borrem els msgs
            self.db.delete("msgs", where=conditions, vars=vars_all)

        return True, f"Eliminats els missatges en quarentena més antics de {days} dies"

    @LibDecorators.safe_sql_method(no_hex=True)
    def get_quarantined_raw_mail(self, mail_id: str) -> Tuple[bool, Union[str, object]]:
        """Retorna el missatge RAW d'un mail_id en quarantena."""
        if not mail_id:
            return False, "INVALID_MAILID"

        mail_id = str(mail_id)
        qr = self.db.select(
            "quarantine",
            what="mail_text",
            where="mail_id = %s" % web.sqlquote(mail_id),
            order="chunk_ind ASC",
            limit=1,
        )
        if not qr:
            return False, "INVALID_MAILID"

        message = parse_from_bytes(qr[0]["mail_text"])
        return True, message

    @LibDecorators.safe_sql_method(no_hex=True)
    def _get_sender_by_mail_id(self, mail_id: str) -> Tuple[bool, Union[str, None]]:
        """
            📬 Obté el remitent associat a un mail_id concret.

            Parameters:
                mail_id (str): Identificador del correu.

            Returns:
                Tuple[bool, Union[str, None]]:
                    - (True, sender_email) si trobat
                    - (False, None) si no trobat o error
        """
        _builder = SQLWhereBuilder()
        _builder = self._build_sql_where(log_type=LogType.RECEIVED, days=None, builder=_builder)
        _builder.add('msgs.mail_id', mail_id)
        conditions, vars_all = _builder.build()

        query = f'''
            SELECT sender.email
            FROM msgs
            LEFT JOIN maddr AS sender ON sender.id = msgs.sid
            WHERE {conditions}
            LIMIT 1
        '''
        result = list(self.db.query(query, vars=vars_all))
        return True, result[0].email

    def _extract_senders(self, mail_ids: list[str], scope: str="sender") -> set[str]:
        """
            🔎 Extreu remitents (adreces o dominis) segons l'scope.
        """
        senders = set()
        for mail_id in mail_ids:
            ok, sender = self._get_sender_by_mail_id(mail_id)
            if ok and sender:
                if scope == "sender":
                    senders.add(sender)
                elif scope == "sender_domain":
                    senders.add(sender.split("@")[-1])
                elif scope == "sender_subdomain":
                    domain = sender.split("@")[-1]
                    senders.add("." + domain)
        return senders

    @LibDecorators.safe_sql_method(no_hex=True)
    def release_quarantined_mails(self, records: Optional[List[Dict[str, Any]]] = None)  -> Tuple[bool, str]:
        """
            Allibera correus en quarantena via Amavisd i actualitza la DB.

            records = [
            {
                'mail_id': 'xxx',
                'secret_id': 'yyy',
                'requested_by': 'zzz',
            },
            [],
            ]

            Consulta la documentació d'Amavisd ('README.protocol') per més detalls
            sobre el procés d'alliberament de correus en quarantena.
        """

        if not records:
            return True, "RELEASED"

        if not self.is_global_admin:
            return False, 'PERMISSION_DENIED'

        released_mail_ids = []

        # 🔌 Connexió amb el servidor Amavisd
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.connect((settings.amavisd_db_host, settings.amavisd_db_port))
        except Exception as e:
            return False, str(e)

        # 🔁 Enviament de comandes una per una (no en bloc)
        # Això evita problemes de sincronització amb la base de dades.
        for record in records:
            if 'mail_id' not in record:
                continue
            cmd_release = 'request=release\r\n'
            cmd_release += "".join(f"{k}={v}\r\n" for k, v in record.items() if v)
            cmd_release += 'quar_type=Q\r\n'
            try:
                s.send((cmd_release + '\r\n').encode())
                # Esperem la resposta d'Amavisd abans d'eliminar el registre SQL.
                s.recv(1024)
                released_mail_ids.append(record['mail_id'])
            except Exception as e:
                s.close()
                return False, str(e)
        s.close()

        # 📭 Si cap correu s'ha alliberat correctament.
        if not released_mail_ids:
            return True, '... no record was released successfully'

        # 🧼 Actualitzem la base de dades:
        # 1️⃣ Marquem els correus com a "nets" (content = 'C')
        self.db.update('msgs', where='mail_id IN ' + web.sqlquote(released_mail_ids), quar_type='', content='C')

        # 2️⃣ Eliminem els registres de la taula `quarantine`
        self.db.delete('quarantine', where='mail_id IN ' + web.sqlquote(released_mail_ids))
        return True, "RELEASED"

    def release_quarantined_with_whitelist(self, records: Optional[List[Dict[str, Any]]] = None, scope: str="sender") -> Tuple[bool, str]:
        """
            📦 Allibera correus en quarantena i whitelisteja el remitent, domini o subdominis.
        """
        ok, msg, *rest = self.release_quarantined_mails(records)
        if not ok:
            return False, msg

        account = self.account if self.account else '@.'
        wb = lib_wblist(account=account, inout_type=Direction.INBOUND)

        mail_ids = [r.get("mail_id") for r in records or [] if r.get("mail_id")]
        senders = self._extract_senders(mail_ids, scope)

        if not senders:
            return True, "DONE_BUT_EMPTY_LIST_FOR_WB"

        ok, msg, *rest = wb.set_whitelist(senders)
        if not ok:
            return False, msg
        return True, 'RELEASED_AND_WHITELIST'

    @LibDecorators.safe_sql_method
    def delete_quarantined_all(self):
        """    
            🗑️ Elimina tots els correus en quarantena (msgs + quarantine + msgrcpt).
            Es fa en una sola transacció per mantenir consistència.
        """
        builder = SQLWhereBuilder()
        builder.add_in("msgs.quar_type", MsgsQuarType.all_values())
        conditions, vars_all = builder.build()

        if not self.is_global_admin:
            return False, 'PERMISSION_DENIED'

        with self.db.transaction():
            # 1️⃣ Elimina entrades relacionades a msgrcpt
            self.db.delete("msgrcpt", where=f"mail_id IN (SELECT mail_id FROM msgs WHERE {conditions})", vars=vars_all)

            # 2️⃣ Elimina entrades relacionades a quarantine
            self.db.delete("quarantine", where=f"mail_id IN (SELECT mail_id FROM msgs WHERE {conditions})", vars=vars_all)

            # 3️⃣ Elimina missatges en quarantena
            self.db.delete("msgs", where=conditions, vars=vars_all)

        return True,'DELETED'

    def delete_quarantined_with_blacklist(self, records: Optional[List[Dict[str, Any]]] = None, scope: str="sender") -> Tuple[bool, str]:
        """
            🗑️ Elimina correus i blacklisteja el remitent o domini.
        """
        mail_ids = [r.get("mail_id") for r in records or [] if r.get("mail_id")]
        if not mail_ids:
            return False, "INVALID_MAILID"

        ok, msg, *rest = self.delete_records_by_mailid(mail_ids)
        if not ok:
            return False, msg

        account = self.account if self.account else '@.'
        wb = lib_wblist(account=account, inout_type=Direction.INBOUND)

        senders = self._extract_senders(mail_ids, scope)

        if not senders:
            return True, "DONE_BUT_EMPTY_LIST_FOR_WB"

        ok, msg, *rest = wb.set_blacklist(senders)
        if not ok:
            return False, msg
        return True, 'DELETED_AND_BLACKLIST'

    def get_counts(self, delete_older_mails: bool = False, days: Union[int, None] = None) -> Union[Dict[str, Any], Tuple[bool, str]]:
        """
            📊 Obté estadístiques agregades de correus processats.

            Parameters:
                delete_older_mails (bool): Si s'han d'eliminar correus antics abans de calcular.
                days (int, optional): Temps en DIES per limitar la cerca.

            Returns:
                Union[Dict[str, Any], Tuple[bool, str]]: Diccionari amb estadístiques o error.

            Diccionari retornat:
            - `count_in`: correus rebuts.
            - `count_out`: correus enviats.
            - `count_quarantined`: correus en quarantena.
            - `count_virus`: correus amb virus.
            - `top_sender`: usuaris que més envien.
            - `top_recip`: usuaris que més reben.

            Opcional:
            - Si `delete_older_mails` és True, elimina correus antics abans de calcular.
        """
        errors = []
        # 1️⃣ Comptadors generals (in/out)
        ok, count_in, *rest = self._count_inout_mails(LogType.RECEIVED, days)
        if not ok:
            errors.append(f'count_in: {count_in}')
        ok, count_out, *rest = self._count_inout_mails(LogType.SENT, days)
        if not ok:
            errors.append(f'count_out: {count_out}')

        # 2️⃣ Comptadors de quarantena i virus

        ok, count_quarantined, *rest = Quarantine(content_type='quarantined').count_quarantined_mails(
            days=days)
        if not ok:
            errors.append(f'count_quarantined: {count_quarantined}')
        ok, count_virus, *rest = Quarantine(content_type='virus').count_quarantined_mails(
            days=days)
        if not ok:
            errors.append(f'count_virus: {count_virus}')

        # 3️⃣ Top senders i recipients
        ok, top_senders, *rest = self._count_top_users(log_type=LogType.SENT, days=days)
        if not ok:
            errors.append(f'top_senders: {top_senders}')
        ok, top_recips, *rest = self._count_top_users(log_type=LogType.RECEIVED, days=days)
        if not ok:
            errors.append(f'top_recips: {top_recips}')

        # 4️⃣ Opcional: eliminar registres antics
        if delete_older_mails:
            ok, err = self.delete_records_older_than_days(settings.AMAVISD_REMOVE_MAILLOG_IN_DAYS)
            if not ok:
                errors.append(f'delete_records_older_than_days: {err}')

        # 5️⃣ Retorn final
        if errors:
            return  {"errors":",".join(errors)}
        else:
            return {
                'in': count_in,
                'out': count_out,
                'quarantined': count_quarantined,
                'virus': count_virus,
                'top_senders': top_senders,
                'top_recips': top_recips,
            }
