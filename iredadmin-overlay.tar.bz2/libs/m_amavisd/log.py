# libs/m_amavisd/log.py
import time
from typing import Any, Dict, List, Tuple, Union, Optional

import settings
from libs.logger import log_traceback 

from libs.m_amavisd import AmavisdWarp
from libs.m_system.mixins import AmavisNewMixin, SQLWhereBuilder, LogType, MsgsContentType, MsgsQuarType
from libs.m_crudlib import domain as lib_domain
from libs.m_system.decorators import LibDecorators


# mail_id and secret_id are composed of below characters:
#   - Amavisd-new-2.7+: [ A-Z, a-z, 0-9, -, _ ]
#   - Amavisd-new-2.6.x: [ A-Z, a-z, 0-9, +, - ]
MAIL_ID_CHARACTERS = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+-_'

class Log(AmavisdWarp, AmavisNewMixin):
    def __init__(self, 
        log_type=None, 
        account_type=None, 
        account=None, 
        page: int = 0, 
        is_global_admin = False
        ):
        super().__init__()
        self.account = self.safe_lower(account)
        self.account_type = self.safe_lower(account_type)

        self.log_type = self.validate_enum(log_type, LogType) or None

        self.cur_page = int(page)
        self.limit = settings.PAGE_SIZE_LIMIT
        self.all_reversed_domain_names = []
        self.is_global_admin =  bool(is_global_admin)
        self.func_init()

    def func_init(self):
        if not self.log_type:
            return False, 'INVALID_LOG_TYPE'
        if not isinstance(self.log_type, LogType):
            return False, f'❌ No és enum LogType: {type(self.log_type)} → {self.log_type}'

        qr = lib_domain.Domain().get_all_domains(names_only=True)
        if qr[0]:    
            self.all_reversed_domain_names = self.reverse_amavisd_domain_names(qr[1]) or False   

    def _build_sql_where(
        self, 
        log_type: LogType = LogType.RECEIVED, 
        days: Union[int, None] = None, # NOTE: en dies
        older: bool = False,                 # NOTE: True -> msgs.time_num < timestamp 
        builder: Optional[SQLWhereBuilder] = None 
        ) -> SQLWhereBuilder:
        """
            Construeix la clàusula WHERE per a les consultes segons log_type i days.

            Parameters:
                log_type (LogType): Tipus de log (SENT o RECEIVED).
                days (int, optional): Temps en dies per limitar la cerca.
                older (bool): True -> msgs.time_num < timestamp | False -> msgs.time_num > timestamp
                builder (SQLWhereBuilder, optional): Builder existent on afegir condicions.
                    Si None, es crea un de nou.

            Returns:
                Tuple[str, Dict[str, Any]]: (where_clause, vars)
        """
        
        if builder is None:
            builder = SQLWhereBuilder()
            
        field = 'recip' if log_type == LogType.RECEIVED else 'sender'

        if self.account_type == 'domain':
            reversed_account = self.reverse_amavisd_domain_names([self.account])
            builder.add(f"{field}.domain IN $domains", 'domains', reversed_account)
        elif self.account_type == 'user':
            builder.add(f"{field}.email = $email", 'email', self.account)
        else:
            builder.add(f"{field}.domain IN $domains", 'domains', self.all_reversed_domain_names)

        if isinstance(days, int):
            timestamp = int(time.time()) - (days * 86400)
            ts_op = "<" if older else ">"
            builder.add(f"msgs.time_num {ts_op} $timestamp", 'timestamp', timestamp)

        return builder

    def _apply_free_text_search(self, builder: SQLWhereBuilder, q: str) -> SQLWhereBuilder:
        """
            Cerca simple:
                - msgs.subject
                - sender.email
                - recip.email
        """
        if not q:
            return builder
        # NOTE: Normalitzem i escapem els caràcters especials del LIKE
        q_norm = q.strip().lower()
        q_norm = (
            q_norm.replace("\\", "\\\\")
                .replace("%", "\\%")
                .replace("_", "\\_")
        )
        
        like = "%{}%".format(q)

        builder.add_or_like(
            ["msgs.subject", "sender.email", "recip.email"],
            like
        )

        return builder

    def _apply_date_filter(self, builder: SQLWhereBuilder, date_from=None, date_to=None):
        import datetime

        if date_from:
            try:
                ts_from = int(datetime.datetime.strptime(date_from, "%Y-%m-%d").timestamp())
                builder.add("msgs.time_num >= $ts_from", "ts_from", ts_from)
            except:
                pass

        if date_to:
            try:
                ts_to = int(datetime.datetime.strptime(date_to, "%Y-%m-%d").timestamp()) + 86399
                builder.add("msgs.time_num <= $ts_to", "ts_to", ts_to)
            except:
                pass

        return builder

    @LibDecorators.safe_sql_method(no_hex=True)    
    def _count_top_users(self, log_type = LogType.SENT, days: Union[int, None] = None, number: int = 10) -> Tuple[bool, List[Dict[str, Any]]]:
        """
            📊 Retorna els usuaris més actius (emissors o receptors) segons el tipus de log.

            Parameters:
                log_type (LogType): Tipus de log (SENT o RECEIVED).
                days (int, optional): Temps en DIES per limitar la cerca.
                number (int): Nombre màxim d'usuaris a retornar.

            Returns:
                List[str]: Llista de correus electrònics més actius.
        """
        if not isinstance(log_type, LogType):
            return False, f'❌ No és enum LogType: {type(log_type)} → {log_type}'

        field = 'recip' if log_type == LogType.RECEIVED else 'sender'
        join_type = 'LEFT' if log_type == LogType.RECEIVED else 'RIGHT'
        
        _builder = SQLWhereBuilder()
        _builder = self._build_sql_where(log_type=log_type, days=days, builder=_builder)
        # _builder.add_in("msgs.quar_type", MsgsQuarType.all_values(), tolerate_null=True)
        conditions, vars = _builder.build()

        query = f'''
            SELECT mail, COUNT(*) AS total
            FROM (
                SELECT msgs.subject, msgs.time_iso, msgs.size, {field}.email AS mail
                FROM msgs
                {join_type} JOIN msgrcpt ON msgrcpt.mail_id = msgs.mail_id
                {join_type} JOIN maddr AS sender ON msgs.sid = sender.id
                {join_type} JOIN maddr AS recip ON msgrcpt.rid = recip.id
                WHERE {conditions}
                GROUP BY msgs.subject, msgs.time_iso, msgs.size, {field}.email
            ) AS grouped_mails
            GROUP BY mail
            ORDER BY total DESC
            LIMIT {number}
        '''

        result = list(self.db.query(query, vars=vars))
        return (True, result)
    
    @LibDecorators.safe_sql_method  
    def _count_inout_mails(self, log_type = None, days: Union[int, None] = None) -> Tuple[bool, int]:
        """
            📈 Compta el nombre total de correus enviats o rebuts (Amavisd NEW).

            Parameters:
                log_type (LogType): Tipus de log (SENT o RECEIVED).
                days (int, optional): Temps en DIES per limitar la cerca.
            
            Agrupació:
                - SENT → agrupem per subjecte, mida i temps (correus idèntics enviats a múltiples destinataris).
                - RECEIVED → agrupem per subjecte, mida i temps (correus rebuts amb duplicats per destinatari).

            Returns:
                (bool, int): Èxit i nombre total de correus.
        """

        _log_type = log_type if log_type else self.log_type
        if not isinstance(_log_type, LogType):
            return False, f'No és enum LogType: {type(_log_type)} → {_log_type}'
        
        builder = SQLWhereBuilder()
        builder = self._build_sql_where(log_type=_log_type, days=days, builder=builder)
        builder.add_in("msgs.quar_type", MsgsQuarType.all_values(), negate = True, tolerate_null=True )

        conditions, vars = builder.build()
        
        join_type = 'LEFT' if _log_type == LogType.RECEIVED else 'RIGHT'

        query = f'''
            SELECT COUNT(*) AS cnt FROM (
                SELECT msgs.subject, msgs.time_iso, msgs.size
                FROM msgs
                {join_type} JOIN msgrcpt ON msgrcpt.mail_id = msgs.mail_id
                {join_type} JOIN maddr AS sender ON sender.id = msgs.sid
                {join_type} JOIN maddr AS recip ON msgrcpt.rid = recip.id
                WHERE {conditions}
                GROUP BY msgs.subject, msgs.time_iso, msgs.size
            ) AS grouped_mails
        '''
        
        result = self.db.query(query, vars=vars)
        return True, int(result[0].cnt)
    
    @LibDecorators.safe_sql_method(no_hex=True) 
    def get_inout_mails(self, payload=None) -> Tuple[bool, Union[List[Dict[str, Any]], str]]:
        """
            📬 Recupera els correus enviats o rebuts, paginats.

            JOINs:
            - `msgs` amb `msgrcpt` per obtenir relació correu-receptor.
            - `msgs` amb `maddr` per obtenir sender i recipient.

            Filtres:
            - Exclou correus en quarantena.
            - Aplica condicions per domini, usuari i pàgina.

            Resultat:
            - Llista de correus amb metadades (subject, mida, temps, sender, recipient).
            - RECEIVED → agrupem per mail_id i sender_email
            - SENT → agrupem per mail_id i recipient_email
        """
        _log_type = self.log_type
        join_type = 'LEFT' if self.log_type == LogType.RECEIVED else 'RIGHT'

        payload = payload or {}
        q = payload.get("query_string")
        date_from = payload.get("date_from")
        date_to = payload.get("date_to")

        _builder = SQLWhereBuilder()
        _builder = self._build_sql_where(log_type=self.log_type, days=None, builder=_builder)
        _builder.add_in("msgs.quar_type", MsgsQuarType.all_values(), negate = True, tolerate_null=True)
        
        _builder = self._apply_free_text_search(_builder, q)
        _builder = self._apply_date_filter(_builder, date_from, date_to)

        sql_where, sql_vars = _builder.build()

        offset = (self.cur_page - 1) * self.limit
        limit_clause = f"LIMIT {self.limit} OFFSET {offset}" if self.cur_page > 0 else ""
        
        query = f'''
            SELECT
                msgs.subject,
                msgs.time_iso,
                msgs.size,
                msgs.quar_type,
                sender.email AS sender_email,
                GROUP_CONCAT(DISTINCT recip.email SEPARATOR ',') AS recip_emails,
                GROUP_CONCAT(DISTINCT msgs.mail_id SEPARATOR ',') AS mail_ids,
                GROUP_CONCAT(DISTINCT msgs.secret_id SEPARATOR ',') AS secret_ids,
                GROUP_CONCAT(DISTINCT CONCAT(msgs.mail_id, '+', msgs.secret_id) SEPARATOR ',') AS record_tokens
            FROM msgs
            {join_type} JOIN msgrcpt ON msgrcpt.mail_id = msgs.mail_id
            {join_type} JOIN maddr AS sender ON sender.id = msgs.sid
            {join_type} JOIN maddr AS recip ON msgrcpt.rid = recip.id
            WHERE {sql_where}
            GROUP BY msgs.subject, msgs.time_iso, msgs.size, msgs.quar_type, sender.email
            ORDER BY msgs.time_iso DESC
            {limit_clause};
        '''

        query_count = f'''
            SELECT COUNT(*) AS cnt FROM (
                SELECT msgs.subject, msgs.time_iso, msgs.size
                FROM msgs
                {join_type} JOIN msgrcpt ON msgrcpt.mail_id = msgs.mail_id
                {join_type} JOIN maddr AS sender ON sender.id = msgs.sid
                {join_type} JOIN maddr AS recip ON msgrcpt.rid = recip.id
                WHERE {sql_where}
                GROUP BY msgs.subject, msgs.time_iso, msgs.size
            ) AS grouped_mails
        '''
        total_row = self.db.query(query_count, vars=sql_vars)
        total = int(total_row[0].cnt) if total_row else 0
        
        records = list(self.db.query(query, vars=sql_vars))
        return True, {
            "total": total,
            "records": records,
            "page": self.cur_page,
            "limit": self.limit,
            "filters": payload,
            "remove_logs_in_days": settings.AMAVISD_REMOVE_MAILLOG_IN_DAYS
        }

    @LibDecorators.safe_sql_method
    def delete_records_older_than_days(self, days: int = 0) -> Tuple[bool, str]:
        """
            🧹 Elimina correus antics que no són crítics (virus, spam, etc.).
            - Només elimina correus amb `content` considerat net o no crític (ex: 'U', 'M', 'H', 'O', 'C')
            - Aplica un límit temporal amb `msgs.time_num < ...`.

            Parameters:
                days (int): Nombre de dies a partir del qual eliminar registres.

            Returns:
                Tuple[bool, str]: Estat de l'operació.

            Taules implicades:
                - msgs
                - msgrcpt
        """
        if days <= 0: # or self.session.get('RemovedSentReceived'):
            return True,
        
        builder = SQLWhereBuilder()
        # NOTE: 1. Construïm condicions base amb el nostre mètode genèric
        builder = self._build_sql_where(
            log_type=LogType.RECEIVED, 
            days=days,
            older=True,
            builder=builder
        )
        # NOTE: 2. Afegim condició indicant el que es pot esborrar
        builder.add_in("msgs.content", MsgsContentType.removable_types())

        # NOTE: 3. Combinar condicions i variables
        conditions, vars_all = builder.build()

        with self.db.transaction():
            # NOTE: A. Elimina entrades relacionades a msgrcpt
            self.db.delete(
                "msgrcpt", 
                where=f"mail_id IN (SELECT mail_id FROM msgs WHERE {conditions})", 
                vars=vars_all
            )

            # NOTE: B. Elimina entrades relacionades a quarantine
            self.db.delete(
                "quarantine", 
                where=f"mail_id IN (SELECT mail_id FROM msgs WHERE {conditions})", 
                vars=vars_all
            )

            # NOTE: C. Finalment, borrem els msgs
            self.db.delete("msgs", where=conditions, vars=vars_all)

        return True, f"Eliminats els missatges més antics de {days} dies"

    @LibDecorators.safe_sql_method
    def delete_records_all(self) -> Tuple[bool, str]:
        """
            🔥 Elimina tots els correus associats als dominis controlats.

            Returns:
                Tuple[bool, str]: Estat de l'operació.
                
            Taules implicades:
            - Si `SENT`: elimina de `msgs` on `sid` coincideix amb `maddr.domain`.
            - Si `RECEIVED`: elimina de `msgrcpt` on `mail_id` coincideix amb `msgs.domain`.
            - Altres casos: elimina directament de `msgs`.

        """
        if not self.all_reversed_domain_names:
            return True,
        
        builder = SQLWhereBuilder()
        builder.add("domain IN $domains", 'domains', self.all_reversed_domain_names)
        builder.add_in("msgs.content", MsgsContentType.removable_types())
        where, vars = builder.build()

        if self.log_type == LogType.SENT:
            self.db.query(
                    '''DELETE FROM msgs WHERE sid IN (SELECT id FROM maddr WHERE domain IN $domains)''',
                    vars=vars
                )
        elif self.log_type == LogType.RECEIVED:
            self.db.query(
                    '''DELETE FROM msgrcpt WHERE mail_id IN (SELECT mail_id FROM msgs WHERE domain IN $domains)''',
                    vars=vars
                )
        else:
            self.db.delete('msgs', where=where, vars=vars)
        return True,

    @LibDecorators.safe_sql_method
    def delete_records_by_mailid(self, records: List[Dict[str, str]] = None) -> Tuple[bool, str]:
        """
            🗑️ Elimina correus específics segons una llista de `mail_id`.

            Parameters:
                (List[Dict]): Diccionaris amb 'mail_id', 'secret_id', 'requested_by'.
            Returns:
                Tuple[bool, str]: Estat de l'operació.

            Taules implicades:
                - msgs
                - msgrcpt
                - quarantine (si és log de quarantina)
        """
        if not isinstance(records, list) or not records:
            return False, 'INVALID_MAILID'
        
        # NOTE: Filtrar mail_ids vàlids
        filtered_ids = [
            v['mail_id'] for v in records
            if 'mail_id' in v and set(v['mail_id']).issubset(MAIL_ID_CHARACTERS)
        ]
        if not filtered_ids:
            return True, 'INVALID_MAILID'
        
        builder = SQLWhereBuilder()
        builder.add_in("mail_id", filtered_ids)
        if not self.is_global_admin:
            builder.add_in("domain", self.all_reversed_domain_names)

        conditions, all_vars = builder.build()

        if self.log_type:
            self.db.delete('msgs', where=conditions, vars=all_vars)
            self.db.delete('msgrcpt', where=conditions, vars=all_vars)
        if self.log_type == LogType.QUARANTINED:
            self.db.delete('quarantine', where=conditions, vars=all_vars)

        return True, 'DELETED'
