
# Flux de gestió de correu amb Amavis New

```mermaid
flowchart TD
    subgraph Receptors
        U[users]
        P[policy]
    end

    subgraph Remitents
        M[mailaddr]
    end

    subgraph Llistes
        WL[wblist]
        OWL[outbound_wblist]
    end

    M -->|sid| WL
    U -->|rid| WL
    WL -->|wb: W/B| FilterIn[Filtre de correu entrant]

    U -->|sid| OWL
    M -->|rid| OWL
    OWL -->|wb: W/B| FilterOut[Filtre de correu sortint]

    U -->|policy_id| P
    P -->|configura| Amavis[Amavisd-new]

    FilterIn --> Amavis
    FilterOut --> Amavis
```
🧠 Explicació de l’esquema
- `users`: conté adreces de correu (receptors) i referència a la política (policy_id)
- `mailaddr`: conté adreces de correu (remitents)
- `wblist`: defineix si un remitent (sid) està permès o bloquejat per un receptor (rid)
- `outbound_wblist`: defineix si un receptor (rid) pot rebre correu d’un remitent (sid) en sortida
- `policy`: defineix el comportament de filtratge (nivells de spam, etiquetes, quarantena, etc.)
Amavisd-new: aplica les polítiques i les llistes blanca/negra en temps real


## Esquema textual del flux
[Remitent] → [mailaddr]
     │
     └──→ [wblist] ──→ [Filtre de correu entrant]
                          │
[Receptor] → [users] ─────┘
     │
     └──→ [policy] ──→ [Amavisd-new]

[Receptor] → [users]
     │
     └──→ [outbound_wblist] ──→ [Filtre de correu sortint]
                                    │
[Remitent] → [mailaddr] ────────────┘
                          │
                          └──→ [Amavisd-new]

### 🧩 Jerarquia de components
1. Receptors (`users`): Conté adreces de correu que reben missatges Associats a una política (policy_id). També poden ser remitents en correu sortint
2. Remitents (`mailaddr`): Adreces que envien correu codificades en HEX. Inclou email_raw per normalitzar subadreces amb +
3. Polítiques (`policy`): Defineixen com es tracta el correu (spam, quarantena, etc.). Assignades per policy_id a cada usuari
4. Llistes (`wblist`, `outbound_wblist`): 
    1. `wblist`: controla correu entrant (remitent → receptor)
    1. `outbound_wblist`: controla correu sortint (receptor → destinatari extern)
Marcat amb __W__ (whitelist) o __B__ (blacklist)
5. Filtratge: 
    1. FilterIn: s’activa si el remitent està a wblist
    1. FilterOut: s’activa si el receptor està a outbound_wblist
6. Amavisd-new: Aplica les polítiques i les llistes en temps real. Decideix si el correu es permet, bloqueja o etiqueta

### Codificació
Per defecte, iRedMail amb Amavisd utilitza HEX UPPER __(no MD5)__ per guardar adreces a: `mailaddr`, `policy` `users`
📚 Referència oficial: Pots consultar els detalls complets a la [documentació d’iRedMail sobre polítiques per destinatari](https://docs.iredmail.org/amavisd.per-recipient.policy.lookup.html).

```python
    address.encode('utf-8').hex().upper()
```
#### Com obtenir el hash MD5 🔑 d'un usuari (si cal) 
Per calcular el hash MD5 d'una adreça de correu (ex: `postmaster@melindro.org`), utilitza la següent comanda segons el teu sistema operatiu:

##### Python
```python
import hashlib

email = "postmaster@melindro.org"
hash_md5 = hashlib.md5(email.encode('utf-8')).hexdigest().upper()  # Majúscules com a conveni
print(hash_md5)

```

##### Linux CLI
    
```bash
echo -n "postmaster@melindro.org" | md5sum | awk '{print toupper($1)}'
# Output: 7A264CCB7A0144A4F8E475F7CA041B42
```

##### macOS CLI

```bash
echo -n "postmaster@melindro.org" | md5 | tr 'a-f' 'A-F'
# Output: 7A264CCB7A0144A4F8E475F7CA041B42
```

## 1️⃣ Taula `users`

```sql
INSERT INTO users (priority, policy_id, email, fullname)
VALUES
    (0, 1, UNHEX('deaddbdefe6384a62f9f9114bf54d67d'), '@.'),
    (5, 2, UNHEX('64acf920efe555d653647ee8b7b69796'), '@melindro.org'),
    (10, 3, UNHEX('7a264ccb7a0144a4f8e475f7ca041b42'), 'postmaster@melindro.org'),
    (10, 3, UNHEX('16a595f8386407458aaf432ceea797a8'), 'angel@melindro.org');
```

## 2️⃣ Taula `maddr`

```sql
INSERT INTO maddr (partition_tag, email, email_raw, domain)
VALUES
    (0, UNHEX('deaddbdefe6384a62f9f9114bf54d67d'), '@.', '.'),
    (0, UNHEX('64acf920efe555d653647ee8b7b69796'), '@melindro.org', 'org.melindro'),
    (0, UNHEX('7a264ccb7a0144a4f8e475f7ca041b42'), 'postmaster@melindro.org', 'org.melindro'),
    (0, UNHEX('16a595f8386407458aaf432ceea797a8'), 'angel@melindro.org', 'org.melindro'),
    [...] ;
```

### Adreces de correu (hex codificades) i normalització amb trigger iRedMail Amavisd-NEW
#### Què fa aquest trigger?
```sql
IF (NEW.email LIKE '%+%') THEN
    SET NEW.email_raw = CONCAT(
        SUBSTRING_INDEX(NEW.email, '+', 1),
        '@',
        SUBSTRING_INDEX(NEW.email, '@', -1)
    );
ELSE
    SET NEW.email_raw = NEW.email;
END IF;
```

Molts servidors de correu permeten etiquetes amb `+` per crear subadreces (exemple: `user+newsletter@example.com`). Quan es fa lookup a la taula `maddr` per aplicar whitelists/blacklists, no es vol que el “+tag” interfereixi. Així, `email_raw` sempre conté l’adreça “netejada” sense la part del `+tag`, útil per comparar i aplicar regles de spam o greylist de forma uniforme.

#### Exemple pràctic

| email                        | email_raw              |
|------------------------------|------------------------|
| user@example.com             | user@example.com       |
| user+newsletter@example.com  | user@example.com       |
| angel@melindro.org           | angel@melindro.org     |

---

## 3️⃣ Taula `mailaddr`
Prioritat utilitzada a la taula SQL `amavisd.mailaddr` i al connector iRedAPD `throttle`.
0 és la prioritat més baixa.
Referència: http://www.amavis.org/README.lookups.txt

Es recomana l'ordre següent (implementat mitjançant ordenació descendent del camp `priority`), per seguir el principi de més específic a més general, igual que en altres taules de consulta:
    9 - consulta per a user+foo@sub.example.com
    8 - consulta per a user@sub.example.com (només si $recipient_delimiter és '+')
    7 - consulta per a user+foo (només si el domini és local)
    6 - consulta per a user     (només local; només si $recipient_delimiter és '+')
    5 - consulta per a @sub.example.com
    3 - consulta per a @.sub.example.com
    2 - consulta per a @.example.com
    1 - consulta per a @.com
    0 - consulta per a @.       (catchall)

```python
    MAILADDR_PRIORITIES = {
        'email': 10,
        'ip': 9,
        'wildcard_ip': 8,
        'wildcard_addr': 7,     # r'user@*'. utilitzat al connector iRedAPD `amavisd_wblist`
                                # com a remitent amb comodí. Ex: 'user@*'
        'domain': 5,
        'subdomain': 3,
        'tld_domain': 2,
        'catchall_ip': 1,       # utilitzat al connector iRedAPD `throttle`
        'catchall': 0,
    }
```
Priority segons `MAILADDR_PRIORITIES`:

```sql
    INSERT INTO mailaddr (priority, email)
    VALUES
      (0,  UNHEX('deaddbdefe6384a62f9f9114bf54d67d')), -- catchall global
      (5,  UNHEX('64acf920efe555d653647ee8b7b69796')), -- domini melindro.org
      (10, UNHEX('7a264ccb7a0144a4f8e475f7ca041b42')), -- email específic postmaster@melindro.org
      (10, UNHEX('16a595f8386407458aaf432ceea797a8')), -- email específic angel@melindro.org
        [...] ;
```

---

## 4️⃣ Taula `wblist` i `outbound_wblist`
`wblist` → per correu entrant (de remitent a destinatari)
`outbound_wblist` → per correu sortint (de remitent intern a destinatari extern)
A amavisd-new amb base de dades MariaDB, les llistes blanques i negres es marquen amb les lletres:
* `W` per a whitelist (llista blanca)
* `B` per a blacklist (llista negra)

Aquestes lletres apareixen a la columna wb de la taula wblist, que relaciona un receptor (rid) amb un remitent (sid) i defineix com s’ha de tractar el correu entre ells. Per exemple:
```sql
+------+-----+----+
| rid  | sid | wb |
+------+-----+----+
| 1917 | 640 | B  |
+------+-----+----+
```
Aquest registre indica que el remitent amb ID 640 està en la llista negra per al receptor amb ID 1917.

* Whitelist / Blacklist per correu entrant
    - rid = id de l'usuari receptor (taula `users`)
    - sid = id del remitent (taula `mailaddr`)
    - wb  = 'W' (whitelist) o 'B' (blacklist)

* Whitelist / Blacklist  per correu sortint
    - rid = id del receptor (taula `mailaddr`)
    - sid = id del remitent (taula `users`)
    - wb  = 'W' (whitelist) o 'B' (blacklist)

```sql
-- Exemple de regles WB/BL
INSERT INTO wblist (rid, sid, wb)
VALUES
  (1, 1, 'W'),  -- catchall whitelist
  (2, 2, 'W'),  -- domini melindro.org whitelist
  (3, 3, 'W'),  -- postmaster whitelist
  (4, 2, 'B');  -- angel@melindro.org blacklist
```
Explicació ràpida: 

| Usuari                  | mailaddr.priority | wblist | Comentari                |
|-------------------------|-------------------|--------|--------------------------|
| `@.`                    | 0                 | W     | Catchall global          |
| `@melindro.org`         | 5                 | W     | Tots els correus del domini |
| `postmaster@melindro.org` | 10              | W     | Usuari concret           |
| `angel@melindro.org`    | 10                | B     | Usuari bloquejat         |

Quan arriba un email, **Amavisd** mira `priority` + `wblist` + `policy_id` per decidir si aplicar whitelist o blacklist.
`maddr.email_raw` serveix per normalitzar subadreces amb `+`.

### Consultes SQL (pe Adminer) per registres W i B
1. `whitelist`
```sql
    SELECT
      LOWER(CONVERT(mailaddr.email USING utf8)) AS sender_address
    FROM wblist
    JOIN mailaddr ON wblist.sid = mailaddr.id
    JOIN users ON wblist.rid = users.id
    WHERE wblist.wb = 'W'
      AND users.email = UNHEX(HEX('@melindro.org'));
```

1. `blacklist`
```sql
    SELECT
      LOWER(CONVERT(mailaddr.email USING utf8)) AS sender_address
    FROM wblist
    JOIN mailaddr ON wblist.sid = mailaddr.id
    JOIN users ON wblist.rid = users.id
    WHERE wblist.wb = 'B'
      AND users.email = UNHEX(HEX('@melindro.org'));
```

## 5️⃣ Taula `policy` resum API ↔ DB
| **Clau API**                   | **Camp DB**                | **Valor/Transformació**                                                                                                              |
| ------------------------------ | -------------------------- | -------------------------------------------------------------------------------------------------------------------------------------|
| `policy_name`                  | `policy_name`              | text lliure. Nom amigable per identificar la política (no afecta Amavis, només organització).                                        |
| `enable_spam_checks`           | `bypass_spam_checks`       | Activa/desactiva comprovació de spam. `yes` → `N` (no bypass, checks actius)<br>`no` → `Y` (bypass, checks desactivats)              | 
| `enable_virus_checks`          | `bypass_virus_checks`      | Activa/desactiva comprovació de virus.                                                                                               |
| `enable_banned_checks`         | `bypass_banned_checks`     | Activa/desactiva comprovació de fitxers prohibits.                                                                                   |
| `enable_header_checks`         | `bypass_header_checks`     | Activa/desactiva comprovació d’encapçalaments.                                                                                       |
| `quarantine_spam`              | `spam_quarantine_to`       | `yes` → `"spam-quarantine"`<br>`no` → `""`<br>⚠️ Si té valor → `spam_lover = 'N'`                                                    |
| `quarantine_virus`             | `virus_quarantine_to`      | `yes` → `"virus-quarantine"`<br>`no` → `""`<br>⚠️ Si té valor → `virus_lover = 'N'`                                                  |
| `quarantine_banned`            | `banned_quarantine_to`     | `yes` → `"banned-quarantine"`<br>`no` → `""`<br>⚠️ Si té valor → `banned_files_lover = 'N'`                                          |
| `quarantine_bad_header`        | `bad_header_quarantine_to` | `yes` → `"bad-header-quarantine"`<br>`no` → `""`<br>⚠️ Si té valor → `bad_header_lover = 'N'`                                        |
| `prefix_spam_in_subject`       | `spam_subject_tag2`        | Afegeix prefix (p. ex. `***SPAM***`) a l’assumpte si `yes` → `settings.AMAVISD_SPAM_SUBJECT_PREFIX`<br>`no` → `""`                   |
| `always_insert_x_spam_headers` | (3 camps)                  | Controla si s’afegeixen sempre capçaleres `X-Spam-*`. Si `yes` → `spam_tag_level = -999`, `spam_tag2_level = 5.0`, `spam_kill_level = 6.5`<br>`no` → defaults (2.0, 6.0, 6.9) |
| `spam_score`                   | `spam_tag2_level`          | Llindar de classificació com a SPAM fort. Es guarda com a `float(val)`<br>Si no hi és → default (6.0)                                |
| `message_size_limit`           | `message_size_limit`       | Entrada en bytes <br> El controller web transforma unitats (MB/GB → bytes)                                                           |


### 📌 Notes (DEFAULT_DB_POLICY)
- Els valors yes/no a la API es transformen a DB com N/Y per als camps bypass_*.
- Els quarantines forcen el corresponent *_lover a N.
- Defaults:
  * spam_tag_level = 2.0
  * spam_tag2_level = 6.0
  * spam_kill_level = 6.9
  * *_lover = Y si no hi ha quarantina, N si sí.
- policy_name serveix només per a identificació a la interfície/admin API, no afecta Amavis.


# ✉️ Simulacions 
## Cas 1: correu de postmaster@melindro.org a angel@melindro.org
1. Arriba un correu
    - Remitent: `postmaster@melindro.org`
    - Destinatari: `angel@melindro.org`
2. Codificació de les adreces. Es codifiquen en HEX UPPER:
    - `postmaster@melindro.org` → `7A264CCB7...`
    - `angel@melindro.org` → `16A595F8...`
3. Lookup a la taula `users`
Es busca `angel@melindro.org` a la taula `users`. S’obté:
- `id = 4`
- `policy_id = 3`
4. Lookup a la taula `mailaddr`
Es busca `postmaster@melindro.org` a la taula `mailaddr`. S’obté:
- `id = 3`
5. Lookup a la taula `wblist`
Es busca si hi ha una regla entre `rid = 4` (angel) i `sid = 3` (postmaster). Resultat:
- `wb = 'B'` → Blacklist
6. Lookup a la taula `policy`
Es consulta la política amb `id = 3`. Exemple de configuració:
- `spam_tag_level = 2.0`
- `spam_kill_level = 6.0`
- `quarantine = yes`
7. Decisió d’Amavis
Com que el remitent està en blacklist, el correu és __bloquejat__. No s’aplica filtratge de spam ni quarantena: es rebutja directament

## Cas 2: correu sense cap regla definida
1. Arriba un correu
    - Remitent: `newsletter@example.com`
    - Destinatari: `angel@melindro.org`
2. Codificació de les adreces. Es codifiquen en HEX UPPER:
    - `newsletter@example.com` → `D4C3B2A1...`
    - `angel@melindro.org` → `16A595F8...`
3. Lookup a la taula `users`
    - `angel@melindro.org` existeix → `id = 4`, `policy_id = 3`
4. Lookup a la taula `mailaddr`
    - `newsletter@example.com` existeix → `id = 9`
5. Lookup a la taula `wblist`
No hi ha cap entrada per `rid = 4`, `sid = 9`
6. Decisió d’Amavis
    - Com que no hi ha cap regla, s’aplica la política per defecte
    - Es fa escaneig de spam, però si el correu no supera el llindar → __es permet__

# Gestió de missatges i quarentenes
## 📌 Camps rellevants de `msgs`:
- `content`: És un codi curt (1 caràcter) que indica quin ha estat el resultat de la classificació del missatge. Justament és el que el teu content_map tradueix:
    + `S` / `s` / `Y` → spam
    + `V` → virus
    + `B` → banned file
    + `H` → bad header
    + `C` → clean

- `quar_type`: Tipus de quarantena aplicada (si n’hi ha). Es guarda també amb un codi:
    + `S` = quarantena de spam
    + `V` = quarantena de virus
    + `B` = quarantena de banned
    + `H` = quarantena de bad header
    + `Q` = quarantena genèrica
    Aquest camp només tindrà valor si el missatge efectivament ha estat posat en quarantena.

- `quar_loc`: Localització física o lògica de la quarantena. Pot contenir:
    + Un hash o ID intern (si està en fitxers/quarantena local).
    + Una referència a la base de dades (si s’ha configurat quarantena SQL).
    + O fins i tot una ruta de fitxer (si es desa al filesystem).

En altres paraules: 
+ `content` et diu __què és__ el missatge.
+ `quar_type` et diu __si s’ha guardat a quarantena__ (i de quin tipus). Si `content` és `S`, `V`, `B` o `H` i la política ho requereix, aleshores `quar_type`rebrà el mateix codi.
+ `quar_loc` et diu __on trobar-lo__ si està en quarantena. On s’ha desat el missatge → indexa la quarantena real.

```python
    # msgs.content:
        #   - V: virus
        #   - B: banned
        #   - U: unchecked
        #   - S: spam(kill)
        #   - Y: spammy(tag2)
        #   - M: bad-mime
        #   - H: bad-header
        #   - O: oversized
        #   - T: mta-error
        #   - C: clean
```

Diagrama simplificat del disseny de la base de dades d’amavisd-new amb les relacions clau (`mail_id` i `_secret_id`):
```scss
                         ┌───────────────────────────┐
                         │          msgs             │
                         │───────────────────────────│
                         │ mail_id (PK)   <────────┐ │
                         │ secret_id               │ │
                         │ time_num                │ │
                         │ from_addr (FK→maddr.id) │ │
                         │ subject, size, quar_type│ │
                         └─────────────────────────┘ │
                                                     │
                                                     │1
                                                     │
                                                     │N
                      ┌───────────────────────────┐  │
                      │         msgrcpt           │  │
                      │───────────────────────────│  │
                      │ mail_id (FK→msgs.mail_id)─┘  │
                      │ rid (FK→maddr.id)           │
                      │ ds (delivery status)        │
                      │ rs (reason string)          │
                      └─────────────────────────────┘

        ┌───────────────────────────┐
        │          maddr            │
        │───────────────────────────│
        │ id (PK)                   │
        │ email                     │
        │ domain                    │
        └───────────────────────────┘

        ┌───────────────────────────┐
        │       quarantine          │
        │───────────────────────────│
        │ mail_id (FK→msgs.mail_id) │
        │ secret_id (FK→msgs.secret_id) │
        │ chunk_ind                 │
        │ mail_text (blob)          │
        └───────────────────────────┘
```
`msgs`: informació bàsica del missatge (qui envia, subject, mida, quarantena...).
`maddr`: taula normalitzada d’adreces i dominis. `from_addr` i `rid` apunten aquí.
`msgrcpt`: mapping N:1 entre missatges (`msgs.mail_id`) i destinataris (`maddr.id`).
`quarantine`: guarda el contingut del correu en blocs (chunk_ind) + fa servir `mail_id` i `secret_id` junts per validar l’accés segur.
Si només vols estadístiques → `mail_id` ja et serveix.
Si vols accedir a contingut quarantinat via web/admin → necessites també `secret_id`.

# Correus per proves
## 1️⃣ Preparar correus de prova
Crea un fitxer `virus.eml` amb contingut de prova que Amavis reconegui com a virus (normalment amb EICAR):
```text
From: postmaster@melindro.org
To: testuser@melindro.org
Subject: Test Virus Email
Date: Thu, 28 Aug 2025 12:00:00 +0200
Message-ID: <virus-test@example.com>

X5O!P%@AP[4\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*
```
Crea un altre `badheader.eml` amb un header mal format:
```text
From: postmaster@melindro.org
To: testuser@melindro.org
Subject: Test Bad Header
Date: Thu, 28 Aug 2025 12:05:00 +0200
Message-ID: <badheader-test@example.com>
X-Bad-Header
```
La línia X-Bad-Header sense valor pot disparar detecció de “bad header” si Amavis està configurat per fer-ho.
## 2️⃣ Enviar correus al servidor local
A la màquina on tens iRedMail/Amavis:
```bash
sendmail -t < virus.eml
sendmail -t < badheader.eml
```

Això fa que el correu passi pel procés normal de Amavis.
Assegura’t que els correus van cap a un compte de prova, per exemple __testuser@melindro.org__.

## 3️⃣ Comprovar la quarantena

Amavis/iRedMail sol posar els correus a la quarantena segons els tipus:
- Virus → MsgsContentType.VIRUS
- Bad header → MsgsContentType.BADHEADER

Comprova-ho amb la base de dades (msgs + msgrcpt) o el panell:
```sql
SELECT mail_id, subject, quar_type
FROM msgs
WHERE quar_type IS NOT NULL;
```
Hauries de veure els dos correus amb quar_type = 'V' i 'H' (o el que tinguis definit en enums).

# 📦 Llicència
Aquest projecte s’ofereix sota la llicència [MIT](https://choosealicense.com/licenses/mit/). Pots modificar-lo, distribuir-lo i integrar-lo lliurement.

# 🤝 Contribucions
Les contribucions són benvingudes! Si tens idees, millores o correccions, obre un issue o envia un pull request.
[![PayPal - Donate](https://img.shields.io/badge/PayPal-Donate-005EA6?logo=paypal&logoColor=white)](https://www.paypal.me/cuquet74)
