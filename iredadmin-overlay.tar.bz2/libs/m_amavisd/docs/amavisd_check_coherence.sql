/* 
# 📄 Consulta SQL – Verificació de coherència
Consulta SQL de diagnòstic que et permet detectar inconsistències entre les principals taules relacionades d’amavisd a iRedMail, com:
    - Els users.policy_id coincideixin amb un policy.id
    - Els users.email coincideixin amb un mailaddr.email
    - Els mailaddr.id siguin referenciats a wblist.sid i rid
    - Els msgs.mail_id i msgrcpt.rid apuntin a entrades existents
    - Els quarantine.mail_id i quarantine.rid també siguin coherents
Aquesta consulta retornarà les anomalies típiques de coherència. Aquí tens un exemple de script SQL que pots executar directament a Adminer o MariaDB/MySQL:

# ℹ️ Com utilitzar aquesta consulta
1.Obre Adminer o el teu client SQL.
2.Vés a l’opció de "SQL".
3.Enganxa tot aquest contingut a l’àrea de consulta.
4.Executa la consulta.
5.Revisa els resultats de cada secció: si alguna retorna files, vol dir que hi ha incoherències.

# ✅ Resultat esperat
Cada subconsulta hauria de tornar 0 files si tot està coherent.
Si alguna torna files, podràs identificar ràpidament:
- Registres orfes (p. ex. usuaris amb policy_id inexistent)
- Referències trencades (p. ex. correus a wblist que no existeixen a mailaddr)
- Entrades de quarantena sense msg relacionat

*/

-- Verifica que els 'users.policy_id' coincideixin amb 'policy.id'
SELECT u.id AS user_id, u.email, u.policy_id
FROM users u
LEFT JOIN policy p ON u.policy_id = p.id
WHERE p.id IS NULL;

-- Verifica que els 'users.email' existeixin a 'mailaddr'
SELECT u.id AS user_id, u.email
FROM users u
LEFT JOIN mailaddr m ON LOWER(u.email) = LOWER(m.email)
WHERE m.id IS NULL;

-- Verifica que 'wblist.sid' i 'wblist.rid' estiguin a 'mailaddr'
SELECT w.id, w.sid, w.rid
FROM wblist w
LEFT JOIN mailaddr m1 ON w.sid = m1.id
LEFT JOIN mailaddr m2 ON w.rid = m2.id
WHERE m1.id IS NULL OR m2.id IS NULL;

-- Verifica que 'outbound_wblist.sid' i 'outbound_wblist.rid' estiguin a 'mailaddr'
SELECT ow.id, ow.sid, ow.rid
FROM outbound_wblist ow
LEFT JOIN mailaddr m1 ON ow.sid = m1.id
LEFT JOIN mailaddr m2 ON ow.rid = m2.id
WHERE m1.id IS NULL OR m2.id IS NULL;

-- Verifica que 'msgs.sid' estigui a 'mailaddr'
SELECT msg.mail_id, msg.sid
FROM msgs msg
LEFT JOIN mailaddr m ON msg.sid = m.id
WHERE m.id IS NULL;

-- Verifica que 'msgrcpt.rid' estigui a 'mailaddr'
SELECT r.mail_id, r.rid
FROM msgrcpt r
LEFT JOIN mailaddr m ON r.rid = m.id
WHERE m.id IS NULL;

-- Verifica que 'quarantine.mail_id' existeixi a 'msgs'
SELECT q.mail_id
FROM quarantine q
LEFT JOIN msgs m ON q.mail_id = m.mail_id
WHERE m.mail_id IS NULL;

-- Verifica que 'quarantine.rid' existeixi a 'mailaddr'
SELECT q.mail_id, q.rid
FROM quarantine q
LEFT JOIN mailaddr m ON q.rid = m.id
WHERE m.id IS NULL;
