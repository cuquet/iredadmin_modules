/* 
# 📄 Script SQL d’exemple – Dades Amavisd per melindro.org
Aquest script insereix dades d’exemple a les principals taules d’Amavisd que utilitza iRedMail,
per provar funcionalitats i fer proves locals amb el domini "melindro.org".

# Contingut i explicació de cada secció:

## Polítiques
Defineix tres polítiques de spam i virus, amb diferents nivells i configuracions:
  - Política global per defecte '@.'
  - Política per al domini 'melindro.org'
  - Política específica per a l’usuari 'postmaster@melindro.org'

## Usuaris
Assigna usuaris relacionats amb les polítiques:
  - L’usuari global '@.'
  - El domini 'melindro.org'
  - El postmaster del domini
  - Un usuari de prova 'angel@melindro.org'

## Adreces de correu `maddr`
Adreces de correu codificades en hexadecimal i desglossades per domini.
Són les adreces que serveixen com a referència per a altres taules.

## Missatges simulats `msgs`
Dues entrades simulades: un missatge net i un missatge classificat com spam,
amb dades bàsics per a proves de quarantena i detecció.

## Destinataris `msgrcpt`
Destinataris dels missatges amb identificadors corresponents a adreces i missatges.

## Llista blanca / negra `wblist`
Relacions de llistes blanca i negra per a usuaris, relacionant remitents i destinataris.

# ℹ️ Com utilitzar aquest script
1. Obre Adminer o un client MySQL/MariaDB.
2. Crea o selecciona la base de dades amavisd.
3. Enganxa aquest script a la consola SQL.
4. Executa-ho per carregar les dades d’exemple.
5. Utilitza les dades per a tests i desenvolupament.

# ✅ Resultat esperat
Les taules quedaran poblades amb informació coherent per començar a treballar amb amavisd i iRedMail
sense errors de referències creuades ni registres orfes.



*/

-- Polítiques
INSERT INTO policy (
  id,
  policy_name,
  virus_lover,
  spam_lover,
  unchecked_lover,
  banned_files_lover,
  bad_header_lover,
  bypass_virus_checks,
  bypass_spam_checks,
  bypass_banned_checks,
  bypass_header_checks,
  virus_quarantine_to,
  spam_quarantine_to,
  banned_quarantine_to,
  unchecked_quarantine_to,
  bad_header_quarantine_to,
  clean_quarantine_to,
  archive_quarantine_to,
  spam_tag_level,
  spam_tag2_level,
  spam_tag3_level,
  spam_kill_level,
  spam_dsn_cutoff_level,
  spam_quarantine_cutoff_level,
  addr_extension_virus,
  addr_extension_spam,
  addr_extension_banned,
  addr_extension_bad_header,
  warnvirusrecip,
  warnbannedrecip,
  warnbadhrecip,
  newvirus_admin,
  virus_admin,
  banned_admin,
  bad_header_admin,
  spam_admin,
  spam_subject_tag,
  spam_subject_tag2,
  spam_subject_tag3,
  message_size_limit,
  banned_rulenames,
  disclaimer_options,
  forward_method,
  sa_userconf,
  sa_username
)
VALUES
  (1,'@.','N','Y',NULL,'N','Y','N','N','N','N','virus-quarantine','','banned-quarantine',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL),
  (2, '@melindro.org', 'Y','Y',NULL,'N','N','N','N','N','N','virus-quarantine','','banned-quarantine',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALLOW_MS_OFFICE,ALLOW_MS_WORD',NULL,NULL,NULL,NULL),
  (3, 'postmaster@melindro.org','Y','Y',NULL,'N','N','N','N','N','N','virus-quarantine','','banned-quarantine',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALLOW_MS_OFFICE,ALLOW_MS_WORD',NULL,NULL,NULL,NULL);
  (3, 'angel@melindro.org','Y','Y',NULL,'N','N','N','N','N','N','virus-quarantine','','banned-quarantine',NULL,'',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'ALLOW_MS_OFFICE,ALLOW_MS_WORD',NULL,NULL,NULL,NULL);



-- ============================================
-- 🧼 MÒDUL 1: Eliminar duplicats per email
-- ============================================
-- Conserva la fila amb menor ID per cada hash d'email
DELETE u1 FROM users u1
JOIN users u2 ON u1.email = u2.email AND u1.id > u2.id;

-- ============================================
-- 🔄 MÒDUL 2: Forçar reconstrucció de la taula
-- ============================================
-- Això força MariaDB a regenerar índexs i estadístiques
ALTER TABLE users ENGINE = InnoDB;

-- ============================================
-- 🧱 MÒDUL 3: Reindexar el camp email
-- ============================================
-- Elimina l’índex si existeix i el torna a crear
DROP INDEX IF EXISTS idx_email ON users;
ALTER TABLE users ADD INDEX idx_email (email);

-- ============================================
-- 🔍 MÒDUL 4: Verificació de longituds de hash
-- ============================================
-- Mostra entrades amb hash incorrecte (no 32 caràcters)
SELECT HEX(email) AS email_hash FROM users WHERE LENGTH(email) != 16;

-- ============================================
-- 🧩 MÒDUL 5: Inserció de dades netes
-- ============================================
-- Cada entrada té un fullname que descriu el tipus d’adreça
INSERT INTO users (priority, policy_id, email, fullname)
VALUES
-- Catchall globals
(0, 1, UNHEX('deaddbdefe6384a62f9f9114bf54d67d'), 'Catchall global: @.'),
(0, 1, UNHEX('a0b6593960c89a2e11d5d7e12d4a6a1b'), 'Catchall: @example.com'),

-- Dominis
(5, 2, UNHEX('64acf920efe555d653647ee8b7b69796'), 'Domini: @melindro.org'),
(5, 2, UNHEX('d4c74594d841139328695756648b6bd6'), 'Domini: @example.org'),
(5, 2, UNHEX('8f14e45fceea167a5a36ded52b845c97'), 'Domini: @pepito.net'),

-- Adreces concretes
(10, 3, UNHEX('7a264ccb7a0144a4f8e475f7ca041b42'), 'Adreça: postmaster@melindro.org'),
(10, 3, UNHEX('16a595f8386407458aaf432ceea797a8'), 'Adreça: angel@melindro.org'),
(10, 3, UNHEX('c4ca4238a0b923820dcc509a6f75849b'), 'Adreça: admin@example.com'),
(10, 3, UNHEX('6512bd43d9caa6e02c990b0a82652dca'), 'Adreça: support@example.org'),
(10, 3, UNHEX('c20ad4d76fe97759aa27a0c99bff6710'), 'Adreça: sales@pepito.net'),

-- Wildcards
(7, 4, UNHEX('e2c865db4162bed963bfaa9ef6ac18f0'), 'Wildcard: info@.'),
(7, 4, UNHEX('a87ff679a2f3e71d9181a67b7542122c'), 'Wildcard: webmaster@.'),

-- Extra adreces
(10, 3, UNHEX('e4da3b7fbbce2345d7772b0674a318d5'), 'Adreça: no-reply@example.com'),
(10, 3, UNHEX('1679091c5a880faf6fb5e6087eb1b2dc'), 'Adreça: contact@example.org');

-- ============================================
-- 🔙 MÒDUL 6: Rollback manual (opcional)
-- ============================================
-- Si cal revertir les insercions, pots executar:
-- DELETE FROM users WHERE fullname LIKE 'Catchall:%'
--     OR fullname LIKE 'Domini:%'
--     OR fullname LIKE 'Adreça:%'
--     OR fullname LIKE 'Wildcard:%';


-- ============================================
-- 📨 MÒDUL 1: Inserció a maddr amb domini invertit
-- ============================================
INSERT INTO maddr (partition_tag, email, email_raw, domain)
VALUES
-- Catchall globals
(0, UNHEX('deaddbdefe6384a62f9f9114bf54d67d'), '@.', '.'),
(0, UNHEX('a0b6593960c89a2e11d5d7e12d4a6a1b'), '@example.com', 'com.example'),

-- Dominis
(0, UNHEX('64acf920efe555d653647ee8b7b69796'), '@melindro.org', 'org.melindro'),
(0, UNHEX('d4c74594d841139328695756648b6bd6'), '@example.org', 'org.example'),
(0, UNHEX('8f14e45fceea167a5a36ded52b845c97'), '@pepito.net', 'net.pepito'),

-- Adreces concretes
(0, UNHEX('7a264ccb7a0144a4f8e475f7ca041b42'), 'postmaster@melindro.org', 'org.melindro'),
(0, UNHEX('16a595f8386407458aaf432ceea797a8'), 'angel@melindro.org', 'org.melindro'),
(0, UNHEX('c4ca4238a0b923820dcc509a6f75849b'), 'admin@example.com', 'com.example'),
(0, UNHEX('6512bd43d9caa6e02c990b0a82652dca'), 'support@example.org', 'org.example'),
(0, UNHEX('c20ad4d76fe97759aa27a0c99bff6710'), 'sales@pepito.net', 'net.pepito'),

-- Wildcards
(0, UNHEX('e2c865db4162bed963bfaa9ef6ac18f0'), 'info@*', '*'),
(0, UNHEX('a87ff679a2f3e71d9181a67b7542122c'), 'webmaster@*', '*'),

-- Extra adreces
(0, UNHEX('e4da3b7fbbce2345d7772b0674a318d5'), 'no-reply@example.com', 'com.example'),
(0, UNHEX('1679091c5a880faf6fb5e6087eb1b2dc'), 'contact@example.org', 'org.example');

-- ============================================
-- 📬 MÒDUL 2: Inserció a mailaddr amb prioritat
-- ============================================
INSERT INTO mailaddr (priority, email)
VALUES
(0,  UNHEX('deaddbdefe6384a62f9f9114bf54d67d')), -- catchall global
(5,  UNHEX('a0b6593960c89a2e11d5d7e12d4a6a1b')), -- catchall per domini example.com
(5,  UNHEX('64acf920efe555d653647ee8b7b69796')), -- domini melindro.org
(5,  UNHEX('d4c74594d841139328695756648b6bd6')), -- domini example.org
(5,  UNHEX('8f14e45fceea167a5a36ded52b845c97')), -- domini pepito.net
(10, UNHEX('7a264ccb7a0144a4f8e475f7ca041b42')), -- postmaster
(10, UNHEX('16a595f8386407458aaf432ceea797a8')), -- angel
(10, UNHEX('c4ca4238a0b923820dcc509a6f75849b')), -- admin
(10, UNHEX('6512bd43d9caa6e02c990b0a82652dca')), -- support
(10, UNHEX('c20ad4d76fe97759aa27a0c99bff6710')), -- sales
(7,  UNHEX('e2c865db4162bed963bfaa9ef6ac18f0')), -- info@*
(7,  UNHEX('a87ff679a2f3e71d9181a67b7542122c')), -- webmaster@*
(10, UNHEX('e4da3b7fbbce2345d7772b0674a318d5')), -- no-reply
(10, UNHEX('1679091c5a880faf6fb5e6087eb1b2dc')); -- contact


-- 📥 Whitelist / Blacklist per correu entrant
-- Relació: rid = id de l'usuari receptor (taula `users`)
--           sid = id del remitent (taula `mailaddr`)
--           wb  = 'W' (whitelist) o 'B' (blacklist)

INSERT INTO wblist (rid, sid, wb)
VALUES
(1,  1, 'W'), -- El receptor id=1 (Catchall global: @.) accepta correu del remitent id=1 (baldufa@melindro.org)
(2,  3, 'W'), -- El receptor id=2 (Catchall: @example.com) accepta correu del remitent id=3 (@google.com)
(3,  1, 'W'), -- El receptor id=3 (Domini: @melindro.org) accepta correu del remitent id=1 (baldufa@melindro.org)
(4,  3, 'B'), -- El receptor id=4 (Domini: @example.org) bloqueja correu del remitent id=3 (@google.com)
(5,  1, 'W'), -- El receptor id=5 (Domini: @pepito.net) accepta correu del remitent id=1 (baldufa@melindro.org)
(6,  3, 'W'), -- El receptor id=6 (postmaster@melindro.org) accepta correu del remitent id=3 (@google.com)
(7,  3, 'B'), -- El receptor id=7 (angel@melindro.org) bloqueja correu del remitent id=3 (@google.com)
(8,  3, 'W'), -- El receptor id=8 (admin@example.com) accepta correu del remitent id=3 (@google.com)
(9,  3, 'W'), -- El receptor id=9 (support@example.org) accepta correu del remitent id=3 (@google.com)
(10, 3, 'B'), -- El receptor id=10 (sales@pepito.net) bloqueja correu del remitent id=3 (@google.com)
(11, 3, 'W'), -- El receptor id=11 (info@.) accepta correu del remitent id=3 (@google.com)
(12, 3, 'W'), -- El receptor id=12 (webmaster@.) accepta correu del remitent id=3 (@google.com)
(13, 3, 'B'), -- El receptor id=13 (no-reply@example.com) bloqueja correu del remitent id=3 (@google.com)
(14, 3, 'W'); -- El receptor id=14 (contact@example.org) accepta correu del remitent id=3 (@google.com)

-- 📤 Whitelist per correu sortint
-- Relació: rid = id del receptor (taula `mailaddr`)
--           sid = id del remitent (taula `users`)
--           wb  = 'W' (whitelist) o 'B' (blacklist)

INSERT INTO outbound_wblist (rid, sid, wb)
VALUES
(1,  1, 'W'),  -- El remitent id=1 (Catchall global: @.) pot enviar correu al receptor id=1 (baldufa@melindro.org)
(3,  2, 'W'),  -- El remitent id=2 (Catchall: @example.com) pot enviar correu al receptor id=3 (@google.com)
(1,  3, 'B'),  -- El remitent id=3 (Domini: @melindro.org) té prohibit enviar correu al receptor id=1 (baldufa@melindro.org)
(4,  4, 'W'),  -- El remitent id=4 (Domini: @example.org) pot enviar correu al receptor id=4 (@badexample.com)
(1,  5, 'W'),  -- El remitent id=5 (Domini: @pepito.net) pot enviar correu al receptor id=1 (baldufa@melindro.org)
(1,  6, 'B'),  -- El remitent id=6 (postmaster@melindro.org) té prohibit enviar correu al receptor id=1 (baldufa@melindro.org)
(1,  7, 'W'),  -- El remitent id=7 (angel@melindro.org) pot enviar correu al receptor id=1 (baldufa@melindro.org)
(1,  8, 'W');  -- El remitent id=8 (admin@example.com) pot enviar correu al receptor id=1 (baldufa@melindro.org)



TEST missatges

-- Crear remitent si no existeix
INSERT INTO maddr (email, domain)
VALUES ('spammer@example.com', 'example.com');
-- Afegim el remitent a mailaddr si no existeix
INSERT INTO mailaddr (email)
VALUES ('spammer@example.com')
ON DUPLICATE KEY UPDATE id = id;

-- Recuperem el seu id
SELECT id FROM mailaddr WHERE email = 'spammer@example.com';
-- Recuperar el seu ID
SELECT id FROM maddr WHERE email='spammer@example.com';

suposem que retorna 15

INSERT INTO msgs (
    mail_id, secret_id, am_id, sid, time_num, time_iso,
    content, quar_type, subject, from_addr, size, policy, host
)
VALUES (
    UNHEX('ABCDEF0123456789ABCDEF0123456789'), -- mail_id 16 bytes
    UNHEX('0123456789ABCDEF0123456789ABCDEF'), -- secret_id 16 bytes, 
    15, 15,
    UNIX_TIMESTAMP(),
    DATE_FORMAT(NOW(), '%y%m%d%H%i%S+0200'),
    'S', 'S',
    'Oferta exclusiva!!!', 'spammer@example.com', 20480, 'default',
    'mail.melindro.org'
);

--  consulta top 10 senders 24H
-- SELECT sender.email AS mail, COUNT(*) AS total
-- FROM msgs
-- JOIN msgrcpt ON msgs.mail_id = msgrcpt.mail_id
-- JOIN maddr AS sender ON msgs.sid = sender.id
-- JOIN maddr AS recip ON msgrcpt.rid = recip.id
-- WHERE msgs.time_num > 1758282694
-- GROUP BY sender.email
-- ORDER BY total DESC
-- LIMIT 10

-- SELECT sender.email AS mail, COUNT(*) AS total
-- FROM msgs
-- JOIN maddr AS sender ON msgs.sid = sender.id
-- WHERE msgs.time_num > 1758282694
-- GROUP BY sender.email
-- ORDER BY total DESC
-- LIMIT 10;
SELECT mail, COUNT(*) AS total FROM (
        SELECT
                msgs.subject,
                msgs.time_iso,
                msgs.size,
                sender.email AS mail
FROM msgs
RIGHT JOIN msgrcpt ON msgs.mail_id = msgrcpt.mail_id
RIGHT JOIN maddr AS sender ON msgs.sid = sender.id
RIGHT JOIN maddr AS recip ON msgrcpt.rid = recip.id
WHERE msgs.time_num > 1758282694 
AND recip.domain IN ('org.melindro', 'mobi.melindro', 'org.aplus', 'uk.melindro', 'gv.melindro')
      AND (msgs.quar_type NOT IN ('S', 'V', 'B', 'H', 'Q') OR msgs.quar_type IS NULL)
GROUP BY msgs.subject, msgs.time_iso, msgs.size, sender.email) AS grouped_mails
GROUP BY mail
ORDER BY total DESC
LIMIT 10


-- consulta top 10 recipients  24H
-- SELECT recip.email AS mail, COUNT(*) AS total
-- FROM msgs
-- JOIN msgrcpt ON msgs.mail_id = msgrcpt.mail_id
-- JOIN maddr AS sender ON msgs.sid = sender.id
-- JOIN maddr AS recip ON msgrcpt.rid = recip.id
-- WHERE msgs.time_num > 1758282694
-- GROUP BY recip.email
-- ORDER BY total DESC
-- LIMIT 10

-- SELECT recip.email AS mail, COUNT(*) AS total
-- FROM msgs
-- JOIN msgrcpt ON msgs.mail_id = msgrcpt.mail_id
-- JOIN maddr AS recip ON msgrcpt.rid = recip.id
-- WHERE msgs.time_num > 1758282694
-- GROUP BY recip.email
-- ORDER BY total DESC
-- LIMIT 10;

SELECT mail, COUNT(*) AS total FROM ( 
        SELECT
                msgs.subject,
                msgs.time_iso,
                msgs.size,
                recip.email AS mail
FROM msgs
LEFT JOIN msgrcpt ON msgs.mail_id = msgrcpt.mail_id
LEFT JOIN maddr AS sender ON msgs.sid = sender.id
LEFT JOIN maddr AS recip ON msgrcpt.rid = recip.id
WHERE msgs.time_num > 1758282694 
AND recip.domain IN ('org.melindro', 'mobi.melindro', 'org.aplus', 'uk.melindro', 'gv.melindro')
      AND (msgs.quar_type NOT IN ('S', 'V', 'B', 'H', 'Q') OR msgs.quar_type IS NULL)
GROUP BY msgs.subject, msgs.time_iso, msgs.size, recip.email) AS grouped_mails
GROUP BY mail
ORDER BY total DESC
LIMIT 10


-- consulta count received

-- consulta count sent 

-- detall sent amb el receptor


-- mysql received
SELECT COUNT(*) AS total
FROM (
    SELECT
        msgs.subject,
        msgs.time_iso,
        msgs.size,
        msgs.quar_type,
        sender.email AS sender_email
    FROM msgs
    LEFT JOIN msgrcpt ON msgrcpt.mail_id = msgs.mail_id
    LEFT JOIN maddr AS sender ON sender.id = msgs.sid
    LEFT JOIN maddr AS recip ON msgrcpt.rid = recip.id
    WHERE recip.domain IN ('org.melindro', 'mobi.melindro', 'org.aplus', 'uk.melindro', 'gv.melindro')
      AND (msgs.quar_type NOT IN ('S', 'V', 'B', 'H', 'Q') OR msgs.quar_type IS NULL)
    GROUP BY msgs.subject, msgs.time_iso, msgs.size, msgs.quar_type, sender.email
) AS grouped_mails


SELECT
    msgs.subject,
    msgs.time_iso,
    msgs.size,
    msgs.quar_type,
    sender.email AS sender_email,
    GROUP_CONCAT(DISTINCT recip.email SEPARATOR ',') AS recip_emails,
    GROUP_CONCAT(DISTINCT msgs.mail_id SEPARATOR ',') AS mail_ids,
    GROUP_CONCAT(DISTINCT msgs.secret_id SEPARATOR ',') AS secret_ids,
    GROUP_CONCAT(DISTINCT CONCAT(msgs.mail_id, '+', msgs.secret_id) SEPARATOR ',') AS record_tokens
FROM msgs
LEFT JOIN msgrcpt ON msgrcpt.mail_id = msgs.mail_id
LEFT JOIN maddr AS sender ON sender.id = msgs.sid
LEFT JOIN maddr AS recip ON msgrcpt.rid = recip.id
WHERE recip.domain IN ('org.melindro', 'mobi.melindro', 'org.aplus', 'uk.melindro', 'gv.melindro')
  AND (msgs.quar_type NOT IN ('S', 'V', 'B', 'H', 'Q') OR msgs.quar_type IS NULL)
GROUP BY msgs.subject, msgs.time_iso, msgs.size, msgs.quar_type, sender.email
ORDER BY msgs.time_iso DESC

-- mysql quarantine
SELECT COUNT(*) AS cnt FROM (
      SELECT
          msgs.subject, msgs.time_iso,
          msgs.content, msgs.size, msgs.spam_level, msgs.quar_type
      FROM msgs
      LEFT JOIN msgrcpt ON msgs.mail_id = msgrcpt.mail_id
      LEFT JOIN maddr AS sender ON sender.id = msgs.sid
      LEFT JOIN maddr AS recip ON msgrcpt.rid = recip.id
WHERE recip.domain IN ('org.melindro', 'mobi.melindro', 'org.aplus', 'uk.melindro', 'gv.melindro')
  AND msgs.quar_type IN ('S', 'V', 'B', 'H', 'Q') 
GROUP BY msgs.subject, msgs.time_iso, msgs.size) AS grouped_mails


SELECT
    msgs.subject,
    msgs.time_iso,
    msgs.size,
    msgs.quar_type,
    sender.email AS sender_email,
    GROUP_CONCAT(DISTINCT recip.email SEPARATOR ',') AS recip_emails,
    GROUP_CONCAT(DISTINCT msgs.mail_id SEPARATOR ',') AS mail_ids,
    GROUP_CONCAT(DISTINCT msgs.secret_id SEPARATOR ',') AS secret_ids,
    GROUP_CONCAT(DISTINCT CONCAT(msgs.mail_id, '+', msgs.secret_id) SEPARATOR ',') AS record_tokens
FROM msgs
LEFT JOIN msgrcpt ON msgrcpt.mail_id = msgs.mail_id
LEFT JOIN maddr AS sender ON sender.id = msgs.sid
LEFT JOIN maddr AS recip ON msgrcpt.rid = recip.id
WHERE recip.domain IN ('org.melindro', 'mobi.melindro', 'org.aplus', 'uk.melindro', 'gv.melindro')
  AND msgs.quar_type IN ('S', 'V', 'B', 'H', 'Q')
GROUP BY msgs.subject, msgs.time_iso, msgs.size, msgs.quar_type, sender.email
ORDER BY msgs.time_iso DESC;


-- consulta SQL que pots executar directament a Adminer per comptar els 
-- correus en quarantena agrupats per tipus (quar_type), amb agrupació per correus únics:
SELECT grouped_mails.quar_type AS type, COUNT(*) AS total
FROM (
    SELECT msgs.subject, msgs.time_iso, msgs.size, msgs.quar_type
    FROM msgs
    LEFT JOIN msgrcpt ON msgrcpt.mail_id = msgs.mail_id
    LEFT JOIN maddr AS sender ON sender.id = msgs.sid
    LEFT JOIN maddr AS recip ON msgrcpt.rid = recip.id
    WHERE recip.domain IN ('org.melindro', 'mobi.melindro', 'org.aplus', 'uk.melindro', 'gv.melindro') 
      AND msgs.quar_type IN ('S', 'V', 'B', 'H', 'Q')
    GROUP BY msgs.subject, msgs.time_iso, msgs.size, msgs.quar_type
) AS grouped_mails
GROUP BY grouped_mails.quar_type
ORDER BY total DESC
-- ______________
-- |type	|total|
-- |Q     |3    |

