# Author: Zhang Huangbin <zhb@iredmail.org>

import os

import web
from jinja2 import Environment, FileSystemLoader

# Directory to be used as the Python egg cache directory.
# Note that the directory specified must exist and be writable by the
# user that the daemon process run as.
os.environ["PYTHON_EGG_CACHE"] = "/tmp/.iredadmin-eggs"
os.environ["LC_ALL"] = "C"

# Absolute path to this file.
rootdir = os.path.abspath(os.path.dirname(__file__))
templates_rootdir = os.path.abspath(os.path.join(rootdir, "..", "templates"))

import settings
from . import iredutils
from . import iredpwd
from . import jinja_filters
from . import ireddate
from . import hooks

# Set debug mode.
web.config.debug = settings.DEBUG

# Set session parameters.
web.config.session_parameters["cookie_name"] = "iRedAdmin-%s" % settings.backend.upper()
web.config.session_parameters["cookie_domain"] = None
web.config.session_parameters["ignore_expiry"] = True
web.config.session_parameters["ignore_change_ip"] = settings.SESSION_IGNORE_CHANGE_IP
web.config.session_parameters["timeout"] = settings.SESSION_TIMEOUT
web.config.session_parameters["httponly"] = True
web.config.session_parameters["samesite"] = "Strict"
# web.config.session_parameters['secure'] = True

# Initialize session object.
__sql_dbn = "mysql"
if settings.backend == "pgsql":
    __sql_dbn = "postgres"

conn_iredadmin = iredutils.get_db_conn(db_name="iredadmin", sql_dbn=__sql_dbn)
web.conn_iredadmin = conn_iredadmin

# URL handlers.
# Import backend related urls.
urls_backend = []
# ************* @MEU
# if settings.backend == "ldap":
#     from controllers.ldap.urls import urls as urls_backend
# elif settings.backend in ["mysql", "pgsql"]:
#     from controllers.sql.urls import urls as urls_backend
# urls = urls_backend 
if settings.backend in ["ldap", "mysql", "pgsql"]:
    from controllers.m_crud.urls import urls as urls_backend

urls = urls_backend

from controllers.m_system.urls import urls as urls_system
urls += urls_system

if settings.ENABLE_RESTFUL_API:
    from api.urls import urls as urls_api 
    urls += urls_api

# Import amavisd related urls.
if settings.amavisd_enable_quarantine \
    or settings.amavisd_enable_logging \
    or settings.amavisd_enable_policy_lookup:
    from controllers.m_amavisd.urls import urls as urls_amavisd
    urls += urls_amavisd

from controllers.m_iredapd.urls import urls as urls_iredapd
urls += urls_iredapd

from controllers.m_maillist.urls import urls as urls_ml
urls += urls_ml

from controllers.m_fail2ban.urls import urls as urls_f2b
urls += urls_f2b

# iRedAdmin.
# from controllers.panel.urls import urls as urls_panel
# urls += urls_panel
# ************* END @MEU


# Initialize application object.
app = web.application(urls)

session_initializer = {
    "webmaster": settings.webmaster,
    "username": None,
    "logged": False,
    # Admin
    "is_global_admin": False,
    "is_user_admin": False, # @MEU
    "is_mail_admin": False,  # @MEU
    "is_mail_user": False,  # @MEU
    "failed_times": 0,  # Integer.
    "lang": settings.default_language,
    # UI skin can be switched per-session without restarting iredadmin.
    "skin": settings.SKIN,
    # Show used quota.
    "show_used_quota": settings.SHOW_USED_QUOTA,
    # Amavisd related features.
    "amavisd_enable_quarantine": settings.amavisd_enable_quarantine,  # @MEU
    "amavisd_enable_logging": settings.amavisd_enable_logging, # @MEU
    "amavisd_enable_policy_lookup": settings.amavisd_enable_policy_lookup, # @MEU
    # iRedAPD related features.
    "enable_iredapd": settings.iredapd_enabled,  # @MEU
}

session = web.session.Session(
    app=app,
    store=web.session.DBStore(conn_iredadmin, "sessions"),
    initializer=session_initializer,
)

web.config._session = session


# Generate CSRF token and store it in session.
def csrf_token():
    if "csrf_token" not in session:
        session["csrf_token"] = iredutils.generate_random_strings(32)

    return session["csrf_token"]

# ************* @MEU
def get_pending_own():
    from libs.m_system.domain_ownership import DomainOwnershipManager
    return DomainOwnershipManager().count_pending_ownership_verifications()
def get_admin_count():
    from libs.m_crudlib.admin import Admin
    return Admin().count_admins()

def _list_available_skins():
    skins = []
    try:
        for name in os.listdir(templates_rootdir):
            p = os.path.join(templates_rootdir, name)
            if os.path.isdir(p) and os.path.isfile(os.path.join(p, "layout.html")):
                skins.append(str(name))
    except Exception:
        skins = []

    if not skins:
        return [settings.SKIN]

    skins = [s for s in sorted(set(skins)) if s != "default"]
    if settings.SKIN in skins:
        skins.remove(settings.SKIN)
        skins.insert(0, settings.SKIN)

    return skins

AVAILABLE_SKINS = tuple(_list_available_skins())

def normalize_skin_name(skin):
    _skin = str(skin or "").strip().lower()
    if _skin in AVAILABLE_SKINS:
        return _skin

    if settings.SKIN in AVAILABLE_SKINS:
        return settings.SKIN

    return AVAILABLE_SKINS[0]

def get_active_skin():
    _skin = None
    try:
        _skin = session.get("skin")
    except Exception:
        _skin = None

    active = normalize_skin_name(_skin)

    # NOTE: Keep session value normalized to avoid invalid skin names.
    try:
        if session.get("skin") != active:
            session["skin"] = active
    except Exception:
        pass

    return active

# ************* END @MEU

jinja_env_vars = {
    # Set global variables for Jinja2 template
    "_": iredutils.ired_gettext,  # Override _() which provided by Jinja2.
    "ctx": web.ctx,  # Used to get 'homepath'.
    "session": web.config._session,
    "backend": settings.backend,
    "csrf_token": csrf_token,
    #--------- count admins
    "admin_count": get_admin_count, # @MEU
    #--------- END count admins
    #--------- ownership_verification
    "pending_own": get_pending_own, # @MEU
    "require_domain_ownership_verification": settings.REQUIRE_DOMAIN_OWNERSHIP_VERIFICATION, # @MEU
    #--------- END ownership_verification
    "page_size_limit": settings.PAGE_SIZE_LIMIT,
    "url_support": settings.URL_SUPPORT,
    # newsletter (mlmmj mailing list)
    "newsletter_base_url": settings.NEWSLETTER_BASE_URL,
    # Brand logo, name, description
    "brand_logo": settings.BRAND_LOGO,
    "brand_name": settings.BRAND_NAME,
    "brand_desc": settings.BRAND_DESC,
    "brand_favicon": settings.BRAND_FAVICON,
    # API docs menu flag. # @MEU
    "enable_api": bool(getattr(settings, "ENABLE_RESTFUL_API", False)), # @MEU
}

from libs.m_system import jinja_filters as m_jinja_filters  # @MEU

jinja_env_filters = {
    "file_size_format": jinja_filters.file_size_format,
    "cut_string": jinja_filters.cut_string,
    "convert_to_percentage": jinja_filters.convert_to_percentage,
    "bytes2human": m_jinja_filters.bytes2human, # @MEU
    "human2bytes": m_jinja_filters.human2bytes, # @MEU
    "regex_search": m_jinja_filters.regex_search, # @MEU
    "urldecode": m_jinja_filters.urldecode, # @MEU
    "errors_to_html": m_jinja_filters.errors_to_html, # @MEU
    "epoch_seconds_to_gmt": iredutils.epoch_seconds_to_gmt,
    "epoch_days_to_date": iredutils.epoch_days_to_date,
    "set_datetime_format": iredutils.set_datetime_format,
    "generate_random_password": iredpwd.generate_random_password,
    "utc_to_timezone": ireddate.utc_to_timezone,
}

# Define template renders.
def render_template(template_name, **kwargs):
    active_skin = get_active_skin()
    selected_template_dir = os.path.join(templates_rootdir, active_skin)
    default_template_dir = os.path.join(templates_rootdir, settings.SKIN)

    loader_dirs = [selected_template_dir]
    if default_template_dir not in loader_dirs:
        loader_dirs.append(default_template_dir)

    jinja_env = Environment(
        loader=FileSystemLoader(loader_dirs),
        extensions=["jinja2.ext.do"],
    )

    jinja_globals = dict(jinja_env_vars)
    jinja_globals.update({
        "skin": active_skin,
        "active_skin": active_skin,
        "available_skins": AVAILABLE_SKINS,
    })
    jinja_env.globals.update(jinja_globals)
    jinja_env.filters.update(jinja_env_filters)

    web.header("Content-Type", "text/html")
    return jinja_env.get_template(template_name).render(kwargs)


class SessionExpired(web.HTTPError):
    def __init__(self, message):
        try:
            # Expire the cookie. Fixed in webpy master branch on Sep 21, 2020.
            cookie_name = web.config.session_parameters['cookie_name']
            web.setcookie(cookie_name, session.session_id, expires=-1)
            session.kill()
        except:
            pass

        message = web.seeother("/login?msg=SESSION_EXPIRED")
        web.HTTPError.__init__(self, "303 See Other", {}, data=message)


# Logger. Logging into SQL database.
def log_into_sql(msg, admin="", domain="", username="", event="", loglevel="info"):
    try:
        if not admin:
            admin = session.get("username")

        msg = str(msg)

        # Prepend '[API]' in log message
        try:
            if web.ctx.fullpath.startswith("/api/"):
                msg = "[API] " + msg
        except:
            pass

        conn_iredadmin.insert(
            "log",
            admin=str(admin),
            domain=str(domain),
            username=str(username),
            loglevel=str(loglevel),
            event=str(event),
            msg=msg,
            ip=str(session.ip),
            timestamp=iredutils.get_gmttime(),
        )
    except:
        pass

    return None


# Load hooks
app.add_processor(web.loadhook(hooks.hook_set_language))

if settings.DEBUG:
    app.internalerror = web.debugerror
elif settings.MAIL_ERROR_TO_WEBMASTER: # Mail 500 error to webmaster.
    app.internalerror = web.emailerrors(settings.webmaster, web.webapi._InternalError)

# Store objects in 'web' module.
web.render = render_template
web.session.SessionExpired = SessionExpired
web.get_available_skins = lambda: AVAILABLE_SKINS
web.normalize_skin_name = normalize_skin_name
