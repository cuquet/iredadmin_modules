# libs/m_system/jinja_filters.py

# referències a => https://code.activestate.com/recipes/578019-bytes-to-human-human-to-bytes-converter/
# wikipedia => http://goo.gl/kTQMs
SYMBOLS = {
#    'customary'     : ('B', 'K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y'),
#    'customary_ext' : ('byte', 'kilo', 'mega', 'giga', 'tera', 'peta', 'exa',
#                       'zetta', 'iotta'),
    'customary'     : ('B', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'),
    'customary_ext' : ('Byte', 'Kilobyte', 'Megabyte', 'Gigabyte', 'Terabyte', 'Petabyte', 'Exabyte',
                       'Zettabyte', 'Iottabyte'),
    'iec'           : ('Bi', 'Ki', 'Mi', 'Gi', 'Ti', 'Pi', 'Ei', 'Zi', 'Yi'),
    'iec_ext'       : ('byte', 'kibi', 'mebi', 'gibi', 'tebi', 'pebi', 'exbi',
                       'zebi', 'yobi'),
}

def bytes2human(n, format='%(value).1f %(symbol)s', symbols='customary'):
    """
        Converteix n bytes en una cadena llegible per humans segons el format.  
        Els símbols poden ser «customary», «customary_ext», «iec» o «iec_ext».,

            >>> bytes2human(0)
            '0.0 B'
            >>> bytes2human(0.9)
            '0.0 B'
            >>> bytes2human(1)
            '1.0 B'
            >>> bytes2human(1.9)
            '1.0 B'
            >>> bytes2human(1024)
            '1.0 K'
            >>> bytes2human(1048576)
            '1.0 M'
            >>> bytes2human(1099511627776127398123789121)
            '909.5 Y'

            >>> bytes2human(9856, symbols="customary")
            '9.6 K'
            >>> bytes2human(9856, symbols="customary_ext")
            '9.6 kilo'
            >>> bytes2human(9856, symbols="iec")
            '9.6 Ki'
            >>> bytes2human(9856, symbols="iec_ext")
            '9.6 kibi'

            >>> bytes2human(10000, "%(value).1f %(symbol)s/sec")
            '9.8 K/sec'

            >>> # precision can be adjusted by playing with %f operator
            >>> bytes2human(10000, format="%(value).5f %(symbol)s")
            '9.76562 K'
    """
    n = int(n)
    if n < 0:
        return "0"
    symbols = SYMBOLS[symbols]
    prefix = {}
    for i, s in enumerate(symbols[1:]):
        prefix[s] = 1 << (i+1)*10
    for symbol in reversed(symbols[1:]):
        if n >= prefix[symbol]:
            value = float(n) / prefix[symbol]
            return format % locals()
    return format % dict(symbol=symbols[0], value=n)

def human2bytes(s):
    """
        Intenta endevinar el format de la cadena segons el conjunt de símbols per defecte  
        i retorna els bytes corresponents com un enter.  
        Si no pot reconèixer el format, es genera una excepció ValueError.

        >>> human2bytes('0 B')
        0
        >>> human2bytes('1 K')
        1024
        >>> human2bytes('1 M')
        1048576
        >>> human2bytes('1 Gi')
        1073741824
        >>> human2bytes('1 tera')
        1099511627776

        >>> human2bytes('0.5kilo')
        512
        >>> human2bytes('0.1  byte')
        0
        >>> human2bytes('1 k')  # k is an alias for K
        1024
        >>> human2bytes('12 foo')
        Traceback (most recent call last):
            ...
        ValueError: can't interpret '12 foo'
    """
    init = s
    num = ""
    while s and s[0:1].isdigit() or s[0:1] == '.':
        num += s[0]
        s = s[1:]
    num = float(num)
    letter = s.strip()
    for name, sset in SYMBOLS.items():
        if letter in sset:
            break
    else:
        if letter == 'kb':
            # treat 'k' as an alias for 'K' as per: http://goo.gl/kTQMs
            sset = SYMBOLS['customary']
            letter = letter.upper()
        else:
            return ValueError("human2bytes: can't interpret %r" % init)
    prefix = {sset[0]:1}
    for i, s in enumerate(sset[1:]):
        prefix[s] = 1 << (i+1)*10
    return int(num * prefix[letter])

import re

def regex_search(value, pattern):
    """
        Cerca si un patró d'expressió regular (regex) apareix dins d'una cadena de text.

        Aquesta funció és útil en plantilles Jinja2 per detectar si un camp conté
        una paraula clau, un test de spam, o qualsevol patró específic.

        Exemple d'ús en Jinja2:
            {% if mail.headers["X-Spam-Status"] |regex_search("SPF_FAIL") %}
                <div class="alert alert--warning">SPF ha fallat.</div>
            {% endif %}

        Parameters:
            value (str): Cadena de text on es fa la cerca.
            pattern (str): Patró regex a cercar.

        Returns:
            bool: True si hi ha coincidència, False si no.
    """
    return re.search(pattern, value or '') is not None

import urllib.parse

def urldecode(value):
    """
        # Filtre per decodificar URL
    """
    if not value:
        return ""
    return urllib.parse.unquote(value)

def errors_to_html(value):
    """
        Filtre per convertir errors ("a: b; c: d") → HTML llegible
    """
    if not value:
        return ""
    value = urllib.parse.unquote(value)
    parts = [p.strip() for p in value.split(";") if p.strip()]
    return "<br>".join(parts)


"""
Codis més comuns de `strftime`

•  %Y → any complet (2025)
•  %m → mes numèric (09)
•  %B → nom del mes (September)
•  %d → dia del mes (09)
•  %H → hora (00–23)
•  %I → hora (01–12)
•  %M → minuts
•  %S → segons
•  %A → nom del dia (Tuesday)
•  %p → AM/PM

epoch_seconds_to_gmt(1757446900, "%Y-%m-%d %H:%M:%S")
# → '2025-09-09 07:41:40'
epoch_seconds_to_gmt(1757446900, "%d/%m/%Y %H:%M")
# → '09/09/2025 07:41'
epoch_seconds_to_gmt(1757446900, "%H:%M:%S")
# → '07:41:40'
epoch_seconds_to_gmt(1757446900, "%I:%M %p")
# → '07:41 AM'   (format 12 hores amb AM/PM)
epoch_seconds_to_gmt(1757446900, "%A, %d %B %Y %H:%M:%S")
# → 'Tuesday, 09 September 2025 07:41:40'
epoch_seconds_to_gmt(1757446900, "%d de %B de %Y, %H:%M")
# → '09 de September de 2025, 07:41'
"""