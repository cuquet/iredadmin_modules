# libs/m_system/mixins/sql/sql_crud_mixin.py
import settings
from typing import Dict, Tuple, List, Union
from libs.iredutils import (
    is_email as _is_email,
    is_domain as _is_domain,
    is_auth_email as _is_auth_email,
    strip_mail_ext_address as _strip_mail_ext_address,
    is_valid_account_first_char as _is_valid_account_first_char,
    get_gmttime as _get_gmttime
)
from libs import iredpwd
if settings.backend in ["mysql", "pgsql"]:
    from libs.sqllib.general import (
        is_global_admin as _is_global_admin,
        is_domain_admin as _is_domain_admin,
        is_email_exists as _is_email_exists,
        is_domain_exists as _is_domain_exists,
        is_ml_exists as _is_ml_exists,
        is_active_user as _is_active_user,
        get_first_char_of_all_accounts as _get_first_char_of_all_accounts,
        filter_existing_emails as _filter_existing_emails, 
        filter_existing_domains as _filter_existing_domains
    )
    from libs.sqllib import sqlutils

from libs.m_system.mixins import SQLWhereBuilder
from libs.m_system.decorators import LibDecorators
from ..pagination_mixin import PaginationMixin

class SQLCRUDMixin(PaginationMixin):
    def _init_mixin(self):
        """
            Cridat des d'AdminBase després de tenir self.conn.
        """
        self.conn = getattr(self, "conn", None)

    #### Wrappers de funcions d'iredutils
    def is_email(self, value):
        return _is_email(value)

    def is_domain(self, value):
        return _is_domain(value)
    
    def is_auth_email(self,value):
        return _is_auth_email(value)
    
    def strip_mail_ext_address(self, value, delimiters=None):
        return _strip_mail_ext_address(value, delimiters)
    
    def is_valid_account_first_char(self, v: str) -> bool:
        return _is_valid_account_first_char(v)
    
    def get_gmttime(self):
        return _get_gmttime()

    #### END Wrappers de funcions d'iredutils

    #### Wrappers sqllib.general
    def is_global_admin(self, admin) -> bool:
        return _is_global_admin(admin=admin, conn=self.conn)

    def is_domain_admin(self, domain, admin=None) -> bool:
        return _is_domain_admin(domain=domain, admin=admin, conn=self.conn)

    def is_email_exists(self, mail) -> bool:
        return _is_email_exists(mail=mail, conn=self.conn)

    def is_domain_exists(self, domain) -> bool:
        return _is_domain_exists(domain, conn=self.conn)

    def is_ml_exists(self, mail) -> bool:
        return _is_ml_exists(mail, conn=self.conn)

    def is_active_user(self, mail) -> bool:
        return _is_active_user(mail, conn=self.conn)

    def get_first_char_of_all_accounts(self, domain, account_type):
        return _get_first_char_of_all_accounts(
            domain= domain,
            account_type = account_type,
            conn=self.conn
            )

    def filter_existing_emails(self, mails:List, account_type=None) -> Dict:
        return _filter_existing_emails(mails=mails, account_type=account_type, conn=self.conn)

    def filter_existing_domains(self, domains:List) -> Dict:
        return _filter_existing_domains(conn=self.conn, domains= domains)

    #### END Wrappers sqllib.general
    
    @staticmethod
    def logger_list_helper(mails: List, max_show: int= 3) -> List:
        '''
            Definim un límit de mails a mostrar
        '''
        num_mails = len(mails)
        if num_mails > max_show:
            display_mails = ', '.join(mails[:max_show]) + f" (and {num_mails - max_show} more)"
        else:
            display_mails = ', '.join(mails)
        
        return display_mails

    def get_accounts_paged_list(self, accounts: List, current_page: int = 0, size_limit: int = None):
        """
        Contracte alineat amb LDAP:
        - `current_page == 0` -> retorna la llista original (mode heretat, sense paginar).
        - `current_page > 0`  -> retorna dict amb `total`, `account_profiles`, `pages`.
        """
        current_page = self.normalize_current_page(current_page=current_page, default=0, min_page=0)
        if current_page == 0:
            return accounts

        if size_limit is None:
            size_limit = settings.PAGE_SIZE_LIMIT

        total = len(accounts)
        pages = self.get_total_pages(total=total, size_limit=size_limit)

        result = {
            'total': total,
            'account_profiles': [],
            'pages': pages,
        }

        if total == 0:
            return result

        if size_limit <= 0:
            result['account_profiles'] = accounts
            return result

        if current_page > pages:
            current_page = pages

        start = (current_page - 1) * size_limit
        end = start + size_limit
        result['account_profiles'] = accounts[start:end]
        return result

    def _resolve_account_target(self, account: str):
        """
            Retorna:
            (True, {"type": "...", "table": "...", "key_col": "...", "key_val": "..."})
            o bé (False, "ERROR_CODE")
            @TODO: si tenim “alias_domain” com a account resoluble, aquí podem inserir una branca (depèn de com el modelem: pot ser per domain + alias_domain).
        """
        if not account:
            return (False, "NO_SUCH_ACCOUNT")

        a = str(account).strip().lower()
        if not a:
            return (False, "NO_SUCH_ACCOUNT")

        # Email -> user/ml/alias
        if self.is_email(a):
            if self.is_email_exists(a):
                return (True, {"type": "user", "table": "mailbox", "key_col": "username", "key_val": a})
            if self.is_ml_exists(a):
                return (True, {"type": "ml", "table": "maillists", "key_col": "address", "key_val": a})
            return (True, {"type": "alias", "table": "alias", "key_col": "address", "key_val": a})

        # Domain o alias_domain
        if self.is_domain(a):
            if self.is_domain_exists(a):
                return (True, {"type": "domain", "table": "domain", "key_col": "domain", "key_val": a})

            qr = self.conn.select(
                "alias_domain",
                vars={"ad": a, "active": 1},
                what="target_domain",
                where="alias_domain=$ad AND active=$active",
                limit=1,
            )
            if qr:
                target = str(qr[0].target_domain).strip().lower()
                if self.is_domain_exists(target):
                    return (True, {
                        "type": "domain_alias",
                        "table": "domain",
                        "key_col": "domain",
                        "key_val": target,
                        "alias_domain": a,
                        "target_domain": target,
                    })
            return (False, "NO_SUCH_DOMAIN")

        # Admin (existència directa)
        qr = self.conn.select(
            "admin",
            vars={"u": a},
            what="username",
            where="username=$u",
            limit=1,
        )
        if qr:
            return (True, {"type": "admin", "table": "admin", "key_col": "username", "key_val": a})

        return (False, "INVALID_ACCOUNT")

    @LibDecorators.safe_sql_method
    def _get_profile(self, table: str, key_col: str, key_val: str, query_filter=None, attributes: str = "*"):
        """
            Getter genèric amb clau variable (username/address/domain).
            Aplica parsing de settings -> accountSetting.
        """
        builder = SQLWhereBuilder()
        builder.add_equals(key_col, key_val)
        sql_where, sql_vars = builder.build()
        if query_filter:
            sql_where = f"{sql_where} AND ({query_filter})"

        result = self.conn.select(
            table,
            vars=sql_vars,
            where=sql_where,
            what=attributes or "*",
            limit=1,
        )
        if not result:
            return (False, "NO_SUCH_ACCOUNT")

        profile = result[0]

        # només parseja settings si existeix
        settings_val = ""
        if hasattr(profile, "settings"):
            settings_val = str(getattr(profile, "settings", "") or "")

        profile["accountSetting"] = sqlutils.account_settings_string_to_dict(settings_val)
        profile["table"] = table
        return (True, {"table": table, "ldif": profile})

    @LibDecorators.safe_sql_method
    def get_account_settings(self, account:str):
        ok, target = self._resolve_account_target(account)
        if not ok:
            return (False, target)

        ok, data, *rest = self._get_profile(
            table=target["table"],
            key_col=target["key_col"],
            key_val=target["key_val"],
            attributes=f'{target["key_col"]},settings'
        )
        if not ok:
            return (False, data)

        profile = data["ldif"]
        return (True, profile.get("accountSetting", {}))

    @LibDecorators.safe_sql_method
    def update_account_settings(self, 
        account: str,
        account_type: str = None,
        exist_settings: dict = None,
        new_settings: dict = None,
        removed_settings: list = None,
        ):
        if not account:
            return (False, "NO_SUCH_ACCOUNT")

        a = str(account).strip().lower()
        if not a:
            return (False, "NO_SUCH_ACCOUNT")

        # Inferir target si no ve especificat (o encara que vingui, si vols validar-lo)
        ok, target = self._resolve_account_target(a)
        if not ok:
            return (False, target)

        if account_type and account_type != target["type"]:
            # Si vols ser permissiu: ignora account_type i usa target["type"]
            # Si vols ser estricte: error
            return (False, "ACCOUNT_TYPE_MISMATCH")

        # Carregar settings actuals
        if exist_settings is not None:
            current = dict(exist_settings)
        else:
            ok, current = self.get_account_settings(a)
            if not ok:
                return (False, current)

        # Merge (add/update)
        if new_settings:
            current.update(new_settings)

        # Remove
        if removed_settings:
            for k in removed_settings:
                current.pop(k, None)

        settings_string = sqlutils.account_settings_dict_to_string(current)

        self.conn.update(
            target["table"],
            vars={"v": target["key_val"]},
            where=f'{target["key_col"]}=$v',
            settings=settings_string,
        )

        return (True, "UPDATED")

    def profile_verify_password(self, mail: str, password: str, table: str = "mailbox") -> Tuple[bool, str]:
        if not self.is_email(mail):
            return (False, 'INVALID_MAIL')
        if not password:
            return (False, 'MISSING_PASSWORD')

        try:
            qr = self.conn.select(
                table,
                vars={'username': mail},
                what='password',
                where='username=$username',
                limit=1,
            )
        except Exception as e:
            return (False, repr(e))

        if not qr:
            return (False, 'NO_SUCH_ACCOUNT')

        pw_hash = str(qr[0].password)
        if iredpwd.verify_password_hash(pw_hash, password):
            return (True, )
        return (False, 'INVALID_CREDENTIALS')

    def profile_change_password(
            self,
            mail: str,
            old_pw: str,
            new_pw: str,
            require_cur_passwd: bool = True,
            table: str = "mailbox"
        ) -> Tuple[bool, str]:
        if not self.is_email(mail):
            return (False, 'INVALID_MAIL')
        if not new_pw:
            return (False, 'MISSING_PASSWORD')

        try:
            qr = self.conn.select(
                table,
                vars={'username': mail},
                what='password',
                where='username=$username',
                limit=1,
            )
        except Exception as e:
            return (False, repr(e))

        if not qr:
            return (False, 'NO_SUCH_ACCOUNT')

        if require_cur_passwd:
            pw_hash = str(qr[0].password)
            if not iredpwd.verify_password_hash(pw_hash, old_pw or ''):
                return (False, 'INCORRECT_OLDPW')

        new_hash = iredpwd.generate_password_hash(new_pw)
        updates = {
            'password': new_hash,
            'passwordlastchange': self.get_gmttime(),
        }
        if settings.STORE_PLAIN_PASSWORD_IN_ADDITIONAL_ATTR:
            updates[settings.STORE_PLAIN_PASSWORD_IN_ADDITIONAL_ATTR] = new_pw

        try:
            self.conn.update(
                table,
                vars={'username': mail},
                where='username=$username',
                **updates,
            )
        except Exception as e:
            return (False, repr(e))

        return (True, )

    @LibDecorators.safe_sql_method
    def enable_disable_accounts(self, values, action, account_type):
        if action not in ("enable", "disable"):
            return (False, "INVALID_ACTION")
        
        # {<account_type>: (<table>, <column>)}
        _maps = {
            "user": ("mailbox", "username"),
            "alias": ("alias", "address"),
            "ml": ("maillists", "address"),
            "domain": ("domain", "domain"),
            "admin": ("admin", "username"),
        }
        if account_type not in _maps:
            return (False, )
        (_table, _column) = _maps[account_type]
        
        values = [str(v).lower() for v in values if self.is_email(v)]
        
        new_status = 1 if action == "enable" else 0

        for mail in values:
            self.conn.update(
                _table,
                vars={"username": mail},
                where=f"{_column}=$username",
                active=new_status
            )
        return (True, f"{action}D".upper())
