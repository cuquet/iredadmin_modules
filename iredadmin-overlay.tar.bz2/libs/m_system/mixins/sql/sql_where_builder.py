# libs/m_system/mixins/sql/sql_where_builder.py
import re
import copy
from typing import Any, Dict, List, Tuple, Optional


class SQLWhereBuilder:
    """
        🧱 SQLWhereBuilder: utilitat per construir condicions SQL de forma modular i segura.

        Objectiu:
        - Acumular condicions SQL en forma de cadenes.
        - Associar valors a variables per passar-les com `vars` a `db.query()` o `db.select()`.
        - Generar la clàusula `WHERE` final amb els valors associats.

        Avantatges:
        - Evita interpolació directa de valors dins SQL.
        - Facilita la reutilització i testabilitat de la lògica condicional.
        - Permet afegir condicions de forma incremental i llegible.
        
        Funcionament:
        ```python
            builder = SQLWhereBuilder()
            builder.add_equals("status", "active")
            builder.add_in("role", ["admin", "editor"])
            builder.add_if("age >= $age", "age", user_age)
            builder.add_raw("deleted_at IS NULL")
            where_clause, vars = builder.build()
        ```
    """
    def __init__(self):
        """
            Inicialitza el constructor amb:
            - `conditions`: llista de condicions SQL com cadenes (ex: "email = $email").
            - `vars`: diccionari de valors associats a les variables SQL (ex: {'email': 'user@example.com'}).
        """
        self.conditions: List[str] = []
        self.vars: Dict[str, Any] = {}
        # comptador per generar claus úniques (base -> count)
        self._key_counts: Dict[str, int] = {}

    def _sanitize_base(self, s: str) -> str:
            # deixar només caràcters alfanumèrics i underscore
            return re.sub(r'\W+', '_', s)

    def _unique_key_for(self, raw: str) -> str:
        """
        Donat 'msgs.quar_type' o 'quar_type' -> retorna 'quar_type' o 'quar_type_2' si ja existeix.
        """
        base = raw.split('.')[-1]  # agafem la part final (important!)
        base = self._sanitize_base(base)
        cnt = self._key_counts.get(base, 0)
        if cnt == 0:
            self._key_counts[base] = 1
            return base
        else:
            # incrementem i retornem base_n
            self._key_counts[base] = cnt + 1
            return f"{base}_{cnt+1}"
    
    def add(self, condition: str, key: Optional[str] = None, value: Any = None):
        """
            Afegeix una condició SQL i, opcionalment, una variable associada.

            Arguments:
            - `condition`: cadena SQL amb placeholder (ex: "domain IN $domains").
            - `key`: nom de la variable (ex: 'domains').
            - `value`: valor associat a la variable (ex: ['example.com', 'test.org']).

            Notes:
            Afegeix una condició arbitrària; si proporciones 'key' i 'value', 
            la clau es normalitza i s'afegeix a self.vars.
            Si cal, també actualitza el placeholder dins condition.
        """
        if key is not None:
            # si l'usuari va passar "msgs.quar_type" com a key no passa res dolent: normalize
            new_key = self._unique_key_for(key)
            # substituïm qualsevol placeholder $key o ${key} per la nova clau
            # fem dues replacements en ordre segur (primer ${key}, després $key)
            condition = condition.replace(f"${{{key}}}", f"${{{new_key}}}")
            condition = condition.replace(f"${key}", f"${new_key}")
            self.vars[new_key] = value
        self.conditions.append(condition)

    def add_equals(self, field: str, value: Any, negate: bool = False):
        """
            ➕ Afegeix una condició d'igualtat: `field = $field`.

            Arguments:
            - `field`: nom del camp SQL.
            - `value`: valor que ha de coincidir.

            Exemple:
            >>> builder.add_equals("status", "active")
            Afegirà: "status = $status", {"status": "active"}
        """
        field_sql = field
        key = self._unique_key_for(field)
        op = "!=" if negate else "="
        condition = f"{field_sql} {op} ${key}"
        self.add(condition, key, value)

    def add_in(self, field: str, values: List[Any], negate: bool = False, tolerate_null: bool = False):
        """
            ➕ Afegeix una condició `IN`: `field IN $field`.

            Arguments:
            - `field`: nom del camp SQL.
            - `values`: llista de valors que han de coincidir.

            Exemple:
            >>> builder.add_in("domain", ["example.com", "test.org"])
            Afegirà: "domain IN $domain", {"domain": [...]}
        """
        field_sql = field
        key = self._unique_key_for(field)
        op = "NOT IN" if negate else "IN"
        base_condition = f"{field_sql} {op} ${key}"
        if tolerate_null:
            condition = f"({base_condition} OR {field_sql} IS NULL)"
        else:
            condition = base_condition

        self.add(condition, key, values)

    def add_if(self, 
            condition_or_field: str,
            key_or_value: Optional[Any] = None,
            value: Any = None,
            negate: bool = False):
        """
            ➕ Afegeix condició només si `value` no és `None`.

            Dual behaviour (compatible amb usos antics i amb nou estil):
            - Usuari antic: add_if("msgs.time_num > $timestamp", "timestamp", timestamp)
            - Nou estil: add_if("msgs.time_num", timestamp)  -> afegeix msgs.time_num = $time_num
            - Nou estil amb negació: add_if("msgs.quar_type", ['Q'], negate=True) -> msgs.quar_type != $quar_type
        """
        # si la primera string conté un placeholder '$', tractem com a condicion literal
        if '$' in condition_or_field:
            # si es va passar (key_or_value, value) interpretem com a (key, value)
            if key_or_value is not None and value is not None:
                key = key_or_value
                self.add(condition_or_field, key, value)
            elif key_or_value is not None and value is None:
                # inferim el nom del placeholder i l'hem passat com a valor
                m = re.search(r'\$([A-Za-z0-9_]+)', condition_or_field)
                if m:
                    ph = m.group(1)
                    self.add(condition_or_field, ph, key_or_value)
        else:
            # nou estil: primer param = nom del camp, key_or_value = valor
            if key_or_value is not None:
                self.add_equals(condition_or_field, key_or_value, negate=negate)

    def add_or(self, conditions: List[Tuple[str, Any]]):
        """
            ➕ Afegeix un bloc OR compost:
            Exemple:
                builder.add_or([
                    ("sender", "a@b.com"),
                    ("recipient", "a@b.com")
                ])

            Resultat:
                "(sender = $sender OR recipient = $recipient_2)"
        """
        parts = []
        for field, value in conditions:
            key = self._unique_key_for(field)
            parts.append(f"{field} = ${key}")
            self.vars[key] = value

        if parts:
            self.conditions.append("(" + " OR ".join(parts) + ")")

    def add_between(self, field: str, start: Any, end: Any):
        """
            ➕ Afegeix condició BETWEEN per rang de dates o números.

            Exemple:
                builder.add_between("init_time", 1700000000, 1700100000)
            
            Resultat:
                "(init_time BETWEEN $init_time_start AND $init_time_end)"
        """
        k1 = self._unique_key_for(f"{field}_start")
        k2 = self._unique_key_for(f"{field}_end")

        self.conditions.append(
            f"({field} BETWEEN ${k1} AND ${k2})"
        )

        self.vars[k1] = start
        self.vars[k2] = end

    def add_or_like(self, fields: list[str], value: str, case_insensitive: bool = True):
        """
        ➕ Afegeix una condició OR amb LIKE sobre múltiples camps.
        
        - Compatible amb MariaDB/MySQL.
        - Funciona amb strings que contenen punts, @, etc.
        
        Exemple:
            builder.add_or_like(
                ["sender", "recipient", "sender_domain", "rcpt_domain", "client_address"],
                "%192.%"
            )
        """
        parts = []
        for field in fields:
            key = self._unique_key_for(field)
            if case_insensitive:
                parts.append(f"LOWER({field}) LIKE ${key} ESCAPE '\\\\'")
            else:
                parts.append(f"{field} LIKE ${key} ESCAPE '\\\\'")
            self.vars[key] = value  # <-- no fem cap replace ni escape extra
        if parts:
            self.conditions.append("(" + " OR ".join(parts) + ")")

    def add_like(self, field: str, value: str, case_insensitive: bool = True):
        """
            ➕ LIKE / ILIKE (compatible MariaDB + PostgreSQL)
            
            PostgreSQL → ILIKE per cerca insensitive
            MariaDB   → LOWER(field) LIKE LOWER($value)
        """
        key = self._unique_key_for(field)

        if case_insensitive:
            # Compatible per ambdós motors
            condition = f"LOWER({field}) LIKE LOWER(${key})"
        else:
            condition = f"{field} LIKE ${key}"

        self.add(condition, key, value)

    def add_raw(self, condition: str):
        """
            ➕ Afegeix una condició literal sense variables.

            Arguments:
            - `condition`: cadena SQL literal.

            Exemple:
            >>> builder.add_raw("deleted_at IS NULL")
        """
        self.conditions.append(condition)

    def build(self) -> Tuple[str, Dict[str, Any]]:
        """
            Construeix la clàusula `WHERE` final.

            Retorn:
            - `where_clause`: cadena amb totes les condicions unides amb `AND`.
            - `vars`: diccionari amb totes les variables associades.

            Exemple:
            >>> builder = SQLWhereBuilder()
            >>> builder.add("email = $email", "email", "user@example.com")
            >>> builder.add("active = $active", "active", True)
            >>> builder.build()
            ("email = $email AND active = $active", {"email": "user@example.com", "active": True})
        """
        where_clause = " AND ".join(self.conditions)
        return where_clause, self.vars

    def clone(self) -> 'SQLWhereBuilder':
        """
        🐑 Retorna una còpia profunda del constructor actual.
        Útil per compartir condicions base (com el temps) i ramificar la cerca.
        """
        return copy.deepcopy(self)
