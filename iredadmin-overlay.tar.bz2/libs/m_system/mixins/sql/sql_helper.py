import settings

if settings.backend in ['mysql', 'pgsql']:
    from libs.m_crudlib import SQLWrap
    from libs.m_system.mixins import SQLCRUDMixin

    class SQLHelper(SQLWrap, SQLCRUDMixin):
        def __init__(self):
            super().__init__()
            if hasattr(self, "_init_mixin"):
                self._init_mixin()
else:
    # No SQLWrap disponible
    SQLHelper = None