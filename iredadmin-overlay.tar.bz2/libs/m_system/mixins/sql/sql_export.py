# libs/m_system/mixins/sql/sql_export.py
import csv
import io
import html
import re
from abc import ABC, abstractmethod
from typing import List, Callable, Iterable, Any, Dict

class SQLExporter(ABC):
    """
    Exportador genèric de taules.
    """
    content_type: str = 'application/octet-stream'
    file_extension: str = 'dat'

    def __init__(
        self,
        headers: List[str],
        row_mapper: Callable[[Dict[str, Any]], List[Any]],
        title: str ="Export"
        ):
        self._headers = headers
        self._row_mapper = row_mapper
        self._title = title

    @staticmethod
    def sanitize_filename(value: str, default: str = "export") -> str:
        """
        Converteix qualsevol valor en un filename segur.
        """
        if not value:
            return default
        value = str(value)
        return re.sub(r'[^A-Za-z0-9._-]', '_', value)

    def filename(self, base: str) -> str:
        return f"{self.sanitize_filename(base)}.{self.file_extension}"

    def headers(self) -> List[str]:
        return self._headers

    def apply_headers(self, web, base_filename: str):
        web.header('Content-Type', f'{self.content_type}; charset=utf-8')
        web.header(
            'Content-Disposition',
            f'attachment; filename="{self.filename(base_filename)}"'
        )

    def row_from_record(self, record: Dict[str, Any]) -> List[Any]:
        return self._row_mapper(record)

    @abstractmethod
    def export(self, records: Iterable[Dict[str, Any]]):
        raise NotImplementedError

class SQLExporterCSV(SQLExporter):
    content_type = 'text/csv'
    file_extension = 'csv'

    def export(self, records):
        output = io.StringIO()
        output.write('\ufeff')  # BOM UTF-8

        writer = csv.writer(output, quoting=csv.QUOTE_NONNUMERIC)
        writer.writerow(self.headers())

        for record in records:
            writer.writerow(self.row_from_record(record))

        return output.getvalue()

class SQLExporterHTML(SQLExporter):
    """
    Exportador HTML compatible amb Excel (.xls).
    """
    content_type = 'application/vnd.ms-excel'
    file_extension = 'xls'

    def apply_headers(self, web, base_filename: str):
        web.header('Content-Type', self.content_type)
        web.header(
            'Content-Disposition',
            f'attachment; filename="{self.filename(base_filename)}"'
        )

    def export(self, records: Iterable[Dict[str, Any]]) -> str:
        out = []

        out.append('<!DOCTYPE html>')
        out.append('<html>')
        out.append('<head>')
        out.append('<meta charset="utf-8">')
        out.append('<style>')
        out.append('table { border-collapse: collapse; }')
        out.append('th, td { border: 1px solid #333; padding: 4px 6px; }')
        out.append('th { background: #eee; font-weight: bold; }')
        out.append('</style>')
        out.append('</head>')
        out.append('<body>')

        out.append(f'<h3>{html.escape(self._title)}</h3>')
        out.append('<table>')

        # Header
        out.append('<thead><tr>')
        for h in self.headers():
            out.append(f'<th>{html.escape(h)}</th>')
        out.append('</tr></thead>')

        # Body
        out.append('<tbody>')
        for record in records:
            out.append('<tr>')
            for cell in self.row_from_record(record):
                value = '' if cell is None else str(cell)
                out.append(f'<td>{html.escape(value)}</td>')
            out.append('</tr>')
        out.append('</tbody>')

        out.append('</table>')
        out.append('</body></html>')

        return '\n'.join(out)
