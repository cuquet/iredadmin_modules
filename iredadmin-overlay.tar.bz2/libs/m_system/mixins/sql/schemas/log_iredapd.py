# libs/m_system/mixins/sql/schemas/log_iredapd.py
from libs.iredutils import epoch_seconds_to_gmt

from libs.m_system.mixins.sql.schemas.sql_export_schema import ExportSchema

GREYLISTING_EXPORT_SCHEMA = ExportSchema.from_fields_auto({
    'sender': ('Sender',),
    'sender_domain': ('Sender Domain',),
    'recipient': ('Recipient',),
    'rcpt_domain': ('Recipient Domain',),
    'client_address': ('Client IP',),
    'init_time': ('First Seen', lambda r: epoch_seconds_to_gmt(r.get('init_time')) if r.get('init_time') else ''),
    'block_expired': ('Wait Until', lambda r: epoch_seconds_to_gmt(r.get('block_expired')) if r.get('block_expired') else ''),
    'record_expired': ('Expire', lambda r: epoch_seconds_to_gmt(r.get('record_expired')) if r.get('record_expired') else ''),
    'blocked_count': ('Blocked Count', lambda r: r.get('blocked_count', 0)),
    'passed': ('Passed', lambda r: 'Yes' if r.get('passed') else 'No'),
})


SMTP_SESSIONS_EXPORT_SCHEMA = ExportSchema.from_fields_auto({
    'id': ('Session ID',),
    'sender': ('Sender',),
    'recipient': ('Recipient',),
    'action': ('Action',),
    'reason': ('Reason',),
    'time_num': ('Date', lambda r: epoch_seconds_to_gmt(r.get('time_num')) if r.get('time_num') else ''),
    'client_address': ('Client IP',),
    'client_name': ('Client Name',),
    'server_address': ('Server IP',),
    'server_port': ('Server Port',),
    'encryption_protocol': ('Encryption Protocol',),
})

