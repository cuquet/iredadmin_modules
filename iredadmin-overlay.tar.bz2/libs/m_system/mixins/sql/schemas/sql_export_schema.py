# libs/m_system/mixins/sql/schemas/sql_export_schema.py
from typing import Callable, Any, Dict, List, Optional, Union

class ExportColumn:
    """
        Defineix una columna d'export:
        - key: clau del record
        - label: capçalera (si None, usa key)
        - mapper: funció opcional per transformar el valor
    """
    def __init__(
        self,
        key: str,
        label: Optional[str] = None,
        mapper: Optional[Callable[[Dict[str, Any]], Any]] = None
        ):
        self.key = key
        self.label = label or key
        self.mapper = mapper

    def value(self, record: Dict[str, Any]) -> Any:
        if self.mapper:
            return self.mapper(record)
        return record.get(self.key, '')

class ExportSchema:
    """
        Conjunt ordenat de columnes per un export.
    """
    def __init__(self, columns: List[ExportColumn]):
        self.columns = columns

    @classmethod
    def from_fields_auto(
        cls,
        fields_dict: Dict[str, Union[tuple, list]]
        ) -> "ExportSchema":
        """
            Crea un ExportSchema a partir d'un dict:
            key -> (label,) o (label, mapper)

            Exemple:
            {
                "sender": ("Sender",),
                "init_time": ("First Seen", lambda r: epoch_seconds_to_gmt(r.get("init_time"))),
            }
        """
        columns = []

        for key, value in fields_dict.items():
            # Accepta tuples o llistes
            if not isinstance(value, (tuple, list)):
                raise TypeError(f"Value for '{key}' must be tuple or list, got {type(value).__name__}")

            if len(value) == 1:
                label, mapper = value[0], None
            elif len(value) == 2:
                label, mapper = value
            else:
                raise ValueError(f"Invalid tuple/list for '{key}': {value}, expected 1 or 2 elements")

            columns.append(ExportColumn(key=key, label=label, mapper=mapper))

        return cls(columns)

    @property
    def headers(self) -> List[str]:
        return [col.label for col in self.columns]

    def row(self, record: Dict[str, Any]) -> List[Any]:
        return [col.value(record) for col in self.columns]
