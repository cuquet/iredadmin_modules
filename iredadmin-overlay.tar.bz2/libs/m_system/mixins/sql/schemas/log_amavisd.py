# libs/m_system/mixins/sql/schemas/log_amavisd.py
from libs.iredutils import set_datetime_format
from libs.ireddate import utc_to_timezone

from libs.m_system.mixins.sql.schemas.sql_export_schema import ExportSchema

AMAVISD_LOG_EXPORT_SCHEMA = ExportSchema.from_fields_auto({
    'subject': ('Subject',),
    'sender_email': ('Sender',),
    'recip_emails': ('Recipients',),
    'size': ('Size', lambda r: r.get('size', 0)),
    'time_iso': ('Date', lambda r: utc_to_timezone(set_datetime_format(r.get('time_iso', '')))),
})

QUARANTINE_EXPORT_SCHEMA = ExportSchema.from_fields_auto({
    'subject': ('Subject',),
    'sender_email': ('Sender',),
    'recip_emails': ('Recipients',),
    'quar_type_readable': ('Quarantine Type',),
    'spam_level': ('Spam Level',),
    'size': ('Size', lambda r: r.get('size', 0)),
    'time_iso': ('Date', lambda r: utc_to_timezone(set_datetime_format(r.get('time_iso', '')))),
})