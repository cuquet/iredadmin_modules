# libs/m_system/mixins/sql/schemas/log_system.py
from libs.m_system.mixins.sql.schemas.sql_export_schema import ExportSchema

LOG_EXPORT_SCHEMA = ExportSchema.from_fields_auto({
    'id':('id',),
    'timestamp':('timestamp',),
    'admin':('admin',),
    'ip':('ip',),
    'domain':('domain',),
    'username':('username',),
    'event':('event',),
    'loglevel':('loglevel',),
    'blockemsgd_count':('msg',)
})
