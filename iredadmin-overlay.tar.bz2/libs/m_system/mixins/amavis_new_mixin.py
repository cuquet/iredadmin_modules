# NOTE: libs/m_system/mixins/amavis_new_mixin.py
import html
import re
import hashlib
from typing import List, Union

from libs.iredutils import (
    is_email as _is_email,
    is_domain as _is_domain,
    is_strict_ip as _is_strict_ip,
    is_ip_or_network as _is_ip_or_network,
    is_wildcard_ipv4 as _is_wildcard_ipv4,
    is_wildcard_addr as _is_wildcard_addr,
    is_valid_amavisd_address as _is_valid_amavisd_address,
    get_account_priority as _get_account_priority,
)

from libs.m_system.mixins.enums import _validate_enum, _validate_enum_flexible

class AmavisNewMixin:
    # NOTE: Wrappers de funcions d'iredutils
    @staticmethod
    def is_email(value):
        return _is_email(value)

    @staticmethod
    def is_domain(value):
        return _is_domain(value)

    @staticmethod
    def is_strict_ip(value):
        return _is_strict_ip(value)
    
    @staticmethod
    def is_ip_or_network(value):
        return _is_ip_or_network(value)
    
    @staticmethod
    def is_wildcard_ipv4(value):
        return _is_wildcard_ipv4(value)
    
    @staticmethod
    def is_wildcard_addr(value):
        return _is_wildcard_addr(value)
    
    @staticmethod
    def get_account_priority(value):
        return _get_account_priority(value)
    
    @staticmethod
    def is_valid_amavisd_address(value):
        return _is_valid_amavisd_address(value)

    # NOTE: Wrappers de m_mixins.__init__.py
    @staticmethod
    def validate_enum_flexible(value, enum_cls):
        return _validate_enum_flexible(value, enum_cls)
    
    @staticmethod
    def validate_enum(value, enum_cls):
        return _validate_enum(value, enum_cls)

    # NOTE: mètodes propis
    @staticmethod
    def safe_lower(value):
        """
            Sí, pots evitar `web.safestr(account).lower()` si no vols importar el mòdul web de web.py,
            tot i que has de tenir en compte què fa exactament safestr(). Aquesta funció normalment 
            s'utilitza per assegurar que una cadena és segura per mostrar-la en HTML (escapant caràcters especials)
            i per convertir objectes en cadenes si cal.
            ```python
                str(account).lower()
            ```
            🔒 Però compte: si el valor de account pot contenir caràcters que necessiten ser escapats 
            per HTML (com <, >, &, etc.), i vols mantenir la seguretat contra XSS, hauries d'utilitzar 
            una funció d'escapat com:
            ```python
                import html
                html.escape(str(account)).lower()
            ```
            web.safestr() pot tenir comportaments addicionals segons el tipus de value (per exemple, 
            si és None, pot retornar una cadena buida).
            html.escape(str(...)) és més explícit i controlat: tu decideixes exactament com es fa 
            la conversió i l’escapat.
        """
        if value is None:
            return ''
        return html.escape(str(value).strip().lower())

    @staticmethod
    def reverse_amavisd_domain_names(domains: Union[str, List[str]] = None) -> List[str]:
        """
        🔄 Inverteix dominis al format utilitzat per Amavis.

        Accepta una cadena única o una llista de dominis.

        Exemple:
            >>> reverse_amavisd_domain_names('example.com')
            ['com.example']

            >>> reverse_amavisd_domain_names(['example.com', 'sub.example.com'])
            ['com.example', 'com.example.sub']

        Args:
            domains (str | list[str]): Un domini o una llista de dominis.

        Returns:
            list[str]: Dominis invertits sense duplicats, mantenint l'ordre.
        """
        if not domains:
            return []

        # NOTE: Si és una cadena, la convertim en llista
        if isinstance(domains, str):
            domains = [domains]

        domains = [str(d).lower() for d in domains if _is_domain(d)]

        # NOTE: Invertim i eliminem duplicats mantenint l'ordre
        reversed_domains = list(dict.fromkeys(
            ".".join(reversed(d.split("."))) for d in domains
        ))
        
        return reversed_domains


    def _normalize_list_wblist(self, items) -> List[str]:
        """
            🔹 Normalitza i valida una llista de remitent/domini (rdns):
                Accepta:
                    - IPs (ex: 192.168.1.10)
                    - IPs amb comodí (ex: 192.168.2.*)
                    - Adreces de correu (user@example.com)
                    - Adreces amb comodí (user@*)
                    - Dominis en format @domain o @.domain (tots subdominis)
                    - Catchall especial '@.'
                Passos:
                    1. Converteix a minúscules, 
                    2. Elimina espais i comentaris implícits.
                    3. Elimina duplicats
                Retorna:
                    Llista ordenada alfabèticament.
        """
        if not items:
            return []

        # NOTE: Si reben una cadena, suportem separació per comes i per salts de línia
        if isinstance(items, str):
            raw_items = [s.strip() for s in re.split(r'[,\n\r]+', items) if s.strip()]
        else:
            raw_items = [str(s).strip().lower() for s in items if s]  # NOTE: ja s'espera iterable

        normalized = []
        for item in raw_items:
            s = item.lower().strip()
            if not s:
                continue
            if s == '@.':
                normalized.append('@.')
            elif self.is_strict_ip(s):
                normalized.append(s)
            elif self.is_wildcard_ipv4(s):
                normalized.append(s)
            elif self.is_email(s):
                normalized.append(s)
            elif self.is_wildcard_addr(s):
                normalized.append(s)
            elif s.startswith('@') and self.is_domain(s.lstrip('@.')):
                normalized.append(s)

        return sorted(set(normalized))
