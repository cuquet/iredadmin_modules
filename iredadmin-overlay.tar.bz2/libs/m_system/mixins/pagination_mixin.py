# libs/m_system/mixins/pagination_mixin.py
import settings


class PaginationMixin:
    def normalize_current_page(self, current_page, default: int = 1, min_page: int = 1) -> int:
        """
        Normalitza el número de pàgina:
        - `None`, buit o valor invàlid -> `default`
        - valors per sota de `min_page` -> `min_page`
        """
        try:
            page = int(current_page or default)
        except (TypeError, ValueError):
            page = default

        if page < min_page:
            page = min_page

        return page

    def normalize_page_size(
        self,
        page_size,
        default: int = None,
        min_size: int = 1,
        max_size: int = None,
        ) -> int:
        if default is None:
            default = settings.PAGE_SIZE_LIMIT

        try:
            size = int(page_size or default)
        except (TypeError, ValueError):
            size = default

        if size < min_size:
            size = min_size

        if max_size is not None and size > max_size:
            size = max_size

        return size

    def get_total_pages(self, total: int, size_limit: int = None) -> int:
        if size_limit is None:
            size_limit = settings.PAGE_SIZE_LIMIT

        if size_limit <= 0:
            return 1 if total else 0

        return (total // size_limit) + (1 if total % size_limit else 0)

    def get_page_offset(self, current_page: int, page_size: int) -> int:
        page = self.normalize_current_page(current_page=current_page, default=1, min_page=1)
        size = self.normalize_page_size(page_size=page_size, min_size=1)
        return (page - 1) * size
