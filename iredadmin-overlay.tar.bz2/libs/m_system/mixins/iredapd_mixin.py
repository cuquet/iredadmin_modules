import re
from typing import List
import html
from libs.iredutils import (
    is_email as _is_email,
    is_domain as _is_domain,
    is_strict_ip as _is_strict_ip,
    is_ip_or_network as _is_ip_or_network,
    is_wildcard_addr as _is_wildcard_addr,
    get_account_priority as _get_account_priority,
    is_valid_amavisd_address as _is_valid_amavisd_address
)

from libs.m_system.mixins.enums import _validate_enum

class iRedAPDMixin:
    # Wrappers de funcions d'iredutils
    def is_email(self, value):
        return _is_email(value)

    def is_domain(self, value):
        return _is_domain(value)

    def is_strict_ip(self, value):
        return _is_strict_ip(value)

    def is_ip_or_network(self, value):
        return _is_ip_or_network(value)

    @staticmethod
    def is_wildcard_addr(sef, value):
        return _is_wildcard_addr(value)

    def get_account_priority(self, value):
        return _get_account_priority(value)

    def is_valid_amavisd_address(self, value):
        return _is_valid_amavisd_address(value)

    # Wrappers de m_mixins.__init__.py
    @staticmethod
    def val_enum(value, enum_cls):
        return _validate_enum(value, enum_cls)

    #mètodes propis
    @staticmethod
    def safe_lower(value):
        """
            Sí, pots evitar `web.safestr(account).lower()` si no vols importar el mòdul web de web.py,
            tot i que has de tenir en compte què fa exactament safestr(). Aquesta funció normalment 
            s'utilitza per assegurar que una cadena és segura per mostrar-la en HTML (escapant caràcters especials)
            i per convertir objectes en cadenes si cal.
            ```python
                str(account).lower()
            ```
            🔒 Però compte: si el valor de account pot contenir caràcters que necessiten ser escapats 
            per HTML (com <, >, &, etc.), i vols mantenir la seguretat contra XSS, hauries d'utilitzar 
            una funció d'escapat com:
            ```python
                import html
                html.escape(str(account)).lower()
            ```
            web.safestr() pot tenir comportaments addicionals segons el tipus de value (per exemple, 
            si és None, pot retornar una cadena buida).
            html.escape(str(...)) és més explícit i controlat: tu decideixes exactament com es fa 
            la conversió i l’escapat.
        """
        if value is None:
            return ''
        return html.escape(str(value).strip().lower())
    
    def _normalize_list_senders(self, items) -> List[str]:
        """
            🔹  Normalitza i valida una llista de remitents per greylisting. 
            Pot ser en format llista, o bé una cadena separada per comes

            Accepta:
                - IPs (ex: 192.168.1.10)
                - Xarxes CIDR (ex: 192.168.1.0/24)
                - Adreces de correu (ex: user@example.com)
                - Dominis en format @domain o @.domain (tots subdominis)

            Retorna:
                Llista de remitents vàlids (pot ser buida).
        """
        if not items:
            return []

        # Si és una cadena, la convertim en llista
        if isinstance(items, str):
            raw_list = [s.strip() for s in re.split(r'[,\n\r]+', items) if s.strip()]
        else:
            raw_list = [str(s).strip().lower() for s in items if s]
        valid_senders = []

        for item in raw_list:
            s = str(item).lower().strip()
            if not s:
                continue
            if self.is_ip_or_network(s):
                valid_senders.append(s)
            elif self.is_email(s):
                valid_senders.append(s)
            elif s.startswith('@') and self.is_domain(s.lstrip('@.')):
                valid_senders.append(s)

        # Eliminar duplicats mantenint l'ordre
        return list(dict.fromkeys(valid_senders))

    def _normalize_list_senders_comments(self, domains) -> List[dict]:
        """
            🔹 Normalitza i valida dominis amb comentaris opcionals:
                Passos:
                    - Converteix a minúscules.
                    - Elimina espais.
                    - Separa comentari si hi ha '#'.
                    - Filtra només dominis vàlids amb _normalize_list_senders()
                    - Elimina duplicats.
                Retorna: 
                    [{sender, comment}, ...].
        """
        if not domains:
            return []

        # Si és string, encapsulem en una llista
        if isinstance(domains, str):
            domains = [d.strip() for d in domains.split(",") if d.strip()]

        senders_comments = {}
        for i in domains:
            if not i:
                continue
            parts = i.split("#", 1)
            dom = self.safe_lower(parts[0].strip())
            comment = parts[1].strip() if len(parts) > 1 else ""
            normalized_senders = self._normalize_list_senders(dom)
            if normalized_senders:
                # normalitzat sempre retorna llista, però aquí serà [un sol sender]
                senders_comments[normalized_senders[0]] = comment

        return [{"sender": d, "comment": c} for d, c in sorted(senders_comments.items())]

    def _normalize_list_domains_ips(self, items) -> List[str]:
        """
            🔹 Normalitza i valida una llista de dominis o IPs estrictes.
                Accepta:
                    - Dominis purs: 'example.com' (valida amb self.is_domain)
                    - Dominis amb subdominis: '.example.com' (valida com a domain)
                    - IPs estrictes: '192.168.1.10' (valida amb self.is_strict_ip)
                
                Passos:
                    1. Converteix a minúscules i elimina espais.
                    2. Filtra només dominis i IPs vàlids.
                    3. Elimina duplicats.
                
                Retorna:
                    Llista ordenada alfabèticament.
        """
        if not items:
            return []

        # Si és string, suportem separació per comes o salts de línia
        if isinstance(items, str):
            raw_items = [s.strip() for s in re.split(r'[,\n\r]+', items) if s.strip()]
        else:
            raw_items = [str(s).strip().lower() for s in items if s]

        normalized = []
        for item in raw_items:
            s = item.lower().strip()
            if self.is_domain(s) or self.is_strict_ip(s):
                normalized.append(s)
            elif self.is_strict_ip(s):
                normalized.append(s)
            elif s.startswith('.') and self.is_domain(s.lstrip('.')):
                normalized.append(s)  # mantenim el punt per indicar "inclou subdominis

        # Eliminar duplicats mantenint ordre i ordenar
        return sorted(set(normalized))
