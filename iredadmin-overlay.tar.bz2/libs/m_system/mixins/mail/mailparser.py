"""
Basat en projecte `mail-parser` https://pypi.org/project/mail-parser/
mantingut per Fedele Mantuano, base del sistema SpamScope.

📦 Característiques:
• Accés a capçaleres, cos, adjunts, dates
• Anàlisi del camp Received amb regex
• Detecció de defectes MIME
• Exportació a JSON
"""

import email
from email import policy
from email.header import decode_header
from email.utils import parsedate_to_datetime
import base64
import re

USEFUL_HEADERS = [
    "X-Amavis-Alert",
    "X-Quarantine-ID",
    "X-Spam-Flag",
    "X-Spam-Score",
    "X-Spam-Level",
    "X-Spam-Status"
]

def decode_header_value(header):
    """Decodifica una capçalera MIME en format llegible"""
    if not header:
        return ""
    parts = decode_header(header)
    return "".join(
        str(part[0], part[1] or 'utf-8') if isinstance(part[0], bytes) else part[0]
        for part in parts
    ).strip()

def split_addresses(header_value):
    """Converteix una cadena de correus separats per comes en llista neta"""
    return [addr.strip() for addr in header_value.split(',')] if header_value else []

def extract_body(message):
    """Prioritza HTML si existeix, sinó text/plain"""
    html_body = ""
    text_body = ""
    if message.is_multipart():
        for part in message.walk():
            content_type = part.get_content_type()
            if content_type == "text/html" and not part.get_filename():
                html_body = part.get_payload(decode=True).decode(part.get_content_charset() or 'utf-8', errors='ignore')
            elif content_type == "text/plain" and not part.get_filename():
                text_body = part.get_payload(decode=True).decode(part.get_content_charset() or 'utf-8', errors='ignore')
    else:
        content_type = message.get_content_type()
        body = message.get_payload(decode=True).decode(message.get_content_charset() or 'utf-8', errors='ignore')
        if content_type == "text/html":
            html_body = body
        else:
            text_body = body
    return html_body or text_body

def extract_mail_path(msg):
    """
        Construeix el recorregut SMTP del correu a partir de les capçaleres Received.
        Retorna una llista ordenada de salts amb origen, destí i data.
    """
    path = []
    for header in msg.get_all("Received", []):
        from_match = re.search(r"from\s+([^\s]+)", header)
        by_match = re.search(r"by\s+([^\s]+)", header)
        date_match = re.search(r";\s*(.+)$", header)
        ip_match = re.search(r"\[([0-9]+\.[0-9]+\.[0-9]+\.[0-9]+)\]", header)

        entry = {
            "from": from_match.group(1) if from_match else None,
            "by": by_match.group(1) if by_match else None,
            "date": date_match.group(1).strip() if date_match else None,
            "ip": ip_match.group(1) if ip_match else None,
            "domain": from_match.group(1).split('.')[-2:] if from_match else None,
            "raw": header.strip()
        }
        path.append(entry)
    return list(reversed(path))

def parse_from_bytes(raw_bytes):
    """Parser principal: extreu metadades, cos, adjunts i capçaleres útils"""
    msg = email.message_from_bytes(raw_bytes, policy=policy.default)

    parsed = {
        "subject": decode_header_value(msg.get("Subject")),
        "from": split_addresses(decode_header_value(msg.get("From"))),
        "to": split_addresses(decode_header_value(msg.get("To"))),
        "cc": split_addresses(decode_header_value(msg.get("Cc"))),
        "reply_to": decode_header_value(msg.get("Reply-To")),
        "user_agent": decode_header_value(msg.get("User-Agent")),
        "x_mailer": decode_header_value(msg.get("X-Mailer")),
        "date": parsedate_to_datetime(msg.get("Date")) if msg.get("Date") else None,
        "message_id": msg.get("Message-ID"),
        "body": extract_body(msg),
        "attachments": [],
        "headers": {}
    }
    # Capçaleres útils
    for key in USEFUL_HEADERS:
        value = msg.get(key)
        if value:
            parsed["headers"][key] = decode_header_value(value)

    # Recorregut SMTP (mail_path)
    mail_path = extract_mail_path(msg)
    if mail_path:
        parsed["headers"]["mail_path"] = mail_path
    
    # Adjunts
    for part in msg.walk():
        if part.get_content_disposition() == "attachment":
            filename = decode_header_value(part.get_filename())
            content = part.get_payload(decode=True)
            parsed["attachments"].append({
                "filename": filename,
                "size": len(content),
                "content_type": part.get_content_type(),
                "base64": base64.b64encode(content).decode('ascii'),
            })

    return parsed