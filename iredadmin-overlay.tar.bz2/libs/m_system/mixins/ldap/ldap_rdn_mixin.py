import web
from ldap.dn import escape_dn_chars

import settings
from libs import iredutils

from libs.ldaplib import attrs,ldaputils

class LdapRDNMixin:
    # Wrappers de funcions d'iredutils
    def is_email(self, value):
        return iredutils.is_email(value)

    def is_domain(self, value):
        return iredutils.is_domain(value)
    
    def is_auth_email(self,value):
        return iredutils.is_auth_email(value)
    
    def strip_mail_ext_address(self, value, delimiters=None):
        return iredutils.strip_mail_ext_address(value, delimiters)
    
    def _rdn_value_to_dn(self, keyword:str, account_type='user'):
        """
        Convert keyword and account type to DN.
        """
        keyword = web.safestr(keyword).strip().replace(' ', '')
        keyword = escape_dn_chars(keyword)
        account_type = web.safestr(account_type)

        # No matter what account type is, try to get a domain name.
        domain = keyword.split('@', 1)[-1]

        # Validate account type.
        if account_type not in attrs.ACCOUNT_TYPES_ALL:
            return 'INVALID_ACCOUNT_TYPE'

        # Validate keyword.
        # Keyword is email address.
        if account_type in attrs.ACCOUNT_TYPES_EMAIL and \
        not self.is_email(keyword):
            return 'INVALID_MAIL'

        # Keyword is domain name.
        if account_type in attrs.ACCOUNT_TYPES_DOMAIN and \
        not self.is_domain(keyword):
            return 'INVALID_DOMAIN_NAME'

        # Convert keyword to DN.
        if account_type == 'user':
            dn = '{}={},{}{}={},{}'.format( attrs.RDN_USER,
                                            keyword,
                                            attrs.DN_BETWEEN_USER_AND_DOMAIN,
                                            attrs.RDN_DOMAIN,
                                            domain,
                                            settings.ldap_basedn)
        elif account_type == 'admin':
            dn = '{}={},{}'.format( attrs.RDN_ADMIN,
                                    keyword,
                                    settings.ldap_domainadmin_dn)
        elif account_type == 'domain':
            dn = '{}={},{}'.format( attrs.RDN_DOMAIN,
                                    keyword,
                                    settings.ldap_basedn)
        return dn
    
    def rdn_value_to_domain_dn(self, value):
        return ldaputils.rdn_value_to_domain_dn(value)

    def rdn_value_to_user_dn(self, value):
        return ldaputils.rdn_value_to_user_dn(value)

    def rdn_value_to_admin_dn(self, value):
        return ldaputils.rdn_value_to_admin_dn(value)

    def rdn_value_to_ou_users_dn(self, value):
        return ldaputils.rdn_value_to_ou_users_dn(value)
        
    def rdn_value_to_maillist_dn(self, value):
        keyword = web.safestr(value).strip().replace(' ', '')
        keyword = escape_dn_chars(value)
        domain = keyword.split('@', 1)[-1]
        if not self.is_domain(domain):
            return 'INVALID_DOMAIN_NAME'
        if not self.is_email(keyword):
            return 'INVALID_MAIL'
        return '{}={},{}{}={},{}'.format( attrs.RDN_ML,
                                            keyword,
                                            attrs.DN_BETWEEN_GROUP_AND_DOMAIN, 
                                            attrs.RDN_DOMAIN,
                                            domain,
                                            settings.ldap_basedn)
    
    def rdn_value_to_ou_maillist_dn(self, value):
        return ldaputils.rdn_value_to_ou_maillists_dn(value)
    
    def rdn_value_to_ou_aliases_dn(self, value):
        return ldaputils.rdn_value_to_ou_aliases_dn(value)
    
    