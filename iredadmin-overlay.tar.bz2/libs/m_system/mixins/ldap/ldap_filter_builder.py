from typing import Union

class LDAPFilter:
    """
        Builder fluent per filtres LDAP.
        Compatible amb Python 3.9+ (Union) i 3.10+ (PEP 604).
        
        Exemple:
            query_filter = LDAPFilter().and_(
                    "(objectClass=mailDomain)",
                    LDAPFilter().or_(
                        "(domainName=example.org)",
                        "(domainAliasName=example.org)"
                    )
                )
            print(query_filter)
            # (&(objectClass=mailDomain)(|(domainName=example.org)(domainAliasName=example.org)))
            
        Exemple 2:
            F = LDAPFilter  # alias curt i visual

            query_filter = (
                F()
                .and_(
                    "(objectClass=mailUser)",       # Ha de ser usuari de correu
                    F().not_("(accountStatus=disabled)"),  # Excloure usuaris deshabilitats
                    F().or_(
                        F().raw("(mailQuota>=1)"),   # Condició en cru: quota major que 0
                        "(uid=postmaster)"           # O bé el uid és postmaster
                    )
                )
            )
            print(query_filter)
            # (&(objectClass=mailUser)(!(accountStatus=disabled))(|(mailQuota>=1)(uid=postmaster)))
    """
class LDAPFilter:
    def __init__(self, filter_str: str = "") -> None:
        self.expr = filter_str  # Només un filtre acumulat, no llista

    def __str__(self) -> str:
        return self.expr or ""

    def and_(self, *filters: Union[str, "LDAPFilter"]) -> "LDAPFilter":
        clauses = [str(f) for f in filters if f]
        if self.expr:
            clauses.insert(0, self.expr)
        self.expr = f"(&{''.join(clauses)})"
        return self

    def or_(self, *filters: Union[str, "LDAPFilter"]) -> "LDAPFilter":
        clauses = [str(f) for f in filters if f]
        if self.expr:
            clauses.insert(0, self.expr)
        self.expr = f"(|{''.join(clauses)})"
        return self

    def not_(self, flt: Union[str, "LDAPFilter"]) -> "LDAPFilter":
        self.expr = f"(!{str(flt)})"
        return self

    def raw(self, flt: str) -> "LDAPFilter":
        self.expr = flt
        return self

    def build(self) -> str:
        flt = str(self)
        if not (flt.startswith("(") and flt.endswith(")")):
            raise ValueError(f"Filtre LDAP creat no vàlid: {flt}")
        return flt
