import settings
if settings.backend == "ldap":
    from libs.m_crudlib import LDAPWrap
    from libs.m_system.mixins import LdapCRUDMixin

    class LDAPHelper(LDAPWrap, LdapCRUDMixin):
        def __init__(self):
            super().__init__()         # això crida LDAPWrap.__init__ i posa self.conn
            # ara inicialitza el mixin si fa falta
            if hasattr(self, "_init_mixin"):
                self._init_mixin()
else:
    LDAPHelper = None