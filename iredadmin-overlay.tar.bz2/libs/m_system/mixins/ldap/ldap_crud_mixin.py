# libs/m_system/mixins/ldap/ldap_crud_mixin.py
import time
import math
import ldap
import logging
import inspect
from typing import Dict, List, Tuple, Literal

import settings
from libs import iredpwd

from libs.iredutils import (
    is_email as _is_email,
    is_domain as _is_domain,
    is_valid_account_first_char as _is_valid_account_first_char,
    bytes2str as _bytes2str
)

if settings.backend in ["ldap"]:
    from libs.ldaplib.ldaputils import (
        mod_replace as _mod_replace,
        account_setting_dict_to_list as _account_setting_dict_to_list,
        account_setting_list_to_dict as _account_setting_list_to_dict
    )
    from libs.ldaplib.general import (
        is_global_admin as _is_global_admin,
        is_domain_admin as _is_domain_admin,
        is_domain_exists as _is_domain_exists,
        add_or_remove_attr_values as _add_or_remove_attr_values,
        update_attr_with_single_value as _update_attr_with_single_value,
        get_profile_by_dn as _get_profile_by_dn,
        delete_ldap_tree as _delete_ldap_tree,
        get_domain_account_setting as _get_domain_account_setting,
        get_user_account_setting as _get_user_account_setting,
        get_admin_account_setting as _get_admin_account_setting
    ) 
    from libs.ldaplib.domain import (
        update_domain_status_for_all_accounts as _update_domain_status_for_all_accounts
    )
from libs.m_system.decorators import LibDecorators
from libs.m_system import utils
from libs.m_system.mixins import LdapRDNMixin
from libs.m_system.mixins.pagination_mixin import PaginationMixin
from libs.m_system.mixins.ldap.ldap_filter_builder import LDAPFilter as F

LOGGER = logging.getLogger(__name__)


class LdapCRUDMixin(LdapRDNMixin, PaginationMixin):
    def _init_mixin(self):
        """
            Cridat des de **Base després de tenir self.conn.
        """
        self.conn = getattr(self, "conn", None)

    # -------------------------------
    # Wrappers de laputils
    # -------------------------------
    @staticmethod
    def mod_replace(attr, value, default=None) -> List[Tuple]:
        """
            Retorna una llista amb (només un) `ldap.MOD_REPLACE` utilitzat per eliminar o actualitzar
            el valor LDAP.

            Quan el valor final és `None` o una llista/tupla/set buit, l'atribut LDAP
            `attr` serà eliminat.

            >>> mod_replace(attr='name', value=None)
            [(2, 'name', None)]
            >>> mod_replace(attr='name', value='')
            [(2, 'name', None)]
            >>> mod_replace(attr='name', value=[])
            [(2, 'name', None)]
            >>> mod_replace(attr='name', value='', default=None)
            [(2, 'name', None)]
            >>> mod_replace(attr='name', value='my name')
            [(2, 'name', [b'my name'])]
            >>> mod_replace(attr='aint', value=5)
            [(2, 'aint', ['5'])]
            >>> mod_replace(attr='alist', value=['elm1', 'elm2'])
            [(2, 'alist', [b'elm1', b'elm2'])]
            >>> mod_replace(attr='atuple', value=('elm1', 'elm2'))
            [(2, 'atuple', [b'elm1', b'elm2'])]
            >>> mod_replace(attr='aset', value={'elm1', 'elm2'})
            [(2, 'aset', [b'elm1', b'elm2'])]
        """
        return _mod_replace(attr=attr, value=value, default=default)
    
    @staticmethod
    def account_setting_dict_to_list(settings_dict: Dict) -> List:
        return _account_setting_dict_to_list(settings_dict)
    
    @staticmethod
    def account_setting_list_to_dict(settings_list: List) -> Dict:
        return _account_setting_list_to_dict(settings_list)
    
    # -------------------------------
    # Wrappers de iredutils
    # -------------------------------
    @staticmethod
    def is_valid_account_first_char(v):
        return _is_valid_account_first_char(v)
    
    @staticmethod
    def is_email(value):
        return _is_email(value)

    @staticmethod
    def is_domain(value):
        return _is_domain(value)
    
    @staticmethod
    def bytes2str(value):
        return _bytes2str(value)
    
    # -------------------------------
    # Wrappers de ldaplib.general
    # -------------------------------
    def is_global_admin(self, admin):
        return _is_global_admin(admin, conn=self.conn)

    def is_domain_admin(self, domain: str,  admin: str) -> tuple[bool, any]:
        return _is_domain_admin(domain, admin, conn=self.conn)    

    def is_domain_exist(self, domain):
        return _is_domain_exists(domain)

    def add_or_remove_attr_values_by_dn(self, dn, attr, values, action, ignore_no_such_object=False):
        return _add_or_remove_attr_values(
            dn, attr, values, action, ignore_no_such_object=ignore_no_such_object, conn=self.conn
        )

    def update_attr_with_single_value_by_dn(self, dn, attr, value):
        return _update_attr_with_single_value(dn, attr, value, conn=self.conn)

    def subtree_delete_by_dn(self, dn):
        return _delete_ldap_tree(dn, conn=self.conn)

    def _get_domain_account_settings(self, domain, profile=None) -> any:
        ok, accs = _get_domain_account_setting(domain, profile=profile, conn=self.conn)
        if not ok:
            return False
        return accs

    def _get_user_account_settings(self, mail, profile=None):
        ok, accs =  _get_user_account_setting(mail, profile=profile, conn=self.conn)
        if not ok:
            return False
        return accs

    def _get_admin_account_settings(self, mail, profile=None):
        ok, accs = _get_admin_account_setting(mail, profile=profile, conn=self.conn)
        if not ok:
            return False
        return accs

    #exclude_non_existing_emails_in_domain
    #filter_existing_emails
    #filter_existing_domains
    
    # -------------------------------
    # Wrappers de ldaplib.domain
    # -------------------------------
    def update_domain_status_for_all_accounts(self, domain, status='active'):
        return _update_domain_status_for_all_accounts(domain=domain, status=status, conn=self.conn)

    # -------------------------------
    # mètodes propis
    # -------------------------------

    @staticmethod
    def logger_list_helper(mails: List, max_show: int= 3) -> List:
        '''
            Definim un límit de mails a mostrar
        '''
        num_mails = len(mails)
        if num_mails > max_show:
            display_mails = ', '.join(mails[:max_show]) + f" (and {num_mails - max_show} more)"
        else:
            display_mails = ', '.join(mails)
        
        return display_mails

    def is_email_exist(self, mail):
        return self.exist_accounts([mail])

    @LibDecorators.safe_ldap_method(no_tuple=True)
    def exist_accounts(self, mails:List, base_dn=None ) -> Dict:
        """
            Verifica si existeixen comptes LDAP per una llista de correus.

            - Si hi ha un sol correu:
                - Retorna `True` si existeix
                - Retorna `False` si no existeix
                - Retorna `(None, 'ERROR_WHILE_QUERYING_DB')` si hi ha error

            - Si hi ha més d’un correu:
                - Retorna un diccionari amb claus:
                    - 'exist': llista de correus trobats
                    - 'nonexist': llista de correus no trobats

            :param mails: llista d'adreces de correu electrònic
            :param base_dn: DN base per la cerca LDAP (opcional)
        """
        mails = [self.strip_mail_ext_address(str(v).lower())
                for v in mails
                if self.is_email(v)]
        mails = list(set(mails))
        result = {'exist': [], 'nonexist': []}

        # Filtre utilitzat per cercar el compte.
        # _filter = '(&'
        # _filter += '(|(objectClass=mailUser)(objectClass=mailList)(objectClass=mailAlias))'
        # for addr in mails:
        #     _filter += f'(|(mail={addr})(shadowAddress={addr}))'
        # _filter += ')'
        
        # Construïm la part OR 
        object_classes = F().or_(
            "(objectClass=mailUser)",
            "(objectClass=mailList)",
            "(objectClass=mailAlias)"
        )
        # Construïm la part OR per cada adreça
        addr_filters = [
            F().or_(f"(mail={addr})", f"(shadowAddress={addr})")
            for addr in mails
        ]
        # Combinem-ho tot en un AND
        search_filter = F().and_(
            object_classes,
            *addr_filters
        ).build()

        attributes = ['mail', 'shadowAddress']

        if not base_dn:
            base_dn = settings.ldap_basedn

        qr = self.conn.search_s(
            base_dn,
            ldap.SCOPE_SUBTREE,
            search_filter,
            attributes)
        if len(mails)==1:
            if qr:
                return True
            return False
        elif qr and len(mails)>1:
            for (_dn, _ldif) in qr:
                #result['exist'] += _ldif.get('mail', []) + _ldif.get('shadowAddress', [])
                result['exist'].extend(_ldif.get('mail', []))
                result['exist'].extend(_ldif.get('shadowAddress', []))
            result['exist'] = list(set(result['exist']))
            result['nonexist'] = [v for v in mails if v not in result['exist']]
            result['nonexist'] = list(set(result['nonexist']))
        
        return result

    @LibDecorators.safe_ldap_method
    def subtree_get_by_dn(self, dn, query_filter=None, attributes=None):
        if not attributes:
            attributes = ['*']
        if not query_filter:
            query_filter = "(objectClass=*)"   
        
        list=[]
        qr = self.conn.search_s(
            dn,
            ldap.SCOPE_SUBTREE,
            query_filter,
            attributes
            )           

        for dn, entry in qr:
            list.append({'dn': dn, 'ldif': entry})
        return(True, list)

    def profile_get_by_dn(self, dn, query_filter=None, attributes=None, raw=False):
        if not dn:
            # NOTE: deixem rastre concret del punt de crida per facilitar diagnosi.
            caller = "unknown"
            try:
                frame = inspect.stack()[1]
                caller = f"{frame.function}:{frame.lineno}"
            except Exception:
                pass
            LOGGER.warning("profile_get_by_dn called without DN (caller=%s)", caller)
            return (False, 'NO_DN_PROVIDED')

        ok, result = _get_profile_by_dn(dn, query_filter=query_filter, attributes=attributes, conn=self.conn)
        if ok and not raw:
            ldif= utils.profile_define_adminType(result['ldif'])
            return (ok, {'dn': result['dn'], 'ldif': ldif})
        return (ok, result)

    @LibDecorators.safe_ldap_method
    def profile_enable_disable_by_dn(self, value, action, account_type):
        action = action.lower()
        if action not in ['enable', 'disable']:
            return (False, 'INVALID_ACTION')

        status = 'active' if action == 'enable' else 'disabled'

        mapping = {
            'user': self.rdn_value_to_user_dn,
            'domain': self.rdn_value_to_domain_dn,
            'admin': self.rdn_value_to_admin_dn,
            'maillist': self.rdn_value_to_maillist_dn
            }

        _func = mapping[account_type]
        dn = _func(value)

        qr = self.update_attr_with_single_value_by_dn(
            dn=dn,
            attr='accountStatus',
            value=status)
        if not qr[0] and account_type in ['admin']:
            if qr[0] == 'NO_SUCH_ACCOUNT':
                # Admin is a normal mail user.
                dn = self.rdn_value_to_user_dn(value)
                self.add_or_remove_attr_values_by_dn(
                    dn=dn,
                    attr='enabledService',
                    values='domainadmin',
                    action=action)

                self.add_or_remove_attr_values_by_dn(
                    dn=dn,
                    attr='domainGlobalAdmin',
                    values='yes',
                    action=action)
        if qr[0] and account_type in ['domain']:
            self.update_domain_status_for_all_accounts(value, status=status)

        return (True, )

    @LibDecorators.safe_ldap_method
    def profile_change_password(self, dn, old_pw, new_pw, require_cur_passwd=True):
        def update_pwd():
            try:
                lastchange= str(int(math.floor(time.time() / 86400)))
                pw_hash = iredpwd.generate_password_hash(new_pw)
                mod_attr = self.mod_replace('userPassword', pw_hash)
                mod_attr += self.mod_replace('shadowLastChange',lastchange)
                self.conn.modify_s(dn, mod_attr)
                return (True, )
            except Exception as e:
                return (False, repr(e))
            
        if require_cur_passwd:
            qr = self.profile_get_by_dn(dn, attributes=["userPassword"])
            old_pwhash= qr[1]['ldif'].get('userPassword','')
            result = iredpwd.verify_password_hash(old_pwhash, old_pw)
            if not result:
                return (False, 'INCORRECT_OLDPW')
            return update_pwd()
        else:
            return update_pwd()

    def add_or_remove_enabled_service_by_dn(self, dn, values, action):
        return self.add_or_remove_attr_values_by_dn(dn=dn, attr="enabledService", values=values, action=action)

    def add_or_remove_disabled_service_by_dn(self, dn, values, action):
        return self.add_or_remove_attr_values_by_dn(dn=dn, attr="disabledService", values=values, action=action)

    def enable_disable_accounts(self, values: List[str], action: Literal["enable", "disable"], account_type: Literal['user', 'admin', 'maillist', 'domain']) -> Tuple[bool, str]:
        msg = {}

        if account_type not in ['user', 'admin', 'maillist', 'domain']:
            return (False, )

        if not values:
            return (True, "NO_ACCOUNT_SELECTED")
        
        for value in values:
            qr = self.profile_enable_disable_by_dn(value, action, account_type)
            if not qr[0]:
                msg[value]=qr[1]
        
        if not msg:
            return (True, f"{action}D".upper())
        return (False, repr(msg))

    @LibDecorators.safe_ldap_method
    def update_domain_alias_for_all_accounts(self, dn_domain, values):
        valid_aliases = utils._normalize_list_domains(values)
        if not valid_aliases:
            return (True, )

        search_filter = F().or_(
            "(objectClass=mailUser)",
            "(objectClass=mailList)"
        ).build()
        
        attributes = ['mail','shadowAddress']

        qr = self.conn.search_s(
            dn_domain,
            ldap.SCOPE_SUBTREE,
            search_filter,
            attributes)

        for (dn, _ldif) in qr:
            mod_attrs = []
            _ldif = self.bytes2str(_ldif)
            mail = _ldif.get('mail', [None])[0]
            if not mail or '@' not in mail:
                continue  # salta entrades malformades
            username, domain = mail.split('@', 1)
            # Filtra shadowAddress que pertanyen al domini original
            shadow_addresses = _ldif.get('shadowAddress', [])
            shadow_addresses = [email for email in shadow_addresses if email.endswith(f"@{domain}")]
            
            for alias_domain in valid_aliases:
                alias_mail = f"{username}@{alias_domain}"
                if alias_mail not in shadow_addresses:
                    shadow_addresses.append(alias_mail)
            mod_attrs = self.mod_replace('shadowAddress', shadow_addresses)

            self.conn.modify_s(dn, mod_attrs)

        return (True, )

    def get_accounts_paged_list(
        self, 
        accounts:Dict,
        current_page=1,
        domain=None,
        account_type=None,
        size_limit=None):
        """
            Ordena els comptes. Retorna un diccionari que conté les claus:
            - total : nombre total de comptes
            - account_profiles: llista de resultats de consultes ldap ((<dn>: {...}) tuples)
            - pages: nombre total de pàgines que s'han de mostrar a la pàgina de llista de comptes.

            :param account_profiles: llista de perfils de compte (amb molts detalls de cada compte)
            :param current_page: pàgina de desplaçament
            :param domain: els comptes pertanyen a aquest domini
            :param account_type: tipus de compte
            :param order_name: ordena el resultat per l'atribut indicat.
            :param order_by_desc: ordena el resultat de manera descendent (desc)
            :param size_limit: mostra quants comptes hi ha en una pàgina
        """
        current_page = self.normalize_current_page(current_page=current_page, default=0, min_page=0)
        if current_page == 0:
            return accounts
        
        if size_limit is None:
            size_limit = settings.PAGE_SIZE_LIMIT

        total = len(accounts)
        pages = self.get_total_pages(total=total, size_limit=size_limit)

        result = {
            'total': total,
            'account_profiles': [],
            'pages': pages,
        }

        if total == 0:
            return result

        if size_limit <= 0:
            result['account_profiles'] = accounts
            return result

        if current_page > pages:
            current_page = pages

        start = (current_page - 1) * size_limit
        end = start + size_limit
        result['account_profiles'] = accounts[start:end]

        return result
