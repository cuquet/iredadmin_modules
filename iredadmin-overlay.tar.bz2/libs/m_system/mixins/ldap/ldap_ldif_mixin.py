# libs/m_system/mixins/ldap/ldap_ldif_mixin.py
import web
from typing import List, Dict

from libs.ldaplib import iredldif, ldaputils, attrs

class LdapLDIFMixin:
    @staticmethod
    def attrs_ldif(kvs:Dict) -> List:
        return ldaputils.attrs_ldif(kvs)

    @staticmethod
    def attr_ldif(attr, value, default=None, mode=None) -> List:
        return ldaputils.attr_ldif(attr=attr, value=value, default=default, mode=mode)

    @staticmethod
    def ldif_domain(domain,
                cn=None,
                transport=None,
                account_status=None,
                account_settings=None):
        return iredldif.ldif_domain(domain, cn=cn,
                transport=transport,
                account_status=account_status,
                account_settings=account_settings)
    
    @staticmethod
    def ldif_group(name):
        return iredldif.ldif_group(name)
    
    @staticmethod
    def ldif_mailadmin(mail,
                passwd,
                cn,
                account_status=None,
                preferred_language=None,
                account_setting=None,
                disabled_services=None):
        return iredldif.ldif_mailadmin(mail,
                passwd,
                cn,
                account_status=account_status,
                preferred_language=preferred_language,
                account_setting=account_setting,
                disabled_services=disabled_services)
    
    @staticmethod
    def ldif_mailuser(domain,
                username,
                cn,
                passwd,
                quota=0,
                storage_base_directory=None,
                mailbox_format=None,
                mailbox_folder=None,
                mailbox_maildir=None,
                language=None,
                disabled_services=None,
                domain_status=None):
        return iredldif.ldif_mailuser(domain,
                username,
                cn,
                passwd,
                quota=int(quota / (1024 * 1024)) if quota > 0 else 0,
                storage_base_directory=storage_base_directory,
                mailbox_format=mailbox_format,
                mailbox_folder=mailbox_folder,
                mailbox_maildir=mailbox_maildir,
                language=language,
                disabled_services=disabled_services,
                domain_status=domain_status)
    

    @staticmethod
    def ldif_alias(mail, cn=u'Mail Alias'):
        mail = web.safestr(mail).lower()

        enabled_services = list(attrs.ALIAS_ENABLED_SERVICE)
        ldif = ldaputils.attrs_ldif({
            'objectClass': ['mailAlias','amavisAccount','top'],
            'mail': mail,
            'accountStatus': 'active',
            'cn': cn,
            'enabledService': enabled_services,
            # Amavisd integration.
            'amavisLocal': 'TRUE',
        })

        return ldif

def ldif_fetch(value=None, account_type=None, fulltree=False):
    import settings
    from libs.m_system.mixins import LDAPHelper
    import os

    _wrap = LDAPHelper()
    ldap_lib = _wrap

    if value and account_type:
        dn = ldaputils.rdn_value_to_dn(value, account_type)
    else:
        dn = settings.ldap_basedn

    if not fulltree:
        attr_map = {
            'domain': '(objectClass=mailDomain)',
            'admin':'(objectClass=mailAdmin)',
            'user': '(objectClass=mailUser)',
            'maillist': '(objectClass=mailList)',
            'alias': '(objectClass=mailAlias)'
        }
        _filter = attr_map[account_type]
        qr = ldap_lib.profile_get_by_dn(dn, query_filter=_filter, raw=True)
        if not qr[0]:
            return False, []
        _list = [qr[1]]
    else:
        qr = ldap_lib.subtree_get_by_dn(dn)
        if not qr[0]:
            return False, []
        _list = qr[1]

    return True, _list
