# libs/m_system/mixins/ldap/ldap_ldif_export.py
import json

STYLE = """
    body {
        font-family: system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
        font-size: 13px;
        line-height: 1.4;
        color: #111;
    }

    h3 {
        margin: 1em 0 0.25em;
        font-size: 14px;
        font-weight: 600;
    }

    ul.ldif-list {
        list-style: none;
        padding-left: 0;
        margin: 0 0 1em;
        border: 1px solid #ddd;
        border-radius: 4px;
    }

    ul.ldif-list li {
        padding: 4px 8px;
        border-bottom: 1px solid #eee;
        font-family: monospace;
    }

    ul.ldif-list li:last-child {
        border-bottom: none;
    }

    .ldif-key {
        font-weight: 600;
    }
    """

class LDIFExporterText:
    content_type = 'text/plain; charset=UTF-8'
    file_extension = 'ldif'

    def apply_headers(self, web, base_filename: str):
        web.header('Content-Type', self.content_type)
        web.header(
            'Content-Disposition',
            f'attachment; filename="{base_filename}.ldif"'
        )

    def export(self, records):
        out = []
        for item in records:
            out.append(f"dn: {item['dn']}")
            for k, v in item['ldif'].items():
                for i in v:
                    out.append(f"{k}: {i}")
            out.append("")
        return "\n".join(out)

class LDIFExporterHTML:
    content_type = 'text/html; charset=UTF-8'
    file_extension = 'html'

    def apply_headers(self, web, base_filename: str):
        web.header('Content-Type', self.content_type)

    def export(self, records):
        out = []
        out.append("<!DOCTYPE html>")
        out.append("<html><head><meta charset='utf-8'>")
        out.append("<style>")
        out.append(STYLE)
        out.append("</style></head><body>")

        for item in records:
            out.append(f"<h3>dn: {item['dn']}</h3>")
            out.append("<ul class='ldif-list'>")
            for k, v in item['ldif'].items():
                for i in v:
                    out.append(
                        f"<li><span class='ldif-key'>{k}:</span> {i}</li>"
                    )
            out.append("</ul>")

        out.append("</body></html>")
        return "\n".join(out)

class LDIFExporterJSON:
    content_type = 'application/json; charset=UTF-8'
    file_extension = 'json'

    def apply_headers(self, web, base_filename: str):
        web.header('Content-Type', self.content_type)
        web.header(
            'Content-Disposition',
            f'attachment; filename="{base_filename}.json"'
        )

    def export(self, records):
        """
            records: [
                {
                    'dn': str,
                    'ldif': { attr: [values...] }
                }
            ]
        """
        out = []

        for item in records:
            out.append({
                'dn': item.get('dn'),
                'attributes': item.get('ldif', {})
            })

        return json.dumps(
            out,
            indent=2,
            ensure_ascii=False
        )