# libs/m_system/mixins/exporter_factory.py
import io
import zipfile
from typing import Union

from libs.m_system.mixins.sql.sql_export import SQLExporter, SQLExporterCSV, SQLExporterHTML
from libs.m_system.mixins.ldap.ldap_ldif_export import LDIFExporterHTML, LDIFExporterText, LDIFExporterJSON

class ZipExporter:
    """
        Wrapper per comprimir l’output d’un altre exportador en un .zip.
    """
    content_type = 'application/zip'
    file_extension = 'zip'
    
    def __init__(self, exporter, inner_filename: str):
        self.exporter = exporter
        self.inner_filename = inner_filename  # el nom del fitxer dins el zip

    def apply_headers(self, web, base_filename: str):
        web.header('Content-Type', self.content_type)
        web.header(
            'Content-Disposition',
            f'attachment; filename="{base_filename}.zip"'
        )

    def export(self, *args, **kwargs) -> bytes:
        # Genera contingut amb l’exportador original
        data = self.exporter.export(*args, **kwargs)
        if isinstance(data, str):
            data = data.encode('utf-8')
        # Posa dins un .zip en memòria
        mem_zip = io.BytesIO()
        with zipfile.ZipFile(mem_zip, mode='w', compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr(self.inner_filename, data)
        mem_zip.seek(0)
        return mem_zip.read()

class ExporterFactory:
    _SQL = {
        'csv': SQLExporterCSV,
        'xls': SQLExporterHTML,
        'html': SQLExporterHTML,  # alias explícit
        # 'pdf': SQLExporterPDF (futur)
    }
    _LDIF = {
        'html': LDIFExporterHTML,
        'ldif': LDIFExporterText,
        'json': LDIFExporterJSON,
    }

    @classmethod
    def from_SQL(
        cls,
        format: str,
        schema,
        title: str = "Export",
        zip: bool = False
        ) -> SQLExporter:

        fmt = str(format).strip().lower()
        exporter_cls = cls._SQL.get(fmt)
        if not exporter_cls:
            raise ValueError(f"Unsupported SQL format: {fmt}")

        exp = exporter_cls(
            headers=schema.headers,
            row_mapper=schema.row,
            title=title
        )
        if zip:
            inner = exp.filename(title)
            return ZipExporter(exp, inner)
        return exp

    @classmethod
    def from_LDIF(
        cls,
        format: str,
        zip: bool = False,
        inner_name: Union[str, None] = None
        ):
        fmt = str(format)
        exporter_cls = cls._LDIF.get(fmt)
        if not exporter_cls:
            raise ValueError(f"Unsupported LDIF format: {fmt}")
        exp = exporter_cls()
        if zip:
            inner = inner_name or exp.filename("export")
            return ZipExporter(exp, inner)
        return exp
