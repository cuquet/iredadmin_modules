from enum import Enum

# | Ús                        | .value necessari? | Exemple correcte                                 |
# |---------------------------|-------------------|--------------------------------------------------|
# | Comparació amb enum       | ❌ No             | if self.inout_type == Direction.OUTBOUND         |
# | Comparació amb string     | ✅ Sí             | if self.inout_type.value == "outbound"           |
# | Assignació a base de dades| ✅ Sí             | vars={"inout_type": self.inout_type.value}       |
# | Inserció en diccionari    | ✅ Sí             | payload["kind"] = self.inout_type.value          |

class ListType(Enum):
    WHITELIST = 'whitelist'
    BLACKLIST = 'blacklist'

    def to_db(self):
        return 'W' if self == ListType.WHITELIST else 'B'

class Direction(Enum):
    """Direcció del correu: entrant, extern o sortint."""
    INBOUND = 'inbound'
    OUTBOUND = 'outbound'
    EXTERNAL = 'external'

class LogType(Enum):
    SENT = 'sent'
    RECEIVED = 'received'
    QUARANTINED = 'quarantined'

class MsgsContentType(Enum):
    """
        Tipus de contingut segons amavisd-new msgs.content.
            "spam": ['S', 's', 'Y'],
            "virus": ['V'],
            "banned": ['B'],
            "badheader": ['H'],
            "clean": ['C'],
            "quarentenable": ['S', 's', 'Y', 'V', 'B', 'H'],
            "removable": ['U', 'M', 'H', 'O', 'C']
    """
    SPAM = 'S'
    SPAM_LOWER = 's'
    SPAM_TAGGED = 'Y'
    VIRUS = 'V'
    BANNED = 'B'
    BADHEADER = 'H'
    BADMIME = 'M'
    OVERSIZED = 'O'
    BADMTA = 'T'
    CLEAN = 'C'
    UNCHECKED = 'U'

    @classmethod
    def spam_types(cls):
        """Retorna totes les variants de spam."""
        return [cls.SPAM.value, cls.SPAM_LOWER.value, cls.SPAM_TAGGED.value]
    
    @classmethod
    def quarentable_types(cls):
        """Retorna només els tipus de contingut que poden passar per quarantena."""
        return [
            cls.SPAM.value,
            cls.SPAM_LOWER.value,
            cls.SPAM_TAGGED.value,
            cls.VIRUS.value,
            cls.BANNED.value,
            cls.BADHEADER.value
        ]
    
    @classmethod
    def removable_types(cls):
        """Retorna totes les que es poden esborrar per freqüència."""
        return [
            cls.UNCHECKED.value, 
            cls.BADMIME.value, 
            cls.BADHEADER.value, 
            cls.OVERSIZED.value, 
            cls.CLEAN.value
        ]
    
    @classmethod
    def virus_types(cls):
        return [
            cls.VIRUS.value, 
        ]
    
    @classmethod
    def all_values(cls):
        """Retorna tots els valors vàlids."""
        return [m.value for m in cls]

    def to_db(self):
        """Valor directe per guardar a base de dades."""
        return self.value

class MsgsQuarType(Enum):
    """Tipus de quarantena segons amavisd-new msgs.quar_type."""
    SPAM = 'S'
    VIRUS = 'V'
    BANNED = 'B'
    BADHEADER = 'H'
    GENERIC = 'Q'

    @classmethod
    def all_values(cls):
        """Retorna tots els valors vàlids per quar_type."""
        return [m.value for m in cls]

    def to_db(self):
        """Valor directe per guardar a base de dades."""
        return self.value

def _validate_enum(value, enum_cls):
    if isinstance(value, enum_cls):
        return value
    elif isinstance(value, str):
        value = value or value.lower()
        for member in enum_cls:
            if value == member.value or value == member.name.lower():
                return member
        raise ValueError(f"Invalid value '{value}' for enum {enum_cls.__name__}")
    elif value is None:
        return None
    else:
        raise TypeError(f"Expected {enum_cls.__name__} or str, got {type(value).__name__}")

def _validate_enum_flexible(value, enum_cls):
    if value is None:
        return None
    if isinstance(value, (list, tuple)):
        return [_validate_enum(v, enum_cls) for v in value]
    return _validate_enum(value, enum_cls)