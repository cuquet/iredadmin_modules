# libs/m_system/utils.py
import re
import os
from typing import Dict, List, Union
try:
    import yaml
except Exception:
    yaml = None

import settings
from libs import iredutils
from libs.sqllib.sqlutils import account_settings_string_to_dict, account_settings_dict_to_string


# Nota de desacoblament:
# Aquest mòdul s'utilitza tant en backend LDAP com SQL. Evitem importar
# `libs.ldaplib.ldaputils` aquí perquè aquell mòdul té dependència directa
# de `python-ldap` (`import ldap`) i en entorns SQL pot no estar disponible.
# Per això mantenim aquestes 2 funcions localment.
def account_setting_list_to_dict(setting_list) -> Dict:
    """Return a dict from LDAP-style accountSetting list."""
    setting_dict = {}

    for item in setting_list:
        item = iredutils.bytes2str(item)

        if ":" not in item:
            continue

        (k, v) = item.split(":", 1)

        if k in [
            "defaultQuota",
            "maxUserQuota",
            "minPasswordLength",
            "maxPasswordLength",
            "numberOfUsers",
            "numberOfAliases",
            "numberOfLists",
            "create_max_domains",
            "create_max_quota",
            "create_max_users",
            "create_max_aliases",
            "create_max_lists",
        ]:
            if v.isdigit() or v == "-1":
                setting_dict[k] = int(v)
        elif k in [
            "disabledDomainProfile",
            "disabledUserProfile",
            "disabledUserPreference",
            "disabledMailService",
        ]:
            v = v.lower()
            if k in setting_dict:
                setting_dict[k].append(v)
            else:
                setting_dict[k] = [v]
        elif k in ["defaultList"]:
            setting_dict[k] = v.split(",")
        else:
            setting_dict[k] = v

    return setting_dict


def account_setting_dict_to_list(setting_dict: Dict) -> List[bytes]:
    """Return LDAP-style accountSetting list from dict."""
    setting_list = []

    for (k, v) in list(setting_dict.items()):
        if not v:
            continue

        if isinstance(v, (list, tuple, set)):
            if k in [
                "disabledDomainProfile",
                "disabledUserProfile",
                "disabledUserPreference",
                "disabledMailService",
            ]:
                for j in v:
                    setting_list.append(f"{k}:{j}".encode())
            else:
                setting_list.append(f"{k}:{','.join(v)}".encode())
        else:
            setting_list.append(f"{k}:{v}".encode())

    return list(set(setting_list))


class KeyMap:
    def __init__(self, path: str= None):
        if path is None:
            current_dir = os.path.dirname(__file__)
            path = os.path.join(current_dir, "key_map.yaml")
            
        raw_map = self._load_key_map(path)
        # backend únic per tota la instància
        self.backend = "ldap" if settings.backend == "ldap" else "sql"
        
        # Construïm el mapa amb backend_key ja resolt
        self._map = {}
        for front_key, entry in raw_map.items():
            backend_key = entry.get(f"backend_{self.backend}") or entry.get("backend_key")
            validators = entry.get("validators", [])
            if isinstance(validators, str):
                validators = [validators]
            self._map[front_key] = {
                "backend_key": backend_key,
                "validators": validators,
                "normalizers": entry.get("normalizers", []),
                "obs": entry.get("obs", []),
                "help": entry.get("help", ""),
            }

    @staticmethod
    def _strip_quotes(value: str) -> str:
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {"'", '"'}:
            return value[1:-1]
        return value

    @classmethod
    def _load_key_map(cls, path: str) -> dict:
        if yaml is not None:
            with open(path, "r", encoding="utf-8") as f:
                return yaml.safe_load(f) or {}

        # Fallback parser per al subconjunt de YAML usat a key_map.yaml.
        # Suporta:
        # - mapa de primer nivell (clau:)
        # - claus de segon nivell (key: value)
        # - llistes simples (key: + - value)
        parsed: dict[str, dict] = {}
        current_key = None
        current_list_key = None

        with open(path, "r", encoding="utf-8") as f:
            for raw in f:
                line = raw.split("#", 1)[0].rstrip("\n")
                if not line.strip():
                    continue

                indent = len(line) - len(line.lstrip(" "))
                text = line.strip()

                if indent == 0 and text.endswith(":"):
                    current_key = text[:-1].strip()
                    parsed[current_key] = {}
                    current_list_key = None
                    continue

                if current_key is None:
                    continue

                if indent == 4 and ":" in text:
                    k, v = text.split(":", 1)
                    k = k.strip()
                    v = v.strip()
                    if v == "":
                        parsed[current_key][k] = []
                        current_list_key = k
                    else:
                        parsed[current_key][k] = cls._strip_quotes(v)
                        current_list_key = None
                    continue

                if indent >= 8 and text.startswith("- ") and current_list_key:
                    item = cls._strip_quotes(text[2:].strip())
                    parsed[current_key][current_list_key].append(item)

        return parsed

    # -------------------------------
    # Wrappers de normalizers
    # -------------------------------
    @classmethod
    def is_value(cls, value: object) -> object:
        if isinstance(value, dict):
            return value
        if isinstance(value, list):
            # NOTE: SQL adapters can surface nullable/scalar fields as empty lists.
            # Mantenim estable el remap tractant `[]` com a cadena buida en lloc de llançar error.
            return str(value[0]) if value else ""
        if isinstance(value, tuple):
            return str(value[0]) if value else ""
        return str(value)

    @classmethod
    def is_list(cls, value: object) -> object:
        if isinstance(value, dict):
            return value
        if isinstance(value, str):
            return [s.strip() for s in re.split(r'[,\n\r]+', value) if s.strip()]
        return [str(s).strip().lower() for s in value if s]

    # -------------------------------
    # Helpers
    # -------------------------------
    def get_entry(self, front_key: str) -> dict[str]:
        return self._map.get(front_key, {})

    def get_normalizers(self, front_key: str, reverse: bool = False) -> list:
        if reverse:
            front_key = next((fk for fk, e in self._map.items() if e["backend_key"] == front_key), None)
            if not front_key:
                return []
        entry = self.get_entry(front_key)
        return [getattr(self.__class__, n) for n in entry.get("normalizers", []) if hasattr(self.__class__, n)]

    def get_applicable_keys(self, object_type: str, profile_type: Union[str, None ] = None) -> list[str]:
        """
            Retorna les claus del mapa que apliquen a un determinat object_type i profile_type.
            Exemple: get_applicable_keys("user", "general") -> ['accountStatus', 'cn', 'mailQuota', ...]
            Si profile_type és None, retorna totes les claus per aquell object_type.
            
            pots fer:
            ```python
                valid_keys = self.keymap.get_applicable_keys(object_type="user", profile_type="general")
                filtered_payload = {k: v for k, v in payload.items() if k in valid_keys}
            ```
        """
        keys = []
        for front_key, entry in self._map.items():
            obs = entry.get("obs", {})
            if isinstance(obs, dict):
                profile_list = obs.get(object_type, [])
                if profile_type is None or profile_type in profile_list:
                    keys.append(front_key)
        return keys

    def remap_dict(self, data: dict, reverse: bool=False, normalize: bool=True) -> dict:
        """
            Remapeja les claus d'un diccionari segons el YAML.
            - reverse=False: front_key -> backend_key
            - reverse=True: backend_key -> front_key
            - normalize=True: executa validators backend → frontend
        """
        output: dict[str, object] = {}

        # Construïm un conjunt de backend_keys i front_keys coneguts
        known_front_keys = set(self._map.keys())
        known_backend_keys = {entry["backend_key"] for entry in self._map.values()}

        for key, val in data.items():
            # Cas especial: accountSetting
            if (reverse and key in {"accountSetting", "settings"}) or (not reverse and key == "accountSetting"):
                if settings.backend == "ldap":
                    new_key = "accountSetting"
                    if reverse:
                        val = account_setting_list_to_dict(val)
                    else:
                        val = account_setting_dict_to_list(val)
                elif settings.backend in {"sql", "mysql", "pgsql"}:
                    new_key = "settings"
                    if reverse:
                        # NOTE: En SQL alguns getters ja retornen `accountSetting` com dict.
                        # NOTE: Evitem re-parsejar-lo com string (trencaria amb `.split()`).
                        if isinstance(val, dict):
                            val = val
                        else:
                            val = account_settings_string_to_dict(val)
                    else:
                        if isinstance(val, dict):
                            val = account_settings_dict_to_string(val)

                output[new_key if reverse else key] = val
                continue

            if reverse:  # backend → frontend
                if key in known_backend_keys:
                    # Troba el front_key corresponent
                    front_key = next((fk for fk, e in self._map.items() if e["backend_key"] == key), key)
                    if isinstance(val, dict):
                        output[front_key] = val
                        continue
                    if normalize:
                        for normalizer in self.get_normalizers(front_key):
                            val = normalizer(val)
                    output[front_key] = val
                else:
                    # Clau desconeguda → la deixem tal qual
                    output[key] = val

            else:  # frontend → backend
                if key in known_front_keys:
                    backend_key = self._map[key]["backend_key"]
                    output[backend_key] = val  # no validació en aquest sentit
                else:
                    # Clau desconeguda → la deixem tal qual
                    output[key] = val

        return output

def profile_define_adminType(profile: Dict) -> Dict[str, Union[str, bool]]:
    """
        Afegeix 'adminType' al perfil:
        - 'globaladmin' si és administrador global
        - 'domainadmin' si és administrador de domini
        - 'mailadmin' si és administrador de correu
        - False si no és administrador

        :param profile: diccionari amb el contingut del perfil
        :return: el mateix diccionari amb la clau 'adminType'
    """
    if not isinstance(profile, dict):
        # Retorn segur si l'entrada no és vàlida
        return {"adminType": False}
    
    if settings.backend == "ldap":
        domain_global_admin = iredutils.bytes2str(profile.get("domainGlobalAdmin", "no"))[0]
        enabled_service = iredutils.bytes2str(profile.get("enabledService", []))
        object_class = iredutils.bytes2str(profile.get("objectClass", []))
        if 'mailadmin' in [cls.lower() for cls in object_class]:
            profile['adminType']= 'mailglobaladmin'
        elif domain_global_admin == "yes":
            profile['adminType']= 'globaladmin'
        elif 'domainadmin' in enabled_service:
            profile['adminType']= 'maildomainadmin' if 'mailadmin' in [cls.lower() for cls in object_class]  else 'domainadmin'
        else:
            profile['adminType']= False
    elif settings.backend in ["mysql", "pgsql"]:
        is_global = int(profile.get("isglobaladmin", 0))
        is_admin = int(profile.get("isadmin", 0))
        table = str(profile.get("table", "")).lower()
        if is_global == 1:
            profile['adminType']= 'globaladmin'
        elif is_admin == 1:
            profile["adminType"] = "mailadmin" if "admin" in table else "domainadmin"
        else:
            profile['adminType']= False
    
    return profile

def accounts_get_first_char_of(accounts):
    chars = list()
    
    if not accounts or not isinstance(accounts, list):
        return chars    
    
    for a in accounts:
        chars.append(a[0].upper())
    chars = list(set(chars)) # eliminate duplicates
    chars.sort()

    return chars

def _normalize_list_mails(items) -> List[str]:
    if not items:
        return []
    # Si és una cadena, la convertim en llista
    if isinstance(items, str):
        raw_list = [s.strip() for s in re.split(r'[,\n\r]+', items) if s.strip()]
    else:
        raw_list = [str(s).strip().lower() for s in items if s]
        
    valid_list = []
    for item in raw_list:
        s = str(item).lower().strip()
        if not s:
            continue
        if iredutils.is_email(s):
            valid_list.append(s)
    return list(dict.fromkeys(valid_list))

def _normalize_list_domains(items) -> List[str]:
    if not items:
        return []
    # Si és una cadena, la convertim en llista
    if isinstance(items, str):
        raw_list = [s.strip() for s in re.split(r'[,\n\r]+', items) if s.strip()]
    else:
        raw_list = [str(s).strip().lower() for s in items if s]
        
    valid_list = []
    for item in raw_list:
        s = str(item).lower().strip()
        if not s:
            continue
        if iredutils.is_domain(s):
            valid_list.append(s)
    return list(dict.fromkeys(valid_list))
