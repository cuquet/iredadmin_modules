# m_system Technical Notes

Aquest document recull detalls tecnics de `libs/m_system` i la seva integracio amb controllers.

## Index

- 1. Contracte de retorn de `LibDecorators`
- 2. KeyMap i `key_map.yaml`
- 3. Normalitzacio de formularis i payloads
- 4. Domain ownership verification
- 5. Search engine (LDAP/SQL)
- 6. Mixins i exportadors
- 7. Integracio amb controllers `m_system`
- 8. Taula controller -> lib method

## 1. Contracte de retorn de `LibDecorators`

Fitxer: `libs/m_system/decorators.py`

Decoradors clau:

- `LibDecorators.safe_sql_method(...)`
- `LibDecorators.safe_ldap_method(...)`

### 1.1 Sortida estandard

Per defecte retornen:

- `(True, data, meta, *extras)`
- `(False, error, meta, *extras)`

On `meta` acostuma a incloure `timestamp` i (LDAP) `source`.

### 1.2 Modes especials

- `no_tuple=True`: retorna directament `data` o `error`.
- `no_hex=True` (SQL): bytes en UTF-8 en lloc de `.hex()`.
- `on_error_pass=True` (SQL): permet continuar flux en excepcio.

### 1.3 Excepcions LDAP mapejades

`safe_ldap_method` transforma errors comuns:

- `ldap.ALREADY_EXISTS` -> `ALREADY_EXISTS`
- `ldap.NO_SUCH_OBJECT` -> `NO_SUCH_ACCOUNT`
- `ldap.SIZELIMIT_EXCEEDED` -> `EXCEEDED_LDAP_SERVER_SIZELIMIT`

Aixo simplifica el tractament de missatges a templates i API.

## 2. KeyMap i `key_map.yaml`

Fitxers:

- `libs/m_system/key_map.yaml`
- `libs/m_system/utils.py` (`class KeyMap`)

### 2.1 Objectiu

Separar claus "frontend" de claus backend LDAP/SQL.

Exemples de mapatge:

- `accountStatus` -> LDAP `accountStatus` / SQL `active`
- `mailQuota` -> LDAP `mailQuota` / SQL `quota`
- `preferredLanguage` -> LDAP `preferredLanguage` / SQL `language`

### 2.2 Flux recomanat

1. Controller llegeix formulari o payload API.
2. Controller normalitza valors base (strings, llistes, quotes, etc.).
3. `KeyMap.remap_dict(...)` converteix claus segons backend.
4. Llibreria CRUD persisteix al backend.

### 2.3 Cas especial `accountSetting`

`KeyMap.remap_dict` transforma `accountSetting/settings` en format adequat:

- LDAP: `list <-> dict` via `account_setting_list_to_dict`.
- SQL: `string <-> dict` via `account_settings_string_to_dict`.

## 3. Normalitzacio de formularis i payloads

Fitxers:

- `libs/m_system/form_utils.py`
- `controllers/m_system/utils.py`

### 3.1 Llistes amb add/remove

`populate_form_list_filtered(form, key)` calcula moviments:

- valors finals (`add`)
- valors eliminats (`remove`)

Admet CSV, multilinia i llistes Python.

### 3.2 Quota

`quota_transformation(name, form)` converteix:

- `mailQuota=1024` + `mailQuotaUnit=MB` -> bytes (int)
- buit -> `0` (unlimited)
- `-1` -> `-1`

### 3.3 Redirects canonics i errors

`controllers/m_system/utils.py` aporta:

- `_redirect_url(...)`
- `_canonical_redirect(...)`
- `_format_errors(...)`
- `_settings_form_payload_to_db(...)`

Aquests helpers redueixen duplicacio en `controllers/m_system/controller.py`.

## 4. Domain ownership verification

Fitxer: `libs/m_system/domain_ownership.py`

Components principals:

- `is_single_domain_verified(primary_domain)`
- `class DomainOwnershipManager(DomainBasic)`

Responsabilitats:

- alta de codis de verificacio
- llistat paginat per estat (`pending`, `done`, `expired`, `all`)
- validacio de permisos de domini (global admin vs domini gestionat)
- marcat de dominis verificats i reinici del flux

Nota tecnica:

- usa `SQLWhereBuilder` per construir filtres robustos.
- `is_single_domain_verified` esta decorat amb `safe_sql_method(no_tuple=True)` i retorna boolea directa.

## 5. Search engine (LDAP/SQL)

Fitxer: `libs/m_system/search.py`

Arquitectura:

- `SearchBase`
- implementacions per backend i tipus (`user`, `domain`, `admin`, `maillist`)
- `SearchEngine.run(...)` retorna grups:
  - `users`, `domains`, `admins`, `maillists`, `total`

Diferencies backend:

- LDAP: cerca en bases limitades segons dominis gestionats.
- SQL: queries directes per taula (`mailbox`, `domain`, `admin`, `maillists`).

## 6. Mixins i exportadors

Entrades principals:

- `libs/m_system/mixins/__init__.py`
- `libs/m_system/mixins/sql/sql_crud_mixin.py`
- `libs/m_system/mixins/ldap/ldap_crud_mixin.py`
- `libs/m_system/mixins/sql/sql_where_builder.py`
- `libs/m_system/mixins/exporter_factory.py`

### 6.1 CRUD mixins

`SQLCRUDMixin` / `LdapCRUDMixin` concentren utilitats compartides:

- validacio `is_email/is_domain`
- comprovacions d'existencia
- canvis de password i verificacio
- enable/disable de comptes

### 6.2 Query builder SQL

`SQLWhereBuilder` evita concatenacions insegures i gestiona:

- equals/in/between/like/or_like
- composicio incremental de condicions
- `where` + `vars` preparats per `web.py`

### 6.3 Export

`ExporterFactory` crea exportadors per:

- SQL: `csv`, `xls` (HTML compatible Excel)
- LDAP: `html`, `ldif`, `json`
- opcionalment `zip` via `ZipExporter`

Esquemes d'export disponibles a `mixins/sql/schemas/*`.

## 7. Integracio amb controllers `m_system`

Fitxers:

- `controllers/m_system/urls.py`
- `controllers/m_system/controller.py`

Rutes gestionades:

- `/system/settings`
- `/system/spampolicy`
- `/system/wblist`
- `/system/greylisting`
- `/system/throttle`
- `/system/log`
- `/verify/domain_ownership`

Peces de `m_system` utilitzades directament:

- `m_system.utils` (redirects, canonical, payload settings)
- `m_system.mixins.ExporterFactory`
- `m_system.domain_ownership.DomainOwnershipManager`
- `m_system.log.Log`

## 8. Taula controller -> lib method

| Ruta | HTTP | Handler | Calls principals | Notes |
|---|---|---|---|---|
| `/verify/domain_ownership` | `GET` | `VerifyOwnership.GET` | `DomainOwnershipManager.list_domains_ownership_verification(...)` | Llistat paginat per `verified/domain/page`. |
| `/verify/domain_ownership` | `POST` | `VerifyOwnership.POST` | `DomainOwnershipManager.verify_domains_with_ownership_verification(...)` | Accio `verify`. |
| `/verify/domain_ownership` | `POST` | `VerifyOwnership.POST` | `DomainOwnershipManager.enable_domains_without_ownership_verification(...)` | Accio `enable_without_verification` (nomes global admin). |
| `/verify/domain_ownership` | `POST` | `VerifyOwnership.POST` | `DomainOwnershipManager.restart_domains_ownership_verification(...)` | Accio `restart_verification` (nomes global admin). |
| `/system/settings` | `GET` | `SystemSettings.GET` | `libs.iredutils.get_settings_from_db()` | Render de settings globals. |
| `/system/settings` | `POST` | `SystemSettings.POST` | `controllers.m_system.utils._settings_form_payload_to_db(...)`, `libs.iredutils.store_settings_in_db(...)` | Guarda account `global`. |
| `/system/spampolicy` | `GET` | `SystemSpampolicy.GET` | `libs.m_amavisd.spampolicy.get_spam_policy(account='@.')` | Llegir politica global. |
| `/system/spampolicy` | `POST` | `SystemSpampolicy.POST` | `controllers.m_system.utils._spampolicy_form_payload_to_db(...)`, `libs.m_amavisd.spampolicy.SpamPolicy(...).update_spam_policy(...)` | Actualitzacio de politica global. |
| `/system/wblist[/wb]` | `GET` | `SystemWBlist.GET` | `WblistRDNS.get_wblist_rdns()`, `libs.m_amavisd.wblist.get_wblist('@.')` | Carrega RDNS + sender/recipient WB list. |
| `/system/wblist/rdns` | `POST` | `SystemWBlist.POST` | `controllers.m_system.utils._rdns_form_payload_to_db(...)`, `WblistRDNS.reset_wblist_rdns(...)` | Normalitza dominis/IP via `_normalize_list_domains_ips`. |
| `/system/wblist/wb` | `POST` | `SystemWBlist.POST` | `controllers.m_system.utils._wblist_form_payload_to_db(...)`, `libs.m_amavisd.wblist.update_wblist(...)` | Update WB list amavisd global (`@.`). |
| `/system/greylisting` | `GET` | `SystemGreylisting.GET` | `libs.m_iredapd.greylist.get_greylisting(account='@.')` | Llegir estat global + llistes. |
| `/system/greylisting` | `POST` | `SystemGreylisting.POST` | `controllers.m_system.utils._greylist_form_payload_to_db(...)`, `libs.m_iredapd.greylist.update_greylisting('@.', payload)` | Update greylisting global. |
| `/system/throttle` | `GET` | `SystemThrottle.GET` | `libs.m_iredapd.throttle.get_throttle_setting('@.')` | Llegir inbound/outbound global. |
| `/system/throttle` | `POST` | `SystemThrottle.POST` | `controllers.m_system.utils._throttle_form_payload_to_db(...)`, `Throttle(...).update_throttle_settings()`, `Throttle(...).remove_throttle_tracking()`, `Throttle(...).remove_throttle_settings()` | Aplica per direccio `inbound/outbound`. |
| `/system/log` | `GET` | `SystemLog.GET` | `libs.m_system.log.Log.list_logs(...)` | Filtres: `query_string`, `event`, `domain`, `admin`. |
| `/system/log` | `POST` | `SystemLog.POST` | `libs.m_system.log.Log.delete_logs(ids=..., delete_all=...)` | Suporta `delete` i `deleteAll`. |
| `/system/log/export` i `/activities/system/log/export` | `GET` / `POST` | `SystemLogExport._handle_export` | `libs.m_system.log.Log.list_logs(page=0, ...)`, `ExporterFactory.from_SQL(..., schema=LOG_EXPORT_SCHEMA, ...)`, `exporter.export(...)` | Export filtrat o complet en `xls/csv` (+ `zip`). |

---

Si afegeixes funcionalitat nova a sistema, el minim recomanat es:

1. Definir o ampliar mapes a `key_map.yaml`.
2. Posar normalitzacio comuna a `m_system`.
3. Reutilitzar decoradors de seguretat de retorn.
4. Deixar el controller com a capa fina de wiring.
