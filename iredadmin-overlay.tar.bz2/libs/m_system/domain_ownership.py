# libs/m_system/domain_ownership.py
import web
from typing import Any, Dict, List, Tuple, Union, Sequence, Optional
import time
from dns import resolver
import pycurl
from io import StringIO 

import settings
from libs import iredutils

from libs.m_crudlib.domain import DomainBasic
from libs.m_system.decorators import LibDecorators
from libs.m_system.mixins import SQLWhereBuilder

session = web.config.get('_session', {})

@LibDecorators.safe_sql_method(no_tuple=True, no_hex=True)
def is_single_domain_verified(primary_domain: Optional[str] = None) -> bool:
    """
        Retorna True si algun registre domain_ownership associat
        al domini principal està verificat.

        Args:
            primary_domain: El domini primari.

        Returns:
            bool
    """
    if not primary_domain or not iredutils.is_domain(primary_domain):
        return False

    primary_domain = primary_domain.lower()

    builder = SQLWhereBuilder()
    builder.add_equals("domain", primary_domain)
    builder.add_equals("verified", 1)

    sql_where, sql_vars = builder.build()

    qr = web.conn_iredadmin.select(
        "domain_ownership",
        where=sql_where,
        vars=sql_vars,
        what="id",
        limit=1,
    )

    return bool(qr)

class DomainOwnershipManager(DomainBasic):
    def __init__(self):
        super().__init__()
        self.is_global_admin=session.get("is_global_admin")

    @LibDecorators.safe_sql_method(no_tuple=True, no_hex=True)
    def count_pending_ownership_verifications(self) -> int:
        """
            Retorna el nombre de dominis amb verificació pendent.

            Condicions:
            - verified = 0
            - expire >= current timestamp
            - Si l'usuari no és admin global, només els dominis del seu compte
        """
        now = int(time.time())

        builder = SQLWhereBuilder()
        builder.add_equals("verified", 0)
        builder.add_if("expire >= $now", "now", now)

        if not self.is_global_admin:
            ok, managed_domains, *rest = self.get_managed_domains(names_only=True)
            if not ok:
                return (False, managed_domains)

            builder.add_in("domain", managed_domains)

        sql_where, sql_vars = builder.build()
        qr = web.conn_iredadmin.query(
            f"SELECT COUNT(*) AS cnt FROM domain_ownership WHERE {sql_where}",
            vars=sql_vars
        )
        return qr[0].cnt if qr else 0

    def _generate_verify_code(self) -> str:
        """
            Genera un codi aleatori de verificació per a un domini.

            Retorna:
                str: Codi prefixat amb DOMAIN_OWNERSHIP_VERIFY_CODE_PREFIX.
        """
        s = iredutils.generate_random_strings(20)
        return settings.DOMAIN_OWNERSHIP_VERIFY_CODE_PREFIX + s

    def _get_single_domain_aliases(self, primary_domain: str = None) -> Tuple[bool, str]:
        if not primary_domain or not iredutils.is_domain(primary_domain):
            return (False, 'INVALID_DOMAIN_NAME')

        # NOTE: Fem servir la mateixa lib de domini per SQL i LDAP.
        # Això evita duplicar lògica de backend i manté un contracte homogeni.
        from libs.m_crudlib import domain as lib_domain

        qr = lib_domain.Domain(domain=primary_domain).get_domain_aliases()
        if not qr[0]:
            return (False, qr[1])

        aliases = [str(a).lower() for a in (qr[1] or [])]
        alias_string = ",".join(aliases)
        return (True, alias_string)

    @LibDecorators.safe_sql_method
    def list_domains_ownership_verification(
        self,
        status: str = "all",
        domain: Optional[str] = None,
        current_page:int=1
        ) -> Tuple[bool, Dict[str, Any]]:
        """
            Llista dominis segons estat de verificació.

            Args:
                status (str): Filtre d'estat; valors acceptats: "all", "pending", "done".
                            Pot arribar amb soroll (p. ex. "all?page=1"); s'hi fa
                            normalització i s'ignora la part de query si és present.
                domain (Optional[str]): nom de domini (ex. "example.org"), o "alldomains",
                                        o None (tots).
                current_page (int): pàgina sol·licitada (1-based), s'utilitza per paginació.

            Returns:
                Tuple[bool, Dict]: (True, result_dict) o (False, {"error": "..."}).

                result_dict:
                    {
                        "total": int,
                        "records": [ {<row dict>}, ... ],
                        "managed_domains": [ ... ],
                        "current_page": int,
                        "page_size": int,
                    }
        """

        # NOTE: --- Validar status ---
        status = status.lower()
        if status not in ("all", "pending", "done", "expired"):
            return (False, {"error": f"Invalid status '{status}' — expected: all | pending | done | expired"})

        # NOTE: --- Normalitza domini ---
        if domain:
            domain = domain.lower()
            if domain != "alldomains" and not iredutils.is_domain(domain):
                return (False, {"error": f"Invalid domain filter '{domain}'"})
        else:
            domain = None

        builder = SQLWhereBuilder()

        # NOTE: --- filtre Status ---
        now = int(time.time())
        if status == "pending":
            builder.add_equals("verified", "0")
            builder.add_if("expire >= $now", "now", now)
        elif status == "expired":
            builder.add_equals("verified", 0)
            builder.add_if("expire < $now", "now", now)
        elif status == "done":
            builder.add_equals("verified", "1")
        else:  # NOTE: "all"
            builder.add_in("verified", ["0", "1"])

        ok, managed_domains, *rest = self.get_all_domains(names_only=True)
        if not ok:
            return (False, managed_domains)
        managed_domains = {d.lower() for d in managed_domains}

        # NOTE: Cas 1: NO és admin global → cal aplicar els permisos sobre dominis
        if not self.is_global_admin:
            if domain and domain != "alldomains":
                if domain not in managed_domains:
                    return (False, "PERMISSION_DENIED")
                allowed = {domain}
            else:
                allowed = managed_domains

            builder.add_in("domain", list(allowed))

        # NOTE: Cas 2: ADMIN GLOBAL → només filtrar per domini si s'ha proporcionat
        else:
            if domain and domain != "alldomains":
                builder.add_equals("domain", domain)
            allowed = managed_domains

        sql_where, sql_vars = builder.build()

        if sql_where:
            total = (
                web.conn_iredadmin.select(
                    'domain_ownership',
                    vars=sql_vars or None,
                    what='COUNT(id) AS total',
                    where=sql_where,
                )[0].total
            ) or 0
        else:
            total = (
                web.conn_iredadmin.select(
                    'domain_ownership',
                    what='COUNT(id) AS total',
                )[0].total
            ) or 0

        qr = web.conn_iredadmin.select(
            "domain_ownership", 
            where=sql_where or None, 
            vars=sql_vars,
            offset=(current_page - 1) * settings.PAGE_SIZE_LIMIT,
            limit=settings.PAGE_SIZE_LIMIT,
        )
        records = [dict(r) for r in qr]
        now = int(time.time())
        for r in records:
            if r["verified"] == 1:
                r["status"] = "done"
            elif r.get("expire", 0) < now:
                r["status"] = "expired"
            else:
                r["status"] = "pending"

        return (True, {
            "total": total,
            "records": records,
            "managed_domains": list(allowed),
            "current_page": current_page,
        })

    @LibDecorators.safe_sql_method
    def set_verify_code_for_new_domain(self, primary_domain: str, alias_domains: Union[None, Sequence[str]] = None) -> Tuple[bool, str]:
        """
            Assigna codis de verificació per a un domini principal i els seus alias.

            Args:
                primary_domain: Domini que es vol validar.
                alias_domains: Llista d’alias opcionals.

            Retorna:
                (True, 'VERIFY_CODES_SET') si OK
                (False, error) si falla
        """
        if not settings.REQUIRE_DOMAIN_OWNERSHIP_VERIFICATION:
            return (True, 'VERIFICATION_NOT_REQUIRED')

        if not iredutils.is_domain(primary_domain):
            return (False, 'INVALID_DOMAIN_NAME')

        alias_domains = [d.lower() for d in alias_domains or [] if iredutils.is_domain(d)]
        expire = int(time.time()) + settings.DOMAIN_OWNERSHIP_EXPIRE_DAYS * 86400

        for d in alias_domains or [None]:
            try:
                web.conn_iredadmin.insert(
                    'domain_ownership',
                    domain=primary_domain,
                    alias_domain=d or '',
                    verify_code=self._generate_verify_code(),
                    expire=expire)
            except Exception as e:
                if e.__class__.__name__ != 'IntegrityError':
                    return (False, repr(e))
        return (True, 'VERIFY_CODES_SET')

    @LibDecorators.safe_sql_method
    def _mark_single_domain_ownership_as_verified(self, rid: Union[int, None] =None, domain: Union[str, None] = None, message: str = None) -> Tuple[bool, str]:
        """
            Marca un registre domain_ownership com verificat.

            Args:
                rid: ID del registre.
                domain: Nom del domini (opcional, si no hi ha rid).
                message: Missatge informatiu.

            Retorna:
                (True, 'DOMAIN_VERIFIED') si OK
                (False, error) si falla
        """

        if not (rid or domain):
            return False, 'MISSING_IDENTIFIER'

        if domain and not iredutils.is_domain(domain):
            return False, 'INVALID_DOMAIN_NAME'

        message = message or ''

        if domain:
            qr = web.conn_iredadmin.select(
                'domain_ownership',
                vars={'domain': domain},
                what='id',
                where="(alias_domain=$domain) OR (domain=$domain AND alias_domain='')",
                limit=1)
            if qr:
                rid = qr[0].id
            else:
                return (False, 'NO_SUCH_ACCOUNT')

        web.conn_iredadmin.update(
            'domain_ownership',
            vars={'id': rid},
            verified=1,
            message=message,
            admin=session.get('username'),
            last_verify=web.sqlliteral('NOW()'),
            where='id=$id')
        return (True, 'DOMAIN_VERIFIED')

    def _enable_single_domain_with_ownership_verification(self, primary_domain:str, alias_domain: Union[str, None] = None) -> Tuple[bool]:
        """
            Activa un domini verificat dins el backend seleccionat (SQL / LDAP).

            SQL:
                - Marca domain.active = 1

            LDAP:
                - Activa serveis associats
                - Afegeix 'mail' com enabledService

            Args:
                primary_domain: Domini principal.
                alias_domain: Alias opcional.

            Retorna:
                (True,) si OK
                (False, <reason>) si falla
        """
        if not primary_domain or not iredutils.is_domain(primary_domain):
            return (False, 'INVALID_DOMAIN_NAME')

        from libs.m_crudlib import domain as lib_domain

        domain_lib = lib_domain.Domain(domain=primary_domain)
        qr_enable = domain_lib.update({'accountStatus': 'active'})
        if not qr_enable[0]:
            return (False, qr_enable[1])

        # NOTE: En LDAP, garantir que el servei `mail` torna a estar actiu
        # quan el domini passa de pending -> verified.
        if settings.backend == 'ldap':
            qr_mail = domain_lib.add_or_remove_enabled_service_by_dn(
                dn=domain_lib.dn_domain,
                values='mail',
                action='add',
            )
            if not qr_mail[0]:
                return (False, qr_mail[1])

        if alias_domain and iredutils.is_domain(alias_domain):
            qr_alias = domain_lib.set_domain_alias_status(alias_domain=alias_domain, active=True)
            if not qr_alias[0]:
                return (False, qr_alias[1])

        return (True, )

    def _enable_single_domain_without_ownership_verification(self, r, reason: str) -> Tuple[bool, Dict[str, Any]]:
        """
            Marca un registre domain_ownership com verificat i activa el domini/alias
            sense validació externa de propietat.

            Args:
                r: registre domain_ownership (row)
                reason: text que es desa a message

            Retorna:
                (
                    ok: bool,
                    {
                        "id": int,
                        "domain": str,
                        "alias_domain": str,
                        "verified": bool,
                        "reason": str
                    }
                )
        """
        rid = int(r.id)
        domain = str(r.domain).lower()
        alias_domain = str(r.alias_domain).lower()

        ok, msg, *rest = self._mark_single_domain_ownership_as_verified(
            rid=rid,
            message=reason
        )
        if not ok:
            return False, {
                "id": rid,
                "domain": domain,
                "alias_domain": alias_domain,
                "verified": False,
                "reason": msg,
            }

        ok2, *detail = self._enable_single_domain_with_ownership_verification(
            primary_domain=domain,
            alias_domain=alias_domain
        )
        if not ok2:
            return (False, {
                "id": rid,
                "domain": domain,
                "alias_domain": alias_domain,
                "verified": False,
                "reason": f"ENABLE_FAILED: {detail}",
            })

        return (True, {
            "id": rid,
            "domain": domain,
            "alias_domain": alias_domain,
            "verified": True,
            "reason": reason,
        })

    def _verify_single_domain_ownership(self, r) -> Tuple[bool, Dict[str, Any]]:
        """
            Verifica propietat d'un registre domain_ownership provant domini principal i alias.

            Returns:
                (
                    verified: bool,
                    {
                        "id": int,
                        "domain": str,
                        "alias_domain": str,
                        "verified": bool,
                        "reason": str
                    }
                )
        """
        rid = int(r.get('id'))# NOTE: int(r.id)
        primary_domain = str(r.domain).lower()
        alias_domain = str(r.alias_domain).lower()
        verify_code = str(r.verify_code)

        # NOTE: 1. Obtenir aliases (LDAP o SQL)

        ok_aliases, aliases_data = self._get_single_domain_aliases(primary_domain)
        if not ok_aliases:
            aliases = []
        else:
            if isinstance(aliases_data, str):
                # NOTE: ja ve com string separada per comes
                aliases = [x.strip().lower() for x in aliases_data.split(",") if x.strip()]
            else:
                aliases = [x.strip().lower() for x in aliases_data]

        # NOTE: Afegim alias_domain si no hi és
        if alias_domain and alias_domain not in aliases:
            aliases.append(alias_domain)

        # NOTE: Afegim primary com primer a provar
        check_domains = [primary_domain] + [a for a in aliases if a != primary_domain]

        verified = False
        reason = ""
        detail = ""

        # NOTE: 2. Funcions auxiliars
        def check_http(domain):
            """
            Torna (True, reason) si verifica per HTTP/HTTPS
            """
            web_file = f"{domain}/{verify_code}"
            for scheme in ("http", "https"):
                url = f"{scheme}://{web_file}"
                try:
                    c = pycurl.Curl()
                    if settings.HTTP_PROXY:
                        c.setopt(c.PROXY, settings.HTTP_PROXY)

                    c.setopt(c.URL, url)
                    c.setopt(c.FOLLOWLOCATION, False)
                    c.setopt(c.CONNECTTIMEOUT, settings.DOMAIN_OWNERSHIP_VERIFY_TIMEOUT)
                    c.setopt(c.TIMEOUT, settings.DOMAIN_OWNERSHIP_VERIFY_TIMEOUT)

                    buf = StringIO()
                    c.setopt(c.WRITEFUNCTION, buf.write)

                    c.perform()
                    status = c.getinfo(pycurl.RESPONSE_CODE)
                    body = buf.getvalue().strip()

                    if status == 200 and body == verify_code:
                        return True, f"{scheme} matches"

                except Exception as e:
                    pass
                finally:
                    try:
                        c.close()
                    except:
                        pass

            return False, "http/https mismatch"

        def check_dns(domain):
            """
            Torna (True, reason) si verifica TXT
            """
            try:
                res = resolver.Resolver()
                res.timeout = settings.DOMAIN_OWNERSHIP_VERIFY_TIMEOUT
                answers = res.query(domain, "TXT")

                for rec in answers:
                    if verify_code == rec.to_text().strip('"'):
                        return True, "DNS matches"

                return False, "TXT not found"

            except Exception as e:
                return False, f"DNS error: {repr(e)}"

        # NOTE: 3. TEST → DOMAIN + ALIASES
        for d in check_domains:
            # NOTE: Web
            ok, reason_web = check_http(d)
            if ok:
                verified = True
                reason = reason_web
                alias_domain = d
                break

            # NOTE: DNS si web KO
            ok, reason_dns = check_dns(d)
            if ok:
                verified = True
                reason = reason_dns
                alias_domain = d
                break

            detail += f"{d}: {reason_web}; {reason_dns} | "

        expire = int(time.time()) + settings.DOMAIN_OWNERSHIP_EXPIRE_DAYS * 86400

        # NOTE: 4. Persistència
        if verified:
            self._mark_single_domain_ownership_as_verified(rid=rid, message=reason)
            self._enable_single_domain_with_ownership_verification(primary_domain, alias_domain)
        else:
            web.conn_iredadmin.update(
                "domain_ownership",
                message=detail,
                last_verify=web.sqlliteral("NOW()"),
                expire=expire,
                where=f"id={rid}",
            )

        return (verified, {
            "id": rid,
            "domain": primary_domain,
            "alias_domain": alias_domain,
            "verified": verified,
            "reason": reason if verified else detail,
        })

    def _restart_single_domain_ownership(self, r: Dict[str, Any]) -> Tuple[bool, Dict[str, Any]]:
        """
            Reinicia la verificació d'un registre domain_ownership EXPIRAT.

            Accions:
                - Regenera verify_code
                - Reassigna expire
                - Neteja message i last_verify
                - NO marca verified
                - NO activa el domini

            Preconditions:
                - r["verified"] == 0
                - r["expire"] < now

            Returns:
                (
                    ok: bool,
                    {
                        "id": int,
                        "domain": str,
                        "alias_domain": str,
                        "status": str,          # NOTE: pending | skipped
                        "reason": str
                    }
                )
        """
        rid = int(r.get("id"))
        domain = str(r.get("domain", "")).lower()
        alias_domain = str(r.get("alias_domain", "")).lower()

        now = int(time.time())

        # NOTE: --- Seguretat: només expirats ---
        if r.get("verified") == 1:
            return (False, {
                "id": rid,
                "domain": domain,
                "alias_domain": alias_domain,
                "status": "skipped",
                "reason": "ALREADY_VERIFIED",
            })

        if int(r.get("expire", 0)) >= now:
            return (False, {
                "id": rid,
                "domain": domain,
                "alias_domain": alias_domain,
                "status": "skipped",
                "reason": "NOT_EXPIRED",
            })

        new_code = self._generate_verify_code()
        new_expire = now + settings.DOMAIN_OWNERSHIP_EXPIRE_DAYS * 86400

        web.conn_iredadmin.update(
            "domain_ownership",
            vars={"id": rid},
            verify_code=new_code,
            expire=new_expire,
            message="",
            last_verify=None,
            admin=session.get("username"),
            where="id=$id",
        )

        return (True, {
            "id": rid,
            "domain": domain,
            "alias_domain": alias_domain,
            "status": "pending",
            "reason": "VERIFICATION_RESTARTED",
        })

    def verify_domains_with_ownership_verification(self, list_id: Sequence[int]) -> Tuple[bool, List[Dict[str, Any]]]:
        """
            Verifica múltiples dominis donats per ID de domain_ownership.

            Per cada registre:
                - Execució de _verify_single_domain_ownership()
                - Recopila resultats

            Args:
                list_id: Seqüència d'IDs a verificar.

            Retorna:
                (True, [...])  si TOTS han estat verificats
                (False, [...]) si algun ha fallat
        """
        builder = SQLWhereBuilder()
        builder.add_equals("verified", 0)
        builder.add_in("id", list_id)
        builder.add_if("expire >= $now", "now", int(time.time()))

        sql_where, sql_vars = builder.build()

        qr = web.conn_iredadmin.select(
            "domain_ownership",
            where=sql_where,
            vars=sql_vars,
        )

        if not qr:
            return (False, [])

        results: List[Dict[str, Any]] = []

        for r in qr:
            ok, info = self._verify_single_domain_ownership(r)
            results.append(info)

        all_ok = all(item["verified"] for item in results)
        return (all_ok, results)

    def enable_domains_without_ownership_verification(self, list_id: Sequence[int]) -> Tuple[bool, List[Dict[str, Any]]]:
        """
            Activa dominis sense requerir validació explícita de propietat.
            Només pot ser executat per un global admin.

            Workflow:
                - Per cada ID:
                    1) Marca domain_ownership com verificat
                    2) Activa el domini/alias en backend (SQL/LDAP)
                - Retorna resultat acumulat

            Args:
                list_id: Seqüència d'IDs de domain_ownership.

            Retorna:
                (
                    all_ok: bool,
                    results: List[
                        {
                            "id": int,
                            "domain": str,
                            "alias_domain": str,
                            "verified": bool,
                            "reason": str
                        }
                    ]
                )
        """
        builder = SQLWhereBuilder()
        builder.add_in("id", list_id)

        sql_where, sql_vars = builder.build()

        qr = web.conn_iredadmin.select(
            "domain_ownership",
            where=sql_where,
            vars=sql_vars,
        )

        if not qr:
            return (False, [])

        results: List[Dict[str, Any]] = []
        reason = f"Activated without verification by global admin: {session.get('username')}"

        for r in qr:
            ok, data = self._enable_single_domain_without_ownership_verification(
                r=r,
                reason=reason
            )
            results.append(data)

        all_ok = all(item["verified"] for item in results)
        return (all_ok, results)

    def restart_domains_ownership_verification(self, list_id: Sequence[int]) -> Tuple[bool, List[Dict[str, Any]]]:
        """
            Reinicia la verificació de múltiples dominis EXPIRATS.

            Per cada registre:
                - Només processa:
                    verified = 0 AND expire < now
                - Executa _restart_single_domain_ownership()

            Args:
                list_id: Seqüència d'IDs de domain_ownership.

            Returns:
                (
                    all_ok: bool,
                    results: List[
                        {
                            "id": int,
                            "domain": str,
                            "alias_domain": str,
                            "status": str,   # NOTE: pending | skipped
                            "reason": str
                        }
                    ]
                )
        """
        if not list_id:
            return (False, 'INVALID_DOMAIN_NAME')

        builder = SQLWhereBuilder()
        builder.add_in("id", list_id)
        builder.add_equals("verified", 0)
        builder.add_if("expire < $now", "now", int(time.time()))

        sql_where, sql_vars = builder.build()

        qr = web.conn_iredadmin.select(
            "domain_ownership",
            where=sql_where,
            vars=sql_vars,
        )

        if not qr:
            return (False, 'NOT_EXPIRED')

        results: List[Dict[str, Any]] = []

        for r in qr:
            ok, data = self._restart_single_domain_ownership(dict(r))
            results.append(data)

        all_ok = all(item["status"] == "pending" for item in results)
        return (all_ok, results)
