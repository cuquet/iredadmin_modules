# Modul `m_system`

Aquest modul agrupa utilitats transversals del projecte: decoradors, normalitzacio de payloads, mapatge de claus, helpers de cerca, verificacio de propietat de domini i mixins SQL/LDAP.

## Objectiu

`m_system` evita duplicacio entre UI i API i centralitza comportaments comuns:

- contractes de retorn i captura d'errors (`LibDecorators`)
- normalitzacio de formularis i payloads
- mapatge frontend <-> backend (`key_map.yaml` + `KeyMap`)
- construccio de filtres SQL/LDAP
- export (CSV/XLS/HTML/LDIF/JSON/ZIP)

## Documentacio ampliada

Per detalls tecnics (contractes de retorn, fluxos interns i decisions de disseny), consulta:

- `libs/m_system/README.technical.md`

## Fitxers principals

- `libs/m_system/decorators.py`
- `LibDecorators.safe_sql_method` i `LibDecorators.safe_ldap_method`.
- Normalitzen sortides de metodes de llibreria en format tuple consistent per UI/API.

- `libs/m_system/utils.py`
- `KeyMap` carrega `key_map.yaml` i fa remap de claus segons backend (`ldap` o `sql`).
- Helpers comuns: definicio de rols (`profile_define_adminType`) i normalitzacio de llistes.

- `libs/m_system/form_utils.py`
- Transformacions de formulari (llistes `add/remove`, quota amb unitats).

- `libs/m_system/jinja_filters.py`
- Filtres Jinja utilitzats per templates (quota bytes<->human, regex, urldecode, errors->html).

- `libs/m_system/domain_ownership.py`
- Gestio de verificacio de domini (`domain_ownership`) i logica de permisos.

- `libs/m_system/search.py`
- Motor de cerca unificat per usuaris, dominis, admins i llistes, amb implementacio LDAP/SQL.

- `libs/m_system/log.py`
- Consulta i eliminacio de logs del sistema amb filtres segurs.

## Submodul `mixins`

`libs/m_system/mixins/` exposa peces reutilitzables:

- SQL: `SQLCRUDMixin`, `SQLHelper`, `SQLWhereBuilder`, `sql_export.py`, `schemas/*`
- LDAP: `LDAPHelper`, `LdapCRUDMixin`, `LdapRDNMixin`, `LdapLDIFMixin`, `ldap_ldif_export.py`
- iredapd/amavisd: normalitzadors i validacions de llistes
- exportacio: `ExporterFactory` + `ZipExporter`
- enums de domini: `Direction`, `ListType`, `LogType`, `MsgsContentType`, `MsgsQuarType`

## Integracio amb controllers

Rutes principals de sistema:

- `controllers/m_system/urls.py`
- `/system/settings`
- `/system/spampolicy`
- `/system/wblist`
- `/system/greylisting`
- `/system/throttle`
- `/system/log`
- `/verify/domain_ownership`

Controladors:

- `controllers/m_system/controller.py`
- Reutilitzen `m_system.utils` per redirects canonics i normalitzacio de payload.
- Reutilitzen `ExporterFactory` per exportacions.

## Recomanacions de manteniment

- Si afegeixes un camp nou per UI/API, actualitza primer `libs/m_system/key_map.yaml`.
- Mantingues paritat SQL/LDAP en mapes i normalitzadors.
- Evita logica de negoci en controllers: posa-la a libs (`m_crudlib`, `m_system`, mixins).
- Per metodes nous de llibreria, usa `@LibDecorators.safe_sql_method` o `@LibDecorators.safe_ldap_method` per mantenir contracte estable.

# 📦 Llicència
Aquest projecte s’ofereix sota la llicència [MIT](https://choosealicense.com/licenses/mit/). Pots modificar-lo, distribuir-lo i integrar-lo lliurement.

# 🤝 Contribucions
Les contribucions són benvingudes! Si tens idees, millores o correccions, obre un issue o envia un pull request.
[![PayPal - Donate](https://img.shields.io/badge/PayPal-Donate-005EA6?logo=paypal&logoColor=white)](https://www.paypal.me/cuquet74)
