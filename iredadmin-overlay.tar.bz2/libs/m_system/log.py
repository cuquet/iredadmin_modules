# libs/m_system/log.py
import web
from typing import Optional, Dict, List, Any

import settings
from libs import iredutils
from libs.panel import LOG_EVENTS

from libs.m_system.decorators import LibDecorators
from libs.m_crudlib import admin as lib_admin
from libs.m_crudlib import domain as lib_domain
from libs.m_system.mixins import SQLWhereBuilder

session = web.config.get('_session')


class Log():
    @LibDecorators.safe_sql_method
    def list_logs(self, page: int = 1, payload: Optional[Dict] = None) -> tuple[bool, Any]:
        event = web.safestr(payload.get('event'))
        domain = web.safestr(payload.get('domain'))
        admin = web.safestr(payload.get('admin'))
        query = payload.get('query_string')

        builder = SQLWhereBuilder()
        if event in LOG_EVENTS and event != 'all':
            builder.add_equals("event", event)

        if iredutils.is_domain(domain):
            if session.get('is_global_admin') or lib_admin.Admin().is_domain_admin(domain=domain, admin=session['username']):
                builder.add_equals("domain", domain)

        if not session.get('is_global_admin'):
            builder.add_equals("admin", session.get('username'))
        elif iredutils.is_email(admin):
            builder.add_equals("admin", admin)

        # Cerca general (IP, sender, recipient)
        if query:
            like = "%{}%".format(query)
            builder.add_or_like(['admin', 'ip', 'username', 'event', 'loglevel', 'msg'], like)

        sql_where, sql_vars = builder.build()
        if not sql_where:  # si no hi ha condicions
            sql_where = None
            sql_vars = None

        # Total count
        total = (web.conn_iredadmin.select(
            'log',
            vars=sql_vars or None,
            what='COUNT(id) AS total',
            where=sql_where,
        )[0].total) or 0

        sql_limit = None
        sql_offset = None
        if page > 0:
            sql_limit = settings.PAGE_SIZE_LIMIT
            sql_offset = (page - 1) * settings.PAGE_SIZE_LIMIT

        # Get records.
        records = web.conn_iredadmin.select(
            'log',
            vars=sql_vars or None,
            where=sql_where,
            order='timestamp DESC',
            limit=sql_limit,
            offset=sql_offset
        )

        # Get all managed domains under control.
        qr = lib_domain.Domain().get_all_domains(names_only=True)
        if qr[0]:
            all_domains = qr[1]

        # Get all admins.
        qr = lib_admin.Admin().list(email_only=True)
        if qr[0]:
            all_admins = qr[1]

        return (True, {
            'total':total, 
            'records': list(records),
            'page': page,
            'query_string': query,
            'all_domains': all_domains,
            'all_admins': all_admins,
        })

    @LibDecorators.safe_sql_method
    def delete_logs(self, ids:List=None , delete_all:bool=False) -> tuple[bool, Optional[str]]:

        if delete_all:
            # 👈 sense condicions, elimina tot
            web.conn_iredadmin.delete('log', where="1=1")
        else:
            if ids:
                builder = SQLWhereBuilder()
                builder.add_in("id", ids)
                sql_where, sql_vars = builder.build()
                if sql_where:  # 👈 només elimina si hi ha condicions
                    web.conn_iredadmin.delete('log', where=sql_where, vars=sql_vars)

        return (True, 'DELETED')
