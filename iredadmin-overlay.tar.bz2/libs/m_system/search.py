# libs/m_system/search.py
import web
from typing import List, Dict, Any

import settings

from libs.m_crudlib import domain as lib_domain

session = web.config.get('_session')

class SearchBase:
    type = None      # 'user', 'domain', 'admin', 'maillist'
    Wrap = None

    def __init__(self):
        if not getattr(self, "Wrap", None):
            raise RuntimeError(f"{self.__class__.__name__} has no Wrap defined")
        self.backend = self.Wrap()
        self.conn = self.backend.conn

    def search(self, text: str, status: str) -> List[Dict[str, Any]]:
        raise NotImplementedError

if settings.backend == "ldap":
    import ldap
    from ldap.filter import escape_filter_chars
    from libs.ldaplib import attrs
    from libs.m_crudlib import LDAPWrap as Wrap
    from libs.m_system.mixins import LdapCRUDMixin

    class LDAPBase(SearchBase, LdapCRUDMixin):
        Wrap = Wrap
        SCOPE = ldap.SCOPE_SUBTREE

        def get_search_bases(self)-> List[str]:
            # Admin global → tot LDAP
            if self.is_global_admin(session['username']):
                return [settings.ldap_basedn, settings.ldap_domainadmin_dn]
            # Sinó: dominis administrats
            bases = []
            ok, doms = lib_domain.Domain().get_managed_domains(names_only=True)
            if ok and doms:
                for d in doms:
                    bases.append(self.rdn_value_to_domain_dn(d))
            return bases

    class SearchUsersLDAP(LDAPBase):
        type = "user"
        oc = "(objectClass=mailUser)"
        attrs = ["mail", "cn", "shadowAddress", "accountStatus"]

        def search(self, text, status):
            s = escape_filter_chars(text)
            fil = [
                self.oc,
                f"(|(mail=*{s}*)(shadowAddress=*{s}*)(cn=*{s}*))",
            ]

            if status == "active":
                fil.append("(accountStatus=active)")
            elif status == "disabled":
                fil.append("(!(accountStatus=active))")

            flt = "(&" + "".join(fil) + ")"
            out = []

            for dn in self.get_search_bases():
                try:
                    res = self.conn.search_s(dn, self.SCOPE, flt, self.attrs)
                except Exception:
                    res = []

                for _dn, entry in res:
                    out.append({
                        "type": self.type,
                        "mail": self.bytes2str(entry.get("mail", [b""])[0]),
                        "cn": self.bytes2str(entry.get("cn", [b""])[0]),
                        "status": self.bytes2str(entry.get("accountStatus", [b"unknown"])[0]),
                        "extra": {},
                    })
            return out

    class SearchDomainsLDAP(LDAPBase):
        type = "domain"
        oc = "(objectClass=mailDomain)"
        attrs = ["domainName", "domainAliasName", "accountStatus"]

        def search(self, text, status):
            s = escape_filter_chars(text)
            fil = [
                self.oc,
                f"(|(domainName=*{s}*)(domainAliasName=*{s}*))",
            ]

            flt = "(&" + "".join(fil) + ")"
            out = []

            for dn in self.get_search_bases():
                try:
                    res = self.conn.search_s(dn, self.SCOPE, flt, self.attrs)
                except Exception:
                    res = []

                for _dn, entry in res:
                    mail = self.bytes2str(entry.get("domainName", [b""])[0])
                    out.append({
                        "type": self.type,
                        "mail": mail,
                        "cn": mail,
                        "status": self.bytes2str(entry.get("accountStatus", [b"unknown"])[0]),
                        "extra": {
                            "aliases": [self.bytes2str(a) for a in entry.get("domainAliasName", [])]
                        },
                    })
            return out

    class SearchAdminsLDAP(LDAPBase):
        type = "admin"
        oc = "(objectClass=mailAdmin)"
        attrs = ["mail", "cn", "domainGlobalAdmin", "accountStatus"]

        def search(self, text, status):
            s = escape_filter_chars(text)
            fil = [self.oc, f"(|(mail=*{s}*)(cn=*{s}*))"]
            flt = "(&" + "".join(fil) + ")"
            out = []

            for dn in self.get_search_bases():
                try:
                    res = self.conn.search_s(dn, self.SCOPE, flt, self.attrs)
                except Exception:
                    res = []

                for _dn, entry in res:
                    out.append({
                        "type": self.type,
                        "mail": self.bytes2str(entry.get("mail", [b""])[0]),
                        "cn": self.bytes2str(entry.get("cn", [b""])[0]),
                        "status": self.bytes2str(entry.get("accountStatus", [b"unknown"])[0]),
                        "extra": {},
                    })
            return out

    class SearchMailListsLDAP(LDAPBase):
        type = "maillist"
        oc = "(objectClass=mailList)"
        attrs = ["mail", "cn", "shadowAddress", "accountStatus"]

        def search(self, text, status):
            s = escape_filter_chars(text)
            fil = [self.oc, f"(|(mail=*{s}*)(shadowAddress=*{s}*)(cn=*{s}*))"]
            flt = "(&" + "".join(fil) + ")"
            out = []

            for dn in self.get_search_bases():
                try:
                    res = self.conn.search_s(dn, self.SCOPE, flt, self.attrs)
                except Exception:
                    res = []

                for _dn, entry in res:
                    out.append({
                        "type": self.type,
                        "mail": self.bytes2str(entry.get("mail", [b""])[0]),
                        "cn": self.bytes2str(entry.get("cn", [b""])[0]),
                        "status": self.bytes2str(entry.get("accountStatus", [b"unknown"])[0]),
                        "extra": {},
                    })
            return out

elif settings.backend in ["mysql", "pgsql"]:
    from libs.m_crudlib import SQLWrap as Wrap
    
    class SQLBase(SearchBase):
        Wrap = Wrap

    class SearchUsersSQL(SQLBase):
        type = "user"
        def search(self, text, status):
            where = "username LIKE $t OR name LIKE $t"
            q = self.conn.select("mailbox", where=where, vars={"t": f"%{text}%"})
            out = []
            for r in q:
                out.append({
                    "type": self.type,
                    "mail": r.username,
                    "cn": r.name,
                    "status": "active" if r.active else "disabled",
                    "extra": {},
                })
            return out

    class SearchDomainsSQL(SQLBase):
        type = "domain"
        def search(self, text, status):
            q = self.conn.select("domain", where="domain LIKE $t", vars={"t": f"%{text}%"})
            out = []
            for r in q:
                out.append({
                    "type": self.type,
                    "mail": r.domain,
                    "cn": r.domain,
                    "status": "active" if r.active else "disabled",
                    "extra": {},
                })
            return out

    class SearchAdminsSQL(SQLBase):
        type = "admin"
        def search(self, text, status):
            q = self.conn.select("admin", where="username LIKE $t", vars={"t": f"%{text}%"})
            out = []
            for r in q:
                out.append({
                    "type": self.type,
                    "mail": r.username,
                    "cn": r.username,
                    "status": "active",
                    "extra": {},
                })
            return out

    class SearchMailListsSQL(SQLBase):
        type = "maillist"
        def search(self, text, status):
            q = self.conn.select("maillists", where="address LIKE $t", vars={"t": f"%{text}%"})
            out = []
            for r in q:
                out.append({
                    "type": self.type,
                    "mail": r.address,
                    "cn": r.address,
                    "status": "active",
                    "extra": {},
                })
            return out

else:
    raise RuntimeError(f"Backend not supported: {settings.backend}")

class SearchEngine:
    def __init__(self):
        self.handlers = []
        if settings.backend == "ldap":
            self.handlers = [
                SearchDomainsLDAP(),
                SearchUsersLDAP(),
                SearchAdminsLDAP(),
                SearchMailListsLDAP(),
            ]
        else:
            self.handlers = [
                SearchDomainsSQL(),
                SearchUsersSQL(),
                SearchAdminsSQL(),
                SearchMailListsSQL(),
            ]

    def run(self, text: str, types: List[str] = None, status: str = "all") -> Dict[str, Any]:
        """
            Run search and return grouped results:
            {
                'total': int,
                'users': [...],
                'domains': [...],
                'admins': [...],
                'maillists': [...],
            }
        """
        types = types or ["user", "domain", "maillist", "admin"]
        # normalize status
        status = (status or "all")
        result_raw = []
        for h in self.handlers:
            if h.type in types:
                result_raw.extend(h.search(text, status))

        # group
        grouped = {"users": [], "domains": [], "admins": [], "maillists": [], "total": 0}
        for r in result_raw:
            t = r.get("type")
            if t == "user":
                grouped["users"].append(r)
            elif t == "domain":
                grouped["domains"].append(r)
            elif t == "admin":
                grouped["admins"].append(r)
            elif t == "maillist":
                grouped["maillists"].append(r)
        grouped["total"] = sum(len(grouped[k]) for k in ("users", "domains", "admins", "maillists"))
        return grouped
