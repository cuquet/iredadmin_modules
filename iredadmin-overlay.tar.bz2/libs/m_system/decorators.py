# libs/m_system/decorators.py
import web
import functools
from datetime import datetime

try:
    import ldap
except ImportError:
    class _LDAPFallback:
        class LDAPError(Exception):
            pass

        class ALREADY_EXISTS(LDAPError):
            pass

        class NO_SUCH_OBJECT(LDAPError):
            pass

        class SIZELIMIT_EXCEEDED(LDAPError):
            pass

    ldap = _LDAPFallback()


from libs.logger import log_traceback

class LibDecorators:
    @staticmethod
    def safe_sql_method(_func=None, no_hex=False, no_tuple=False, on_error_pass=False):
        """
            ## 🛡️ Decorador per encapsular mètodes que accedeixen a la base de dades.

            Funcionalitat:
            - Captura excepcions i evita que trenquin el flux del programa.
            - Converteix objectes `web.storage` a `dict` per facilitar la serialització.
            - Retorna una tupla normalitzada: `(True/False, data o error, meta, *extras)`
            excepte si `no_tuple=True`, on només retorna `data` (o `error`)
            - Afegeix metadades com `timestamp` si no es proporcionen.

            Avantatges:
            - Simplifica la gestió d'errors en controladors HTML i APIs.
            - Permet reutilitzar la lògica en múltiples contextos (web, API, scripts).
            - Facilita el test, el logging i la traçabilitat.
            
            Compatible amb:
                - `@safe_db_method`
                - `@safe_db_method(no_hex=True)`
                - `@safe_sql_method(no_tuple=True)`

            Paràmetres:
                - no_hex (bool): Si és True, no converteix bytes a hexadecimal.
                - no_tuple (bool): Si és True, només retorna `data` o `error`,
                sense `True/False` ni metadades.
                
            🔍 `functools.wraps` s'utilitza per preservar el nom, docstring i metadades de la funció original.

            ---
            ### 🧪 Exemple d’ús a `libs/iredapd/greylist.py`
            ```python
            from libs.decorators import LibDecorators
            
            class Greylisting(iRedAPDWrap):
                [...]
                @LibDecorators.safe_db_method
                def get_greylist_setting(self):
                    [...]
                    return (True, list(qr)) if qr else (False, "No s'han trobat registres")
            ```
        """
        def decorator(func):
            @functools.wraps(func)
            def wrapper(self, *args, **kwargs):
                timestamp = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
                    ## ISO 8601 (estàndard i llegible), Resultat: "2025-08-12T00:42:00" -> datetime.now().isoformat(timespec='seconds')
                    ## europeu clàssic, Resultat: "12/08/2025 00:42:00" -> datetime.now().strftime('%d/%m/%Y %H:%M:%S')
                try:
                    result = func(self, *args, **kwargs)

                    def convert(obj):
                        if isinstance(obj, web.storage):
                            return convert(dict(obj))
                        elif isinstance(obj, list):
                            return [convert(i) for i in obj]
                        elif isinstance(obj, dict):
                            return {k: convert(v) for k, v in obj.items()}
                        elif isinstance(obj, (bytes, bytearray)):
                            return obj.decode('utf-8', errors='ignore') if no_hex else obj.hex()
                        return obj

                    if isinstance(result, tuple):
                        success, *rest = result
                        
                        if not success:
                            return (False, rest[0], {'timestamp':timestamp}, *rest[1:])

                        data = convert(rest[0]) if rest else None

                        # Si hi ha metadades, les deixem; si no, afegim timestamp
                        meta = dict(rest[1]) if len(rest) > 1 and isinstance(rest[1], dict) else {}
                        meta['timestamp']= timestamp

                        # Si hi ha més elements, els passem com extra
                        extras = rest[2:] if len(rest) > 2 else []

                        return data if no_tuple else (True, data, meta, *extras)

                    if isinstance(result, (dict, list)):
                        # Retorn simple, considerat èxit
                        return convert(result) if no_tuple else (True, convert(result), {'timestamp': timestamp})

                    # Qualsevol altre cas el tractem com error
                    return str(result) if no_tuple else (False, str(result), {'timestamp': timestamp})

                except Exception as e:
                    if on_error_pass:
                        pass
                    log_traceback()
                    return str(e) if no_tuple else (False, repr(e), {'timestamp': timestamp})

            return wrapper
        # Compatibilitat doble: amb o sense paràmetres
        return decorator if _func is None else decorator(_func)

    @staticmethod
    def safe_ldap_method(_func=None, *, no_decode=False, no_tuple=False):
        """
            ## 🛡️ Decorador per encapsular mètodes que accedeixen a LDAP.
            Compatible amb:
            - `@safe_ldap_method`
            - `@safe_ldap_method(no_decode=True)`
            - `@safe_ldap_method(no_tuple=True)`
            
            Funcionalitat:
            - Captura excepcions LDAP (`ldap.LDAPError`) i generals.
            - Converteix bytes i estructures LDAP a formats llegibles (`str`, `dict`, `list`).
            - Retorna:
                - Una **tupla normalitzada** `(True/False, data o error, meta, *extras)`
                - O, si `no_tuple=True`, només `data` (en cas d’èxit) o `error` (en cas de fallada).
            - Afegeix metadades com `timestamp` i `source` (LDAP o General).

            Avantatges:
            - Simplifica la gestió d'errors en consultes LDAP.
            - Permet reutilitzar la lògica en controladors web i APIs.
            - Facilita el test, el logging i la traçabilitat.

            🔍 `functools.wraps` s'utilitza per preservar el nom, docstring i metadades de la funció original.

            ### 🧪 Exemple d’ús amb LDAP
            Suposem que tens una classe LdapUserManager que fa consultes a LDAP:
            ```python
                from libs.decorators import LibDecorators

                class LdapUserManager:
                    def __init__(self, conn):
                        self.conn = conn  # connexió LDAP

                    @LibDecorators.safe_ldap_method
                    def get_user(self, email):
                        dn = f"mail={email},ou=Users,domainName=example.com,o=domains,dc=iredmail,dc=org"
                        result = self.conn.search_s(dn, ldap.SCOPE_BASE)
                        if result:
                            return (True, result[0][1])
                        else:
                            return (False, "Usuari no trobat")
            ```
            #### 🧩 Controlador que reutilitza la lògica
            ```
            class API_UserInfo:
                @json_response
                def GET(self):
                    email = web.input().get('email')
                    ldap_conn = get_ldap_connection()
                    manager = LdapUserManager(ldap_conn)
                    return manager.get_user(email)
            ```
        """
        def _decode_like_bytes(b):
            # converteix a bytes i (si s’escau) a str
            if isinstance(b, memoryview):
                b = b.tobytes()
            if isinstance(b, bytearray):
                b = bytes(b)
            if isinstance(b, bytes):
                return b if no_decode else b.decode('utf-8', errors='ignore')
            return b  # no és bytes

        def decorator(func):
            @functools.wraps(func)
            def wrapper(self, *args, **kwargs):
                timestamp = datetime.now().strftime('%d/%m/%Y %H:%M:%S')
                try:
                    result = func(self, *args, **kwargs)

                    def convert(obj):
                        # 1) str que "sembla" bytes -> intenta recuperar i decodificar
                        if isinstance(obj, str):
                            if (obj.startswith("b'") and obj.endswith("'")) or \
                                (obj.startswith('b"') and obj.endswith('"')):
                                try:
                                    import ast
                                    maybe_b = ast.literal_eval(obj)
                                    return _decode_like_bytes(maybe_b)
                                except Exception:
                                    pass
                            return obj

                        # 2) bytes-like
                        if isinstance(obj, (bytes, bytearray, memoryview)):
                            return _decode_like_bytes(obj)

                        # 3) col·leccions
                        if isinstance(obj, (list, tuple, set)):
                            typ = type(obj)
                            return typ(convert(x) for x in obj)

                        # 4) dicts / Storage / cidict de python-ldap
                        if isinstance(obj, (dict, web.utils.Storage)):
                            return {k: convert(v) for k, v in obj.items()}
                        try:
                            import ldap.cidict
                            if isinstance(obj, ldap.cidict.cidict):
                                return {k: convert(v) for k, v in obj.items()}
                        except Exception:
                            pass

                        # 5) per defecte, no fem repr(obj): el deixem tal qual
                        return obj

                    if no_tuple:
                        if isinstance(result, tuple):
                            success, *rest = result
                            return convert(rest[0]) if success else (rest[0] if rest else None)
                        return convert(result)

                    if isinstance(result, tuple):
                        success, *rest = result
                        if not success:
                            return (False, rest[0], {
                                'timestamp': timestamp,
                                'source': 'LibDecorators LDAP'
                            }, *rest[1:])

                        data = convert(rest[0]) if rest else None
                        meta = dict(rest[1]) if len(rest) > 1 and isinstance(rest[1], dict) else {}
                        meta['timestamp']= timestamp
                        meta.setdefault('source', 'LibDecorators LDAP')
                        extras = rest[2:] if len(rest) > 2 else []
                        return (True, data, meta, *extras)

                    # Igual que safe_db_method: dict/llista = èxit
                    if isinstance(result, (dict, list)):
                        return (True, convert(result), {
                            'timestamp': timestamp,
                            'source': 'LibDecorators LDAP'
                        })

                    # Qualsevol altra cosa no esperada -> error
                    return (False, str(result), {
                        'timestamp': timestamp, 
                        'source': 'LibDecorators LDAP'
                    })
                except ldap.ALREADY_EXISTS:
                    return (False, 'ALREADY_EXISTS',{'timestamp':timestamp})
                except ldap.NO_SUCH_OBJECT:
                    return (False, 'NO_SUCH_ACCOUNT',{'timestamp':timestamp})
                except ldap.SIZELIMIT_EXCEEDED:
                    return (False, 'EXCEEDED_LDAP_SERVER_SIZELIMIT',{'timestamp':timestamp})
                except ldap.LDAPError as e:
                    return str(e) if no_tuple else (False, repr(e), {
                        'timestamp': timestamp,
                        'source': e.__class__.__name__
                    })

                except Exception as e:
                    log_traceback()
                    return str(e) if no_tuple else (False, str(e), {
                        'timestamp': timestamp,
                        'source': 'General'
                    })

            return wrapper
        # Compatibilitat doble: amb o sense paràmetres
        return decorator if _func is None else decorator(_func)
