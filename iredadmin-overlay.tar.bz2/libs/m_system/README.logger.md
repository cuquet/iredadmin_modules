# 📘 Guia de logging a iRedAdmin
Aquest document explica què fa cada funció, quan usar-la i què registra exactament.
Inclou:

* logger (stdout/syslog)
* log_activity() (BD + syslog/stdout)
* log_traceback() (errors inesperats)
* recomanacions de bon ús
* exemples pràctics

els **events** estan a `iRedMailMyAdmin/libs/panel/__init__.py`


## 🏗️ Inicialització del logger

El codi carrega un logger centralitzat anomenat iredadmin:

```python
    logger = logging.getLogger("iredadmin")
```

El destí pot ser:
* stdout
* syslog local (via /dev/log o socket)
* syslog remot (host + port)

En funció de `settings.LOG_TARGET`.

## 🧰 Funcions disponibles
### 1. logger.info(msg) / logger.error(msg)
➤ **Què fan?**
Escriuen al `syslog` o `stdout`, segons configuració.

➤ **Quan usar-les?**
* Per registrar informació de depuració.
* Quan no cal registrar res a la base de dades.
* Per missatges interns del sistema.

➤ **Què NO fan?**
* No escriuen a la taula SQL log.
* No afegeixen IP ni usuari.

✔ Exemple:
```python
logger.info("Starting user synchronization")
logger.error("Invalid configuration value")
```
### 2. log_activity(msg, …)
➤ **Què fa?**
Funció de "triple logging":

| Destí                   | Escriu? |
| ----------------------- | ------- |
| syslog / stdout         | ✔       |
| Taula MySQL `log`       | ✔       |
| Afegir IP automàtica    | ✔       |
| Afegir usuari de sessió | ✔       |

➤ **Quan usar-la?**
* Quan vols que l’administrador ho vegi a la GUI
* Quan vols registrar accions d’usuaris o admins
* Quan vols tenir auditoria i traçabilitat
* Quan vols guardar logs al syslog i a la base de dades

➤ **Comporta automàticament:**
* Afegeix session.ip
* Afegeix admin si no el passes
* Prefixa [API] si la crida prové d’una ruta /api/

✔ Exemple bàsic:
```python
log_activity("Disabled mailbox", event="disable_mailbox")
```

✔ Exemple amb detalls:
```python
log_activity(
    "Quota updated",
    domain="example.com",
    username="user@example.com",
    event="update_quota",
    loglevel="info",
)
```

3. log_traceback()
➤ **Què fa?**
Quan hi ha una excepció inesperada, captura:
* tipus d’excepció
* missatge
* stacktrace complet

I el registra com:
```python
logger.error() (→ syslog / stdout)
```
➤ **Quan usar-la?**
* Quan tens un try/except i vols deixar rastre complet
* Quan tens errors difícils de reproduir

✔ Exemple:
```python
try:
    risky_code()
except:
    log_traceback()
    return False
```
## 📌 Resum: quin faig servir?
| Situació                                   | Funció recomanada                  |
| ------------------------------------------ | ---------------------------------- |
| Escriure al syslog només                   | `logger.info()` / `logger.error()` |
| Escriure logs visibles per admins a la GUI | `log_activity()`                   |
| Registrar accions d’usuaris o admins       | `log_activity()`                   |
| Guardar auditoria (IP, usuari, event)      | `log_activity()`                   |
| Registrar errors inesperats amb traceback  | `log_traceback()`                  |
| Depuració interna del backend              | `logger.info()`                    |

## ⚙️ Exemple complet d’integració
```python
from libs.logger import logger, log_activity, log_traceback

def update_user_quota(user, quota):
    try:
        logger.info(f"Updating quota for {user}")

        # Operació
        do_update(user, quota)

        log_activity(
            f"Quota updated to {quota} MB",
            username=user,
            event="update_quota"
        )

    except:
        log_traceback()
        log_activity(
            "Failed to update quota",
            username=user,
            event="update_quota",
            loglevel="error"
        )
```

## ⭐ Bonus: Afegir nom de mòdul i funció
Recomanació útil per debugging:
```python
def log_with_context(func, msg, **kwargs):
    full = f"{func.__module__}.{func.__name__}: {msg}"
    return log_activity(full, **kwargs)
```

Ús:
```python
log_with_context(update_user_quota, "Starting update", username=user)
```

