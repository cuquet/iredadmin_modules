# libs/m_system/form_utils.py
import re
import web
from typing import Union, List, Tuple, Dict, Any

from libs.form_utils  import *
from . import jinja_filters

def populate_form_list_filtered(form: Dict[str, Any], input_value: str) -> Tuple[bool, Dict[str, str]]:
    """
        Normalitza i compara llistes provinents d'un formulari (add, old, actuals).

        Accepta formats:
            - CSV: "a,b,c"
            - Multilínia: "a\nb\nc"
            - Llistes Python: ["a", "b", "c"]

        Tractament:
            - Combina nous valors amb els antics si hi ha `add_*`
            - Detecta què s'ha eliminat
            - Manté comentaris '#'
            - Elimina duplicats
            - Ordena alfabèticament

        Retorna:
        (True, {"add": "v1,v2", "remove": "v3"}) si hi ha moviments
        (False, {}) si no hi ha cap canvi
    """
    key_new = input_value            # ex: "whitelists"
    key_old = f"old_{input_value}"   # ex: "old_whitelists"
    key_add = f"add_{input_value}"   # ex: "add_whitelists"

    # Helpers ---------------------------------------------
    def normalize(raw) -> List[str]:
        """
            Normalitza un valor:
                - string → split per línies i comes
                - llista → avaluada
            Es retornen elements únics, amb espais trim, preservant comentaris.
        """
        if not raw:
            return []

        items = []

        # --- STRING ----------------------------------------------------
        if isinstance(raw, str):
            # normalitzar salts
            raw = raw.replace("\r\n", "\n").replace("\r", "\n")

            for line in raw.split("\n"):
                line = line.strip()
                if not line:
                    continue

                if "," in line:
                    # dividir en CSV, però respectant comentaris
                    for p in line.split(","):
                        p = p.strip()
                        if p:
                            items.append(p)
                else:
                    items.append(line)

        # --- LIST ------------------------------------------------------
        elif isinstance(raw, list):
            for elem in raw:
                if not elem:
                    continue
                # recursiu: cada element pot ser multilínia
                items.extend(normalize(elem))

        # --- ALTRE -----------------------------------------------------
        else:
            return []

        # Únics mantenint ordre
        seen = set()
        result = []
        for p in items:
            if p not in seen:
                result.append(p)
                seen.add(p)

        return result

    # Dades antigues
    old_values = normalize(form.get(key_old))

    # Si hi ha add → ignorem lo “nou” i fem merge old + add
    if form.get(key_add):
        add_values = normalize(form.get(key_add))
        combined = sorted(set(old_values + add_values))

        return True, {
            "add": ",".join(combined),
            "remove": ""
        }

    # Si NO hi ha add → comparem old vs new
    if key_new in form:
        new_values = sorted(set(normalize(form.get(key_new))))
        removed = sorted(set(old_values) - set(new_values))

        return True, {
            "add": ",".join(new_values),
            "remove": ",".join(removed),
        }

    # Si només hi havia valors antics i ara no hi ha res → eliminar tot
    if key_old in form:
        return True, {
            "add": "",
            "remove": ",".join(sorted(set(old_values))),
        }

    # Cap moviment
    return False, {}


def normalize_text_multivalue(form: Dict[str, Any], input_name: str) -> List[str]:
    """
    Normalitza camps multi-valor textuals preservant cada entrada completa.

    Cas típic: atributs LDAP com `telephoneNumber` o `title`, on un únic valor
    escalar no s'ha de tractar mai com una seqüència de caràcters.

    Comportament:
    - accepta valor escalar o llista
    - accepta també claus indexades tipus `telephoneNumber[0]`
    - fa `strip()` a cada element
    - elimina només duplicats exactes
    - preserva l'ordre d'entrada
    """
    indexed_pattern = re.compile(rf"^{re.escape(input_name)}\[(\d+)\]$")
    indexed_values = []

    for key in form.keys():
        match = indexed_pattern.match(web.safestr(key))
        if not match:
            continue
        indexed_values.append((int(match.group(1)), form.get(key)))

    if indexed_values:
        indexed_values.sort(key=lambda item: item[0])
        raw = [value for _, value in indexed_values]
    else:
        raw = form.get(input_name)

    if raw is None:
        values = []
    elif isinstance(raw, (list, tuple, set)):
        values = list(raw)
    else:
        values = [raw]

    result = []
    seen = set()
    for item in values:
        value = web.safestr(item).strip()
        if not value or value in seen:
            continue
        result.append(value)
        seen.add(value)

    return result


def quota_transformation(name: str, form: Dict[str, Any]) -> Union[int, str]:
    """
        Converteix una quota humana a bytes treballant amb int.
        Retorna:
            - 0      → 0
            - -1     → -1
            - <n>    → bytes (int)
    """
    raw = web.safestr(form.get(name, '')).strip()

    # 👉 Si està buit, interpretem com quota il·limitada
    if raw == '':
        return 0

    # Normalització  coma → punt
    raw = raw.replace(",", ".", 1)
    
    # Casos especials convertits a int
    if raw == '0':
        return 0

    if raw == '-1':
        return -1

    # Intentar convertir a float
    try:
        number = float(raw)
    except ValueError:
        # Valor no numèric → retornem 0
        return 0

    unit = web.safestr(form.get(name + 'Unit', '')).strip()
    human_value = f"{number} {unit}".strip()

    return jinja_filters.human2bytes(human_value)
