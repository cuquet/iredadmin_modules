# libs/m_crudlib/user.py
import web
import os
# per python =< 3.9 si > 3.9 no cal importar i amb minúscules
from typing import Union, List, Tuple, Dict, Optional

import settings
from libs import iredutils, iredpwd, form_utils
from libs.l10n import TIMEZONES
from libs.logger import log_activity

from libs.m_system.decorators import LibDecorators
from libs.m_crudlib import security, domain as lib_domain
from libs.m_maillist.ml import MailList_API, MailList as lib_ml
from libs.m_system import utils
from libs.m_system.mixins import SQLWhereBuilder

session = web.config.get('_session')
mapper = utils.KeyMap()

class UserBase:
    def __init__(self, domain: Optional[str] = None, mail: Optional[str] = None):
        self.domain = domain
        self.mail = mail
        self.backend = Wrap()
        self.conn = self.backend.conn

    # def _not_implemented(self, method_name):
    #     raise NotImplementedError(f"{self.__class__.__name__}.{method_name} no està implementat per aquest backend")

    # def delete_users(self, *args, **kwargs):
    #     self._not_implemented("delete_users")

    def users_get_first_char_of(self, accounts) -> List:
        chars = list()
        chars = utils.accounts_get_first_char_of(accounts)
        return chars

    def users_get_first_char_of_all(self) -> Tuple[bool, Union[List[str], Dict, str]]:
        """
            NOTE:
            Implementació comuna per SQL/LDAP.
            Depèn del contracte compartit de `list(email_only=True)`.
        """
        qr = self.list(email_only=True)
        if not qr[0]:
            return qr
        return (True, self.users_get_first_char_of(qr[1]))

    def _normalize_forwarding_payload(
        self,
        payload: Dict,
        keep_local_when_disabled: bool = True,
    ) -> Tuple[bool, Union[Dict, str]]:
        """
            NOTE:
            Lògica comuna SQL/LDAP per normalitzar forwarding des de payload.
            La persistència final es resol al backend.
        """
        if not isinstance(payload, dict):
            return (False, "INVALID_PAYLOAD")

        forward_enabled = payload.get("forwarding") == "active"
        savecopy_enabled = payload.get("savecopy") == "active"

        raw_forwardings = payload.get("catchallAddress")
        if raw_forwardings is None:
            raw_forwardings = payload.get("mailForwardingAddress")

        if isinstance(raw_forwardings, dict):
            forwardings = utils._normalize_list_mails(raw_forwardings.get("add"))
        else:
            forwardings = utils._normalize_list_mails(raw_forwardings)

        if "forwarding" not in payload and forwardings:
            # NOTE: Compat API: si venen destinataris però no el flag explícit,
            # assumim forwarding actiu.
            forward_enabled = True

        if forward_enabled:
            if savecopy_enabled or not forwardings:
                forwardings.append(self.mail)
            else:
                forwardings = [m for m in forwardings if m != self.mail]
        else:
            forwardings = [self.mail] if keep_local_when_disabled else []

        forwardings = list(dict.fromkeys([str(m).lower() for m in forwardings if m]))
        if keep_local_when_disabled and not forwardings:
            forwardings = [self.mail]

        return (True, {
            "forward_enabled": forward_enabled,
            "savecopy_enabled": savecopy_enabled,
            "forwardings": forwardings,
        })

    def _build_2fa_settings_update(
        self,
        payload: Dict,
        account_settings: Dict,
    ) -> Tuple[bool, Union[Dict, str]]:
        """
            NOTE:
            Construeix el delta de settings 2FA (alta/baixa secret + flag enable).
            No persisteix res: cada backend aplica el resultat.
        """
        if not isinstance(payload, dict):
            return (False, "INVALID_PAYLOAD")
        if not isinstance(account_settings, dict):
            account_settings = {}

        new_settings = {}
        removed_settings = []

        secret_input = payload.get("2fa_secret")
        current_secret = account_settings.get("2fa_secret")

        if "2fa_enabled" in payload:
            enabled_twofa = payload.get("2fa_enabled") == "active"
            if enabled_twofa:
                new_settings["2fa_enabled"] = "yes"
            else:
                removed_settings.extend(["2fa_enabled", "2fa_secret"])

        if payload.get("2fa_enabled") == "active":
            if not current_secret and not secret_input:
                secret_input = security.generate_2fa_setup(self.mail)["secret"]

        if secret_input:
            encrypted_input = security.encrypt_secret(secret_input)
            if encrypted_input != current_secret:
                new_settings["2fa_secret"] = encrypted_input

        return (True, {
            "new_settings": new_settings,
            "removed_settings": removed_settings,
        })

    def _is_active_value(self, value: object) -> bool:
        return str(value).strip().lower() in {"1", "on", "yes", "true", "active", "enabled"}

    def _normalize_text_list(self, value: object) -> List[str]:
        if value is None:
            return []

        if isinstance(value, str):
            items = []
            for line in value.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
                line = line.strip()
                if not line:
                    continue
                items.extend([v.strip() for v in line.split(",") if v.strip()])
            return list(dict.fromkeys(items))

        if isinstance(value, (list, tuple, set)):
            return list(dict.fromkeys([str(v).strip() for v in value if str(v).strip()]))

        return []

    def _build_target_enabled_services(
        self,
        payload: Dict,
        current_enabled: Optional[List[str]] = None,
    ) -> Tuple[bool, Union[List[str], str]]:
        """
            NOTE:
            Normalitza `enabledService`/`disabledService` i flags simples
            (`forwarding`, `aliases`, `domainadmin`, `domainGlobalAdmin`)
            cap a una llista objectiu d'`enabledService`.
        """
        if not isinstance(payload, dict):
            return (False, "INVALID_PAYLOAD")

        def _canon_service_names(values: List[str]) -> List[str]:
            # NOTE: Manté noms canònics per serveis que no són totalment lowercase.
            canonical_map = {
                "domainglobaladmin": "domainGlobalAdmin",
                "displayedinglobaladdressbook": "displayedInGlobalAddressBook",
            }
            out = []
            for v in values:
                _v = str(v).strip()
                if not _v:
                    continue
                _lv = _v.lower()
                out.append(canonical_map.get(_lv, _lv))
            return list(dict.fromkeys(out))

        target = set(_canon_service_names(self._normalize_text_list(current_enabled or [])))

        if "enabledService" in payload:
            raw_enabled = payload.get("enabledService")
            if isinstance(raw_enabled, dict):
                target.update(self._normalize_text_list(raw_enabled.get("add")))
                target.difference_update(self._normalize_text_list(raw_enabled.get("remove")))
            else:
                target = set(_canon_service_names(self._normalize_text_list(raw_enabled)))

        if "disabledService" in payload:
            raw_disabled = payload.get("disabledService")
            if isinstance(raw_disabled, dict):
                target.difference_update(self._normalize_text_list(raw_disabled.get("add")))
                target.update(self._normalize_text_list(raw_disabled.get("remove")))
            else:
                target.difference_update(self._normalize_text_list(raw_disabled))

        target = set(_canon_service_names(list(target)))

        service_flag_map = {
            "forwarding": "forward",
            "aliases": "shadowaddress",
            "alias": "shadowaddress",
            "domainadmin": "domainadmin",
            "domainGlobalAdmin": "domainGlobalAdmin",
        }
        for payload_key, service_name in service_flag_map.items():
            if payload_key in payload:
                if self._is_active_value(payload.get(payload_key)):
                    target.add(service_name)
                else:
                    target.discard(service_name)

        return (True, sorted(target))

    @LibDecorators.safe_sql_method
    def get_account_used_quota(self, mail: Union[str, List[str]]) -> Dict:
        """
            Get real-time used quota per un sol compte.
            - Accepta 'user@domain.com' o ['user@domain.com'].
        """
        if settings.backend == "ldap":
            connDB=  web.conn_iredadmin
        elif settings.backend in ["mysql", "pgsql"]:
            connDB = self.conn
                
        if isinstance(mail, list):
            if not mail:   # NOTE: si rebem una llista buida
                return {"bytes": 0, "messages": 0}
            mail = mail[0]
        elif not isinstance(mail, str):
            return {"bytes": 0, "messages": 0}

        builder = SQLWhereBuilder()
        builder.add_equals("username", mail)
        sql_where, sql_vars = builder.build()

        qr = connDB.select(
            settings.SQL_TBL_USED_QUOTA,
            vars=sql_vars,
            what='SUM(bytes) AS bytes, SUM(messages) AS messages',
            where=sql_where)

        for i in qr:
            return {'bytes': int(i.bytes) if i.bytes else 0, 'messages': int(i.messages) if i.messages else 0 }

    @LibDecorators.safe_sql_method
    def get_account_last_login(self, mail: Union[str, List[str]]) -> Dict[str, int]:
        """
            Obté els timestamps del últim accés per a un sol compte.
            - Accepta 'user@domain.com' o ['user@domain.com'].
            - Retorna un diccionari amb les claus: 'imap', 'pop3', 'lda', 'lmtp'.
        """
        if settings.backend == "ldap":
            connDB = web.conn_iredadmin
        elif settings.backend in ["mysql", "pgsql"]:
            connDB = self.conn
        else:
            return {"imap": 0, "pop3": 0, "lda": 0, "lmtp": 0}

        # NOTE: Process input
        if isinstance(mail, list):
            if not mail:   # NOTE: empty list
                return {"imap": 0, "pop3": 0, "lda": 0, "lmtp": 0}
            mail = mail[0]
        elif not isinstance(mail, str):
            return {"imap": 0, "pop3": 0, "lda": 0, "lmtp": 0}

        # NOTE: Split user@domain
        try:
            user, domain = mail.split("@", 1)
        except ValueError:
            return {"imap": 0, "pop3": 0, "lda": 0, "lmtp": 0}

        builder = SQLWhereBuilder()
        builder.add_equals("username", mail)
        builder.add_equals("domain", domain)
        sql_where, sql_vars = builder.build()

        # NOTE: Consulta la taula `last_login`
        qr = connDB.select(
            "last_login",
            vars=sql_vars,
            where=sql_where,
            what="SUM(imap) AS imap, SUM(pop3) AS pop3, SUM(lda) AS lda"
        )

        # NOTE: Retorna un diccionari
        last_login = {"imap": 0, "pop3": 0, "lda": 0, "lmtp": 0}
        for row in qr:
            last_login["imap"] = int(row.imap) if row.imap else 0
            last_login["pop3"] = int(row.pop3) if row.pop3 else 0
            last_login["lda"] = int(row.lda) if row.lda else 0
            last_login["lmtp"] = last_login["lda"]  # NOTE: lmtp is treated as lda

        return last_login

if settings.backend in ["mysql", "pgsql"]:
    from libs.m_crudlib import SQLWrap as Wrap
    from libs.m_system.mixins import SQLCRUDMixin
    from libs.sqllib import user as sql_lib_user
    from libs.sqllib import domain as sql_lib_domain
    from libs.sqllib import sqlutils

    class User(UserBase, SQLCRUDMixin):
        def __init__(self, domain: Optional[str] = None, mail: Optional[str] = None) :
            super().__init__(domain=domain, mail=mail)

            self.mail = mail if self.is_email(mail) else None # NOTE: session.get('username') if not mail else str(mail).lower()
            if self.is_domain(domain):
                self.domain = str(domain).strip().lower()
            elif self.mail:
                self.domain = self.mail.split('@', 1)[-1]
            else:
                self.domain = None

        @LibDecorators.safe_sql_method
        def list(self,
                domain: Optional[str] = None,
                cur_page: int = 0,
                current_page: Optional[int] = None,
                admin_only: bool = False,
                order_name: Optional[str] = None,
                order_by_desc: Optional[bool] = None,
                starts_with: Optional[str] = None,
                disabled_only: bool = False,
                email_only: bool = False) -> Tuple[bool, Union[List, Dict, str]]:
            # NOTE: Contracte:
            #  - current_page <= 0: mode heretat, retorna la llista completa.
            #  - current_page > 0 : càrrega paginada per als controladors CRUD de la UI.
            domain = str(domain or self.domain or '').lower()
            if not self.is_domain(domain):
                return (False, 'INVALID_DOMAIN_NAME')

            if current_page is None:
                current_page = cur_page
            current_page = self.normalize_current_page(current_page=current_page, default=0, min_page=0)
            use_pagination = current_page > 0

            builder = SQLWhereBuilder()
            builder.add_equals('mailbox.domain', domain)
            if admin_only:
                builder.add_raw('(mailbox.isadmin=1 OR mailbox.isglobaladmin=1)')
            if starts_with:
                builder.add_like('mailbox.username', starts_with.lower() + '%', case_insensitive=False)
            if disabled_only:
                builder.add_equals('mailbox.active', 0)
            sql_where, sql_vars = builder.build()

            # NOTE: `order_name` és opcional:
            # - templates/controllers canònics el poden enviar (name/quota)
            # - mòduls personalitzats poden no enviar-lo
            # Mantenim aquest branch i fallback estable a `username`.
            if order_name == 'quota':
                if settings.backend == 'mysql':
                    sql_cmd_percentage = '100 * IFNULL(%s.bytes, 0)/(mailbox.quota * 1024 * 1024) AS percentage' % settings.SQL_TBL_USED_QUOTA
                else:
                    # NOTE: PostgreSQL: evitem divisió per zero en quota il·limitada.
                    sql_cmd_percentage = 'COALESCE((100 * COALESCE(%s.bytes, 0)/(NULLIF(mailbox.quota, 0) * 1024 * 1024)), 0) as percentage' % settings.SQL_TBL_USED_QUOTA

                _order_by = 'DESC' if order_by_desc else 'ASC'

                sql_q = f"""
                    SELECT
                        mailbox.username, mailbox.name, mailbox.quota,
                        mailbox.employeeid, mailbox.active, mailbox.isadmin,
                        mailbox.isglobaladmin, mailbox.passwordlastchange,
                        {sql_cmd_percentage}
                    FROM mailbox
                    LEFT JOIN {settings.SQL_TBL_USED_QUOTA} ON ({settings.SQL_TBL_USED_QUOTA}.username = mailbox.username)
                    WHERE {sql_where}
                    ORDER BY percentage {_order_by}, mailbox.username ASC
                """

                if use_pagination and settings.PAGE_SIZE_LIMIT > 0:
                    qr = self.conn.query(
                        sql_q + " LIMIT $limit OFFSET $offset",
                        vars={**sql_vars, 'limit': settings.PAGE_SIZE_LIMIT, 'offset': (current_page - 1) * settings.PAGE_SIZE_LIMIT}
                    )
                else:
                    qr = self.conn.query(sql_q, vars=sql_vars)

            elif order_name == 'name':
                sql_order = 'name DESC, username ASC' if order_by_desc else 'name ASC, username ASC'
                if use_pagination and settings.PAGE_SIZE_LIMIT > 0:
                    qr = self.conn.select(
                        'mailbox',
                        vars=sql_vars,
                        what='username,name,quota,employeeid,active,isadmin,isglobaladmin,passwordlastchange',
                        where=sql_where,
                        order=sql_order,
                        limit=settings.PAGE_SIZE_LIMIT,
                        offset=(current_page - 1) * settings.PAGE_SIZE_LIMIT,
                    )
                else:
                    qr = self.conn.select(
                        'mailbox',
                        vars=sql_vars,
                        what='username,name,quota,employeeid,active,isadmin,isglobaladmin,passwordlastchange',
                        where=sql_where,
                        order=sql_order,
                    )
            
            else:
                # NOTE: Cas per defecte amb ordre simple per `username` (compatible amb el
                # contracte històric de llistat de comptes).
                what = 'username' if email_only else 'username,name,quota,employeeid,active,isadmin,isglobaladmin,passwordlastchange'
                if use_pagination and settings.PAGE_SIZE_LIMIT > 0:
                    qr = self.conn.select(
                        'mailbox',
                        vars=sql_vars,
                        what=what,
                        where=sql_where,
                        order='username ASC',
                        limit=settings.PAGE_SIZE_LIMIT,
                        offset=(current_page - 1) * settings.PAGE_SIZE_LIMIT
                    )
                else:
                    qr = self.conn.select(
                        'mailbox',
                        vars=sql_vars,
                        what=what,
                        where=sql_where,
                        order='username ASC',
                    )

            records = list(qr)
            # NOTE: Mantenim el contracte de llista SQL alineat amb el key-map de CRUD:
            # clau backend `address` -> clau frontend `mail`.
            # La taula `mailbox` desa el login a `username`, així que el reflectim.
            # NOTE: En SQL la taula `mailbox` guarda el login a `username`; exposem també
            # `address` per coherència amb key-map CRUD i plantilles.
            for row in records:
                if not getattr(row, 'address', None):
                    row.address = str(getattr(row, 'username', '') or '').lower()

            if email_only:
                emails = sorted({
                    str(r.username).lower()
                    for r in records
                    if getattr(r, 'username', None)
                })
                return (True, emails)

            if not use_pagination:
                return (True, records)

            count_qr = self.conn.select(
                'mailbox',
                vars=sql_vars,
                what='COUNT(username) AS total',
                where=sql_where,
            )
            total = int(count_qr[0].total) if count_qr else 0

            pages = self.get_total_pages(total=total, size_limit=settings.PAGE_SIZE_LIMIT)

            return (True, {
                'total': total,
                'account_profiles': records,
                'pages': pages,
            })

        @LibDecorators.safe_sql_method
        def get_profile(self, attributes: Optional[Union[List[str], str]] = None):
            requested_attrs = None
            if attributes:
                if isinstance(attributes, str):
                    _raw = [v.strip() for v in attributes.split(",") if str(v).strip()]
                elif isinstance(attributes, (list, tuple, set)):
                    _raw = [str(v).strip() for v in attributes if str(v).strip()]
                else:
                    _raw = []

                # NOTE: `*` manté comportament complet (sense filtre explícit de claus).
                if _raw and _raw != ["*"]:
                    requested_attrs = list(dict.fromkeys(_raw))

            if not self.mail or not self.is_email(self.mail):
                return (False, "INVALID_MAIL")

            qr = self.conn.select(
                "mailbox",
                vars={"mail": self.mail},
                what="*",
                where="username=$mail",
                limit=1,
            )
            if not qr:
                return (False, "NO_SUCH_ACCOUNT")

            profile = dict(qr[0])
            profile["accountSetting"] = sqlutils.account_settings_string_to_dict(
                str(profile.get("settings", ""))
            )

            need_forwardings = (
                requested_attrs is None
                or bool(set(requested_attrs) & {
                    "catchallAddress",
                    "extra_address",
                    "alias",
                    "enabledService",
                    "mailForwardingAddress",
                    "shadowAddress",
                })
            )
            if need_forwardings:
                fwd_qr = self.conn.select(
                    "forwardings",
                    vars={"mail": self.mail},
                    what="address,forwarding",
                    where="address=$mail OR forwarding=$mail",
                )
                catchall_addresses = []
                extra_addresses = []
                for row in fwd_qr:
                    addr = str(row.address).lower()
                    fwd = str(row.forwarding).lower()
                    if addr == self.mail and fwd != self.mail:
                        catchall_addresses.append(fwd)
                    elif fwd == self.mail and addr != self.mail:
                        extra_addresses.append(addr)

                profile["catchallAddress"] = sorted(set(catchall_addresses))
                profile["extra_address"] = sorted(set(extra_addresses))
                profile["alias"] = "active" if profile["extra_address"] else "disabled"

                enabled_services = []
                if profile["catchallAddress"]:
                    enabled_services.append("forward")
                if profile["extra_address"]:
                    enabled_services.append("shadowaddress")
                if int(profile.get("isadmin", 0) or 0) == 1:
                    enabled_services.append("domainadmin")
                if int(profile.get("isglobaladmin", 0) or 0) == 1:
                    enabled_services.append("domainGlobalAdmin")
                profile["enabledService"] = enabled_services
                profile["disabledService"] = []

            need_statistics = requested_attrs is None or "statistics" in requested_attrs
            if need_statistics:
                quota_data = self.get_account_used_quota(self.mail)
                login_data = self.get_account_last_login(self.mail)
                statistics = {}
                if isinstance(quota_data, tuple):
                    if quota_data and quota_data[0] and len(quota_data) > 1 and isinstance(quota_data[1], dict):
                        statistics.update(quota_data[1])
                elif isinstance(quota_data, dict):
                    statistics.update(quota_data)
                if isinstance(login_data, tuple):
                    if login_data and login_data[0] and len(login_data) > 1 and isinstance(login_data[1], dict):
                        statistics.update(login_data[1])
                elif isinstance(login_data, dict):
                    statistics.update(login_data)
                profile["statistics"] = statistics

            if requested_attrs is not None:
                # NOTE: Compat SQL<->LDAP en lectura d'atributs de forwarding/aliases.
                alias_map = {
                    "mailForwardingAddress": "catchallAddress",
                    "shadowAddress": "extra_address",
                }
                filtered = {}
                for key in requested_attrs:
                    source_key = alias_map.get(key, key)
                    if source_key in profile:
                        filtered[key] = profile.get(source_key)
                return (True, filtered)

            return (True, profile)

        @LibDecorators.safe_sql_method
        def add(self, payload: Dict) -> Tuple[bool, str]:
            if not isinstance(payload, dict):
                return (False, "INVALID_PAYLOAD")

            if not self.domain:
                self.domain = self.mail.split("@", 1)[-1]
            if not self.is_domain(self.domain):
                return (False, "INVALID_DOMAIN_NAME")

            username = (payload.get("username") or "").strip()
            mail = (f"{username}@{self.domain}" if username and self.domain else (self.mail or "")).strip().lower()
            mail = self.strip_mail_ext_address(mail)
            
            if not mail or not self.is_auth_email(mail):
                return (False, "INVALID_MAIL")
            self.mail = mail
            
            if self.is_email_exists(mail):
                return (False, 'ALREADY_EXISTS')

            # NOTE: `payload` ja arriba normalitzat i remapejat a claus de backend
            # (controllers/api -> _parse_*_payload_to_db). Aquí només calculem
            # derivats (quota efectiva, maildir, flags de servei...) i persistim.

            # NOTE: Obté `@domainProfile` `@domainAccountSetting`.
            domain_lib = lib_domain.Domain(self.domain)
            # NOTE: En SQL no existeix `accountStatus` (equivalent: `active`).
            # Demanem només els camps mínims que fem servir aquí.
            qr = domain_lib.get_profile(attributes=['settings', 'maxquota', 'active'])
            if not qr[0]:
                return qr
            domain_profile = qr[1]
            domain_settings = sqlutils.account_settings_string_to_dict(domain_profile['settings']) # accountSetting si  usar self.self._resolve_account_target() -> self._get_profile()

            # NOTE: Comprova el límit de nombre de comptes.
            _num_users_max = int(domain_settings.get("numberOfUsers", 0))
            # NOTE: `Domain.get_profile()` retorna `statistics` en el contracte actual.
            _num_users = int((domain_profile.get('statistics') or {}).get('users') or 0)
            if _num_users_max == -1:
                return (False, 'NOT_ALLOWED')
            elif _num_users > 0:
                if _num_users_max > 0 and _num_users_max <= _num_users:
                    return (False, 'EXCEEDED_DOMAIN_ACCOUNT_LIMIT')

            # NOTE: establim la contrasenya
            passwd_plain = ""
            _pw_hash = payload.get('password_hash', '')
            if _pw_hash:
                if not iredpwd.is_supported_password_scheme(_pw_hash):
                    return (False, 'INVALID_PASSWORD_SCHEME')
                passwd_hash = _pw_hash
            else:
                pwd_data = domain_lib.get_domain_pwd_data()
                qr_pw = form_utils.get_password(
                    form=payload,
                    input_name='newpw',
                    confirm_pw_input_name='confirmpw',
                    min_passwd_length=pwd_data.get("min_passwd_length"),
                    max_passwd_length=pwd_data.get("max_passwd_length"))
                if not qr_pw[0]:
                    return qr_pw
                passwd_plain = qr_pw[1]['pw_plain']
                passwd_hash = qr_pw[1]['pw_hash']

            # NOTE: Obtenir l'idioma preferit.
            preferred_language = str(payload.get("language", "") or "").strip()
            preferred_language = preferred_language if preferred_language in iredutils.get_language_maps() else ""

            # NOTE: Obtenir la quota.
            try:
                mailQuota = int(payload.get("quota", 0) or 0)
            except Exception:
                mailQuota = 0
            domainDefaultQuotaNewUser = domain_settings.get("default_user_quota")
            domainMaxQuotaUser = domain_profile.get("maxquota")
            if mailQuota == 0:
                # NOTE: 0 vol dir quota il·limitada
                quota = 0
            elif mailQuota == -1:
                # NOTE: -1 vol dir quota bloquejada
                quota = -1
            else:
                mailQuota = abs(mailQuota)
                if mailQuota == 0 and domainDefaultQuotaNewUser is not None:
                    quota = domainDefaultQuotaNewUser
                elif domainDefaultQuotaNewUser is not None and domainMaxQuotaUser is not None:
                    quota = min(max(mailQuota, domainDefaultQuotaNewUser), domainMaxQuotaUser)
                else:
                    quota = mailQuota
                # NOTE: Si quota calculada supera el límit màxim (i no és bloquejat), el limitem
                if domainMaxQuotaUser is not None and quota != -1:
                    quota = min(quota, domainMaxQuotaUser)

            # NOTE: Obtén el directori base d'emmagatzematge.
            _storage_base_directory = settings.storage_base_directory
            splited_sbd = _storage_base_directory.rstrip('/').split('/')
            storage_node = splited_sbd.pop()
            storage_base_directory = '/'.join(splited_sbd)
            maildir = iredutils.generate_maildir_path(self.mail)

            # Read full maildir path from web form - from RESTful API.
            mailbox_maildir = payload.get('maildir', '').lower().rstrip('/')
            if mailbox_maildir and os.path.isabs(mailbox_maildir):
                # Split storageBaseDirectory and storageNode
                _splited = mailbox_maildir.rstrip('/').split('/')
                storage_base_directory = '/' + _splited[0]
                storage_node = _splited[1]
                maildir = '/'.join(_splited[2:])

            domain_active_raw = domain_profile.get('accountStatus', domain_profile.get('active', 1))
            domain_is_active = str(domain_active_raw).strip().lower() in {
                '1', 'yes', 'true', 'on', 'active', 'enable', 'enabled'
            }

            record = {'domain': self.domain,
                    'username': self.mail,
                    'password': passwd_hash,
                    'name': payload.get("cn", ""),
                    'quota': quota,
                    'storagebasedirectory': storage_base_directory,
                    'storagenode': storage_node,
                    'maildir': maildir,
                    'language': preferred_language,
                    'passwordlastchange': iredutils.get_gmttime(),
                    'created': iredutils.get_gmttime(),
                    # NOTE: No creem bústies actives sota dominis desactivats.
                    'active': 1 if domain_is_active else 0}

            # NOTE: `mailboxFormat`/`mailboxFolder`/`maildir` no formen part del
            # keymap CRUD canònic. Es resolen localment a l'alta SQL per evitar
            # acoblar el flux d'alta als mapatges de perfil.
            
            db_settings = iredutils.get_settings_from_db()
            _mailbox_format = payload.get('mailboxFormat', db_settings['mailbox_format']).lower()
            _mailbox_folder = payload.get('mailboxFolder', db_settings['mailbox_folder'])
            if iredutils.is_valid_mailbox_format(_mailbox_format):
                record['mailboxformat'] = _mailbox_format

            if iredutils.is_valid_mailbox_folder(_mailbox_folder):
                record['mailboxfolder'] = _mailbox_folder

            # Set disabled mail services.
            disabled_mail_services = domain_settings.get('disabled_mail_services', [])
            for srv in disabled_mail_services:
                record['enable' + srv] = 0

            # globally disabled mail services
            for srv in settings.ADDITIONAL_DISABLED_USER_SERVICES:
                record['enable' + srv] = 0

            # globally enabled mail services
            for srv in settings.ADDITIONAL_ENABLED_USER_SERVICES:
                record['enable' + srv] = 1

            # NOTE: Guarda la contrasenya en clar només si està configurat i disponible.
            if settings.STORE_PLAIN_PASSWORD_IN_ADDITIONAL_ATTR and passwd_plain:
                record[settings.STORE_PLAIN_PASSWORD_IN_ADDITIONAL_ATTR] = passwd_plain

            # Store new user in SQL db.
            self.conn.insert('mailbox', **record)

            # Create an entry in `vmail.forwardings` with `address=forwarding`
            self.conn.insert(
                'forwardings',
                address=self.mail,
                forwarding=self.mail,
                domain=self.domain,
                dest_domain=self.domain,
                is_forwarding=1,
                active=1)

            log_activity(event='create',
                admin=session.get("username"),
                domain=self.domain,
                msg=f"Create user: {self.mail}.",
                )

            return (True, self.mail)

        def update(self, profile_type: str, payload: Dict) -> Tuple[bool, Union[Dict, str]]:
            profile_type = web.safestr(profile_type).strip().lower()
            if not isinstance(payload, dict):
                return (False, "INVALID_PAYLOAD")
            if not self.mail or not self.is_email(self.mail):
                return (False, "INVALID_MAIL")

            qr_domain = sql_lib_domain.simple_profile(
                conn=self.conn,
                domain=self.domain,
                columns=["maxquota", "settings"],
            )
            if not qr_domain[0]:
                return qr_domain
            domain_profile = qr_domain[1]
            domain_settings = sqlutils.account_settings_string_to_dict(
                domain_profile.get("settings", "")
            )

            disabled_user_profiles = domain_settings.get("disabled_user_profiles", [])
            if not session.get("is_global_admin") and profile_type in disabled_user_profiles:
                return (False, "PERMISSION_DENIED")

            # NOTE: Domain admin assignment (domainNames add/remove)
            if payload.get("domainNames"):
                qr = self.update_user_as_admin(payload)
                if not qr[0]:
                    return qr

            if profile_type == "forwarding":
                return self._update_forwarding(payload)

            if profile_type == "2fa":
                return self._update_2fa(payload)

            if profile_type == "aliases":
                return self._update_aliases(payload)

            if profile_type == "services":
                return self._update_services(payload)

            if profile_type == "password":
                oldpw = web.safestr(payload.get("oldpw", ""))
                newpw = web.safestr(payload.get("newpw", ""))
                confirmpw = web.safestr(payload.get("confirmpw", ""))
                min_passwd_length = domain_settings.get("min_passwd_length", 0)
                max_passwd_length = domain_settings.get("max_passwd_length", 0)

                qr_pw = iredpwd.verify_new_password(
                    newpw=newpw,
                    confirmpw=confirmpw,
                    min_passwd_length=min_passwd_length,
                    max_passwd_length=max_passwd_length,
                )
                if not qr_pw[0]:
                    return qr_pw

                require_cur_passwd = False if session.get("is_global_admin") else True
                return self.profile_change_password(
                    self.mail,
                    oldpw,
                    qr_pw[1],
                    require_cur_passwd=require_cur_passwd,
                    table="mailbox",
                )

            if profile_type != "general":
                # NOTE: Mantenim compatibilitat històrica: perfils desconeguts no fallen.
                return (True, "UPDATED")

            if payload.get("subscribed_ml"):
                qr = self._update_subscribed_ml(payload)
                if not qr[0]:
                    return qr

            updates = {"modified": iredutils.get_gmttime()}

            if "name" in payload or "cn" in payload:
                updates["name"] = payload.get("name", payload.get("cn", ""))

            if "language" in payload or "preferredLanguage" in payload:
                preferred_language = str(payload.get("language", payload.get("preferredLanguage", ""))).strip()
                if preferred_language in iredutils.get_language_maps():
                    updates["language"] = preferred_language
                else:
                    updates["language"] = ""

                if session.get("username") == self.mail and session.get("lang", "en_US") != preferred_language:
                    session["lang"] = preferred_language

            active_changed = False
            if "active" in payload or "accountStatus" in payload:
                updates["active"] = 1 if self._is_active_value(payload.get("active", payload.get("accountStatus", "disabled"))) else 0
                active_changed = True

            if "quota" in payload or "mailQuota" in payload:
                quota_raw = payload.get("quota", payload.get("mailQuota", 0))
                try:
                    quota = int(quota_raw or 0)
                except Exception:
                    quota = 0
                if quota < 0:
                    quota = 0
                updates["quota"] = quota

            if "employeeid" in payload or "employeeNumber" in payload:
                updates["employeeid"] = payload.get("employeeid", payload.get("employeeNumber", ""))

            try:
                self.conn.update(
                    "mailbox",
                    vars={"username": self.mail},
                    where="username=$username",
                    **updates,
                )
            except Exception as e:
                return (False, repr(e))

            if active_changed:
                try:
                    self.conn.update(
                        "forwardings",
                        vars={"address": self.mail},
                        where="address=$address OR forwarding=$address",
                        active=updates["active"],
                    )
                except Exception:
                    pass

            as_normal_admin = None
            if "isadmin" in payload or "domainadmin" in payload:
                as_normal_admin = self._is_active_value(payload.get("isadmin", payload.get("domainadmin")))

            as_global_admin = None
            if ("isglobaladmin" in payload or "domainGlobalAdmin" in payload) and session.get("is_global_admin"):
                as_global_admin = self._is_active_value(payload.get("isglobaladmin", payload.get("domainGlobalAdmin")))

            if as_normal_admin is not None or as_global_admin is not None:
                qr = sql_lib_user.mark_user_as_admin(
                    conn=self.conn,
                    domain=self.domain,
                    users=[self.mail],
                    as_normal_admin=as_normal_admin,
                    as_global_admin=as_global_admin,
                )
                if not qr[0]:
                    return qr

            settings_updates = {}
            settings_removes = []

            if "timezone" in payload:
                tz_name = str(payload.get("timezone", "") or "").strip()
                if tz_name:
                    settings_updates["timezone"] = tz_name
                    if session.get("username") == self.mail and tz_name in TIMEZONES:
                        session["timezone"] = TIMEZONES[tz_name]
                else:
                    settings_removes.append("timezone")

            for key in ["grant_admin", "disable_view_mail_log", "disable_manage_quarantined_mails"]:
                if key in payload:
                    settings_updates[key] = "yes" if self._is_active_value(payload.get(key)) else None

            if "create_new_domains" in payload:
                create_enabled = self._is_active_value(payload.get("create_new_domains"))
                settings_updates["create_new_domains"] = "yes" if create_enabled else None
                if create_enabled:
                    for key in ["create_max_domains", "create_max_users", "create_max_aliases", "create_max_quota"]:
                        if key in payload:
                            try:
                                value = int(payload.get(key))
                            except Exception:
                                continue
                            if value == -1 or value >= 0:
                                settings_updates[key] = value
                else:
                    settings_removes.extend(["create_max_domains", "create_max_users", "create_max_aliases", "create_max_quota"])

            if settings_updates or settings_removes:
                qr = self.update_user_settings(
                    mail=self.mail,
                    new_settings=settings_updates if settings_updates else None,
                    removed_settings=settings_removes if settings_removes else None,
                )
                if not qr[0]:
                    return qr

            log_activity(event="update",
                admin=session.get("username"),
                username=self.mail,
                domain=self.domain,
                msg=f"Update user profile ({profile_type}): {self.mail}."
            )
            return (True, "UPDATED")

        def rename(self, new_mail: str) -> Tuple[bool, str]:
            if not self.mail or not self.is_email(self.mail):
                return (False, 'INVALID_MAIL')

            new_mail = web.safestr(new_mail).strip().lower()
            if not self.is_email(new_mail):
                return (False, 'INVALID_MAIL')

            old_mail = self.mail
            if new_mail == old_mail:
                return (True, old_mail)

            old_domain = old_mail.split('@', 1)[-1]
            new_domain = new_mail.split('@', 1)[-1]
            if old_domain != new_domain:
                return (False, 'DOMAIN_MISMATCH')

            if self.is_email_exists(new_mail):
                return (False, 'ALREADY_EXISTS')

            new_maildir = iredutils.generate_maildir_path(new_mail)
            now = iredutils.get_gmttime()

            try:
                # NOTE: mailbox
                self.conn.update(
                    'mailbox',
                    vars={'old_username': old_mail},
                    where='username=$old_username',
                    username=new_mail,
                    maildir=new_maildir,
                    modified=now,
                )

                # NOTE: forwardings
                self.conn.update(
                    'forwardings',
                    vars={'old_address': old_mail},
                    where='address=$old_address',
                    address=new_mail,
                )
                self.conn.update(
                    'forwardings',
                    vars={'old_forwarding': old_mail},
                    where='forwarding=$old_forwarding',
                    forwarding=new_mail,
                )

                # NOTE: domain admin mappings
                self.conn.update(
                    'domain_admins',
                    vars={'old_username': old_mail},
                    where='username=$old_username',
                    username=new_mail,
                )

                # NOTE: taules d'ús i login (si existeixen)
                try:
                    self.conn.update(
                        settings.SQL_TBL_USED_QUOTA,
                        vars={'old_username': old_mail},
                        where='username=$old_username',
                        username=new_mail,
                    )
                except Exception:
                    pass

                try:
                    self.conn.update(
                        'last_login',
                        vars={'old_username': old_mail},
                        where='username=$old_username',
                        username=new_mail,
                        domain=new_domain,
                    )
                except Exception:
                    pass

            except Exception as e:
                return (False, repr(e))

            log_activity(event='update',
                admin=session.get("username"),
                domain=old_domain,
                msg=f"Rename user: {old_mail} -> {new_mail}."
            )

            self.mail = new_mail
            return (True, new_mail)

        @LibDecorators.safe_sql_method
        def delete(self, keep_mailbox_days: int = 0):
            """Backend-parity helper used by API DELETE /api/user/<mail>."""
            if not self.mail or not self.is_email(self.mail):
                return (False, "INVALID_MAIL")

            qr = self.delete_users([self.mail], keep_mailbox_days=keep_mailbox_days)
            if qr[0]:
                return (True, "DELETED")
            return qr

        @LibDecorators.safe_sql_method
        def delete_users(self, mails: List[str], keep_mailbox_days: int = 0) -> Tuple[bool, Union[List[str], Dict, str]]:
            """Manté el mateix contracte que la implementació LDAP per als controladors m_crud."""
            if not mails:
                return (False, "NO_ACCOUNT_SELECTED")

            accounts = [str(v).strip().lower() for v in mails if self.is_email(v)]
            if self.domain:
                accounts = [m for m in accounts if m.endswith("@" + self.domain)]

            if not accounts:
                return (False, "NO_ACCOUNT_SELECTED")

            qr = sql_lib_user.delete_users(
                accounts=accounts,
                keep_mailbox_days=keep_mailbox_days,
                conn=self.conn,
            )
            if qr[0]:
                return (True, "DELETED")
            return qr

        @LibDecorators.safe_sql_method
        def update_user_as_admin(self, payload: Dict) -> Tuple[bool, Union[Dict, str]]:
            if not self.mail or not self.is_email(self.mail):
                return (False, "INVALID_MAIL")

            domain_names = payload.get("domainNames", {}) if isinstance(payload, dict) else {}
            add_domains = utils._normalize_list_domains(domain_names.get("add", "")) if isinstance(domain_names, dict) else []
            remove_domains = utils._normalize_list_domains(domain_names.get("remove", "")) if isinstance(domain_names, dict) else []

            if not add_domains and not remove_domains:
                return (True, "NO_DOMAIN_SELECTED")

            errors = {}
            for d in remove_domains:
                ok, msg, *rest = self.update_domain_admins(domain=d, remove_admins=[self.mail])
                if not ok:
                    errors[d] = msg
            for d in add_domains:
                ok, msg, *rest = self.update_domain_admins(domain=d, add_admins=[self.mail])
                if not ok:
                    errors[d] = msg

            if errors:
                return (False, repr(errors))

            log_activity(event="update",
                admin=session.get("username"),
                msg=f"Update domain admin domains: {self.mail} (add: {self.logger_list_helper(add_domains)}, remove: {self.logger_list_helper(remove_domains)})."
                )
            return (True, "UPDATED")

        @LibDecorators.safe_sql_method
        def update_domain_admins(
            self,
            domain: str,
            add_admins: List[str] = None,
            remove_admins: List[str] = None,
            remove_all: bool = False
            ) -> Tuple[bool, Union[Dict, str]]:
            domain = web.safestr(domain).strip().lower()
            if not self.is_domain(domain):
                return (False, "INVALID_DOMAIN")

            add_admins = add_admins or []
            remove_admins = remove_admins or []

            # NOTE: ens quedem només amb correus del mateix domini
            add_admins = [
                str(m).strip().lower()
                for m in add_admins
                if m and isinstance(m, str) and m.strip().lower().endswith(f"@{domain}")
            ]
            remove_admins = [
                str(m).strip().lower()
                for m in remove_admins
                if m and isinstance(m, str) and m.strip().lower().endswith(f"@{domain}")
            ]

            if remove_all:
                self.conn.delete(
                    "domain_admins",
                    vars={"domain": domain},
                    where="domain=$domain",
                )
            else:
                if remove_admins:
                    self.conn.delete(
                        "domain_admins",
                        vars={"domain": domain, "mails": remove_admins},
                        where="domain=$domain AND username IN $mails",
                    )
                if add_admins:
                    self.conn.delete(
                        "domain_admins",
                        vars={"domain": domain, "mails": add_admins},
                        where="domain=$domain AND username IN $mails",
                    )
                    records = [
                        {
                            "username": m,
                            "domain": domain,
                            "created": iredutils.get_gmttime(),
                            "active": 1,
                        }
                        for m in add_admins
                    ]
                    if records:
                        self.conn.multiple_insert("domain_admins", records)

            log_activity(event="update",
                admin=session.get("username"),
                msg=f"Update domain admins for {domain} (add: {self.logger_list_helper(add_admins)}, remove: {self.logger_list_helper(remove_admins)}, remove_all: {remove_all})."
            )
            return (True, "UPDATED")

        def verify_password(self, password: str) -> Tuple[bool, str]:
            if not self.mail:
                return (False, 'INVALID_MAIL')
            return self.profile_verify_password(self.mail, password, table='mailbox')

        @LibDecorators.safe_sql_method
        def users_mark_unmark_as_globaladmin(self, mails: List[str], action: str) -> Tuple[bool, Union[List[str], Dict, str]]:
            """Parity with LDAP action names used by batch actions in user list UI."""
            if not session.get("is_global_admin"):
                return (False, "PERMISSION_DENIED")

            if action not in {"markasglobaladmin", "unmarkasglobaladmin", "add", "remove"}:
                return (False, "INVALID_ACTION")

            accounts = [str(v).strip().lower() for v in mails if self.is_email(v)]
            if self.domain:
                accounts = [m for m in accounts if m.endswith("@" + self.domain)]
            if not accounts:
                return (False, "NO_ACCOUNT_SELECTED")

            promote = action in {"markasglobaladmin", "add"}
            qr = sql_lib_user.promote_users_to_be_global_admin(
                mails=accounts,
                promote=promote,
                conn=self.conn,
            )
            if qr[0]:
                return (True, "MARKASGLOBALADMIN" if promote else "UNMARKASGLOBALADMIN")
            return qr

        def enable_disable_accounts(self, values, action):
            return super().enable_disable_accounts(values, action, 'user')

        def get_user_settings(self, mail: Optional[str] = None):
            target = mail if (mail and self.is_email(mail)) else self.mail
            if not target or not self.is_email(target):
                return (False, "INVALID_MAIL")
            return self.get_account_settings(target)
            #return _get_user_settings(mail=mail, existing_settings=existing_settings, conn=self.conn)

        @LibDecorators.safe_sql_method
        def get_user_forwardings(self, profile=None):
            if not profile:
                qr = self.get_profile()
                if not qr[0]:
                    return qr
                profile = qr[1]

            addresses = profile.get("catchallAddress")
            if addresses is None:
                addresses = profile.get("mailForwardingAddress", [])

            addrs = []
            for v in addresses or []:
                addr = str(v).strip().lower()
                if self.is_email(addr):
                    addrs.append(addr)

            return (True, sorted(set(addrs)))

        @LibDecorators.safe_sql_method
        def reset_user_forwardings(self, forwardings=None):
            if not self.mail or not self.is_email(self.mail):
                return (False, "INVALID_MAIL")

            if forwardings:
                addrs = [str(v).strip().lower() for v in forwardings if self.is_email(v)]
            else:
                addrs = []

            # NOTE: Mantenim lliurament local per defecte si la crida no passa destinació.
            if not addrs:
                addrs = [self.mail]

            addrs = list(dict.fromkeys(addrs))

            self.conn.delete(
                "forwardings",
                vars={"address": self.mail},
                where="address=$address",
            )

            records = []
            for fwd in addrs:
                records.append({
                    "address": self.mail,
                    "forwarding": fwd,
                    "domain": self.domain,
                    "dest_domain": fwd.split("@", 1)[-1],
                    "is_forwarding": 1,
                    "active": 1,
                })

            if records:
                self.conn.multiple_insert("forwardings", records)

            return (True, "")


        def _get_allowed_alias_domains(self) -> List[str]:
            allowed = {self.domain}
            try:
                qr = self.conn.select(
                    "alias_domain",
                    vars={"domain": self.domain},
                    what="alias_domain",
                    where="target_domain=$domain",
                )
                for row in qr:
                    alias_domain = str(row.alias_domain).strip().lower()
                    if alias_domain:
                        allowed.add(alias_domain)
            except Exception:
                pass

            return sorted(allowed)

        def _list_user_alias_addresses(self) -> List[str]:
            qr = self.conn.select(
                "forwardings",
                vars={"mail": self.mail},
                what="address",
                where="forwarding=$mail AND address<>$mail",
            )
            return sorted({
                str(row.address).lower()
                for row in qr
                if row.address
            })

        def _update_subscribed_ml(self, payload: Dict) -> Tuple[bool, Union[Dict, str]]:
            data = payload.get("subscribed_ml", {})
            if not isinstance(data, dict):
                return (True, "UPDATED")

            remove_mls = utils._normalize_list_mails(data.get("remove"))
            add_mls = utils._normalize_list_mails(data.get("add"))
            if not remove_mls and not add_mls:
                return (True, "UPDATED")

            errors = {}

            for ml in remove_mls:
                ml_domain = ml.split("@", 1)[-1]
                ok, msg = MailList_API(domain=ml_domain, mail=ml).remove_subscribers([self.mail])
                if not ok:
                    errors.setdefault("subscribed_ml_remove", {})[ml] = msg

            for ml in add_mls:
                ml_domain = ml.split("@", 1)[-1]
                ok, msg = MailList_API(domain=ml_domain, mail=ml).add_subscribers([self.mail])
                if not ok:
                    errors.setdefault("subscribed_ml_add", {})[ml] = msg

            if errors:
                return (False, errors)
            return (True, "UPDATED")

        def _update_aliases(self, payload: Dict) -> Tuple[bool, Union[Dict, str]]:
            if not isinstance(payload, dict):
                return (False, "INVALID_PAYLOAD")

            current_aliases = set(self._list_user_alias_addresses())
            target_aliases = set(current_aliases)

            raw_aliases = payload.get("extra_address")
            if isinstance(raw_aliases, dict):
                to_remove = set(utils._normalize_list_mails(raw_aliases.get("remove")))
                to_add = set(utils._normalize_list_mails(raw_aliases.get("add")))
                target_aliases.difference_update(to_remove)
                target_aliases.update(to_add)
            elif raw_aliases is not None:
                target_aliases = set(utils._normalize_list_mails(raw_aliases))

            target_aliases.discard(self.mail)

            alias_status = payload.get("alias")
            if alias_status is None:
                alias_status = payload.get("aliases")
            if alias_status == "disabled":
                target_aliases = set()

            allowed_domains = set(self._get_allowed_alias_domains())
            invalid_domain_aliases = sorted(
                alias for alias in target_aliases
                if alias.split("@", 1)[-1] not in allowed_domains
            )
            if invalid_domain_aliases:
                return (False, {"INVALID_ALIAS_DOMAIN": invalid_domain_aliases})

            duplicated = sorted(
                alias for alias in target_aliases
                if alias not in current_aliases and self.is_email_exists(alias)
            )
            if duplicated:
                return (False, {"ALREADY_EXISTS": duplicated})

            try:
                self.conn.delete(
                    "forwardings",
                    vars={"mail": self.mail},
                    where="forwarding=$mail AND address<>$mail",
                )

                records = []
                for alias in sorted(target_aliases):
                    alias_domain = alias.split("@", 1)[-1]
                    records.append({
                        "address": alias,
                        "forwarding": self.mail,
                        "domain": alias_domain,
                        "dest_domain": self.domain,
                        "is_alias": 1,
                        "active": 1,
                    })

                if records:
                    self.conn.multiple_insert("forwardings", records)
            except Exception as e:
                return (False, repr(e))

            log_activity(event="update",
                admin=session.get("username"),
                username=self.mail,
                domain=self.domain,
                msg=f"Update user aliases: {self.mail}."
            )
            return (True, "UPDATED")

        def _update_forwarding(self, payload: Dict) -> Tuple[bool, Union[Dict, str]]:
            qr_forwarding = self._normalize_forwarding_payload(
                payload=payload,
                keep_local_when_disabled=True,
            )
            if not qr_forwarding[0]:
                return qr_forwarding
            forwardings = qr_forwarding[1]["forwardings"]

            try:
                self.conn.delete(
                    "forwardings",
                    vars={"address": self.mail},
                    where="address=$address",
                )

                records = []
                for fwd in forwardings:
                    dest_domain = fwd.split("@", 1)[-1]
                    records.append({
                        "address": self.mail,
                        "forwarding": fwd,
                        "domain": self.domain,
                        "dest_domain": dest_domain,
                        "is_forwarding": 1,
                        "active": 1,
                    })

                if records:
                    self.conn.multiple_insert("forwardings", records)

                log_activity(event="update",
                    admin=session.get("username"),
                    username=self.mail,
                    domain=self.domain,
                    msg=f"Update user forwarding: {self.mail}."                    
                )
                return (True, "UPDATED")
            except Exception as e:
                return (False, repr(e))

        def _update_services(self, payload: Dict) -> Tuple[bool, Union[Dict, str]]:
            if not isinstance(payload, dict):
                return (False, "INVALID_PAYLOAD")

            qr_profile = self.get_profile(attributes=["enabledService", "mailForwardingAddress", "shadowAddress"])
            if not qr_profile[0]:
                return qr_profile
            profile = qr_profile[1] if isinstance(qr_profile[1], dict) else {}

            current_enabled = set(self._normalize_text_list(profile.get("enabledService")))
            qr_target = self._build_target_enabled_services(payload, current_enabled=list(current_enabled))
            if not qr_target[0]:
                return qr_target
            target_enabled = set(qr_target[1])

            supported_services = {"forward", "shadowaddress", "domainadmin", "domainGlobalAdmin"}
            unsupported = sorted([s for s in target_enabled if s not in supported_services])
            if unsupported:
                return (False, {
                    "UNSUPPORTED_SERVICES": unsupported,
                    "SUPPORTED_SERVICES": sorted(supported_services),
                })

            current_global = "domainGlobalAdmin" in current_enabled
            target_global = "domainGlobalAdmin" in target_enabled
            if current_global != target_global and not session.get("is_global_admin"):
                return (False, "PERMISSION_DENIED")

            qr_admin = sql_lib_user.mark_user_as_admin(
                conn=self.conn,
                domain=self.domain,
                users=[self.mail],
                as_normal_admin=("domainadmin" in target_enabled),
                as_global_admin=(target_global if session.get("is_global_admin") else None),
            )
            if not qr_admin[0]:
                return qr_admin

            current_forward = "forward" in current_enabled
            target_forward = "forward" in target_enabled
            if current_forward != target_forward:
                raw_forwardings = profile.get("mailForwardingAddress", [])
                forward_payload = {
                    "forwarding": "active" if target_forward else "disabled",
                    "savecopy": "active",
                    "mailForwardingAddress": utils._normalize_list_mails(raw_forwardings),
                }
                qr_forward = self._update_forwarding(forward_payload)
                if not qr_forward[0]:
                    return qr_forward

            current_alias = "shadowaddress" in current_enabled
            target_alias = "shadowaddress" in target_enabled
            if current_alias != target_alias:
                if target_alias:
                    # NOTE: En SQL `shadowaddress` depèn d'existència real d'àlies.
                    # No es pot "activar" sense adreces àlies configurades.
                    raw_aliases = profile.get("shadowAddress", [])
                    aliases = utils._normalize_list_mails(raw_aliases)
                    if not aliases:
                        return (False, "MISSING_ALIAS_ADDRESSES")

                qr_alias = self._update_aliases({"aliases": "active" if target_alias else "disabled"})
                if not qr_alias[0]:
                    return qr_alias

            log_activity(event="update",
                admin=session.get("username"),
                username=self.mail,
                domain=self.domain,
                msg=f"Update user services: {self.mail}.",
            )
            return (True, "UPDATED")

        def _update_2fa(self, payload: Dict) -> Tuple[bool, Union[Dict, str]]:
            qr = self.get_user_settings(self.mail)
            if not qr[0]:
                return (False, qr[1])
            account_settings = qr[1] or {}

            qr_2fa = self._build_2fa_settings_update(
                payload=payload,
                account_settings=account_settings,
            )
            if not qr_2fa[0]:
                return qr_2fa
            new_settings = qr_2fa[1]["new_settings"]
            removed_settings = qr_2fa[1]["removed_settings"]

            qr_update = self.update_user_settings(
                mail=self.mail,
                exist_settings=account_settings,
                new_settings=new_settings if new_settings else None,
                removed_settings=removed_settings if removed_settings else None,
            )
            if not qr_update[0]:
                return qr_update

            log_activity(event="update",
                admin=session.get("username"),
                username=self.mail,
                domain=self.domain,
                msg=f"Update user 2FA settings: {self.mail}."                
            )
            return (True, "UPDATED")

        def update_user_settings(self,
            mail: str,
            exist_settings: Optional[Dict] = None,
            new_settings: Optional[Dict] = None,
            removed_settings: Optional[List[str]] = None
            ):
            return self.update_account_settings(
                account=mail, 
                exist_settings=exist_settings,
                new_settings=new_settings,
                removed_settings=removed_settings
                )
            # return _update_user_settings(
            #     conn=self.conn, 
            #     mail=mail, 
            #     exist_settings=exist_settings,
            #     new_settings=new_settings,
            #     removed_settings=removed_settings
            #     )

elif settings.backend == "ldap":
    import ldap
    from libs.ldaplib import attrs
    from libs.ldaplib.user import (
        delete as _delete_users, 
        __delete_single_user as delete_single_user, 
        mark_unmark_as_admin
    )

    from libs.m_crudlib import LDAPWrap as Wrap 
    from libs.m_system.mixins import  LdapCRUDMixin, LdapLDIFMixin
    from libs.m_system.mixins.ldap.ldap_filter_builder import LDAPFilter as F
    
    class User(UserBase, LdapCRUDMixin, LdapLDIFMixin):
        def __init__(self, domain: Optional[str] = None, mail: Optional[str] = None):
            super().__init__(domain=domain, mail=mail)

            self.mail = mail if self.is_email(mail) else None #session.get('username') if not mail else str(mail).lower()
            self.domain = web.safestr(domain).strip().lower() if self.is_domain(domain) else None 
            if self.mail and not self.domain:
                self.domain = self.mail.split('@', 1)[-1]
            
            # NOTE: LDAP-specific init
            if self.mail and self.is_email(self.mail):
                self.dn = self.rdn_value_to_user_dn(self.mail)
            else:
                self.dn = None

            if self.domain and self.is_domain(self.domain):
                self.dn_domain = self.rdn_value_to_domain_dn(self.domain)
            else:
                self.dn_domain = None

        @LibDecorators.safe_ldap_method
        def list(self, search_filter: Optional[str] = None, attributes: Optional[List[str]] = None, email_only: bool = False, disabled_only: bool = False, starts_with: Optional[str] = None, current_page: int = 0):
            """
                Actualitza el nombre d'usuaris existents al perfil del domini.
            """
            update_count = False

            '''
                if not search_filter:
                    # Use '(!(mail=@domain.com))' to hide catch-all account.
                    filters = [f'(objectClass=mailUser)', f'(!(mail=@{self.domain}))']
                    update_count = True

                if disabled_only is True:
                    # utilitza "is True" aquí per evitar que el client introdueixi un valor invàlid a l'URL.
                    filters.append('(accountStatus=disabled)')

                if starts_with: #and self.is_valid_account_first_char(starts_with):
                    filters.append(f'(mail={starts_with}*)')

                search_filter = f"(&{''.join(filters)})"
            '''

            if not search_filter:
                query = F().and_(
                    f"(objectClass=mailUser)",
                    f"(!(mail=@{self.domain}))"
                )

                if disabled_only is True:
                    query.and_("(accountStatus=disabled)")

                if starts_with:
                    query.and_(f"(mail={starts_with}*)")

                search_filter = query.build()
                update_count = True

            if not attributes:
                attributes = [*attrs.USER_SEARCH_ATTRS, 'objectClass']

            if email_only:
                attributes = ['mail']

            qr = self.conn.search_s(
                self.rdn_value_to_ou_users_dn(self.domain),
                ldap.SCOPE_ONELEVEL,
                search_filter,
                attributes)

            _total_quota_sum = 0
            _list = []
            for (_dn, _ldif) in qr:
                if email_only:
                    _list.append(_ldif['mail'][0])
                else:
                    _ldif = utils.profile_define_adminType(_ldif)
                    # NOTE: Badges...
                    badges = []    
                    badges.append(_ldif.get('adminType'))
                    if 'shadowAddress' in _ldif and _ldif['shadowAddress']:
                        badges.append('aliases')
                    # NOTE: Comprova si és subscriptor de mailing lists (mlmmjadmin API)
                    _mail_val = iredutils.bytes2str(_ldif.get('mail'))
                    if isinstance(_mail_val, list):
                        _mail_val = _mail_val[0] if _mail_val else ''
                    if (
                        _mail_val
                        and settings.MLMMJADMIN_API_BASE_URL
                        and settings.mlmmjadmin_api_auth_token
                    ):
                        ok_ml, ml_lists, *rest = lib_ml(domain=self.domain).list(
                            subscriber=str(_mail_val).lower(),
                            email_only=True,
                            current_page=0,
                            all_domains=True,
                        )
                        if ok_ml and ml_lists:
                            badges.append('ml-member')
                    _ldif['img_badges'] = badges

                    # NOTE: Quota individual i suma total
                    # NOTE: Obtenim el valor de la quota de l'LDIF directament per sumar
                    q_val = _ldif.get('mailQuota', ['0'])[0]
                    if isinstance(q_val, bytes):
                        q_val = q_val.decode()
                    if str(q_val).isdigit():
                        _total_quota_sum += int(q_val)

                    if settings.SHOW_USED_QUOTA :
                        ok, _statistics, *rest = self.get_account_used_quota(_ldif.get('mail'))
                        _ldif['statistics']= _statistics
                    _list.append(_ldif)

            if update_count:
                d_obj = lib_domain.Domain(self.domain)
                # NOTE: 1. Actualitzem el comptador d'usuaris
                d_obj.num_users_under_domain()
                # NOTE: 2. Actualitzem la quota total calculada al vol
                # Actualitza el valor actual de quota de domini a LDAP (@attrs.ATTR_DOMAIN_CURRENT_QUOTA_SIZE).
                self.update_attr_with_single_value_by_dn(
                    d_obj.dn_domain, 
                    attrs.ATTR_DOMAIN_CURRENT_QUOTA_SIZE, 
                    str(_total_quota_sum)
                )

            sl = self.get_accounts_paged_list(_list, current_page=current_page, domain=self.domain, account_type='user')
            return (True, sl)

        @LibDecorators.safe_ldap_method
        def get_profile(self, attributes: Optional[List[str]] = None) -> Tuple[bool, Union[Dict, str]]:
            """
                Obté el perfil de l'usuari. Dades retornades: (True, {dict}) o (False, <error_reason>).

                :param attributes: llista de noms d'atributs LDAP
            """
            if not attributes:
                attributes = [*attrs.USER_ATTRS_ALL, 'objectClass']

            query_filter = F().and_(
                "(objectClass=mailUser)",
                f"(mail={self.mail})"
            ).build()
            qr = self.profile_get_by_dn(self.dn, query_filter=query_filter, attributes=attributes)
            if not qr[0]:
                return qr
            _ldif = qr[1]['ldif']

            # NOTE: Els administradors de domini normals no poden veure/actualitzar el perfil d'administrador global
            if not session.get('is_global_admin'):
                if _ldif.get('domainGlobalAdmin', 'no') == 'yes':
                    return (False, 'PERMISSION_DENIED_UPDATE_GLOBAL_ADMIN_PROFILE')

            _ldif['statistics'] = {**(self.get_account_used_quota(_ldif['mail'])[1] if settings.SHOW_USED_QUOTA else {}), **self.get_account_last_login(_ldif['mail'])[1]}

            for k in ['shadowAddress', 'mailForwardingAddress']:
                if k in _ldif:
                    _addrs = _ldif[k]
                    _addrs.sort()
                    _ldif[k] = _addrs

            return (True, _ldif)

        @LibDecorators.safe_ldap_method
        def add(self, payload: Dict) -> Tuple[bool, str]:
            '''
                Get domain name, username, cn.
                
                :param form:
            '''
            if not isinstance(payload, dict):
                return (False, "INVALID_PAYLOAD")

            if not self.domain:
                self.domain = self.mail.split("@", 1)[-1]
            if not self.is_domain(self.domain):
                return (False, "INVALID_DOMAIN_NAME")

            username = web.safestr(payload.get('username')).strip()
            mail = (f"{username}@{self.domain}" if username and self.domain else (self.mail or "")).strip().lower()
            mail = self.strip_mail_ext_address(mail)

            if not mail or not self.is_auth_email(mail):
                return (False, 'INVALID_MAIL')

            if self.exist_accounts([mail]):
                return (False, 'ALREADY_EXISTS')

            # NOTE: Obté `@domainProfile` `@domainAccountSetting`.
            domain_lib = lib_domain.Domain(self.domain)
            qr = domain_lib.get_domain_account_settings()
            if not qr[0]:
                return qr
            domain_settings = qr[1]
            qr =domain_lib.get_profile(attributes=['accountStatus', 'statistics'])
            if not qr[0]:
                return qr
            domain_profile = qr[1]
            domainStatus= domain_profile['accountStatus'] if qr[0] else {}

            # NOTE: Comprova el límit de nombre de comptes.
            _num_users_max = int(domain_settings.get("numberOfUsers", 0))
            _num_users = int(domain_profile['statistics']['users']) or 0
            if _num_users_max == -1:
                return (False, 'NOT_ALLOWED')
            elif _num_users > 0:
                if _num_users_max > 0 and _num_users_max <= _num_users:
                    return (False, 'EXCEEDED_DOMAIN_ACCOUNT_LIMIT')

            # NOTE: establim la contrasenya
            passwd_plain = ""
            _pw_hash = payload.get('password_hash', '')
            if _pw_hash:
                if not iredpwd.is_supported_password_scheme(_pw_hash):
                    return (False, 'INVALID_PASSWORD_SCHEME')
                passwd_hash = _pw_hash
            else:
                pwd_data = lib_domain.Domain(self.domain).get_domain_pwd_data()
                qr_pw = form_utils.get_password(
                    form=payload,
                    input_name='newpw',
                    confirm_pw_input_name='confirmpw',
                    min_passwd_length=pwd_data.get("min_passwd_length"),
                    max_passwd_length=pwd_data.get("max_passwd_length"))

                if not qr_pw[0]:
                    return qr_pw
                passwd_plain = qr_pw[1]['pw_plain']
                passwd_hash = qr_pw[1]['pw_hash']

            # NOTE: Obtenir l'idioma preferit.
            preferred_language = payload.get("language", "") or ""
            preferred_language = preferred_language if preferred_language in iredutils.get_language_maps() else ""

            # NOTE: Obtenir la quota.
            mailQuota = int(payload.get("mailQuota", 0))
            domainDefaultQuotaNewUser = domain_settings.get("defaultQuota")
            domainMaxQuotaUser = domain_settings.get("maxUserQuota")
            if mailQuota == 0:
                # NOTE: 0 vol dir quota il·limitada
                quota = 0
            elif mailQuota == -1:
                # NOTE: -1 vol dir quota bloquejada
                quota = -1
            else:
                mailQuota = abs(mailQuota)
                if mailQuota == 0 and domainDefaultQuotaNewUser is not None:
                    quota = domainDefaultQuotaNewUser
                elif domainDefaultQuotaNewUser is not None and domainMaxQuotaUser is not None:
                    quota = min(max(mailQuota, domainDefaultQuotaNewUser), domainMaxQuotaUser)
                else:
                    quota = mailQuota
                # NOTE: Si quota calculada supera el límit màxim (i no és bloquejat), el limitem
                if domainMaxQuotaUser is not None and quota != -1:
                    quota = min(quota, domainMaxQuotaUser)

            # NOTE: Obtenim les llistes de correu per defecte definides a `accountSetting` del domini.
            ldif = self.ldif_mailuser(
                domain=self.domain,
                username=username,
                cn=payload.get("cn", ""),
                passwd=passwd_hash,
                quota=quota,
                language=preferred_language,
                domain_status=domainStatus,
            )

            dn_user = self.rdn_value_to_user_dn(mail)

            # NOTE: Emmagatzema la contrasenya simple en un atribut addicional
            if passwd_plain and settings.STORE_PLAIN_PASSWORD_IN_ADDITIONAL_ATTR:
                ldif += [(settings.STORE_PLAIN_PASSWORD_IN_ADDITIONAL_ATTR, [passwd_plain])]

            self.conn.add_s(dn_user, ldif)

            lib_domain.Domain(self.domain).num_users_under_domain(increase=True)

            log_activity(event='create',
                admin=session.get("username"),
                domain=self.domain,
                msg=f"Create user: {mail}.",
                )

            return (True, mail)

        @LibDecorators.safe_ldap_method
        def update(self, profile_type: str, payload:Dict) -> Tuple[bool, Union[Dict, str]]:
            msg={}
            args={}
            mod_attrs = []
            domain_settings = {}
            plain_password_for_additional_attr = ""

            if not self.mail or not self.domain:
                return (False, "INVALID_MAIL")

            # NOTE: Domain admin assignment (domainNames add/remove)
            if isinstance(payload, dict) and payload.get("domainNames"):
                qr = self.update_user_as_admin(payload)
                if not qr[0]:
                    return qr

            qr_domain_settings = lib_domain.Domain(self.domain).get_domain_account_settings()
            if not qr_domain_settings[0]:
                return (False, qr_domain_settings[1])
            domain_settings = qr_domain_settings[1]
            disabled_user_profiles = domain_settings.get("disabledUserProfile", [])
            if not session.get("is_global_admin"):
                if profile_type in disabled_user_profiles:
                    return (False, "PERMISSION_DENIED")

            qr = self.get_profile()
            if not qr[0]:
                return qr
            profile = qr[1] if qr[0] else {}
            qr_user_settings = self.get_user_settings()
            if not qr_user_settings[0]:
                return (False, qr_user_settings[1])
            account_settings = qr_user_settings[1] if isinstance(qr_user_settings[1], dict) else {}
            enabled_services = { k : "add" for k in profile.get("enabledService", "") if qr[0]}
            # NOTE: Per contracte LDAP mantenim `disabledService`; sovint ve buit perquè
            # el model opera sobretot via `enabledService` + account settings.
            disabled_services = { k : "add" for k in profile.get("disabledService", "") if qr[0]}

            if profile_type == 'general':
                if session.get("is_global_admin") and "domainGlobalAdmin" in payload:
                    is_global_admin = payload.get("domainGlobalAdmin") == "active"
                    was_global_admin = profile.get("domainGlobalAdmin") == "yes"
                    args["domainGlobalAdmin"] = "yes" if is_global_admin else None

                    if is_global_admin and not was_global_admin:
                        log_activity(event="grant",
                            admin=session.get("username"),
                            username=self.mail,
                            domain=self.domain,
                            msg=f"User {self.mail} is marked as global admin."                            
                        )
                    elif not is_global_admin and was_global_admin:
                        log_activity(event="revoke",
                            admin=session.get("username"),
                            username=self.mail,
                            domain=self.domain,
                            msg=f"User {self.mail} is not a global admin anymore."                            
                        )

                if session.get("is_global_admin") or session.get("grant_admin"):
                    enabled_services.update({
                        k: "add" if payload.get(k) == "active" else "remove"
                        for k in ["domainadmin", "grant_admin"]
                        if k in payload
                    })

                    for k in ["disable_view_mail_log", "disable_manage_quarantined_mails"]:
                        if k in payload:
                            account_settings[k] = "yes" if payload.get(k) == "active" else None

                    if "create_new_domains" in payload:
                        create_enabled = payload.get("create_new_domains") == "active"
                        account_settings["create_new_domains"] = "yes" if create_enabled else None

                        if create_enabled:
                            for k in ["create_max_domains", "create_max_users", "create_max_aliases", "create_max_quota"]:
                                if k in payload:
                                    account_settings[k] = payload.get(k)
                        else:
                            for k in ["create_max_domains", "create_max_users", "create_max_aliases", "create_max_quota"]:
                                if k in account_settings:
                                    account_settings[k] = None

                # NOTE: Obté nom complet, nom, cognom, employeeNumber, mòbil i càrrec.
                # NOTE: cn, givenName, sn are required by objectClass `inetOrgPerson`.
                localpart = self.mail.split("@", 1)[0]
                for k in ["cn", "givenName", "sn"]:
                    if k in payload:
                        args[k] = (payload.get(k) or localpart).strip()

                for k in ["employeeNumber", "mailQuota", "accountStatus", "mtaTransport"]:
                    if k in payload:
                        args[k] = payload.get(k) or None

                # NOTE: Si l'usuari actual és el mateix i el llenguatge ha canviat, actualitza la sessió
                preferred_lang = None
                if 'defaultLanguage' in payload:
                    preferred_lang = payload.get('defaultLanguage')
                elif 'preferredLanguage' in payload:
                    preferred_lang = payload.get('preferredLanguage')

                if preferred_lang:
                    args['preferredLanguage'] = preferred_lang
                    if session.get('username') == self.mail and session.get('lang', 'en_US') != preferred_lang:
                        session['lang'] = preferred_lang

                # NOTE: Actualitza la zona horària
                tz_name = payload.get('timezone')
                if tz_name and TIMEZONES.get(tz_name) :
                    account_settings['timezone'] = tz_name
                    if session['username'] == self.mail and tz_name:
                        session['timezone'] = TIMEZONES[tz_name]

                for k in ["mobile", "telephoneNumber"]:
                    if k in payload:
                        values = payload.get(k)
                        if not isinstance(values, list):
                            values = [values]
                        values = [web.safestr(v).strip() for v in values if web.safestr(v).strip()]
                        args[k] = list(dict.fromkeys(values)) if values else None

                if "title" in payload:
                    values = payload.get("title")
                    if not isinstance(values, list):
                        values = [values]
                    values = [web.safestr(v).strip() for v in values if web.safestr(v).strip()]
                    args["title"] = list(dict.fromkeys(values)) if values else None

                # NOTE: check account status.
                if "subscribed_ml" in payload:
                    remove_ml_subscription=utils._normalize_list_mails(payload["subscribed_ml"]["remove"])
                    if remove_ml_subscription:
                        for mail in remove_ml_subscription:
                            result=MailList_API(domain=self.domain, mail=mail).remove_subscribers([self.mail])
                            if not result[0]:
                                msg.setdefault("update_profile subscribed_ml_remove", {})[mail] = result[1]
                    set_ml_subscription=utils._normalize_list_mails(payload["subscribed_ml"]["add"])
                    if set_ml_subscription:
                        for mail in set_ml_subscription:
                            result=MailList_API(domain=self.domain, mail=mail).add_subscribers([self.mail])
                            if not result[0]:
                                msg.setdefault("update_profile subscribed_ml_add", {})[mail] = result[1]

            elif profile_type == 'aliases':
                # NOTE: Compat API/UI: `aliases` és el flag funcional equivalent a `shadowaddress`.
                if "aliases" in payload and "shadowaddress" not in payload:
                    payload["shadowaddress"] = payload.get("aliases")

                if "shadowaddress" in payload:
                    is_alias_active = payload.get("shadowaddress") == "active"
                    enabled_services["shadowaddress"] = ("add" if is_alias_active else "remove")
                    if not is_alias_active:
                        # NOTE: Si es desactiva el servei d'àlies, netegem les adreces.
                        args["shadowAddress"] = None

                if "shadowAddress" in payload:
                    raw_shadow = payload.get("shadowAddress")
                    if isinstance(raw_shadow, dict):
                        args['shadowAddress'] = utils._normalize_list_mails(raw_shadow.get("add"))
                    else:
                        args['shadowAddress'] = utils._normalize_list_mails(raw_shadow)

            elif profile_type == 'password':
                pw_hash = payload.get('password_hash')
                if pw_hash:
                    if not iredpwd.is_supported_password_scheme(pw_hash):
                        msg['update_profile verify_password_hash'] = 'INVALID_PASSWORD_SCHEME'
                    else:
                        args['userPassword'] = pw_hash
                else:
                    pwd_data = lib_domain.Domain(self.domain).get_domain_pwd_data()
                    # NOTE: Obté les contrasenyes noves de l'entrada d'usuari.
                    args['currentUserPassword'] = payload.get('oldpw', '')
                    newpw = web.safestr(payload.get('newpw', ''))
                    confirmpw = web.safestr(payload.get('confirmpw', ''))

                    result = iredpwd.verify_new_password(
                        newpw               =newpw,
                        confirmpw           =confirmpw,
                        min_passwd_length   =pwd_data.get("min_passwd_length"),
                        max_passwd_length   =pwd_data.get("max_passwd_length"))

                    if not result[0]:
                        msg['update_profile verify_new_password'] = result[1]
                    args['userPassword'] = result[1]
                    req_cur_passwd = False if session.get('is_global_admin') else True
                    qr = self.profile_change_password(self.dn, args['currentUserPassword'], args['userPassword'], req_cur_passwd)
                    if not qr[0]:
                        msg['update_profile profile_change_password'] = qr[1]
                    else:
                        plain_password_for_additional_attr = newpw
                    for key in ('userPassword', 'currentUserPassword'):
                        args.pop(key, None)

            elif profile_type == 'forwarding':
                ok, err = self._update_forwarding(payload, enabled_services)
                if not ok:
                    msg['update_profile forwarding'] = err

            elif profile_type == 'services':
                ok, err = self._update_services(payload, profile, enabled_services, disabled_services, args)
                if not ok:
                    msg['update_profile services'] = err

            elif profile_type == '2fa':
                ok, err = self._update_2fa(payload, account_settings)
                if not ok:
                    msg['update_profile 2fa'] = err

            for k in enabled_services:
                self.add_or_remove_enabled_service_by_dn(self.dn, k, enabled_services[k] )

            for k in disabled_services:
                self.add_or_remove_disabled_service_by_dn(self.dn, k, disabled_services[k] )

            args['accountSetting'] = self.account_setting_dict_to_list(account_settings)

            for k in args:
                mod_attrs += self.mod_replace(k, args[k])

            if settings.STORE_PLAIN_PASSWORD_IN_ADDITIONAL_ATTR and plain_password_for_additional_attr:
                mod_attrs += self.mod_replace(
                    settings.STORE_PLAIN_PASSWORD_IN_ADDITIONAL_ATTR,
                    plain_password_for_additional_attr,
                )

            try:
                self.conn.modify_s(self.dn, mod_attrs)
            except Exception as e:
                msg['update_profile modify_s'] = repr(e)

            if msg == {}:
                log_activity(event='update',
                    admin=session.get('username'),
                    username=self.mail,
                    domain=self.domain,
                    msg=f"Update user profile ({profile_type}): {self.mail}."
                    )
                return (True, 'UPDATED')
            else:
                return (False, msg)

        def rename(self, new_mail: str) -> Tuple[bool, str]:
            if not self.mail or not self.is_email(self.mail):
                return (False, 'INVALID_MAIL')

            new_mail = web.safestr(new_mail).strip().lower()
            if not self.is_email(new_mail):
                return (False, 'INVALID_MAIL')

            old_mail = self.mail
            if new_mail == old_mail:
                return (True, old_mail)

            old_domain = old_mail.split('@', 1)[-1]
            new_domain = new_mail.split('@', 1)[-1]
            if old_domain != new_domain:
                return (False, 'DOMAIN_MISMATCH')

            if self.exist_accounts([new_mail]):
                return (False, 'ALREADY_EXISTS')

            # NOTE: Capture current profile data before renaming DN
            qr = self.profile_get_by_dn(self.dn, attributes=['mail', 'uid', 'shadowAddress'])
            if not qr[0]:
                return (False, qr[1])
            _ldif = qr[1]['ldif']

            # NOTE: Rename DN
            try:
                from ldap.dn import escape_dn_chars
                new_rdn = f"{attrs.RDN_USER}={escape_dn_chars(new_mail)}"
                self.conn.modrdn_s(self.dn, new_rdn, delold=1)
            except Exception as e:
                return (False, repr(e))

            # NOTE: Actualitza els atributs de l'entrada
            mod_attrs = []
            mod_attrs += self.mod_replace('mail', new_mail)
            mod_attrs += self.mod_replace('uid', new_mail.split('@', 1)[0])

            shadow = _ldif.get('shadowAddress', [])
            try:
                shadow = [v.decode() if isinstance(v, bytes) else v for v in shadow]
            except Exception:
                pass
            if shadow:
                shadow = [new_mail if v == old_mail else v for v in shadow]
                mod_attrs += self.mod_replace('shadowAddress', shadow)

            new_dn = self.rdn_value_to_user_dn(new_mail)
            try:
                if mod_attrs:
                    self.conn.modify_s(new_dn, mod_attrs)
            except Exception as e:
                return (False, repr(e))

            # NOTE: Actualitza les referències de `domainAdmin` si cal
            try:
                domain_dn = self.rdn_value_to_domain_dn(old_domain)
                qr = self.profile_get_by_dn(domain_dn, attributes=['domainAdmin'], raw=True)
                if qr[0]:
                    domain_admins = qr[1]['ldif'].get('domainAdmin', [])
                    try:
                        domain_admins = [v.decode() if isinstance(v, bytes) else v for v in domain_admins]
                    except Exception:
                        pass
                    if old_mail in domain_admins:
                        self.add_or_remove_attr_values_by_dn(domain_dn, 'domainAdmin', old_mail, 'remove')
                        self.add_or_remove_attr_values_by_dn(domain_dn, 'domainAdmin', new_mail, 'add')
            except Exception:
                pass

            log_activity(event='update',
                admin=session.get("username"),
                domain=old_domain,
                msg=f"Rename user: {old_mail} -> {new_mail}."
            )

            self.mail = new_mail
            self.dn = new_dn
            return (True, new_mail)

        def delete(self, keep_mailbox_days: int = 0):
            return delete_single_user(self.mail, keep_mailbox_days, self.conn)

        def delete_users(self, mails: List[str], keep_mailbox_days: int = 0) -> Tuple[bool, Union[List[str], Dict, str]]:
            qr = _delete_users(self.domain, mails,keep_mailbox_days, self.conn)
            if qr[0]:
                return (True, 'DELETED')
            return qr

        @LibDecorators.safe_ldap_method
        def update_user_as_admin(self, payload: Dict) -> Tuple[bool, Union[Dict, str]]:
            if not self.mail or not self.is_email(self.mail):
                return (False, "INVALID_MAIL")

            domain_names = payload.get("domainNames", {}) if isinstance(payload, dict) else {}
            add_domains = utils._normalize_list_domains(domain_names.get("add", "")) if isinstance(domain_names, dict) else []
            remove_domains = utils._normalize_list_domains(domain_names.get("remove", "")) if isinstance(domain_names, dict) else []

            if not add_domains and not remove_domains:
                return (True, "NO_DOMAIN_SELECTED")

            errors = {}
            for d in remove_domains:
                ok, msg, *rest = self.update_domain_admins(domain=d, remove_admins=[self.mail])
                if not ok:
                    errors[d] = msg
            for d in add_domains:
                ok, msg, *rest = self.update_domain_admins(domain=d, add_admins=[self.mail])
                if not ok:
                    errors[d] = msg

            if errors:
                return (False, repr(errors))
            return (True, "UPDATED")

        @LibDecorators.safe_ldap_method
        def update_domain_admins(
            self,
            domain: str,
            add_admins: List[str] = None,
            remove_admins: List[str] = None,
            remove_all: bool = False
            ) -> Tuple[bool, Union[Dict, str]]:
            domain = web.safestr(domain).strip().lower()
            if not self.is_domain(domain):
                return (False, "INVALID_DOMAIN")

            add_admins = add_admins or []
            remove_admins = remove_admins or []

            add_admins = [
                str(m).strip().lower()
                for m in add_admins
                if m and isinstance(m, str) and m.strip().lower().endswith(f"@{domain}")
            ]
            remove_admins = [
                str(m).strip().lower()
                for m in remove_admins
                if m and isinstance(m, str) and m.strip().lower().endswith(f"@{domain}")
            ]

            domain_dn = self.rdn_value_to_domain_dn(domain)

            if remove_all:
                self.conn.modify_s(domain_dn, self.mod_replace("domainAdmin", None))
            else:
                if remove_admins:
                    self.add_or_remove_attr_values_by_dn(
                        dn=domain_dn,
                        attr="domainAdmin",
                        values=remove_admins,
                        action="remove",
                    )
                if add_admins:
                    self.add_or_remove_attr_values_by_dn(
                        dn=domain_dn,
                        attr="domainAdmin",
                        values=add_admins,
                        action="add",
                    )
            return (True, "UPDATED")

        def verify_password(self, password: str) -> Tuple[bool, str]:
            if not self.mail or not self.is_email(self.mail):
                return (False, 'INVALID_MAIL')
            if not password:
                return (False, 'MISSING_PASSWORD')

            qr = self.profile_get_by_dn(self.dn, attributes=['userPassword'])
            if not qr[0]:
                return (False, qr[1])

            pw_hash = qr[1]['ldif'].get('userPassword', [''])[0]
            if iredpwd.verify_password_hash(pw_hash, password):
                return (True, )
            return (False, 'INVALID_CREDENTIALS')

        def users_mark_unmark_as_globaladmin(self, mails: List[str], action: str) -> Tuple[bool, Union[List[str], Dict, str]]:
            qr= mark_unmark_as_admin(self.domain, mails, action, self.conn )
            if qr[0]:
                return (True, 'MARKASGLOBALADMIN' if action in['add'] else 'UNMARKASGLOBALADMIN')
            return qr

        def enable_disable_accounts(self, values, action):
            return super().enable_disable_accounts(values, action, 'user')

        def get_user_settings(self):
            if not self.mail or not self.is_email(self.mail):
                return (False, 'INVALID_MAIL')

            accs = self._get_user_account_settings(self.mail, profile=None)
            if accs is False:
                return (False, 'FAILED_TO_GET_USER_SETTINGS')
            if not isinstance(accs, dict):
                return (False, 'INVALID_USER_SETTINGS')
            return (True, accs)

        def get_user_forwardings(self, profile=None):
            if not profile:
                _qr = self.get_profile(['mailForwardingAddress'])
                if not _qr[0]:
                    return _qr

            _addresses = [i.lower() for i in _qr[1].get('mailForwardingAddress', [])]
            _addresses = list(set(_addresses))

            return (True, _addresses)

        def reset_user_forwardings(self, forwardings=None):
            if forwardings:
                _addresses = [str(v).lower()
                            for v in forwardings
                            if self.is_email(v)]
            else:
                _addresses = []

            # NOTE: Elimina adreces duplicades
            if _addresses:
                _addresses = list(set(_addresses))

            # NOTE: Elimina adreces inexistents del mateix domini.
            addrs_in_domain = set()
            addrs_not_in_domain = set()

            for addr in _addresses:
                if addr.endswith('@' + self.domain):
                    addrs_in_domain.add(addr)
                else:
                    addrs_not_in_domain.add(addr)

            # NOTE: Obté les adreces existents
            valid_addrs_in_domain = set()
            if addrs_in_domain:
                _qr = self.exist_accounts(mails=addrs_in_domain, base_dn=self.dn_domain)
                if isinstance(_qr, dict):
                    valid_addrs_in_domain = set(_qr.get('exist', []))
                elif _qr is True:
                    # NOTE: `exist_accounts` retorna bool quan rep una sola adreça.
                    valid_addrs_in_domain = set(addrs_in_domain)
                else:
                    valid_addrs_in_domain = set()

            fwd_addrs = list(valid_addrs_in_domain | addrs_not_in_domain)

            if fwd_addrs:
                mod_attr = self.mod_replace('mailForwardingAddress', fwd_addrs)
            else:
                mod_attr = self.mod_replace('mailForwardingAddress', None)

            try:
                self.conn.modify_s(self.dn, mod_attr)
                return (True, )
            except Exception as e:
                return (False, repr(e))


        def _update_forwarding(self, payload: Dict, enabled_services: Dict) -> Tuple[bool, str]:
            qr_forwarding = self._normalize_forwarding_payload(
                payload=payload,
                keep_local_when_disabled=False,
            )
            if not qr_forwarding[0]:
                return (False, qr_forwarding[1])
            forward_enabled = qr_forwarding[1]["forward_enabled"]
            forwardings = qr_forwarding[1]["forwardings"]

            if "forwarding" in payload:
                enabled_services["forward"] = "add" if forward_enabled else "remove"

            qr = self.reset_user_forwardings(forwardings)
            if not qr[0]:
                return (False, qr[1])
            return (True, "")

        def _update_services(
            self,
            payload: Dict,
            profile: Dict,
            enabled_services: Dict,
            disabled_services: Dict,
            args: Dict,
        ) -> Tuple[bool, str]:
            current_enabled = self._normalize_text_list(profile.get("enabledService", []))
            qr_target = self._build_target_enabled_services(payload, current_enabled=current_enabled)
            if not qr_target[0]:
                return (False, qr_target[1])
            target_enabled = set(qr_target[1])
            current_enabled_set = set(current_enabled)

            supported_services = set(attrs.USER_SERVICES_ALL) | {"domainGlobalAdmin"}
            unsupported = sorted([s for s in target_enabled if s not in supported_services])
            if unsupported:
                return (False, {
                    "UNSUPPORTED_SERVICES": unsupported,
                    "SUPPORTED_SERVICES": sorted(supported_services),
                })

            current_global = profile.get("domainGlobalAdmin") == "yes"
            target_global = "domainGlobalAdmin" in target_enabled
            if current_global != target_global:
                if not session.get("is_global_admin"):
                    return (False, "PERMISSION_DENIED")
                args["domainGlobalAdmin"] = "yes" if target_global else None

            added = target_enabled - current_enabled_set
            removed = current_enabled_set - target_enabled

            for srv in added:
                if srv == "domainGlobalAdmin":
                    continue
                enabled_services[srv] = "add"
                if srv in disabled_services:
                    disabled_services[srv] = "remove"

            for srv in removed:
                if srv == "domainGlobalAdmin":
                    continue
                enabled_services[srv] = "remove"
                disabled_services[srv] = "add"

            return (True, "")

        def _update_2fa(self, payload: Dict, account_settings: Dict) -> Tuple[bool, str]:
            qr_2fa = self._build_2fa_settings_update(
                payload=payload,
                account_settings=account_settings,
            )
            if not qr_2fa[0]:
                return (False, qr_2fa[1])

            new_settings = qr_2fa[1]["new_settings"]
            removed_settings = qr_2fa[1]["removed_settings"]

            for k, v in new_settings.items():
                account_settings[k] = v
            for k in removed_settings:
                account_settings[k] = None

            return (True, "")

else:
    raise RuntimeError(f"Backend no suportat: {settings.backend}")
