# libs/m_crudlib/admin.py
import web
from typing import List, Tuple, Dict, Union, Optional

import settings
from libs import iredutils, iredpwd
from libs.l10n import TIMEZONES
from libs.logger import log_activity

from libs.m_system.decorators import LibDecorators
from libs.m_crudlib import security, domain as lib_domain
from libs.m_crudlib import user as lib_user
from libs.m_system import utils

session = web.config.get('_session')

class AdminBase:
    def __init__(self, domain: Optional[str] = None, mail: Optional[str] = None):
        self.domain = domain
        self.mail = mail
        self.backend = Wrap()
        self.conn = self.backend.conn

    # def _not_implemented(self, method_name):
    #     raise NotImplementedError(f"{self.__class__.__name__}.{method_name} no està implementat per aquest backend")

    # def list(self, *args, **kwargs):
    #     self._not_implemented("list")

    # def get_profile(self, *args, **kwargs):
    #     self._not_implemented("get_profile")

    def statistics(self) -> Dict:
        results = {
            'domains': 0,
            'users':0,
            'maillists':0,
            'bytes': 0,
            'messages':0,
            'amavisd':{}
        }
        time_length = 1  # NOTE: `None` per a proves.

        qr = lib_domain.Domain().get_all_domains()
        if not qr[0] or not isinstance(qr[1], list):
            return results

        results['domains'] =len(qr[1])
        for d in qr[1]:
            # NOTE: LDAP retorna 'domainName', SQL retorna 'domain'.
            domain_raw = d.get('domainName') if isinstance(d, dict) else None
            if domain_raw is None and isinstance(d, dict):
                domain_raw = d.get('domain')

            if isinstance(domain_raw, list):
                domain = str(domain_raw[0]).lower() if domain_raw else ''
            else:
                domain = str(domain_raw).lower() if domain_raw else ''

            if not domain:
                continue

            results[domain] = {}
            domain_lib = lib_domain.Domain(domain=domain)
            results[domain]['users'] = domain_lib.num_users_under_domain()
            results[domain]['maillists'] = domain_lib.num_maillists_under_domain()
            quota_qr = domain_lib.get_domain_used_quota(domain)
            _domain_used_quota = {'bytes': 0, 'messages': 0}
            if isinstance(quota_qr, tuple):
                ok = bool(quota_qr[0]) if len(quota_qr) > 0 else False
                data = quota_qr[1] if len(quota_qr) > 1 and isinstance(quota_qr[1], dict) else {}
                if ok:
                    _domain_used_quota['bytes'] = int(data.get('bytes', 0) or 0)
                    _domain_used_quota['messages'] = int(data.get('messages', 0) or 0)
            elif isinstance(quota_qr, dict):
                _domain_used_quota['bytes'] = int(quota_qr.get('bytes', 0) or 0)
                _domain_used_quota['messages'] = int(quota_qr.get('messages', 0) or 0)

            results[domain]['bytes'] = _domain_used_quota['bytes']
            results[domain]['messages'] = _domain_used_quota['messages']
            results['users']+=results[domain]['users']
            results['maillists']+=results[domain]['maillists']
            results['bytes']+=results[domain]['bytes']
            results['messages']+=results[domain]['messages']

        if settings.amavisd_enable_logging or settings.amavisd_enable_quarantine:
            try:
                from libs.m_amavisd import quarantine as lib_qua
                lib_log = lib_qua.Quarantine(is_global_admin=session.get('is_global_admin'))
                results['amavisd'] = lib_log.get_counts(False, days=time_length)
            except Exception:
                results['amavisd'] = {}

        # NOTE: iredAPD SMTP Stats
        try:
            from libs.m_iredapd import smtp as lib_smtp
            smtp_lib = lib_smtp.SMTPStats()
            results['smtp'] = smtp_lib.get_counts(days=time_length)
        except Exception:
            results['smtp'] = {}

        # NOTE: Fail2Ban Stats
        try:
            from libs.m_fail2ban import fail2ban as lib_f2b
            results['fail2ban'] = lib_f2b.F2BManager().get_counts(days=time_length)
        except Exception:
            results['fail2ban'] = {}

        return results

    def count_admins(self) -> int:
        try:
            qr = self.list(email_only=True)
            if isinstance(qr, tuple):
                if len(qr) > 1 and qr[0]:
                    data = qr[1]
                    if isinstance(data, list):
                        return len(data)
                return 0
            if isinstance(qr, list):
                return len(qr)
        except Exception:
            pass
        return 0

    def get_creation_limits(self, mail: Optional[str] = None) -> Dict:
        results = {
            "account": mail,
            "create_max_users": 0,
            "create_max_domains": 0,
            "num_spare_users": 0,
            "num_spare_domains": 0,
        }

        try:
            qr = lib_user.User(mail=mail).get_user_settings()
            if not (isinstance(qr, tuple) and qr and qr[0] and isinstance(qr[1], dict)):
                return results
            data = qr[1]

            for key in [
                "create_max_users",
                "create_max_domains",
                "num_spare_users",
                "num_spare_domains",
            ]:
                try:
                    results[key] = int(data.get(key, 0) or 0)
                except Exception:
                    results[key] = 0
        except Exception:
            return results

        return results

    def get_account_last_login(self,  mail: Optional[str] = None) -> Dict[str, int]:
        return lib_user.User(mail=mail).get_account_last_login(mail)

    def _admin_profile_statistics(self, mail: Optional[str] = None) -> Dict:
        # NOTE: Contracte únic per perfil admin (SQL/LDAP): objecte dict, buit si no hi ha dades.
        if not mail:
            return {}

        try:
            qr = self.get_account_last_login(mail)
        except Exception:
            return {}

        if isinstance(qr, tuple):
            if qr and qr[0] and len(qr) > 1 and isinstance(qr[1], dict):
                return qr[1]
            return {}

        if isinstance(qr, dict):
            return qr

        return {}

    @staticmethod
    def _resolve_admin_profile_type(profile_type: Optional[str], payload: Optional[Dict]) -> str:
        valid = {'general', 'password', '2fa'}
        ptype = web.safestr(profile_type or '').strip().lower()
        if ptype in valid:
            return ptype

        keys = set(payload.keys()) if isinstance(payload, dict) else set()
        if keys.intersection({'oldpw', 'newpw', 'confirmpw', 'currentUserPassword', 'password', 'password_hash'}):
            return 'password'
        if any(str(k).startswith('2fa_') for k in keys):
            return '2fa'

        # NOTE: Fallback segur per compatibilitat amb callers antics que no envien `profile_type`.
        return 'general'

if settings.backend in ["mysql", "pgsql"]:
    from libs.m_crudlib import SQLWrap as Wrap
    from libs.m_system.mixins import SQLCRUDMixin, SQLWhereBuilder
    from libs.sqllib.general import (
        get_admin_settings as _get_admin_settings, 
        update_admin_settings as _update_admin_settings,
    )

    class Admin(AdminBase, SQLCRUDMixin):
        def __init__(self, domain: Optional[str] = None, mail: Optional[str] = None):
            super().__init__(domain=domain, mail=mail)

        @staticmethod
        def _is_truthy_flag(value: object) -> bool:
            return str(value or '').strip().lower() in {'1', 'yes', 'true', 'on', 'active', 'enabled'}

        def _get_admin_privilege_state(self, mail: str) -> Dict[str, int]:
            state = {'isadmin': 0, 'isglobaladmin': 0}
            if not self.is_email(mail):
                return state

            qr = self.conn.select(
                'domain_admins',
                vars={'username': mail},
                what='domain,active',
                where='username=$username',
            )
            for row in qr:
                if not self._is_truthy_flag(getattr(row, 'active', 1)):
                    continue

                state['isadmin'] = 1
                domain_name = str(getattr(row, 'domain', '') or '').strip().upper()
                if domain_name == 'ALL':
                    state['isglobaladmin'] = 1

            qr_mb = self.conn.select(
                'mailbox',
                vars={'username': mail},
                what='isadmin,isglobaladmin',
                where='username=$username',
                limit=1,
            )
            if qr_mb:
                row = qr_mb[0]
                mb_isadmin = 1 if self._is_truthy_flag(getattr(row, 'isadmin', 0)) else 0
                mb_isglobaladmin = 1 if self._is_truthy_flag(getattr(row, 'isglobaladmin', 0)) else 0
                state['isadmin'] = max(state['isadmin'], mb_isadmin, mb_isglobaladmin)
                state['isglobaladmin'] = max(state['isglobaladmin'], mb_isglobaladmin)

            return state

        @LibDecorators.safe_sql_method
        def list(self, email_only: bool = False, current_page: int = 0) -> Tuple[bool, Union[List, Dict, str]]:
            # NOTE: Contracte:
            # - current_page <= 0: retorna la llista completa (usat pels helpers).
            # - current_page > 0 : càrrega paginada per als controladors CRUD de la UI.
            current_page = self.normalize_current_page(current_page=current_page, default=0, min_page=0)
            use_pagination = current_page > 0

            sql_what = 'username' if email_only else '*'
            records = []

            qr = self.conn.select('admin', what=sql_what, order='username')
            records += list(qr)

            builder = SQLWhereBuilder()
            builder.add_raw('(isadmin=1 OR isglobaladmin=1)')
            sql_where, sql_vars = builder.build()

            qr = self.conn.select(
                'mailbox',
                vars=sql_vars,
                what=sql_what,
                where=sql_where,
                order='username'
            )
            records += list(qr)

            if email_only:
                emails = sorted(set(str(r.username).lower() for r in records))
                return True, emails

            if not use_pagination:
                return True, records

            return True, self.get_accounts_paged_list(records, current_page=current_page)

        @LibDecorators.safe_sql_method
        def get_profile(self, columns: Optional[Union[List[str], Tuple[str, ...], set]] = None) -> Tuple[bool, Union[Dict, str]]:
            mail = self.mail
            if not self.is_email(mail):
                return (False, 'INVALID_MAIL')

            if isinstance(columns, (list, tuple, set)):
                columns = ','.join(columns)
            else:
                columns = '*'

            qr = self.conn.select('admin',
                vars={'username': mail},
                what=columns,
                where='username=$username',
                limit=1)

            if qr:
                profile = list(qr)[0]
                state = self._get_admin_privilege_state(mail=mail)
                profile['isadmin'] = state.get('isadmin', 0)
                profile['isglobaladmin'] = state.get('isglobaladmin', 0)
                stats = self._admin_profile_statistics(mail=mail)
                try:
                    profile['statistics'] = stats
                except Exception:
                    profile = {**dict(profile), 'statistics': stats}
                return (True, profile)
            else:
                return (False, 'NO_SUCH_ACCOUNT')

        def verify_password(self, password: str) -> Tuple[bool, str]:
            if not self.mail:
                return (False, 'INVALID_MAIL')
            return self.profile_verify_password(self.mail, password, table='admin')

        @LibDecorators.safe_sql_method
        def add(self, payload: Dict) -> Tuple[bool, Union[Dict, str]]:
            mail = web.safestr(payload.get('mail')).strip().lower()

            if not self.is_email(mail):
                return (False, 'INVALID_MAIL')

            # NOTE: Obté la contrasenya nova.
            newpw = web.safestr(payload.get('newpw'))
            confirmpw = web.safestr(payload.get('confirmpw'))

            qr = iredpwd.verify_new_password(newpw=newpw, confirmpw=confirmpw)
            if not qr[0]:
                return qr
            passwd = qr[1]

            # NOTE: Comprova domini local.
            domain = mail.split('@', 1)[-1]
            if not self.is_domain(domain):
                return (False, 'INVALID_DOMAIN')

            if self.is_domain_exists(domain=domain):
                return (False, 'CAN_NOT_BE_LOCAL_DOMAIN')

            # NOTE: Comprova si l'admin ja existeix.
            if self.is_admin_exists(admin=mail):
                return (False, 'ALREADY_EXISTS')

            # NOTE: Nom i idioma.
            cn = payload.get('cn', '')
            lang = payload.get('defaultLanguage', '')
            _status = payload.get('accountStatus', 'active')
            _status = 1 if _status == 'active' else 0

            self.conn.insert('admin',
                username=mail,
                name=cn,
                password=iredpwd.generate_password_hash(passwd),
                language=lang,
                created=iredutils.get_gmttime(),
                active=_status)

            self.conn.insert('domain_admins',
                username=mail,
                domain='ALL',
                created=iredutils.get_gmttime(),
                active='1')

            log_activity(event='create',
                admin= session.get('username'), 
                msg=f"Create admin: {mail}."
                )
            return (True, "CREATED")

        @LibDecorators.safe_sql_method
        def delete(
            self,
            mails: Optional[List[str]] = None,
            revoke_admin_privilege_from_user: bool = True,
            ) -> Tuple[bool, Union[Dict, str]]:
            if not mails:
                return (True, "NO_ACCOUNTS")

            mails = utils._normalize_list_mails([
                str(v).split(":", 1)[0].strip().lower()
                for v in mails
            ])
            if not mails:
                return (True, "NO_VALID_EMAILS")

            sql_vars = {'mails': mails}
            self.conn.delete('admin',
                vars=sql_vars,
                where='username IN $mails')

            self.conn.delete('domain_admins',
                vars=sql_vars,
                where='username IN $mails')

            # NOTE: Unmark globa/domain admin which is mail user
            if revoke_admin_privilege_from_user:
                self.conn.update('mailbox',
                    vars=sql_vars,
                    where='username IN $mails AND (isadmin=1 OR isglobaladmin=1)',
                    isadmin=0,
                    isglobaladmin=0)

            log_activity(event='delete', 
                admin=session.get('username'),
                msg=f"Delete admin(s): {self.logger_list_helper(mails)}."
                )

            return (True, "DELETED")

        @LibDecorators.safe_sql_method
        def update(
            self,
            profile_type: str,
            payload: Dict
            ) -> Tuple[bool, Union[Dict, str]]:
            """
                # Relació d'administració de dominis (emmagatzemada a la taula SQL `domain_admins`)
                # Un administrador de domini normal tindrà registres per a cada domini gestionat,
                # mentre que l'administrador global només tindrà un registre:
                #
                #   - administrador normal: "username=<mail> AND domain='<domain>'"
                #   - administrador global: "username=<mail> AND domain='ALL'"
                # NOTE: la paraula 'ALL' està en majúscules.
            """
            if not isinstance(payload, dict):
                return (False, 'INVALID_PAYLOAD')

            profile_type = self._resolve_admin_profile_type(profile_type, payload)

            # NOTE: La validació de `mail` es fa per mètode (i no a __init__)
            # perquè `list()` i altres crides no requereixen `self.mail`.
            mail = str(self.mail or "").lower()
            if not self.is_email(mail):
                return (False, 'INVALID_MAIL')

            sql_vars = {'username': mail}

            params = {}
            if profile_type == 'general':
                # NOTE: Name, preferred language
                if 'cn' in payload:
                    params['name'] = payload.get('cn', '')

                if 'defaultLanguage' in payload or 'preferredLanguage' in payload:
                    params['language'] = payload.get('defaultLanguage') or payload.get('preferredLanguage') or ''

                # NOTE: Actualitza l'estat del compte
                if 'accountStatus' in payload:
                    account_status = str(payload.get('accountStatus', '')).strip().lower()
                    params['active'] = 1 if account_status in {'active', 'enabled', 'yes', 'on', '1'} else 0

                if 'timezone' in payload:
                    qr_settings = self.get_admin_settings(admin=mail)
                    if not qr_settings[0]:
                        return qr_settings

                    account_settings = qr_settings[1] or {}
                    tz_name = str(payload.get('timezone', '')).strip()
                    if tz_name and tz_name in TIMEZONES:
                        qr_tz = self.update_admin_settings(
                            mail=mail,
                            exist_settings=account_settings,
                            new_settings={'timezone': tz_name},
                        )
                        if not qr_tz[0]:
                            return qr_tz
                        if session.get('username') == mail:
                            session['timezone'] = TIMEZONES[tz_name]
                    else:
                        qr_tz = self.update_admin_settings(
                            mail=mail,
                            exist_settings=account_settings,
                            removed_settings=['timezone'],
                        )
                        if not qr_tz[0]:
                            return qr_tz
                        if session.get('username') == mail:
                            session['timezone'] = ''

                if 'domainGlobalAdmin' in payload:
                    enable_global = str(payload.get('domainGlobalAdmin', '')).strip().lower() in {
                        'active', 'enabled', 'yes', 'on', '1', 'true'
                    }
                    if enable_global:
                        qr_all = self.conn.select(
                            'domain_admins',
                            vars={'username': mail, 'domain': 'ALL'},
                            what='domain',
                            where='username=$username AND domain=$domain',
                            limit=1,
                        )
                        if qr_all:
                            self.conn.update(
                                'domain_admins',
                                vars={'username': mail, 'domain': 'ALL'},
                                where='username=$username AND domain=$domain',
                                active='1',
                            )
                        else:
                            self.conn.insert(
                                'domain_admins',
                                username=mail,
                                domain='ALL',
                                created=iredutils.get_gmttime(),
                                active='1',
                            )
                    else:
                        self.conn.delete(
                            'domain_admins',
                            vars={'username': mail, 'domain': 'ALL'},
                            where='username=$username AND domain=$domain',
                        )

                    qr_mb = self.conn.select(
                        'mailbox',
                        vars={'username': mail},
                        what='username',
                        where='username=$username',
                        limit=1,
                    )
                    if qr_mb:
                        state = self._get_admin_privilege_state(mail=mail)
                        self.conn.update(
                            'mailbox',
                            vars={'username': mail},
                            where='username=$username',
                            isglobaladmin=state.get('isglobaladmin', 0),
                            isadmin=state.get('isadmin', 0),
                        )
            elif profile_type == 'password':
                oldpw = web.safestr(payload.get('oldpw', ''))
                newpw = web.safestr(payload.get('newpw', ''))
                confirmpw = web.safestr(payload.get('confirmpw', ''))

                # NOTE: Verify new passwords.
                qr = iredpwd.verify_new_password(newpw=newpw, confirmpw=confirmpw)
                if not qr[0]:
                    return qr

                # NOTE: Per administradors no globals, exigim contrasenya actual.
                require_cur_passwd = not bool(session.get('is_global_admin'))
                if require_cur_passwd:
                    qr_old = self.profile_verify_password(mail, oldpw, table='admin')
                    if not qr_old[0]:
                        return (False, 'INCORRECT_OLDPW')

                params['password'] = iredpwd.generate_password_hash(qr[1])
                params['passwordlastchange'] = iredutils.get_gmttime()

            elif profile_type == '2fa':
                qr_settings = self.get_admin_settings(admin=mail)
                if not qr_settings[0]:
                    return qr_settings

                account_settings = qr_settings[1] or {}
                new_settings = {}
                removed_settings = []

                secret_input = payload.get("2fa_secret")
                current_secret = account_settings.get("2fa_secret")
                enabled_twofa = payload.get("2fa_enabled") == "active"

                if "2fa_enabled" in payload:
                    if enabled_twofa:
                        new_settings["2fa_enabled"] = "yes"
                    else:
                        removed_settings.extend(["2fa_enabled", "2fa_secret"])

                if enabled_twofa and not current_secret and not secret_input:
                    secret_input = security.generate_2fa_setup(mail)["secret"]

                if secret_input:
                    encrypted_input = security.encrypt_secret(secret_input)
                    if encrypted_input != current_secret:
                        new_settings["2fa_secret"] = encrypted_input

                qr_update = self.update_admin_settings(
                    mail=mail,
                    exist_settings=account_settings,
                    new_settings=new_settings if new_settings else None,
                    removed_settings=removed_settings if removed_settings else None,
                )
                if not qr_update[0]:
                    return qr_update

                log_activity(
                    event='update',
                    admin=session.get('username'),
                    msg=f"Update admin 2FA settings: {mail}.",
                )

            if params:
                self.conn.update('admin',
                    vars=sql_vars,
                    where='username=$username',
                    **params)

            return (True, "UPDATED")


        def is_admin_exists(self, admin: str) -> bool:
            # NOTE: Retorna True si el compte és invàlid o ja existeix.
            admin = str(admin).lower()
            if not self.is_email(admin):
                return True

            try:
                qr = self.conn.select('admin',
                    vars={'username': admin},
                    what='username',
                    where='username=$username',
                    limit=1,
                )

                if qr:
                    # NOTE: Ja existeix.
                    return True

                return False
            except:
                # NOTE: Retorna True com a existent per no permetre crear un nou domini/compte.
                return True

        def enable_disable_accounts(self, values: List[str], action: str) -> Tuple[bool, Union[Dict, str]]:
            return super().enable_disable_accounts(values, action, 'admin')
        
        def get_admin_settings(self, admin: Optional[str] = None, existing_settings: Optional[Dict] = None):
            return _get_admin_settings(admin=admin, existing_settings=existing_settings, conn=self.conn)
        
        def update_admin_settings(self,
            mail: str,
            exist_settings: Optional[Dict] = None,
            new_settings: Optional[Dict] = None,
            removed_settings: Optional[List[str]] = None
            ):
            return _update_admin_settings(
                conn=self.conn,
                mail=mail,
                exist_settings=exist_settings,
                new_settings=new_settings,
                removed_settings=removed_settings
                )

elif settings.backend == "ldap":
    import ldap
    from libs.ldaplib import attrs
    from libs.m_crudlib import  LDAPWrap as Wrap
    from libs.m_system.mixins import  LdapCRUDMixin, LdapLDIFMixin
    
    class Admin(AdminBase, LdapCRUDMixin, LdapLDIFMixin):
        def __init__(self, domain: Optional[str] = None, mail: Optional[str] = None):
            super().__init__(domain=domain, mail=mail)

            if self.mail and self.is_email(self.mail):
                self.dn = self.rdn_value_to_admin_dn(self.mail)
            else:
                self.dn = None

            if self.domain and self.is_domain(self.domain):
                self.dn_domain = self.rdn_value_to_domain_dn(self.domain)
            else:
                self.dn_domain = None

        def count_admins(self) -> Union[int, Tuple[bool, str]]:
            ok, data, *rest = self.list(email_only=True)
            if not ok:
                return ok, data
            return int(len(data))

        @LibDecorators.safe_ldap_method
        def list(self, attributes: Optional[List[str]] = None, email_only: bool = False, current_page: int = 0) -> Tuple[bool, Union[Dict, str]]:
            if not attributes:
                attributes = list(attrs.ADMIN_SEARCH_ATTRS)

            qr_admins = self.conn.search_s(
                settings.ldap_domainadmin_dn,
                ldap.SCOPE_ONELEVEL,
                '(&(objectClass=mailAdmin)(domainGlobalAdmin=yes))',
                attributes
            )
            qr_users_global = self.conn.search_s(
                settings.ldap_basedn,
                ldap.SCOPE_SUBTREE,
                '(&(objectClass=mailUser)(domainGlobalAdmin=yes))',
                attributes
            )
            qr_users = self.conn.search_s(
                settings.ldap_basedn,
                ldap.SCOPE_SUBTREE,
                '(&(objectClass=mailUser)(enabledService=domainadmin)(!(domainGlobalAdmin=yes)))',
                attributes
            )

            if self.domain:
                qr_domain_admins = self.conn.search_s(
                    self.rdn_value_to_domain_dn(self.domain),
                    ldap.SCOPE_SUBTREE,
                    f'(&(objectClass=mailDomain)(domainName={self.domain}))',
                    ['domainAdmin']
                )

                domain_admin_list = []
                qr_users = []
                for (_dn, _ldif) in qr_domain_admins:
                    domain_admin_list =_ldif.get('domainAdmin', [])
                
                for _mail in domain_admin_list:
                    _dn = self.rdn_value_to_user_dn(self.bytes2str(_mail))

                    _filter = (
                        f'(&(enabledService=domainadmin)(!(domainGlobalAdmin=yes)))'
                    )
                    _qr = self.profile_get_by_dn(_dn, query_filter=_filter, attributes=attributes)

                    if _qr[0]:
                        qr_users.append((_qr[1]['dn'], _qr[1]['ldif']))

            qr = qr_admins + qr_users_global + qr_users

            _list = []
            for (_dn, _ldif) in qr:
                if email_only:
                    _list.append(_ldif['mail'][0])
                else:
                    _ldif = utils.profile_define_adminType(_ldif)
                    _list.append(_ldif)

            sl = self.get_accounts_paged_list(_list, current_page=current_page)
            return (True, sl)

        @LibDecorators.safe_ldap_method
        def get_profile(self, attributes: Optional[List[str]] = None) -> Tuple[bool, Union[Dict, str]]:
            if not attributes:
                attributes = list(attrs.ADMIN_ATTRS_ALL)

            _filter = f'(&(objectClass=mailAdmin)(mail={self.mail}))'
            qr = self.profile_get_by_dn(self.dn, query_filter=_filter, attributes=attributes)
            if not qr[0]:
                return qr

            _ldif = qr[1]['ldif']
            profile_mail = _ldif.get('mail', '')
            if isinstance(profile_mail, list):
                profile_mail = profile_mail[0] if profile_mail else ''
            _ldif['statistics'] = self._admin_profile_statistics(mail=profile_mail)

            return (True, qr[1]['ldif'])

        def verify_password(self, password: str) -> Tuple[bool, str]:
            if not self.mail or not self.is_email(self.mail):
                return (False, 'INVALID_MAIL')
            if not password:
                return (False, 'MISSING_PASSWORD')

            qr = self.profile_get_by_dn(self.dn, attributes=['userPassword'])
            if not qr[0]:
                return (False, qr[1])

            pw_hash = qr[1]['ldif'].get('userPassword', [''])[0]
            if iredpwd.verify_password_hash(pw_hash, password):
                return (True, )
            return (False, 'INVALID_CREDENTIALS')

        @LibDecorators.safe_ldap_method
        def add(self, payload: Dict) -> Tuple[bool, Union[Dict, str]]:
            if not self.is_auth_email(self.mail):
                return (False, 'INVALID_MAIL')

            # NOTE: Assegurem que no sigui un domini allotjat
            if self.is_domain_exist(self.mail.split('@', 1)[-1]):
                return (False, 'CAN_NOT_BE_LOCAL_DOMAIN')

            # NOTE: Comprova la contrasenya.
            qr = iredpwd.verify_new_password(payload.get('newpw'), payload.get('confirmpw'))
            if not qr[0]:
                return qr

            ldif = self.ldif_mailadmin(
                mail=self.mail,
                passwd=iredpwd.generate_password_hash(qr[1]),
                cn=payload.get('cn'),
                account_status="active",
                preferred_language=payload.get("defaultLanguage"))

            dn = self.rdn_value_to_admin_dn(self.mail)

            self.conn.add_s(dn, ldif)

            log_activity(event='create', 
                admin=session.get('username'),
                msg=f"Create admin: {self.mail}."
                )
            return (True, "CREATED")

        def update(self, profile_type: str, payload: Dict) -> Tuple[bool, Union[Dict, str]]:
            if not isinstance(payload, dict):
                return (False, 'INVALID_PAYLOAD')

            profile_type = self._resolve_admin_profile_type(profile_type, payload)

            args={}
            mod_attrs = []

            account_settings = self._get_admin_account_settings(self.mail)
            if not isinstance(account_settings, dict):
                account_settings = {}

            if profile_type == 'general':
                # NOTE: `inetOrgPerson` requereix aquests camps, però en updates parcials
                # NOTE: només toquem els camps presents per no sobreescriure dades existents.
                for k in ["cn", "givenName", "sn"]:
                    if k in payload:
                        args[k] = (payload.get(k) or self.mail.split("@", 1)[0]).strip()

                if 'defaultLanguage' in payload or 'preferredLanguage' in payload:
                    preferred_lang = payload.get('defaultLanguage') or payload.get('preferredLanguage')
                    if preferred_lang:
                        args['preferredLanguage'] = preferred_lang
                        if session.get('username') == self.mail and session.get('lang', 'en_US') != preferred_lang:
                            session['lang'] = preferred_lang

                if 'timezone' in payload:
                    tz_name = payload.get('timezone')
                    if tz_name and TIMEZONES.get(tz_name):
                        account_settings['timezone'] = tz_name
                        if session['username'] == self.mail and tz_name:
                            session['timezone'] = TIMEZONES[tz_name]
                    else:
                        account_settings.pop('timezone', None)
                        if session.get('username') == self.mail:
                            session['timezone'] = ''

                if 'accountStatus' in payload:
                    account_status = str(payload.get('accountStatus', '')).strip().lower()
                    args['accountStatus'] = "active" if account_status in {'active', 'enabled', 'yes', 'on', '1'} else "disabled"

                if 'domainGlobalAdmin' in payload:
                    global_admin_status = str(payload.get('domainGlobalAdmin', '')).strip().lower()
                    args['domainGlobalAdmin'] = 'yes' if global_admin_status in {'active', 'enabled', 'yes', 'on', '1', 'true'} else None

            elif profile_type == '2fa':
                enabled_twofa = payload.get("2fa_enabled") == "active"
                secret_input = payload.get("2fa_secret")
                current_secret = account_settings.get("2fa_secret", None)

                account_settings["2fa_enabled"] = "yes" if enabled_twofa else None
                
                if not enabled_twofa:
                    # NOTE: Si es desactiva el 2FA, eliminem el secret
                    account_settings["2fa_secret"] = None

                elif not current_secret:
                    # NOTE: Genera un nou secret si no n’hi ha cap
                    new_secret = security.generate_2fa_setup(self.mail)["secret"]
                    account_settings["2fa_secret"] = security.encrypt_secret(new_secret)

                elif enabled_twofa and secret_input:
                    # NOTE: Actualitza secret si n"hi ha un d’entrada i és diferent
                    encrypted_input = security.encrypt_secret(secret_input)
                    if encrypted_input != current_secret:
                        account_settings["2fa_secret"] = encrypted_input    

            elif profile_type == 'password':
                args['currentUserPassword'] = payload.get('oldpw')
                newpw = payload.get('newpw')
                confirmpw = payload.get('confirmpw')
                qr = iredpwd.verify_new_password(newpw, confirmpw)
                if not qr[0]:
                    return qr
                args['userPassword'] = qr[1]
                req_cur_passwd = False if session.get('is_global_admin') else True
                qr = self.profile_change_password(self.dn, args['currentUserPassword'], args['userPassword'], req_cur_passwd)
                if not qr[0]:
                    return qr
                for key in ('userPassword', 'currentUserPassword'):
                    args.pop(key, None)

            args['accountSetting'] = self.account_setting_dict_to_list(account_settings)

            for k in args:
                mod_attrs += self.mod_replace(k, args[k])

            try:
                self.conn.modify_s(self.dn, mod_attrs)
                return (True, "UPDATED")
            except Exception as e:
                return (False, repr(e))

        @LibDecorators.safe_ldap_method
        def delete(self, mails: Optional[List[str]] = None) -> Tuple[bool, str]:
            if not mails:
                return (True, "NO_ACCOUNTS" )

            mails = utils._normalize_list_mails([
                str(v).split(":", 1)[0].strip().lower()
                for v in mails
            ])

            if not mails:
                return (True, "NO_VALID_EMAILS")
            
            err = {}

            for mail in mails:
                _dn = self.rdn_value_to_admin_dn(mail)
                try:
                    self.conn.delete_s(_dn)
                    continue
                except ldap.NO_SUCH_OBJECT:
                    # NOTE: És un admin que també és usuari de correu.
                    _dn = self.rdn_value_to_user_dn(mail)
                    try:
                        # NOTE: Elimina `enabledService=domainadmin`.
                        self.add_or_remove_attr_values_by_dn(
                            dn=_dn,
                            attr='enabledService',
                            values=['domainadmin'], 
                            action="remove"
                        )
                        # NOTE: Elimina `domainGlobalAdmin=yes`.
                        self.add_or_remove_attr_values_by_dn(
                            dn=_dn,
                            attr='domainGlobalAdmin',
                            values=['yes'], 
                            action="remove"
                        )
                        continue
                    except Exception as e:
                        err[mail] = str(e)
                except ldap.LDAPError as e:
                    err[mail] = str(e)

            if not err:
                log_activity(event='delete', 
                    admin=session.get('username'),
                    msg=f"Delete admin(s): {self.logger_list_helper(mails)}" 
                    )
                return (True, "DELETED")
            return (False, repr(err))

        def enable_disable_accounts(self, raw_values: List[str], action: str) -> Tuple[bool, Union[Dict, str]]:
            def _split_role(values):
                """
                    Rep ['mail:role', ...] i retorna 2 llistes:
                    admins_amb_mail_extern, admins_amb_mail_intern
                """
                mailadmins = []
                usersadmins = []

                for entry in values:
                    try:
                        mail, role = entry.split(":", 1)
                    except ValueError:
                        continue

                    role = role.lower()

                    if role.startswith("mail"):     # NOTE: mailglobaladmin / maildomainadmin
                        mailadmins.append(mail)
                    else:                           # NOTE: globaladmin / domainadmin
                        usersadmins.append(mail)

                return mailadmins, usersadmins

            mail_admins, user_admins = _split_role(raw_values)

            errors= []
            msg = ""
            if mail_admins:
                ok, msg = super().enable_disable_accounts(mail_admins, action, 'admin')
                if not ok:
                    errors.append(msg)
            if user_admins:
                ok, msg = super().enable_disable_accounts(user_admins, action, 'user')
                if not ok:
                    errors.append(msg)

            if errors:
                return (False, " | ".join(errors))

            return (True, msg)

else:
    raise RuntimeError(f"Backend no suportat: {settings.backend}")
