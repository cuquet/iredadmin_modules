# libs/m_crudlib/decorators.py
from controllers import decorators as base_decorators

require_login = base_decorators.require_login
require_global_admin = base_decorators.require_global_admin
csrf_protected = base_decorators.csrf_protected

from api.core import decorators as api_decorators

json_response = api_decorators.json_response
require_admin_login = api_decorators.require_admin_login
require_user_login = api_decorators.require_user_login
require_preference_access = api_decorators.require_preference_access
require_permission_create_domain = api_decorators.require_permission_create_domain
require_domain_access = api_decorators.require_domain_access
