# Modul `m_crudlib`

Capa de negoci CRUD per a comptes de correu dins iRedMailMyAdmin.

Aquest modul es la base compartida per:

- UI (`controllers/m_crud/*`, `controllers/m_system/*`)
- API REST (`api/crud/*` i altres endpoints que reutilitzen logica de domini/usuari/admin)
- autenticacio (`libs/m_crudlib/auth.py`)
- 2FA i seguretat associada (`libs/m_crudlib/security.py`)

## Documentacio ampliada

Per conservar notes tecniques extenses i proves de concepte (2FA, captcha, snippets, fluxos), consulta:

- `libs/m_crudlib/README.technical.md`

## Arquitectura

Seleccio de backend en runtime:

- `ldap` -> classes LDAP
- `mysql` / `pgsql` -> classes SQL

La seleccio es fa a `libs/m_crudlib/__init__.py` i a cada modul (`user.py`, `domain.py`, `admin.py`) amb blocs condicionals per backend.

## Fitxers principals

- `libs/m_crudlib/user.py`
- Gestio de mail users: llistat, perfil, alta, update per pestanya, baixa, verify password, rename/change_email, rols admin, aliases, forwarding, subscribed mailing lists, 2FA.

- `libs/m_crudlib/domain.py`
- Gestio de dominis: llistat (global/gestionats), perfil, alta, update, baixa i comptadors; integracio amb iredapd/amavisd per throttle/greylist/spampolicy/wblist.

- `libs/m_crudlib/admin.py`
- Gestio de domain/global admins (standalone i mail users amb privilegis), llistat, perfil, alta, update, baixa, verify password, limits i estadistiques.

- `libs/m_crudlib/auth.py`
- Flux de login principal: validacio credencials, resolucio de rols de sessio, dominis gestionats, idioma/timezone i control 2FA.

- `libs/m_crudlib/security.py`
- Utilitats de seguretat: generacio/visualitzacio TOTP, validacio token, activacio 2FA i xifrat simetric AES-GCM per secrets.

- `libs/m_crudlib/decorators.py`
- Decoradors compartits del modul (complementaris als decoradors de `libs/m_system/decorators.py`).

## Flux de dades (UI/API -> lib)

1. Controller recull formulari o payload API.
2. Controller normalitza claus i tipus (mapeig de claus a `libs/m_system/key_map.yaml` i utilitats de `form_utils`).
3. Controller invoca metodes de `m_crudlib` (`User`, `Domain`, `Admin`).
4. La lib aplica logica de negoci i persisteix en SQL/LDAP.
5. Controller transforma resposta a HTML o JSON.

## Disseny de metodes

Patrons comuns:

- validacio d'entrada al principi (`is_email`, `is_domain`, etc.)
- retorn tuple tipus `(ok, data_o_msg, *meta)`
- separacio per `profile_type` en updates
- wrappers de seguretat:
- SQL: `@LibDecorators.safe_sql_method`
- LDAP: `@LibDecorators.safe_ldap_method`

## Integracio amb API CRUD

Els endpoints d'`api/crud/controller.py` deleguen principalment en:

- `lib_user.User(...)`
- `lib_domain.Domain(...)`
- `lib_admin.Admin(...)`

Exemples ja disponibles a la capa de negoci i exposats des de l'API:

- `verify_password` per user/admin
- `rename` / `change_email`
- actualitzacions per pestanya (`general`, `aliases`, `forwarding`, `2fa`, etc.)

## Notes de manteniment

- Mantingues paritat funcional SQL/LDAP quan afegeixis nous camps.
- Si afegeixes una clau nova de payload API/UI, actualitza:
- `libs/m_system/key_map.yaml`
- normalitzacio del controller corresponent
- branch `update(profile_type=...)` de la lib afectada
- handler de missatges si apareix un nou codi de resposta.

- Evita posar logica de negoci al controller; deixa-la a `m_crudlib` per mantenir coherencia entre UI i API.

- Per funcionalitats sensibles (auth/2FA/roles), conserva la logica centralitzada a `auth.py` i `security.py`.

## Estat del README

Aquest fitxer es la vista operativa i actual del modul.
Les notes historiques i detallades queden a `README.technical.md`.

# 📦 Llicència
Aquest projecte s’ofereix sota la llicència [MIT](https://choosealicense.com/licenses/mit/). Pots modificar-lo, distribuir-lo i integrar-lo lliurement.

# 🤝 Contribucions
Les contribucions són benvingudes! Si tens idees, millores o correccions, obre un issue o envia un pull request.
[![PayPal - Donate](https://img.shields.io/badge/PayPal-Donate-005EA6?logo=paypal&logoColor=white)](https://www.paypal.me/cuquet74)
