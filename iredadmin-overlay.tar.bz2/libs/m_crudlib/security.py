# libs/m_crudlib/security.py
import os
import base64
from io import BytesIO, StringIO
import re
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import logging

import settings
from libs.logger import log_activity

from libs.m_system.mixins import SQLHelper, LDAPHelper
from libs.sqllib import sqlutils

log = logging.getLogger(__name__)

try:
    import pyotp
except Exception:
    pyotp = None

try:
    import qrcode
except Exception:
    qrcode = None


def _twofa_available() -> bool:
    return pyotp is not None and qrcode is not None


def generate_2fa_setup(email: str) -> dict:
    """
    Genera un secret nou de 2FA per a l'usuari i retorna QR + URI + secret.
    Encara NO el desa a DB/LDAP (fase prèvia de setup).
    """
    if pyotp is None:
        log_activity(event="update", loglevel="error",
            admin=email,
            msg="[2FA] pyotp module missing; cannot generate secret",
            )
        return {}

    secret = pyotp.random_base32()

    # Logging oficial iRedAdmin
    log_activity(event="update", loglevel="info",
        admin=email,
        msg="[2FA] secret generated (not stored yet)",
        )

    return show_2fa_secret(secret, email)

def show_2fa_secret(secret: str, email: str, issuer: str = "iRedMail") -> dict:
    """
    Retorna secret, provisioning URI i QR en base64
    """
    if not _twofa_available():
        log_activity(event="update", loglevel="error",
            admin=email,
            msg="[2FA] pyotp/qrcode modules missing; cannot render QR setup",
            )
        return {}

    if not secret:
        log_activity(event="update", loglevel="error",
            admin=email,
            msg="[2FA] empty secret passed to show_2fa_secret",
            )
        return {}
    secret = decrypt_secret(secret)
    # 1️⃣ Crear provisioning URI
    uri = pyotp.TOTP(secret).provisioning_uri(name=email, issuer_name=issuer)

    # 2️⃣ Generar QR i convertir-lo a base64
    qr_img = qrcode.make(uri)
    buffered = BytesIO()
    qr_img.save(buffered, format="PNG")
    qr_base64 = base64.b64encode(buffered.getvalue()).decode("utf-8")

    # 3️⃣ QR ASCII per CLI
    qr_ascii = qrcode.QRCode()
    qr_ascii.add_data(uri)
    qr_ascii.make(fit=True)
    ascii_buffer = StringIO()
    qr_ascii.print_ascii(out=ascii_buffer,invert=True)
    qr_ascii_text = ascii_buffer.getvalue()

    # Logging oficial
    log_activity(event="update", loglevel="info",
        admin=email,
        msg="[2FA] QR code displayed to user",
        )

    return {
        "secret": secret,
        "uri": uri,
        "qr_base64": qr_base64,
        "qr_ascii": qr_ascii_text
    }

def activate_2fa(username: str, secret: str, backend: str = "sql") -> bool:
    """
    Desa el secret xifrat a la DB o LDAP per l'usuari.
    """
    enc_secret = encrypt_secret(secret)

    if backend in ["mysql", "pgsql"]:
        sql_helper = SQLHelper()
        sql_lib = sql_helper 
        conn = sql_lib.conn 
        try:
            # Afegim al camp JSON 'settings' de mailbox
            qr = conn.select(
                "mailbox",
                vars={"username": username},
                where="username=$username",
                what="settings",
                limit=1,
            )
            if not qr:
                log_activity(event="update", loglevel="error",
                    admin=username,
                    msg="[2FA] activation failed (user not found in SQL)",
                    )
                return False

            current_settings = sqlutils.account_settings_string_to_dict(qr[0].settings or "")
            current_settings["2fa_secret"] = enc_secret
            current_settings["2fa_enabled"] = 1

            conn.update(
                "mailbox",
                vars={"username": username},
                where="username=$username",
                settings=sqlutils.account_settings_dict_to_string(current_settings),
            )

            log_activity(event="update", loglevel="info",
                admin=username,
                msg="[2FA] activated successfully (SQL backend)",
                )
            return True

        except Exception as e:
            log.exception("Error activating 2FA (SQL)")
            log_activity(event="update", loglevel="error",
                admin=username,
                msg=f"[2FA] activation failed (SQL exception)",
                )
            return False

    elif backend == "ldap":
        _wrap = LDAPHelper()
        ldap_lib = _wrap
        conn = ldap_lib.conn
        dn = ldap_lib.rdn_value_to_user_dn(username)
        account_settings = ldap_lib._get_user_account_settings(username)
        if not account_settings:
            account_settings = ldap_lib._get_admin_account_settings(username)
            dn = ldap_lib.rdn_value_to_admin_dn(username)
        account_settings["2fa_secret"] = enc_secret
        account_settings["2fa_enabled"] = "yes"
        mod_attrs = ldap_lib.mod_replace(
            "accountSetting",
            ldap_lib.account_setting_dict_to_list(account_settings)
        )
        try:
            conn.modify_s(dn, mod_attrs)

            log_activity(event="update", loglevel="info",
                admin=username,
                msg="[2FA] activated successfully (LDAP backend)",
                )
            return True
        except Exception:
            log.exception("Error activating 2FA (LDAP)")
            log_activity(event="update", loglevel="error",
                admin=username,
                msg=f"[2FA] activation failed (LDAP exception)",
                )
            return False

    log_activity(event="update", loglevel="error",
        admin=username,
        msg=f"[2FA] activation failed (unknown backend '{backend}')",
        )
    return False

def verify_2fa_token(enc_secret: str, token: str, username: str ) -> bool:
    """
        Desencripta el secret emmagatzemat i verifica el token TOTP rebut.

        Args:
            enc_secret: cadena codificada (base64) amb nonce+ciphertext (el que hi ha a la BD).
            token: codi TOTP que ha introduït l'usuari (string o int).
            username: mail de l'usuari

        Retorna:
            True si el token és vàlid (amb una petita finestra de tolerància), False altrament.
    """
    if not enc_secret:
        log.debug("No hi ha secret emmagatzemat")
        return False

    if pyotp is None:
        log_activity(event="login", loglevel="error",
            admin=username,
            msg="2FA verification unavailable: pyotp module missing",
            ip=None,
            )
        return False

    # 1) desencriptem
    try:
        secret = decrypt_secret(enc_secret)  # la teva funció que retorna str
    except Exception as e:
        log.exception("Error desenxifrant secret 2FA")
        return False

    if not secret:
        log.debug("Secret desencriptat buit")
        return False

    # 2) normalitzar token
    token_str = str(token).strip()
    if not token_str.isdigit():
        log.debug("Token no numèric: %r", token_str)
        return False

    # 3) crear TOTP i verificar
    try:
        totp = pyotp.TOTP(secret)          # <-- aquí cal passar el secret, no el token
        # valid_window=1 accepta +/- 1 interval per compensar rellotges lleugerament desfets
        ok = totp.verify(token_str, valid_window=1)
        return bool(ok)
    except Exception as e:
        log.exception("Error verificant token TOTP")
        log_activity(event="login", loglevel="error", # un event oficial
            admin=username,
            msg="Error verificant token TOTP",
            ip=None,                             # es detecta automàticament
            )
        return False

def user_has_totp(username, backend: str = "sql"):
    if backend in ("mysql", "pgsql", "sql"):
        sql_helper = SQLHelper()
        sql_lib = sql_helper
        conn = sql_lib.conn

        qr = conn.select(
            "mailbox",
            vars={"username": username},
            where="username=$username",
            what="settings",
            limit=1,
        )
        if not qr:
            qr = conn.select(
                "admin",
                vars={"username": username},
                where="username=$username",
                what="settings",
                limit=1,
            )
        if not qr:
            return (False, None)

        account_settings = sqlutils.account_settings_string_to_dict(qr[0].settings or "")
        enc_secret = account_settings.get("2fa_secret")
        enabled_raw = str(account_settings.get("2fa_enabled", "0")).strip().lower()
        enabled = enabled_raw in ("1", "yes", "true")

        log_activity(event="update", loglevel="info",
            admin=username,
            msg="[2FA] checking TOTP state",
            )
        return (enabled, enc_secret)

    if backend == "ldap":
        _wrap = LDAPHelper()
        ldap_lib = _wrap
        #conn = ldap_lib.conn
        #dn = ldap_lib.rdn_value_to_user_dn(username)
        account_settings = ldap_lib._get_user_account_settings(username)
        if not account_settings:
            account_settings = ldap_lib._get_admin_account_settings(username)
        if not account_settings or not isinstance(account_settings, dict):
            return (False, None)
        enc_secret = account_settings.get("2fa_secret")
        enabled = (account_settings.get("2fa_enabled") == "yes")

        log_activity(event="update", loglevel="info",
            admin=username,
            msg="[2FA] checking TOTP state",
            )

        return (enabled, enc_secret)

    return (False, None)


##### amb encriptació simètrica AES
BASE_DIR = Path(__file__).resolve().parent.parent
SETTINGS_FILE = BASE_DIR / "settings.py"
CUSTOM_SETTINGS_FILE = BASE_DIR / "custom_settings.py"

def ensure_aes_key() -> bytes:
    """
        Retorna la clau AES carregada. Si no existeix, la crea i l’afegeix a custom_settings.py.
        Assegura que custom_settings.py sigui importat des de settings.py.
    """
    # 1. Si ja hi ha la clau a settings.py (o importada), la fem servir
    key_b64 = getattr(settings, "AES_SECRET_KEY", None)
    if key_b64:
        try:
            return base64.urlsafe_b64decode(key_b64)
        except Exception as e:
            raise ValueError(f"Invalid AES_SECRET_KEY format: {e}")

    # 2. No existeix — veure si custom_settings.py ja la conté
    if CUSTOM_SETTINGS_FILE.exists():
        text = CUSTOM_SETTINGS_FILE.read_text(encoding="utf-8")
        m = re.search(r"AES_SECRET_KEY\s*=\s*['\"]([A-Za-z0-9_\-]+=*)['\"]", text)
        if m:
            key_b64 = m.group(1)
            try:
                return base64.urlsafe_b64decode(key_b64)
            except Exception as e:
                raise ValueError(f"AES_SECRET_KEY in custom_settings.py invalid: {e}")

    # 3. No existeix la clau enlloc → Generem-ne una nova
    new_key = base64.urlsafe_b64encode(AESGCM.generate_key(bit_length=256)).decode()

    # Assegurar que custom_settings.py existeix (crear si cal)
    if not CUSTOM_SETTINGS_FILE.exists():
        CUSTOM_SETTINGS_FILE.write_text("# Custom settings for iRedAdmin\n", encoding="utf-8")
        os.chmod(CUSTOM_SETTINGS_FILE, 0o600)

    # Afegim la definició de la clau al final
    append = (
        "\n# AES_SECRET_KEY used for encrypting tokens, secrets, etc.\n"
        f"AES_SECRET_KEY = '{new_key}'\n"
    )
    with open(CUSTOM_SETTINGS_FILE, "a", encoding="utf-8") as f:
        f.write(append)
    os.chmod(CUSTOM_SETTINGS_FILE, 0o600)

    # 4. Assegurar que settings.py faci `from custom_settings import *`
    settings_text = SETTINGS_FILE.read_text(encoding="utf-8")
    if "from custom_settings import *" not in settings_text:
        # afegir-la al final
        with open(SETTINGS_FILE, "a", encoding="utf-8") as f:
            f.write("\nfrom custom_settings import *\n")
        os.chmod(SETTINGS_FILE, 0o600)

    return base64.urlsafe_b64decode(new_key)

# Carreguem o creem la clau
AES_KEY = ensure_aes_key()

def encrypt_secret(secret: str) -> str:
    """
        Xifra un valor amb AES-256-GCM i retorna en format Base64 amb prefix 'ENC_'.
    """
    aesgcm = AESGCM(AES_KEY)
    nonce = os.urandom(12)  # IV únic
    ct = aesgcm.encrypt(nonce, secret.encode(), None)
    encoded = base64.urlsafe_b64encode(nonce + ct).decode()
    return f"ENC_{encoded}"

def decrypt_secret(value: str) -> str:
    """
        Desxifra un valor que tingui prefix 'ENC_'.
    """
    if not value.startswith("ENC_"):
        # No està xifrat
        return value

    encoded = value[4:]
    aesgcm = AESGCM(AES_KEY)
    data = base64.urlsafe_b64decode(encoded.encode())
    nonce, ct = data[:12], data[12:]
    return aesgcm.decrypt(nonce, ct, None).decode()

def is_encrypted(value: str) -> bool:
    """
        Comprova si el valor té prefix 'ENC_'.
    """
    return value.startswith("ENC_")
