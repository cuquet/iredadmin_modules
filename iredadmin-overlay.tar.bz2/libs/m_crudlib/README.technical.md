# m_crudlib Technical Notes

Aquest document conserva notes tecniques i snippets de treball (especialment 2FA i captcha).

Important:
- Inclou parts historiques i propostes no necessàriament desplegades tal qual al codi actual.
- La referencia operativa del modul es `libs/m_crudlib/README.md`.

## Index

- [1. 2FA: flux, xifrat i snippets](#1-2fa-flux-xifrat-i-snippets)
- [1.1 Xifrat simetric](#11-xifrat-simetric)
- [1.2 Exemple amb `cryptography` (AES-GCM)](#12-exemple-amb-cryptography-aes-gcm)
- [1.3 `secure_store.py` (no implementat)](#13-secure_storepy-no-implementat)
- [1.4 Exemple d'integracio amb LDAP `accountSetting`](#14-exemple-dintegracio-amb-ldap-accountsetting)
- [1.5 Exemple de xifrat simetric amb standard library (no implementat)](#15-exemple-de-xifrat-simetric-amb-standard-library-no-implementat)
- [1.6 Guardar `2fa_secret` (LDAP/SQL)](#16-guardar-2fa_secret-ldapsql)
- [1.7 Validacio del codi 2FA](#17-validacio-del-codi-2fa)
- [1.8 Flux complet de login amb 2FA](#18-flux-complet-de-login-amb-2fa)
- [1.9 Extra: QR code per configurar autenticador](#19-extra-qr-code-per-configurar-autenticador)
- [1.10 Punts clau de seguretat](#110-punts-clau-de-seguretat)
- [2. Friendly Captcha (client web)](#2-friendly-captcha-client-web)
- [3. Gestio amb token API (no implementat)](#3-gestio-amb-token-api-no-implementat)

## 1. 2FA: flux, xifrat i snippets

### 1.1 Xifrat simetric
Generes la clau **AES** i la guardes al backend (fitxer .env o equivalent, amb permisos 600) o bé amb estàndard library: Podem aprofitar **hashlib** + **hmac** + **base64** per muntar un xifrat molt senzill i simètric.
Com que necessitem recuperar el secret (no només verificar), el més pràctic és usar XOR simètric + clau mestra derivada d’una passphrase que defines a `settings.py`.

Quan generes un 2fa_secret, el xifres abans de desar-lo a LDAP.
Quan cal validar un codi TOTP, el backend llegeix de LDAP, desxifra el secret i calcula el codi.

### 1.2 Exemple amb `cryptography` (AES-GCM)
```python
import os
import base64
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

# Clau de 32 bytes (AES-256)
# Guarda-la en un fitxer segur i NO dins del codi
AES_KEY = base64.urlsafe_b64decode("TU_CLAU_AES_EN_BASE64_DE_32_BYTES==")

def encrypt_secret(secret: str) -> str:
    aesgcm = AESGCM(AES_KEY)
    nonce = os.urandom(12)  # IV/Nonce únic per cada xifrat
    ct = aesgcm.encrypt(nonce, secret.encode(), None)
    # Guardem nonce + ciphertext junts, codificats en base64
    return base64.urlsafe_b64encode(nonce + ct).decode()

def decrypt_secret(encoded: str) -> str:
    aesgcm = AESGCM(AES_KEY)
    data = base64.urlsafe_b64decode(encoded.encode())
    nonce, ct = data[:12], data[12:]
    return aesgcm.decrypt(nonce, ct, None).decode()

# Exemple d'ús
if __name__ == "__main__":
    original_secret = "JBSWY3DPEHPK3PXP"  # Exemple de secret TOTP
    encrypted = encrypt_secret(original_secret)
    print("🔒 Encrypted:", encrypted)

    decrypted = decrypt_secret(encrypted)
    print("🔑 Decrypted:", decrypted)
```
#### Emmagatzematge a LDAP
A accountSetting, el valor quedaria així:

```ruby
2fa_secret:ENC:<valor_base64>
Exemple:
```
```ruby
2fa_secret:ENC:BnN2fM-0cGZpcK3KeuOlOeBhcKhRmP1mOaPQ...
```

#### Mesures de seguretat extra
ACL a LDAP → només el servei backend pot llegir 2fa_secret.
Clau AES → guardar en .env o /etc/iredadmin/secret.key amb chmod 600.
Nonce diferent per cada xifrat → ja ho fa os.urandom(12).

### 1.3 `secure_store.py` (no implementat)
Mòdul `secure_store.py` perquè puguis guardar i llegir 2fa_secret (o qualsevol altra dada sensible) de LDAP amb AES-256-GCM de manera transparent.

Aquest mòdul inclou:
+ Gestió de la clau AES des d’un fitxer .key amb permisos segurs (chmod 600).
+ Funcions encrypt_secret i decrypt_secret.
+ Prefix "ENC:" per marcar valors xifrats a LDAP.
+ Compatibilitat per emmagatzemar a accountSetting en format var:value.

```python
import os
import base64
from pathlib import Path
from cryptography.hazmat.primitives.ciphers.aead import AESGCM

# Ruta on guardarem la clau AES
DEFAULT_KEY_FILE = "/opt/custom/iredadmin/secure_store.key"

def load_aes_key(key_file: str = DEFAULT_KEY_FILE) -> bytes:
    """
    Carrega o genera una clau AES-256 i la desa al fitxer amb permisos segurs.
    """
    key_path = Path(key_file)
    if not key_path.exists():
        # Generem clau nova
        key = AESGCM.generate_key(bit_length=256)
        key_path.write_bytes(base64.urlsafe_b64encode(key))
        os.chmod(key_path, 0o600)
        return key
    else:
        return base64.urlsafe_b64decode(key_path.read_bytes())

# Carreguem la clau globalment
AES_KEY = load_aes_key()

def encrypt_secret(secret: str) -> str:
    """
    Xifra un valor amb AES-256-GCM i retorna en format Base64 amb prefix 'ENC:'.
    """
    aesgcm = AESGCM(AES_KEY)
    nonce = os.urandom(12)  # IV únic
    ct = aesgcm.encrypt(nonce, secret.encode(), None)
    encoded = base64.urlsafe_b64encode(nonce + ct).decode()
    return f"ENC:{encoded}"

def decrypt_secret(value: str) -> str:
    """
    Desxifra un valor que tingui prefix 'ENC:'.
    """
    if not value.startswith("ENC:"):
        # No està xifrat
        return value

    encoded = value[4:]
    aesgcm = AESGCM(AES_KEY)
    data = base64.urlsafe_b64decode(encoded.encode())
    nonce, ct = data[:12], data[12:]
    return aesgcm.decrypt(nonce, ct, None).decode()

def is_encrypted(value: str) -> bool:
    """
    Comprova si el valor té prefix 'ENC:'.
    """
    return value.startswith("ENC:")

# Exemple d'ús
if __name__ == "__main__":
    original = "JBSWY3DPEHPK3PXP"  # secret TOTP
    encrypted = encrypt_secret(original)
    print("🔒 Xifrat:", encrypted)

    decrypted = decrypt_secret(encrypted)
    print("🔑 Desxifrat:", decrypted)

```

### 1.4 Exemple d'integracio amb LDAP `accountSetting`
```python
from secure_store import encrypt_secret, decrypt_secret

# Guardar a LDAP
ldap_value = encrypt_secret("JBSWY3DPEHPK3PXP")
print(f"Valor per LDAP: 2fa_secret:{ldap_value}")

# Llegir de LDAP
valor_guardat = ldap_value  # recuperat de LDAP
print("Valor desxifrat:", decrypt_secret(valor_guardat))
```

### 1.5 Exemple de xifrat simetric amb standard library (no implementat)
Podem aprofitar hashlib + hmac + base64 per muntar un xifrat molt senzill i simètric.
Com que necessitem recuperar el secret (no només verificar), el més pràctic és usar XOR simètric + clau mestra derivada d’una passphrase que defines a `settings.py`.

```python
import base64
import hashlib

MASTER_KEY = b"la_teva_clau_mestra_llarga"  # posar-la a settings.py

def _derive_key(master: bytes, length: int = 32) -> bytes:
    """Deriva una clau SHA256 de longitud fixa a partir de master."""
    return hashlib.sha256(master).digest()[:length]

def encrypt_secret(secret: str) -> str:
    key = _derive_key(MASTER_KEY, len(secret))
    encrypted = bytes([a ^ b for a, b in zip(secret.encode(), key)])
    return base64.urlsafe_b64encode(encrypted).decode()

def decrypt_secret(enc: str) -> str:
    data = base64.urlsafe_b64decode(enc.encode())
    key = _derive_key(MASTER_KEY, len(data))
    decrypted = bytes([a ^ b for a, b in zip(data, key)])
    return decrypted.decode()
```
👉 Això et dona un mecanisme de “ofuscació forta” (millor que plaintext, però no tant com AES).
La seguretat depèn de la clau MASTER_KEY que tu controles.

### 1.6 Guardar `2fa_secret` (LDAP/SQL)
🔹 **LDAP (accountSetting)**
Afegim:
- accountSetting: 2fa_enabled:yes
- accountSetting: 2fa_secret:ENC(Kk3D8ajd...)

```python
from libs import ldaplib
from utils.security import encrypt_secret

def enable_2fa_ldap(conn, dn, secret):
    encrypted = encrypt_secret(secret)
    mods = [
        (ldaplib.MOD_REPLACE, 'accountSetting', [
            '2fa_enabled=TRUE',
            f'2fa_secret={encrypted}',
        ])
    ]
    conn.modify_s(dn, mods)
```

🔹 **SQL (mailbox.settings)**

Afegim dins del JSON del camp settings:
```json
{
  "2fa_enabled": true,
  "2fa_secret": "ENC(Kk3D8ajd...)"
}
```
```python
import simplejson as json
from utils.security import encrypt_secret

def enable_2fa_sql(conn, email, secret):
    cur = conn.cursor()
    enc = encrypt_secret(secret)

    # Agafem settings actuals
    cur.execute("SELECT settings FROM mailbox WHERE username=%s", (email,))
    row = cur.fetchone()
    if row and row[0]:
        settings = json.loads(row[0])
    else:
        settings = {}

    settings['2fa_enabled'] = True
    settings['2fa_secret'] = enc

    cur.execute(
        "UPDATE mailbox SET settings=%s WHERE username=%s",
        (json.dumps(settings), email),
    )
    conn.commit()
```

### 1.7 Validacio del codi 2FA

Amb pyotp és trivial:
```python
import pyotp
from utils.security import decrypt_secret

def verify_2fa_token(enc_secret: str, token: str) -> bool:
    secret = decrypt_secret(enc_secret)
    totp = pyotp.TOTP(secret)
    return totp.verify(token, valid_window=1)
```

👉 Això accepta lleugeres desviacions de temps amb valid_window=1.

### 1.8 Flux complet de login amb 2FA

Usuari posa user + password.

Validem password amb la lògica actual (libs.auth).

Si l’usuari té 2fa_enabled = True, li demanem el token.

Recuperem 2fa_secret → decrypt_secret(...).

Fem totp.verify(token).

Si OK → login completat.

Si KO → deneguem accés.

### 1.9 Extra: QR code per configurar autenticador

Amb pyotp també pots generar l’URI per mostrar en un QR:

```python
import pyotp
import qrcode

def generate_2fa_qr(username: str, secret: str, issuer="iRedMailMyAdmin"):
    totp = pyotp.TOTP(secret)
    uri = totp.provisioning_uri(name=username, issuer_name=issuer)
    img = qrcode.make(uri)
    return img  # pots enviar-la com PNG a la UI
```

### 1.10 Punts clau de seguretat
- El fitxer `/opt/custom/iredadmin/secure_store.key` es la clau mestra.
- Si es perd, no es poden desxifrar secrets existents.
- Nomes l'usuari del servei (ex. `iredadmin`) ha de tenir permis de lectura.
- No emmagatzemis mai la clau dins del codi ni a Git.

## 2. Friendly Captcha (client web)
1. Registra’t i obtén la clau pública i privada:
👉 https://friendlycaptcha.com
2. Incrusta el widget al formulari de login (HTML)
```html

{% if show_captcha -%}
    <script src="https://cdn.jsdelivr.net/npm/friendly-challenge@0.9.12/widget.min.js" async defer></script>
    {%  set lang_code = ctx.lang.split('_')[0] -%}
    <div class="margin-bottom-sm">
        <div class="frc-captcha" data-sitekey="<friendly_site_key>" data-lang="{{lang_code}}" ></div>
    </div>
{%- endif %}
```
3. Backend: verifica el token
Quan reps el formulari, envia el token a Friendly Captcha:
```python
import requests

def verify_captcha(solution):
    response = requests.post(
        "https://api.friendlycaptcha.com/api/v1/siteverify",
        data={
            "solution": solution,
            "secret": "YOUR_PRIVATE_KEY"
        }
    )
    return response.json().get("success", False)

def verify_captchav2(solution: str) -> bool:
    url = "https://global.frcapi.com/api/v2/captcha/siteverify"
    headers = {
        "X-API-Key": "LA_TEVA_API_KEY"  # Substitueix amb la teva clau real
    }
    data = {
        "response": solution
        # Opcional: "sitekey": "LA_TEVA_SITEKEY"
    }

    response = requests.post(url, json=data, headers=headers)
    result = response.json()

    return result.get("success", False)
[...]
class Login:
    def GET(self):
        if not session.get('logged'):
            form = web.input(_unicode=False)
            [...]
            if 'failed_times' not in session:
                session['failed_times'] = 0
            show_captcha = session['failed_times'] > 2
            [...]
            # Show login page.
            return web.render('login.html',
                [...]
                show_captcha=show_captcha)
        else:
        [...]
    def POST(self):
        [...]
        captcha_solution = form.get('frc-captcha-solution', '').strip()
        # CAPTCHA si ha fallat massa vegades
        if session.get('failed_times', 0) > 2:
            if not verify_captcha(captcha_solution):
                raise web.seeother('/login?msg=INVALID_CAPTCHA')
        [...]
        auth_result [...]
```
4. Lògica de bloqueig
Guarda els intents fallits en sessió o base de dades.
Si intents > 2, mostra el CAPTCHA abans de permetre nous intents.

### Integracio amb `web.py`
```python
import web

urls = ("/login", "Login")
app = web.application(urls, globals())
session = web.session.Session(app, web.session.DiskStore('sessions'))

class Login:
    def GET(self):
        return render.login(show_captcha=session.attempts > 2)

    def POST(self):
        i = web.input()
        if session.attempts > 2 and not verify_captcha(i["frc-captcha-solution"]):
            return "Captcha incorrecte"
        if check_password(i.username, i.password):
            if verify_totp(i.totp_code):
                session.logged_in = True
                session.attempts = 0
                return "Login correcte"
            else:
                session.attempts += 1
                return "Codi TOTP incorrecte"
        else:
            session.attempts += 1
            return "Credencials incorrectes"
```

## 3. Gestio amb token API (no implementat)

### `libs/m_crudlib/security.py`
```python
import base64
import pickle

def generate_token(length=32):
    return base64.urlsafe_b64encode(os.urandom(length)).decode('utf-8')


def extract_session_from_db(data_serialitzada):
    try:
        # data_serialitzada pot tenir salts de línia, els netegem
        data_b64_clean = data_serialitzada.replace('\n', '').replace('\r', '')
        
        # Decodifiquem base64 per obtenir bytes
        decoded_bytes = base64.b64decode(data_b64_clean)
        
        # Deserialitzem amb pickle
        session_data = pickle.loads(decoded_bytes)
        
        return session_data
    except Exception as e:
        print(f"❌ Error deserialitzant sessió: {e}")
        return None
```

### `libs/m_crudlib/auth.py`
```python
from libs.m_crudlib.security import generate_token

def login_auth(username, password):
    [...]
    if session.get('is_global_admin') or session.get('is_domain_admin'):
        token = generate_token()
        session['api_token'] = token
        session.modified = True
        session._save()
    [...]
```

### `api/core/decorators.py`
```python
from libs.m_crudlib.security import extract_session_from_db

def require_api_token(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        session = web.config._session
        headers = web.ctx.env
        params = web.input(api_token=None)

        token = None
        
        # 1. Authorization: Bearer <token>
        auth_header = (
            headers.get('HTTP_AUTHORIZATION') or
            headers.get('Authorization') or
            headers.get('REDIRECT_HTTP_AUTHORIZATION')
        )
        if auth_header and auth_header.startswith('Bearer '):
            token = auth_header[7:].strip()
        
        # 2. ?api_token=... (GET param)
        if not token and params.api_token:
            token = params.api_token
        
        # 3. Sessió autenticada
        if not token:
            token = session.get('api_token')
        
        if not token:
            return {'_success': False, 'msg': 'MISSING_BEARER_TOKEN'}
        
        # Cerquem sessions actives l'últim dia
        cutoff = (datetime.datetime.utcnow() - datetime.timedelta(days=1)).strftime('%Y-%m-%d %H:%M:%S')
        try:
            rows = web.conn_iredadmin.select(
                'sessions',
                what='session_id, data',
                where='atime >= $cutoff',
                vars={'cutoff': cutoff}
            )
        except Exception as e:
            return {'_success': False, '_msg': f'ERROR_DB: {e}'}

        for row in rows:
            session_data = extract_session_from_db(row.data)

            if not isinstance(session_data, dict):
                continue

            sess_token = session_data.get('api_token')
            if sess_token == token:
                web.ctx.api_session = session_data
                web.ctx.api_username = session_data.get('username')
                return func(*args, **kwargs)
        return {'_success': False, '_msg': 'INVALID_TOKEN'}

    return wrapper
```
