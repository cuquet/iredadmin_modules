# libs/m_crudlib/__init__.py
import settings

if settings.backend == "ldap":
    from libs.ldaplib.core import LDAPWrap
elif settings.backend in ["mysql", "pgsql"]:
    from libs.sqllib import SQLWrap

