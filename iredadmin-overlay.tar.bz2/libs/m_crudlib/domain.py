# libs/m_crudlib/domain.py
import web
import re
from datetime import datetime, timedelta
from typing import Union, List, Tuple, Dict, Set, Optional

import settings
from libs import iredutils
from libs.logger import logger, log_traceback, log_activity

from libs.m_system.decorators import LibDecorators
from libs.m_system import utils
from libs.m_system.mixins import Direction, SQLWhereBuilder
from libs.m_iredapd import (
    throttle as lib_throttle, 
    greylist as lib_greylist
    )
from libs.m_amavisd import (
    spampolicy as lib_spampolicy,
    wblist as lib_wblist
    )

session = web.config.get('_session')

class DomainBasic:
    def __init__(self, domain: Optional[str] = None):
        self.domain = domain
        self.backend = Wrap()
        self.conn = self.backend.conn
        if settings.backend == "ldap":
            self.conn_iredadmin=  web.conn_iredadmin
        elif settings.backend in ["mysql", "pgsql"]:
            self.conn_iredadmin = self.conn

    def get_managed_domains(
        self, attributes: Optional[List[str]] = None,
        names_only: bool = False,
        disabled_only: bool = False,
        starts_with: Optional[str] = None,
        admin: Optional[str] = None):
        '''
            List all domains under control.   
        '''
        session = web.config.get('_session')
        admin= admin if admin else session['username']
        if settings.backend == 'ldap':
            search_filter = f'(&(objectClass=mailDomain)(domainAdmin={admin}))'
            vars_map = {}
        elif settings.backend in ['mysql', 'pgsql']:
            search_filter = "domain IN (SELECT domain FROM domain_admins WHERE username=$admin)"
            vars_map = {'admin': admin}
        else:
            return (False, 'UNSUPPORTED_BACKEND')

        return self.get_all_domains(
            attributes=attributes,
            search_filter=search_filter,
            names_only=names_only,
            disabled_only=disabled_only, 
            starts_with=starts_with,
            vars_map=vars_map)

    def get_all_domains(
        self, attributes: Optional[List[str]] = None,
        search_filter: Optional[str] = None,
        names_only: bool = False,
        disabled_only: bool = False,
        starts_with: Optional[str] = None,
        vars_map: Optional[Dict] = None):
        """
            Llista tots els dominis

            :param attributes: llista de noms d'atributs ldap que s'han de consultar.
            :param search_filter: filtre de cerca ldap utilitzat per consultar el domini.
            :param names_only: [True | False]. Retorna una llista de noms de dominis de correu.
            :param disabled_only: [True | False]. Només consulta dominis desactivats.
            :param starts_with: un caràcter. Només consulta noms de dominis de correu que comencen pel caràcter indicat.
        """
        session = web.config.get('_session')
        admin = session['username']
        _list = []

        if settings.backend == "ldap":
            if not attributes:
                attributes = list(attrs.DOMAIN_SEARCH_ATTRS)
            if names_only:
                attributes = ['domainName']

            if not search_filter:
                if session.get('is_user_admin'):
                    search_filter = f'(&(objectClass=mailDomain)(domainAdmin={admin}))'
                if session.get('is_global_admin'):
                    search_filter = '(objectClass=mailDomain)'

            if disabled_only is True:
                # NOTE: use "is True" here to prevent client input invalid value in url.
                search_filter = f'(&{search_filter}(accountStatus=disabled))'

            if starts_with:
                if iredutils.is_valid_account_first_char(starts_with):
                    search_filter = f'(&{search_filter}(domainName={starts_with}*))'

            try:
                qr = self.conn.search_s(
                    settings.ldap_basedn,
                    ldap.SCOPE_ONELEVEL,
                    search_filter,
                    attributes)
            except Exception as e:
                return (False, repr(e))

            if qr:
                qr = iredutils.bytes2str(qr)
                for (_dn, _ldif) in qr:
                    if names_only:
                        _list.append( _ldif['domainName'][0])
                    else:
                        domain = _ldif['domainName'][0]
                        if settings.SHOW_USED_QUOTA :
                            ok, _domainUsedQuota, *rest = self.get_domain_used_quota(domain)
                            _ldif['domainUsedQuota'] = _domainUsedQuota
                    # NOTE: REQUIRE VERIFICATION → disable + no mail
                        if settings.REQUIRE_DOMAIN_OWNERSHIP_VERIFICATION:
                            from libs.m_system.domain_ownership import is_single_domain_verified
                            verified = is_single_domain_verified(domain)
                            if verified == "True":
                                _ldif['img_status'] = _ldif['accountStatus'][0]
                            else:
                                _ldif['img_status'] = "own_pending"
                        else:
                            _ldif['img_status'] = _ldif['accountStatus'][0]

                    # NOTE: BADGES
                        badges = []
                        if _ldif.get('domainBackupMX', [''])[0] == 'yes':
                            badges.append('backupmx')
                        transport = _ldif.get('mtaTransport', [''])[0]
                        if transport.startswith('relay:'):
                            badges.append('relay')
                        if 'domainAliasName' in _ldif and _ldif['domainAliasName']:
                            badges.append('aliases')
                        _ldif['img_badges'] = badges

                        _list.append(_ldif)

        elif settings.backend in ['mysql', 'pgsql']:
            try:
                where_clauses = []
                
                if search_filter:
                    where_clauses.append(search_filter)
                
                if disabled_only is True:
                    where_clauses.append("active=0")
                else:
                    where_clauses.append("active=1")
                if vars_map is None:
                    vars_map = {}
                    
                if starts_with:
                    if iredutils.is_valid_account_first_char(starts_with):
                        where_clauses.append("domain LIKE $starts_with")
                        vars_map['starts_with'] = starts_with + '%'

                where = " AND ".join(where_clauses) if where_clauses else None

                qr = self.conn.select(
                    'domain',
                    what='domain' if names_only else 'domain, description, transport, aliases, mailboxes, maxquota, quota, active, backupmx',
                    where=where,
                    vars=vars_map,
                    order='domain',
                )

                # -------- PRELOAD ALIAS DOMAINS (1 sola query) --------
                qr_alias_all = self.conn.select(
                    'alias_domain',
                    what='target_domain',
                    where="active=1"
                )
                aliases_by_domain = {row.target_domain: True for row in qr_alias_all}

                for row in qr:
                    if names_only:
                        _list.append(row.domain)
                    else:
                        row_dict = {
                            'domain': row.domain,
                            'desc': row.description,
                            'transport': row.transport,
                            'aliases': row.aliases,
                            'mailboxes': row.mailboxes,
                            'maxquota': row.maxquota,
                            'quota': row.quota,
                            'active': row.active,
                        }
                        if settings.SHOW_USED_QUOTA:
                            ok, _domainUsedQuota, *rest = self.get_domain_used_quota(row.domain)
                            row_dict['domainUsedQuota'] = _domainUsedQuota
                        # NOTE: REQUIRE VERIFICATION
                        if settings.REQUIRE_DOMAIN_OWNERSHIP_VERIFICATION:
                            from libs.m_system.domain_ownership import is_single_domain_verified
                            verified = is_single_domain_verified(row.domain)

                            if str(verified) == "True":
                                row_dict['img_status'] = "active" if row.active else "disabled"
                            else:
                                row_dict['img_status'] = "own_pending"
                        else:
                            # NOTE: Si no cal verificació, copia comportament LDAP:
                            row_dict['img_status'] = "active" if row.active else "disabled"

                        # NOTE: BADGES
                        row_dict['img_badges'] = []
                        if row.backupmx:
                            row_dict['img_badges'].append('backupmx')
                        if row.transport and row.transport.startswith('relay:'):
                            row_dict['img_badges'].append('relay')
                        if row.domain in aliases_by_domain:
                            row_dict['img_badges'].append('aliases')

                        _list.append(row_dict)

            except Exception as e:
                return (False, repr(e))

        return (True, _list)

    def domains_get_first_char_of_all(self):
        """
            Get a list of first character of all domains.
        """
        chars = list()
        qr = self.get_all_domains(names_only=True)
        if not qr[0]:
            return qr
        chars = utils.accounts_get_first_char_of(qr[1])
        return chars

    @LibDecorators.safe_sql_method
    def get_domain_used_quota(self, domain: Union[str, List[str]]) -> Tuple[bool, Dict]:
        """
            Obté la quota utilitzada en temps real del domini indicat.
            -> ldaplib.general.py get_domain_used_quota()
        """
        if isinstance(domain, list):
            if not domain:   # NOTE: si rebem una llista buida
                return {"bytes": 0, "messages": 0}
            domain = domain[0]
        elif not isinstance(domain, str):
            return {"bytes": 0, "messages": 0}

        builder = SQLWhereBuilder()
        builder.add_equals("domain", domain)
        sql_where, sql_vars = builder.build()

        qr = self.conn_iredadmin.select(
            settings.SQL_TBL_USED_QUOTA,
            vars=sql_vars,
            what='SUM(bytes) AS bytes, SUM(messages) AS messages',
            where=sql_where)

        for i in qr:
            return {'bytes': int(i.bytes) if i.bytes else 0, 'messages': int(i.messages) if i.messages else 0}

    @LibDecorators.safe_sql_method
    def delete_domain_used_quota(self, domain: Union[str, List[str]]) -> Tuple[bool, Dict]:
        """
            Elimina la quota de bústia de correu en temps real.
        """
        if isinstance(domain, list):
            if not domain:   # NOTE: si rebem una llista buida
                return (True, )
            domain = domain[0]
        elif not isinstance(domain, str):
            return (True, )

        builder = SQLWhereBuilder()
        builder.add_equals("domain", domain)
        sql_where, sql_vars = builder.build()

        self.conn_iredadmin.delete(
            settings.SQL_TBL_USED_QUOTA,
            vars=sql_vars,
            where=sql_where,
        )

        return (True, )

    @LibDecorators.safe_sql_method
    def delete_domain_ownership(self, domains: Union[str, List[str]]) -> Tuple[bool, str]:
        """
            Elimina registres de verificació de propietat per dominis esborrats.
            És important purgar-los per evitar residus a `iredadmin.domain_ownership`.
        """
        if isinstance(domains, str):
            domains = [domains]

        domains = [str(d).lower() for d in (domains or []) if self.is_domain(str(d).lower())]
        if not domains:
            return (True, )

        web.conn_iredadmin.delete(
            'domain_ownership',
            vars={'domains': domains},
            where='domain IN $domains OR alias_domain IN $domains',
        )
        return (True, )

    def get_domain_pwd_data(self, fallback_to_global_settings=True):
        global_db_settings = iredutils.get_settings_from_db(params=['min_passwd_length', 'max_passwd_length'])
        db_settings = iredutils.get_settings_from_db(account=self.domain, params=['min_passwd_length', 'max_passwd_length'])

        def _to_int(v, default=0):
            try:
                return int(v or 0)
            except Exception:
                return default

        # NOTE: Garantim valors numèrics aquí per evitar conversió duplicada als controllers/templates.
        min_pw_len = _to_int(db_settings.get('min_passwd_length', 0), 0)
        max_pw_len = _to_int(db_settings.get('max_passwd_length', 0), 0)
        global_min = _to_int(global_db_settings.get('min_passwd_length', 0), 0)
        global_max = _to_int(global_db_settings.get('max_passwd_length', 0), 0)

        if fallback_to_global_settings:
            if min_pw_len < global_min:
                min_pw_len = global_min

            # NOTE: global_max=0 implica "sense límit superior"; només corregim si és >0.
            if global_max > 0:
                if max_pw_len > global_max or max_pw_len < min_pw_len:
                    max_pw_len = global_max

        return {
            'min_passwd_length': min_pw_len,
            'max_passwd_length': max_pw_len,
            'passwd_policies': iredutils.get_password_policies(),
            'store_password_in_plain_text':settings.STORE_PASSWORD_IN_PLAIN_TEXT
        }

    def get_filtered_account_setting(self, key):
        """
            Retorna un únic valor de `accountSetting` amb contracte homogeni
            per LDAP i SQL: valor o False si no existeix.
        """
        qr = self.get_domain_account_settings()
        if not qr[0]:
            return False
        _as = qr[1]
        if not isinstance(_as, dict):
            return False
        return _as.get(key, False)

if settings.backend in ['mysql', 'pgsql']:
    from libs.m_crudlib import SQLWrap as Wrap
    from libs.m_system.mixins import SQLCRUDMixin
    from libs.sqllib.general import (
        __num_accounts_under_domain as _num_accounts_under_domain_helper,
    )
    class Domain(DomainBasic, SQLCRUDMixin) :
        def __init__(self, domain: Optional[str] = None):
            super().__init__(domain=domain)
            self.domain = web.safestr(domain).lower() if self.is_domain(domain) else False

        def _project_account_setting_to_sql(
            self,
            account_setting: Dict,
            domain_settings: Optional[Dict] = None,
            validate_language: bool = False,
            preserve_raw: bool = True,
            ) -> Tuple[Dict, Dict]:
            """
                Converteix `accountSetting` a:
                - columnes SQL de `domain` (`aliases`, `mailboxes`, `maillists`, `quota`, `maxquota`)
                - diccionari `settings` serialitzable.

                Aquesta funció centralitza la mateixa lògica per `add()` i `update()`.
            """
            if not isinstance(account_setting, dict):
                account_setting = {}
            if not isinstance(domain_settings, dict):
                domain_settings = {}

            incoming = dict(account_setting)
            settings_out = dict(domain_settings)
            sql_columns = {}

            int_map = {
                'numberOfAliases': 'aliases',
                'numberOfUsers': 'mailboxes',
                'numberOfLists': 'maillists',
                'domainQuota': 'quota',
                'maxUserQuota': 'maxquota',
            }
            for src, dst in int_map.items():
                if src in incoming:
                    try:
                        sql_columns[dst] = int(incoming.get(src) or 0)
                    except (TypeError, ValueError):
                        sql_columns[dst] = 0

            if preserve_raw:
                settings_out.update(incoming)
            else:
                filtered = {k: v for (k, v) in incoming.items() if k not in {'defaultLanguage', 'defaultQuota'}}
                settings_out.update(filtered)

            if 'defaultLanguage' in incoming and incoming.get('defaultLanguage'):
                default_lang = str(incoming.get('defaultLanguage')).strip()
                if default_lang and ((not validate_language) or default_lang in iredutils.get_language_maps()):
                    settings_out['default_language'] = default_lang

            if 'defaultQuota' in incoming:
                try:
                    default_quota = int(incoming.get('defaultQuota') or 0)
                except (TypeError, ValueError):
                    default_quota = 0

                if default_quota > 0:
                    settings_out['default_user_quota'] = default_quota
                else:
                    settings_out.pop('default_user_quota', None)

            return (sql_columns, settings_out)

        def list(self, starts_with: Optional[str] = None, disabled_only: bool = False, names_only: bool = False, current_page: int = 0):
            qr = self.get_all_domains(
                disabled_only=disabled_only,
                starts_with=starts_with,
                names_only=names_only,
            )
            if not qr[0]:
                return qr

            account_profiles = qr[1] if isinstance(qr[1], list) else []
            current_page = self.normalize_current_page(current_page=current_page, default=0, min_page=0)
            sl = self.get_accounts_paged_list(account_profiles, current_page=current_page)
            return (True, sl)

        @LibDecorators.safe_sql_method
        def get_profile(self, attributes: Optional[List[str]] = None):
            domain = str(self.domain).lower()
            if not self.is_domain(domain):
                return (False, 'INVALID_DOMAIN_NAME')

            sql_what = '*'
            if attributes:
                sql_what = ','.join(attributes)

            ok_base, base_data, *rest = self._get_profile(
                table='domain',
                key_col='domain',
                key_val=domain,
                attributes=sql_what,
            )
            if not ok_base:
                if base_data == 'NO_SUCH_ACCOUNT':
                    return (False, 'INVALID_DOMAIN_NAME')
                return (False, base_data)

            if isinstance(base_data, dict) and isinstance(base_data.get('ldif'), dict):
                p = base_data['ldif']
                ok, _domainUsedQuota, *rest = self.get_domain_used_quota(self.domain)

                # NOTE: Domain BCC settings (SQL tables: recipient_bcc_domain/sender_bcc_domain)
                rbcc_qr = self.conn.select(
                    'recipient_bcc_domain',
                    vars={'domain': self.domain},
                    what='bcc_address',
                    where='domain=$domain AND active=1',
                    limit=1,
                )
                sbcc_qr = self.conn.select(
                    'sender_bcc_domain',
                    vars={'domain': self.domain},
                    what='bcc_address',
                    where='domain=$domain AND active=1',
                    limit=1,
                )
                p['rbcc_addr'] = str(rbcc_qr[0].bcc_address).lower() if rbcc_qr else ''
                p['sbcc_addr'] = str(sbcc_qr[0].bcc_address).lower() if sbcc_qr else ''

                # NOTE: Relayhost de remitent sortint (taula SQL: sender_relayhost)
                relay_qr = self.conn.select(
                    'sender_relayhost',
                    vars={'account': f'@{self.domain}'},
                    what='relayhost',
                    where='account=$account',
                    limit=1,
                )
                p['senderRelayHost'] = str(relay_qr[0].relayhost) if relay_qr else ''

                # NOTE: Catch-all de domini i dominis àlies
                ok_catchall, catchall_addresses, *rest = self.get_catchall_addresses()
                p['catchallAddress'] = catchall_addresses if ok_catchall else []

                ok_alias, alias_domains, *rest = self.get_domain_aliases()
                p['domainAliasName'] = alias_domains if ok_alias else []
                p['domainalias'] = 'active' if p['domainAliasName'] else 'disabled'

                enabled_services = []
                if p['domainAliasName']:
                    enabled_services.append('domainalias')
                if p['rbcc_addr']:
                    enabled_services.append('recipientbcc')
                if p['sbcc_addr']:
                    enabled_services.append('senderbcc')
                p['enabledService'] = enabled_services

                p['statistics']= {
                        'users' : self.num_users_under_domain(self.domain),
                        'maillists' : self.num_maillists_under_domain(self.domain),
                        'bytes' : _domainUsedQuota['bytes'],
                        'messages' : _domainUsedQuota['messages'],
                    }
                return (True, p)
            return (False, 'INVALID_DOMAIN_NAME')

        @LibDecorators.safe_sql_method
        def add(self, payload: Dict):
            def assign_admins_to_domain(admins, domain_name: str):
                if not isinstance(admins, (List, Tuple, Set)):
                    return (False, 'NO_ADMINS')
                else:
                    admins = [str(i).lower() for i in admins if self.is_email(i)]
                    if not admins:
                        return (False, 'NO_ADMINS')
                for adm in admins:
                    try:
                        self.conn.insert(
                            'domain_admins',
                            domain=domain_name,
                            username=adm)
                    except Exception as e:
                        if e.__class__.__name__ == 'IntegrityError':
                            pass
                        else:
                            return (False, repr(e))

                return (True, )

            if not isinstance(payload, dict):
                return (False, 'INVALID_PAYLOAD')

            # NOTE:
            # API_Domain.POST pot enviar `accountSetting` com a diccionari.
            # No es pot passar directament a `conn.insert('domain', **payload)`
            # perquè PyMySQL no admet dict com a valor SQL (TypeError).
            payload = dict(payload)
            account_setting = payload.pop('accountSetting', {})
            if not isinstance(account_setting, dict):
                account_setting = {}

            domain = payload.get('domainName')
            if not self.is_domain(domain):
                return (False, 'INVALID_DOMAIN_NAME')
            if self.is_domain_exists(domain=domain):
                return (False, 'ALREADY_EXISTS')
            self.domain = domain

            kv = {
                'domain': domain,
                'description': payload.get('cn', payload.get('name')),
                'transport': settings.default_mta_transport,
                'active': 1,
                'created': iredutils.get_gmttime(),
            }

            # NOTE: Projectem accountSetting en columnes SQL i settings serialitzats.
            sql_columns, domain_settings = self._project_account_setting_to_sql(
                account_setting=account_setting,
                domain_settings={},
                validate_language=False,
                preserve_raw=True,
            )
            kv.update(sql_columns)
            if domain_settings:
                kv['settings'] = utils.account_settings_dict_to_string(domain_settings)

            # NOTE: Add domain in database.
            self.conn.insert('domain', **kv)
            log_activity(event='create',
                admin=session.get('username'),
                domain=domain,
                msg=f"New domain: {domain}."
                )

            # NOTE: Si és un administrador de domini normal amb permís per crear un domini nou,
            # NOTE: assign current admin as admin of this newly created domain.
            if session.get('create_new_domains'):
                qr = assign_admins_to_domain(
                    admins=[session.get('username')],
                    domain_name=domain,
                )
                if not qr[0]:
                    return qr

            # CREATE REQUIRED RFC ALIASES (postmaster, abuse)
            # Aquests dos àlies són obligatoris per RFC 5321 / RFC 2142,
            # i serveixen per garantir que qualsevol domini pugui rebre 
            # reclamacions d'abús, problemes postals, etc.
            rfc_aliases = ["postmaster", "abuse"]
            creator = session.get('username')

            for localpart in rfc_aliases:
                alias_addr = f"{localpart}@{domain}"
                if self.is_email_exists(alias_addr):
                    continue
                try:
                    # NOTE: En backend SQL (iRedMail vmail), els alias de correu viuen a `forwardings`.
                    # NOTE: La taula `alias` és per maillists i no té columna `goto`.
                    dest_domain = (creator or "").split('@', 1)[-1] if self.is_email(creator) else domain
                    self.conn.insert(
                        'forwardings',
                        address=alias_addr,
                        forwarding=creator or "",
                        domain=domain,
                        dest_domain=dest_domain,
                        is_alias=1,
                        is_forwarding=1,
                        active=1
                    )

                except Exception as e:
                    return (False, f"SQL create RFC alias {alias_addr}: {repr(e)}")

            if settings.REQUIRE_DOMAIN_OWNERSHIP_VERIFICATION:
                from libs.m_system.domain_ownership import DomainOwnershipManager
                qr = DomainOwnershipManager().set_verify_code_for_new_domain(primary_domain=domain)
                if not qr[0]:
                    return qr

            return (True, )

        @LibDecorators.safe_sql_method
        def update(self, payload: Dict) -> Tuple[bool, str]:
            def _as_enabled(value) -> bool:
                if isinstance(value, bool):
                    return value
                if isinstance(value, (int, float)):
                    return int(value) == 1
                return str(value).strip().lower() in {
                    '1', 'yes', 'true', 'on', 'active', 'enable', 'enabled'
                }

            def _to_int(value, default=0) -> int:
                try:
                    return int(value)
                except Exception:
                    return default

            def _normalize_service_list(values) -> List[str]:
                if isinstance(values, str):
                    values = [v.strip() for v in values.split(",") if v.strip()]
                elif not isinstance(values, list):
                    values = []
                out = []
                for v in values:
                    s = str(v).strip().lower()
                    if s:
                        out.append(s)
                return out

            if not isinstance(payload, dict):
                return (False, 'INVALID_PAYLOAD')
            # NOTE: Contracte d'entrada ja unificat al parser CRUD/API:
            # NOTE: aquí esperem claus canòniques (`maxUserQuota`, `defaultQuota`).

            global_db_settings = iredutils.get_settings_from_db()
            qr = self.get_profile()
            if not qr[0]:
                return qr
            domain_profile = qr[1]
            domain_settings = utils.account_settings_string_to_dict(domain_profile.get('settings', ''))
            old_disabled_mail_services = set(_normalize_service_list(domain_settings.get('disabledMailService', [])))

            disabled_domain_profiles = []
            if not session.get('is_global_admin'):
                disabled_domain_profiles = domain_settings.get('disabled_domain_profiles', [])
                if not disabled_domain_profiles:
                    disabled_domain_profiles = domain_settings.get('disabledDomainProfile', [])
                if isinstance(disabled_domain_profiles, str):
                    disabled_domain_profiles = [i.strip() for i in disabled_domain_profiles.split(',') if i.strip()]
                elif not isinstance(disabled_domain_profiles, list):
                    disabled_domain_profiles = []

            key_to_profile = {
                'rbcc_addr': 'bcc',
                'sbcc_addr': 'bcc',
                'transport': 'relay',
                'mtaTransport': 'relay',
                'catchallAddress': 'catchall',
                'domainalias': 'aliases',
                'domainAliasName': 'aliases',
                'throttle_inb': 'throttle',
                'throttle_out': 'throttle',
                'whitelists': 'greylisting',
                'whitelist_domains': 'greylisting',
                'rdns_whitelist': 'greylisting',
                'rdns_blacklist': 'greylisting',
                'greylisting': 'greylisting',
                'whitelistSender': 'wblist',
                'blacklistSender': 'wblist',
                'whitelistRecipient': 'wblist',
                'blacklistRecipient': 'wblist',
                'policy_name': 'spampolicy',
                'effectivebypriority': 'spampolicy',
                'enable_spam_checks': 'spampolicy',
                'enable_virus_checks': 'spampolicy',
                'enable_banned_checks': 'spampolicy',
                'enable_header_checks': 'spampolicy',
                'quarantine_spam': 'spampolicy',
                'quarantine_virus': 'spampolicy',
                'quarantine_banned': 'spampolicy',
                'quarantine_bad_header': 'spampolicy',
                'prefix_spam_in_subject': 'spampolicy',
                'always_insert_x_spam_headers': 'spampolicy',
                'spam_score': 'spampolicy',
                'spam_kill_level': 'spampolicy',
                'spam_tag_level': 'spampolicy',
                'banned_rulenames': 'spampolicy',
                'message_size_limit': 'spampolicy',
                'backupmx': 'backupmx',
                'domainBackupMX': 'backupmx',
            }

            if disabled_domain_profiles and not session.get('is_global_admin'):
                touched_profiles = {
                    key_to_profile[k] for k in payload if k in key_to_profile
                }
                if touched_profiles.intersection(set(disabled_domain_profiles)):
                    return (False, 'PERMISSION_DENIED')

            updates = {'modified': iredutils.get_gmttime()}
            errors = {}
            args_db = {}

            if 'name' in payload or 'cn' in payload:
                updates['description'] = payload.get('name', payload.get('cn', ''))

            if 'active' in payload or 'accountStatus' in payload:
                status_val = payload.get('active', payload.get('accountStatus', 'disabled'))
                updates['active'] = 1 if _as_enabled(status_val) else 0

            # NOTE: Relay / backupmx
            if 'transport' in payload or 'mtaTransport' in payload:
                updates['transport'] = payload.get('transport', payload.get('mtaTransport', ''))

            if 'senderRelayHost' in payload or 'relayhost' in payload:
                relayhost = str(payload.get('senderRelayHost', payload.get('relayhost', ''))).strip()
                relay_account = f'@{self.domain}'
                self.conn.delete(
                    'sender_relayhost',
                    vars={'account': relay_account},
                    where='account=$account',
                )
                if relayhost:
                    self.conn.insert(
                        'sender_relayhost',
                        account=relay_account,
                        relayhost=relayhost,
                    )

            if 'backupmx' in payload or 'domainBackupMX' in payload:
                backup_val = payload.get('backupmx', payload.get('domainBackupMX', 'disabled'))
                primary_mx = str(payload.get('primary_mx', '')).strip()
                if _as_enabled(backup_val) and primary_mx:
                    updates['backupmx'] = 1
                    updates['transport'] = f"relay:{primary_mx}"
                else:
                    updates['backupmx'] = 0
                    updates.setdefault('transport', 'dovecot')

            if 'relay_without_verify_local_recipient' in payload:
                relay_wo_verify = _as_enabled(payload.get('relay_without_verify_local_recipient'))
                mta_value = str(payload.get('transport', payload.get('mtaTransport', updates.get('transport', domain_profile.get('transport', '')))))
                if mta_value.startswith('relay:'):
                    updates['backupmx'] = 1
                elif relay_wo_verify and (mta_value.startswith('smtp:') or mta_value.startswith('uucp:') or mta_value.startswith(':')):
                    updates['backupmx'] = 1
                else:
                    updates['backupmx'] = 0

            # NOTE: Domain BCC
            if 'rbcc_addr' in payload:
                recipient_bcc = str(payload.get('rbcc_addr', '')).strip().lower()
                if recipient_bcc and not self.is_email(recipient_bcc):
                    errors.setdefault('bcc', []).append('INVALID_MAIL')
                    recipient_bcc = ''
                self.conn.delete(
                    'recipient_bcc_domain',
                    vars={'domain': self.domain},
                    where='domain=$domain',
                )
                if recipient_bcc:
                    now = iredutils.get_gmttime()
                    self.conn.insert(
                        'recipient_bcc_domain',
                        domain=self.domain,
                        bcc_address=recipient_bcc,
                        created=now,
                        modified=now,
                        active=1,
                    )

            if 'sbcc_addr' in payload:
                sender_bcc = str(payload.get('sbcc_addr', '')).strip().lower()
                if sender_bcc and not self.is_email(sender_bcc):
                    errors.setdefault('bcc', []).append('INVALID_MAIL')
                    sender_bcc = ''
                self.conn.delete(
                    'sender_bcc_domain',
                    vars={'domain': self.domain},
                    where='domain=$domain',
                )
                if sender_bcc:
                    now = iredutils.get_gmttime()
                    self.conn.insert(
                        'sender_bcc_domain',
                        domain=self.domain,
                        bcc_address=sender_bcc,
                        created=now,
                        modified=now,
                        active=1,
                    )

            # NOTE: Domain catch-all
            if 'catchallAddress' in payload:
                catchall_values = payload.get('catchallAddress')
                if isinstance(catchall_values, dict):
                    catchall_values = catchall_values.get('add')

                ok_catchall, msg_catchall, *rest = self.update_catchall_addresses(
                    utils._normalize_list_mails(catchall_values)
                )
                if not ok_catchall:
                    errors.setdefault('catchall', []).append(msg_catchall)

            # NOTE: Domain alias domains
            if 'domainalias' in payload or 'domainAliasName' in payload:
                ok_alias, msg_alias, *rest = self.update_domain_aliases(
                    payload_aliases=payload.get('domainAliasName'),
                    domainalias_status=payload.get('domainalias'),
                )
                if not ok_alias:
                    errors.setdefault('aliases', []).append(msg_alias)

            # NOTE: accountSetting (domain.settings)
            as_keys = [
                'domainQuota', 'maxUserQuota', 'numberOfUsers', 'numberOfLists',
                'numberOfAliases', 'defaultList', 'disabledUserPreference',
                'disabledUserProfile', 'disabledMailService', 'disabledDomainProfile',
                'defaultRecipientBccAddress', 'defaultSenderBccAddress',
            ]
            account_setting_updates = {}
            for k in as_keys:
                if k in payload:
                    account_setting_updates[k] = payload[k]

            if 'timezone' in payload:
                account_setting_updates['timezone'] = str(payload.get('timezone', '')).strip()

            if 'defaultLanguage' in payload:
                account_setting_updates['defaultLanguage'] = payload.get('defaultLanguage')

            if 'defaultQuota' in payload:
                account_setting_updates['defaultQuota'] = payload.get('defaultQuota')

            sql_columns, domain_settings = self._project_account_setting_to_sql(
                account_setting=account_setting_updates,
                domain_settings=domain_settings,
                validate_language=True,
                preserve_raw=False,
            )
            updates.update(sql_columns)

            # NOTE: Aplica nous `disabledMailService` als usuaris existents del domini (SQL).
            new_disabled_mail_services = set(_normalize_service_list(domain_settings.get('disabledMailService', [])))
            services_to_disable = sorted(new_disabled_mail_services - old_disabled_mail_services)
            for srv in services_to_disable:
                if not re.match(r'^[a-z0-9_]+$', srv):
                    errors.setdefault('disabledMailService', []).append(f'INVALID_SERVICE_NAME:{srv}')
                    continue

                try:
                    self.conn.update(
                        'mailbox',
                        vars={'domain': self.domain},
                        where='domain=$domain',
                        **{f'enable{srv}': 0},
                    )
                except Exception as e:
                    errors.setdefault('disabledMailService', []).append(f'{srv}:{repr(e)}')

            if 'min_passwd_length' in payload or 'max_passwd_length' in payload:
                if session.get('is_global_admin') or ('password_policies' not in disabled_domain_profiles):
                    for k in ['min_passwd_length', 'max_passwd_length']:
                        if k not in payload:
                            continue
                        _length = _to_int(payload.get(k, 0), 0)
                        if _length > 0:
                            if not session.get('is_global_admin'):
                                if k == 'min_passwd_length':
                                    if _length < global_db_settings['min_passwd_length']:
                                        _length = global_db_settings['min_passwd_length']
                                elif k == 'max_passwd_length':
                                    if (global_db_settings['max_passwd_length'] > 0) and (
                                        _length > global_db_settings['max_passwd_length']
                                        or _length <= global_db_settings['min_passwd_length']
                                    ):
                                        _length = global_db_settings['max_passwd_length']
                            args_db[k] = _length

            # NOTE: iredapd throttle
            if any(k in payload for k in ['throttle_inb', 'throttle_out']):
                account = f'@{self.domain}'

                def _apply_throttle(direction_key, direction_enum):
                    if payload.get(direction_key):
                        throttle = lib_throttle.Throttle(account, payload[direction_key], direction_enum)
                        ok, msg, *rest = throttle.update_throttle_settings()
                    else:
                        throttle = lib_throttle.Throttle(account, {}, direction_enum)
                        throttle.remove_throttle_tracking()
                        ok, msg, *rest = throttle.remove_throttle_settings()

                    if not ok:
                        errors.setdefault('throttle', []).append(msg)

                _apply_throttle('throttle_inb', Direction.INBOUND)
                _apply_throttle('throttle_out', Direction.OUTBOUND)

            # NOTE: iredapd greylisting
            if any(k in payload for k in ['whitelists', 'whitelist_domains', 'rdns_whitelist', 'rdns_blacklist', 'greylisting']):
                ok, msg, *rest = lib_greylist.update_greylisting(account=f'@{self.domain}', payload=payload)
                if not ok:
                    errors.setdefault('greylist', []).append(msg)

            # NOTE: amavisd wblist
            if any(k in payload for k in ['whitelistSender', 'blacklistSender', 'whitelistRecipient', 'blacklistRecipient']):
                ok, msg, *rest = lib_wblist.update_wblist(f'@{self.domain}', payload)
                if not ok:
                    errors.setdefault('wblist', []).append(msg)

            # NOTE: amavisd spampolicy
            if any(k in payload for k in [
                'policy_name', 'effectivebypriority', 'enable_spam_checks',
                'enable_virus_checks', 'enable_banned_checks', 'enable_header_checks',
                'quarantine_spam', 'quarantine_virus', 'quarantine_banned',
                'quarantine_bad_header', 'prefix_spam_in_subject',
                'always_insert_x_spam_headers', 'spam_score',
                'spam_kill_level', 'spam_tag_level', 'banned_rulenames',
                'message_size_limit',
            ]):
                ok, msg, *rest = lib_spampolicy.SpamPolicy(account=f'@{self.domain}').update_spam_policy(payload)
                if not ok:
                    errors.setdefault('spampolicy', []).append(msg)

            updates['settings'] = utils.account_settings_dict_to_string(domain_settings)

            builder = SQLWhereBuilder()
            builder.add_equals("domain", self.domain)
            sql_where, sql_vars = builder.build()

            self.conn.update(
                'domain',
                vars=sql_vars,
                where=sql_where,
                **updates)

            if args_db:
                qr_db = iredutils.store_settings_in_db(args_db, account=self.domain, flush=True)
                if not qr_db[0]:
                    errors['store_settings_in_db'] = qr_db[1]

            if errors:
                return (False, errors)

            log_activity(event='update',
                admin=session.get('username'),
                domain=self.domain,
                msg=f"Update domain profile: {self.domain}."
                )

            return (True, "UPDATED")

        def delete(self, domain: Optional[str] = None, keep_mailbox_days: int = 0):
            if domain:
                self.domain = str(domain).lower()
            if not self.domain or not self.is_domain(self.domain):
                return (False, 'INVALID_DOMAIN_NAME')
            return self.delete_domains(domains=[self.domain], keep_mailbox_days=keep_mailbox_days)

        @LibDecorators.safe_sql_method
        def delete_domains(self, domains: List=None, keep_mailbox_days:int=0) -> Tuple[bool, Union[str, None]]:
            domains = [str(d).lower() for d in domains if iredutils.is_domain(d)]
            if not domains:
                return (True, )

            # NOTE: Conservem les bústies “per sempre”, fixant-ho a 100 anys.

            sql_keep_days = web.sqlliteral('Null')
            if keep_mailbox_days > 0:
                if settings.backend == 'pgsql':
                    sql_keep_days = web.sqlliteral("""CURRENT_TIMESTAMP + INTERVAL '%d DAYS'""" % keep_mailbox_days)
                else:
                    # NOTE: settings.backend == 'mysql'
                    sql_keep_days = web.sqlliteral('DATE_ADD(CURDATE(), INTERVAL %d DAY)' % keep_mailbox_days)

            sql_vars = {'domains': domains,
                    'admin': session.get('username'),
                    'sql_keep_days': sql_keep_days}
            # NOTE: Log maildir paths of existing users.
            # Aquest bloc és no-fatal: si falla el backup de rutes de maildir,
            # continuem amb l'esborrat de domini per no deixar residus actius.
            try:
                # NOTE: CONCAT_WS funciona tant a PostgreSQL com a MySQL/MariaDB.
                # Així evitem ramificació per backend i mantenim una sola SQL.
                sql_raw = '''
                    INSERT INTO deleted_mailboxes (username, maildir, domain, admin, delete_date)
                    SELECT username, \
                        CONCAT_WS('/', storagebasedirectory, storagenode, maildir) AS maildir, \
                        domain, \
                        $admin, \
                        $sql_keep_days
                    FROM mailbox
                    WHERE domain IN $domains'''

                self.conn.query(sql_raw, vars=sql_vars)
            except Exception as e:
                logger.error(e)

            # NOTE: Elimina el nom de domini.
            for tbl in ['domain', 'alias', 'domain_admins', 'mailbox',
                        'recipient_bcc_domain', 'recipient_bcc_user',
                        'sender_bcc_domain', 'sender_bcc_user',
                        'forwardings', 'moderators',
                        settings.SQL_TBL_USED_QUOTA]:
                self.conn.delete(tbl,
                            vars=sql_vars,
                            where='domain IN $domains')

            # NOTE: Elimina dominis àlies.
            self.conn.delete('alias_domain',
                        vars=sql_vars,
                        where='alias_domain IN $domains OR target_domain IN $domains')

            # NOTE: Elimina administradors de domini.
            for d in domains:
                self.conn.delete('domain_admins',
                            vars={'domain': '%%@' + d},
                            where='username LIKE $domain')

            qr_ownership = self.delete_domain_ownership(domains)
            if not qr_ownership[0]:
                return (False, f"purge_domain_ownership failed: {qr_ownership[1]}")

            for d in domains:
                log_activity(event='delete',
                    admin=session.get('username'),
                    domain=d,
                    msg=f"Delete domain: {d}."
                    )
            return (True, 'DELETED')

        def enable_disable_domains(self, values, action):
            return self.enable_disable_accounts(values, action, 'domain')


        def get_domain_account_settings(self):
            return self.get_account_settings(account=self.domain)

        def get_filtered_account_setting(self, key):
            return super().get_filtered_account_setting(key)


        @LibDecorators.safe_sql_method
        def get_catchall_addresses(self) -> Tuple[bool, List[str]]:
            catchall_address = f'@{self.domain}'
            qr = self.conn.select(
                'forwardings',
                vars={'address': catchall_address},
                what='forwarding',
                where='address=$address AND is_forwarding=1 AND active=1',
            )
            addresses = sorted({
                str(row.forwarding).lower()
                for row in qr
                if row.forwarding and self.is_email(str(row.forwarding).lower())
            })
            return (True, addresses)

        @LibDecorators.safe_sql_method
        def update_catchall_addresses(self, addresses: List[str]) -> Tuple[bool, str]:
            catchall_address = f'@{self.domain}'
            addresses = list(dict.fromkeys(utils._normalize_list_mails(addresses)))

            self.conn.delete(
                'forwardings',
                vars={'address': catchall_address},
                where='address=$address',
            )

            if not addresses:
                return (True, 'CATCHALL_REMOVED')

            records = []
            for fwd in addresses:
                records.append({
                    'address': catchall_address,
                    'forwarding': fwd,
                    'domain': self.domain,
                    'dest_domain': fwd.split('@', 1)[-1],
                    'is_forwarding': 1,
                    'active': 1,
                })

            if records:
                self.conn.multiple_insert('forwardings', records)

            return (True, 'UPDATED')

        @LibDecorators.safe_sql_method
        def get_domain_aliases(self) -> Tuple[bool, List[str]]:
            qr = self.conn.select(
                'alias_domain',
                vars={'domain': self.domain},
                what='alias_domain',
                where='target_domain=$domain AND active=1',
            )
            aliases = sorted({
                str(row.alias_domain).lower()
                for row in qr
                if row.alias_domain and self.is_domain(str(row.alias_domain).lower())
            })
            return (True, aliases)

        @LibDecorators.safe_sql_method
        def update_domain_aliases(
            self,
            payload_aliases: Optional[Union[Dict, List[str], str]] = None,
            domainalias_status: Optional[str] = None,
            ) -> Tuple[bool, Union[str, Dict]]:
            ok_cur, current_aliases, *rest = self.get_domain_aliases()
            if not ok_cur:
                return (False, current_aliases)

            current_set = set(current_aliases or [])

            if isinstance(payload_aliases, dict):
                # NOTE: `populate_form_list_filtered` retorna els valors finals a "add"
                target_aliases = set(utils._normalize_list_domains(payload_aliases.get('add')))
            elif payload_aliases is None:
                target_aliases = set(current_set)
            else:
                target_aliases = set(utils._normalize_list_domains(payload_aliases))

            target_aliases.discard(self.domain)

            if domainalias_status == 'disabled':
                target_aliases = set()

            conflicts = sorted(
                d for d in target_aliases
                if d not in current_set and self.is_domain_exists(d)
            )
            if conflicts:
                return (False, {'ALREADY_EXISTS': conflicts})

            self.conn.delete(
                'alias_domain',
                vars={'domain': self.domain},
                where='target_domain=$domain',
            )

            if target_aliases:
                now = iredutils.get_gmttime()
                records = [{
                    'alias_domain': d,
                    'target_domain': self.domain,
                    'created': now,
                    'modified': now,
                    'active': 1,
                } for d in sorted(target_aliases)]
                self.conn.multiple_insert('alias_domain', records)

            return (True, 'UPDATED')

        @LibDecorators.safe_sql_method
        def set_domain_alias_status(self, alias_domain: str, active: bool = True) -> Tuple[bool, str]:
            alias = str(alias_domain or '').strip().lower()
            if not self.is_domain(alias):
                return (False, 'INVALID_ALIAS_DOMAIN')
            if not self.is_domain(self.domain):
                return (False, 'INVALID_DOMAIN_NAME')

            self.conn.update(
                'alias_domain',
                vars={'alias_domain': alias, 'target_domain': self.domain},
                where='alias_domain=$alias_domain AND target_domain=$target_domain',
                active=1 if active else 0,
            )
            return (True, 'UPDATED')


        def num_users_under_domain(
            self,
            domain: Optional[str] = None,
            increase: bool = False,
            decrease: bool = False,
            step_number: int = 1,
            ) -> int:
            domain = str(domain or self.domain or '').lower()
            if not self.is_domain(domain):
                return 0

            total = _num_accounts_under_domain_helper(
                domain=domain,
                account_type='user',
                conn=self.conn
            )
            # NOTE: Mantenim `domain.mailboxes` sincronitzat amb el recompte real.
            try:
                self.conn.update(
                    'domain',
                    vars={'domain': domain},
                    where='domain=$domain',
                    mailboxes=total,
                    modified=iredutils.get_gmttime(),
                )
            except Exception:
                pass
            return int(total or 0)

        def num_maillists_under_domain(
            self,
            domain: Optional[str] = None,
            increase: bool = False,
            decrease: bool = False,
            step_number: int = 1,
            ) -> int:
            domain = str(domain or self.domain or '').lower()
            if not self.is_domain(domain):
                return 0

            total = _num_accounts_under_domain_helper(
                domain=domain,
                account_type='maillist',
                conn=self.conn
            )
            # NOTE: Mantenim `domain.maillists` sincronitzat amb el recompte real.
            try:
                self.conn.update(
                    'domain',
                    vars={'domain': domain},
                    where='domain=$domain',
                    maillists=total,
                    modified=iredutils.get_gmttime(),
                )
            except Exception:
                pass
            return int(total or 0)


        @LibDecorators.safe_sql_method
        def update_domain_status_for_all_accounts(self, dn_domain, status='active'):
            domain = str(dn_domain or self.domain or '').lower()
            if not self.is_domain(domain):
                return (False, 'INVALID_DOMAIN_NAME')

            active = 1 if str(status).lower() == 'active' else 0
            now = iredutils.get_gmttime()

            for tbl in ['mailbox', 'maillists', 'alias']:
                self.conn.update(
                    tbl,
                    vars={'domain': domain},
                    where='domain=$domain',
                    active=active,
                    modified=now,
                )

            return (True, )

        @LibDecorators.safe_sql_method
        def update_domain_alias_for_all_accounts(self, dn_domain, values):
            domain = str(dn_domain or self.domain or '').lower()
            if not self.is_domain(domain):
                return (False, 'INVALID_DOMAIN_NAME')

            if domain != self.domain:
                self.domain = domain
            return self.update_domain_aliases(payload_aliases=values)

elif settings.backend == "ldap":
    import ldap
    from libs.ldaplib import attrs
    from libs.m_crudlib import LDAPWrap as Wrap
    from libs.m_system.mixins import  LdapCRUDMixin, LdapLDIFMixin
    
    class Domain(DomainBasic, LdapCRUDMixin, LdapLDIFMixin):
        def __init__(self, domain: Optional[str] = None):
            super().__init__(domain = domain)
            self.dn_domain = ''
            self.domain = web.safestr(domain).lower() if self.is_domain(domain) else None
            if self.domain:
                self.dn_domain = self.rdn_value_to_domain_dn(self.domain)

        def list(self, starts_with: Optional[str] = None, disabled_only: bool = False, names_only: bool = False, current_page: int = 0):
            qr = self.get_all_domains(disabled_only=disabled_only, starts_with=starts_with, names_only=names_only)
            if not qr[0]:
                return qr
            sl = self.get_accounts_paged_list(qr[1], current_page=current_page)
            return (True, sl)

        def get_profile(self, attributes: Optional[List[str]] = None):
            if not attributes:
                attributes = list(attrs.DOMAIN_ATTRS_ALL)
            _filter = f'(&(objectClass=mailDomain)(|(domainName={self.domain})(domainAliasName={self.domain})))'
            qr = self.profile_get_by_dn(self.dn_domain, query_filter=_filter, attributes=attributes)
            if not qr[0]:
                return qr
            _ldif = qr[1]['ldif']

            ok, _domainUsedQuota, *rest = self.get_domain_used_quota(self.domain)     
            _ldif['statistics']= {
                    'users' : self.num_users_under_domain(),
                    'maillists' : self.num_maillists_under_domain(),
                    'bytes' : _domainUsedQuota['bytes'],
                    'messages' : _domainUsedQuota['messages'],
                }
            ok, catchall_addresses = self.get_catchall_addresses()
            _ldif["mailForwardingAddress"] = catchall_addresses.get('mailForwardingAddress', []) if ok else []
            return (True, _ldif)

        def add(self, payload: Dict):
            '''
                Afegeix un nou domini de correu amb les dades enviades des del formulari web 
                (un diccionari).

                :param form: un diccionari amb les dades enviades des del formulari web.
            '''
            def assign_admins_to_domain(admins):
                '''
                    Assign list of NEW admins to specified mail domain.
                    It doesn't remove existing admins.
                '''
                if not isinstance(admins, (List, Tuple, Set)):
                    return (False, 'NO_ADMINS')
                else:
                    admins = [str(i).lower() for i in admins if self.is_email(i)]
                    if not admins:
                        return (False, 'NO_ADMINS')

                qr = self.add_or_remove_attr_values_by_dn(
                    dn=_dn,
                    attr='domainAdmin',
                    values=[admins],
                    action='add')

                return qr   

            raw_domain = payload.get("domainName")
            if isinstance(raw_domain, (list, tuple, set)):
                domain = next((str(d).strip() for d in raw_domain if d), "")
            else:
                domain = str(raw_domain).strip() if raw_domain else ""

            if not domain:
                return (False, "INVALID_DOMAIN_NAME")

            # NOTE: Comprova si el nom de domini ja existeix (domainName, domainAliasName).
            if self.is_domain_exist(domain):
                return (False, 'ALREADY_EXISTS')

            _dn = self.rdn_value_to_domain_dn(domain)

            # NOTE: per-domain account settings pendent: podem passar el DICT des del form ;)
            _as = payload.get('accountSetting', {})

            ldif = self.ldif_domain(
                domain=domain,
                cn=payload["cn"],
                account_settings=_as,
                transport=payload.get("transport")
                )

            # NOTE: pendent REQUIRE VERIFICATION → disable + no mail
            if settings.REQUIRE_DOMAIN_OWNERSHIP_VERIFICATION:
                from libs.m_system.domain_ownership import DomainOwnershipManager
                qr = DomainOwnershipManager().set_verify_code_for_new_domain(primary_domain=domain)
                if not qr[0]:
                    return qr

                ldif = [(k, v) for (k, v) in ldif if k not in  {"accountStatus", "enabledService"}]
                # NOTE: Usem attr_ldif per generar els valors forçats (bytes correctament formats)
                ldif += self.attr_ldif('accountStatus', 'disabled')

                # NOTE: Exemple: treure 'mail' de enabledService si fos necessari
                # (tot i que normalment es fa via llista filtrada)
                # ldif += self.attr_ldif('enabledService', ['internal', 'dovecot'])

            errors: dict[str, list[str]] = {}

            # NOTE: Add domain dn.
            try:
                self.conn.add_s(_dn, ldif)
            except ldap.LDAPError as e:
                log_traceback()
                return (False, repr(e))

            # NOTE: Afegim els grups per defecte sota el domini.
            if attrs.DEFAULT_GROUPS:
                for i in attrs.DEFAULT_GROUPS:
                    try:
                        group_dn = 'ou=' + str(i) + ',' + str(_dn)
                        group_ldif = self.ldif_group(str(i))

                        self.conn.add_s(group_dn, group_ldif)
                    except ldap.ALREADY_EXISTS:
                        pass
                    except Exception as e:
                        log_traceback()
                        errors[i] = repr(e)

            # NOTE: Si és un administrador de domini normal amb permís per crear un domini nou,
            # assign current admin as admin of this newly created domain.
            if session.get('create_new_domains'):
                qr = assign_admins_to_domain(admins=[session.get('username')])
                if not qr[0]:
                    errors[f"assign_admins_to_domain: {session.get('username')}"] = repr(qr[1])

            # NOTE: CREATE REQUIRED RFC ALIASES (postmaster, abuse)
            # Aquests dos àlies són obligatoris per RFC 5321 / RFC 2142,
            # i serveixen per garantir que qualsevol domini pugui rebre 
            # reclamacions d'abús, problemes postals, etc.
            required_aliases = ["postmaster", "abuse"]
            for localpart in required_aliases:
                alias_addr = f"{localpart}@{domain}"

                # NOTE: Verificar que no existeixi
                if self.is_email_exist(alias_addr):
                    continue
                # NOTE: DN: mail=postmaster@example.com,ou=Aliases,domainName=example.com,o=domains,dc=...
                dn_alias = f"mail={alias_addr},{self.rdn_value_to_ou_aliases_dn(domain)}"
                ldif_alias=self.ldif_alias(mail=alias_addr)
                ldif_alias.append(
                    ("mailForwardingAddress", iredutils.str2bytes([session.get("username")]))
                    )
                try:
                    self.conn.add_s(dn_alias, ldif_alias)
                except ldap.ALREADY_EXISTS:
                    pass
                except Exception as e:
                    log_traceback()
                    errors[f"alias_{localpart}"] = repr(e)

            if not errors:
                log_activity(event='create',
                    admin=session.get('username'),
                    domain=self.domain,
                    msg=f"New domain: {self.domain}."
                    )
                return (True, 'CREATED')
            return (False, repr(errors))

        def update(self, payload: Dict) -> Tuple[bool, str]:
            '''
                Actualitza el perfil del domini amb les dades enviades des d'un formulari web o API.
                :param payload: diccionari amb les dades del formulari.
            '''
            args, args_db, errors, mod_attrs = {}, {}, {}, []
            old_profile = {}
            current_account_settings = {}
            old_enabled_service = []
            old_disabled_mail_services = set()
            def _normalize_service_list(values) -> List[str]:
                if isinstance(values, str):
                    values = [v.strip() for v in values.split(",") if v.strip()]
                elif not isinstance(values, list):
                    values = []
                out = []
                for v in values:
                    s = str(v).strip().lower()
                    if s:
                        out.append(s)
                return out

            # NOTE: 1. Recuperem perfil actual (necessari per a comparacions)
            qr = self.get_profile(attributes=['accountStatus', 'accountSetting', 'enabledService'])
            if qr[0]:
                old_profile = qr[1]
                current_account_settings = self.account_setting_list_to_dict(old_profile.get('accountSetting', []) ) or {}
                old_enabled_service = old_profile.get('enabledService', []) or []
                old_disabled_mail_services = set(_normalize_service_list(current_account_settings.get('disabledMailService', [])))
            del qr

            # NOTE: 2. Processament d'atributs DIRECTES (LDAP/SQL)
            for k in ['cn', 'disclaimer', 'accountStatus', 'mtaTransport', 'domainBackupMX']:
                if k in payload:
                    val = payload[k]
                    # NOTE: Lògica específica: si canviem status, actualitzem sub-comptes
                    if k == 'accountStatus' and val != old_profile.get('accountStatus'):
                        qr = self.update_domain_status_for_all_accounts(self.domain, status=val)
                        if not qr[0]:
                            return qr
                    args[k] = val

            # NOTE: 3. Processament de SETTINGS (accountSetting)
            # Recollim tot el que ha d'anar al diccionari de configuracions
            # NOTE: Quan hi ha nous serveis desactivats al domini, es projecten
            # sobre els usuaris existents retirant-los d`enabledService`.
            as_keys = [
                'domainQuota', 'defaultQuota', 'maxUserQuota', 
                'defaultLanguage', 'timezone', 'numberOfUsers', 
                'numberOfLists', 'numberOfAliases', 'defaultList',
                'disabledUserPreference', 'disabledUserProfile', 
                'disabledMailService', 'disabledDomainProfile',
                'defaultRecipientBccAddress', 'defaultSenderBccAddress' 
            ]
            updates_in_as = False
            for k in as_keys:
                if k in payload:
                    # NOTE: Validació específica per a BCCs si cal
                    if k in ["defaultRecipientBccAddress", "defaultSenderBccAddress"]:
                        _addr = payload[k]
                        if _addr and not self.is_domain_exist(domain=_addr.split('@', 1)[-1]):
                            continue
                    current_account_settings[k] = payload[k]
                    updates_in_as = True

            # NOTE: Aplica nous serveis desactivats a usuaris existents (LDAP).
            new_disabled_mail_services = set(_normalize_service_list(current_account_settings.get('disabledMailService', [])))
            services_to_disable = sorted(new_disabled_mail_services - old_disabled_mail_services)
            if services_to_disable:
                try:
                    qr_users = self.conn.search_s(
                        self.rdn_value_to_ou_users_dn(self.domain),
                        ldap.SCOPE_ONELEVEL,
                        "(objectClass=mailUser)",
                        ['dn'],
                    )
                    for (dn_user, _ldif) in qr_users:
                        for srv in services_to_disable:
                            qr_rm = self.add_or_remove_enabled_service_by_dn(dn_user, srv, "remove")
                            if not qr_rm[0]:
                                errors.setdefault('disabledMailService', []).append(f'remove:{srv}:{qr_rm[1]}')
                except Exception as e:
                    errors.setdefault('disabledMailService', []).append(repr(e))

            # NOTE: 4. Serveis (enabledService)
            if 'enabledService' in payload:
                args['enabledService'] = payload['enabledService']

            # NOTE: 5. DB Settings (Passwd Lengths)
            if any(k in payload for k in ['min_passwd_length', 'max_passwd_length']):
                global_db_settings = iredutils.get_settings_from_db()
                for k in ['min_passwd_length', 'max_passwd_length']:
                    try:
                        _length = int(payload.get(k, 0))
                    except:
                        _length = 0

                    if _length > 0:
                        # NOTE: Assegurem que la configuració de domini no superi la configuració global.
                        if k == 'min_passwd_length':
                            # NOTE: No pot ser menor que el mínim global
                            _length = max(_length, global_db_settings.get('min_passwd_length', 0))
                        elif k == 'max_passwd_length':
                            # NOTE: No pot ser més gran que el màxim global ni menor que el mínim global
                            max_global = global_db_settings.get('max_passwd_length', 0)
                            min_global = global_db_settings.get('min_passwd_length', 0)
                            if max_global > 0:
                                _length = min(max(_length, min_global + 1), max_global)

                    args_db[k]=_length
                # NOTE: Validació addicional: assegurar consistència min <= max
                if 'min_passwd_length' in args_db and 'max_passwd_length' in args_db:
                    if args_db['min_passwd_length'] > args_db['max_passwd_length']:
                        args_db['max_passwd_length'] = args_db['min_passwd_length']

            # NOTE: 6. Mòduls (Greylist, Throttle, WBLister...)
            # Simplement mirem si el payload porta les claus que aquestes libs necessiten
            # bcc
            if any(k in payload for k in ['domainRecipientBccAddress', 'domainSenderBccAddress']):
                new_enabled = set(args.get('enabledService', old_enabled_service))
                for k in ["domainRecipientBccAddress", "domainSenderBccAddress"]:
                    if k in payload:
                        _addr = payload[k]
                        args[k] = _addr if (_addr and self.is_email_exist(_addr)) else ""
                        # NOTE: Actualitzem serveis segons si hi ha adreça o no
                        svc = "recipientbcc" if k == "domainRecipientBccAddress" else "senderbcc"
                        if args[k]: new_enabled.add(svc)
                        else: new_enabled.discard(svc)
                args["enabledService"] = list(sorted(new_enabled))
            # NOTE: relay
            if any(k in payload for k in ['mtaTransport', 'relay_without_verify_local_recipient']):
                mta = payload.get('mtaTransport', '')
                args['mtaTransport'] = mta
                if mta.startswith('relay:'):
                    args['domainBackupMX']='yes'
                elif payload.get('relay_without_verify_local_recipient') == 'active':
                    if mta.startswith('smtp:') or mta.startswith('uucp:') or mta.startswith(':'):
                        args['domainBackupMX']='yes'
                    else:
                        args['domainBackupMX'] = ''
                else:
                    args['domainBackupMX'] = ''
                args['senderRelayHost'] = payload.get('senderRelayHost', '')
            # NOTE: 'catchall'
            if any(k in payload for k in ['mailForwardingAddress']):
                '''
                    On es defineixen les adreces catch-all a LDAP
                    Segons la documentació oficial d’iRedMail:
                    Es crea una entrada LDAP amb l’atribut mail igual al domini (ex: example.com).
                    Es defineix l’atribut mailForwardingAddress amb les bústies que rebran el correu catch-all.
                    Exemple d’entrada LDAP:
                    ldif
                    dn: mail=example.com,ou=Aliases,domainName=example.com,o=domains,dc=iredmail,dc=org
                    objectClass: mailAlias
                    objectClass: top
                    mail: example.com
                    mailForwardingAddress: user1@example.com
                    mailForwardingAddress: user2@example.com
                    🔍 Notes importants
                    Les adreces user1@example.com i user2@example.com han d’existir com a comptes reals.
                    Aquesta configuració fa que qualsevol correu enviat a qualsevol@exemple.com que no coincideixi amb una bústia existent es redirigeixi a les adreces definides.
                    Si fas servir iRedAdmin-Pro, pots gestionar-ho des de la interfície gràfica del perfil de domini.
                    
                    ✔ Catch-all del domini = ÚNICA entrada LDAP amb objectClass=mailAlias, mail=domini i mailForwardingAddress=…
                    ✔ domainAliasName = alias del domini → permet que tots els usuaris del domini rebin també a @alias.com
                    ✔ domainAliasName genera automàticament shadowAddress a tots els usuaris del domini
                    ✔ shadowAddress = alias individual de cada usuari → usuari@alias.com

                    
                    👉 domainAliasName afecta només els usuaris.
                    👉 catch-all afecta només adreces sense bústia.
                    👉 són subsistemes completament separats.
                '''
                forwards = utils._normalize_list_mails(payload.get("mailForwardingAddress"))
                valid = [addr for addr in forwards if self.is_email_exist(addr)]
                ok_c, msg_c, *rest = self.update_catchall_addresses(valid)
                if not ok_c: errors['catchall'] = msg_c
            # NOTE: 'aliases'
            if any(k in payload for k in ['domainalias', 'domainAliasName']):
                domainalias = payload.get('domainalias')
                if domainalias == 'disabled':
                    args["enabledService"] = [ x for x in old_enabled_service if x != "domainalias"]
                elif domainalias == 'active':
                    args['enabledService'] = list({*old_enabled_service, "domainalias"})

                if payload.get('domainAliasName'):
                    args['domainAliasName'] = utils._normalize_list_domains(payload['domainAliasName']["add"])
                    qr_alias = self.update_domain_alias_for_all_accounts(self.dn_domain, args['domainAliasName'])
                    if not qr_alias[0]: errors['aliases'] = qr_alias[1]
            # NOTE: 'backupmx'
            if any(k in payload for k in ['domainBackupMX']):
                if payload.get("domainBackupMX") == "active" and payload.get("primary_mx"):
                    args["domainBackupMX"] = "yes"
                    args["mtaTransport"] = f"relay:{payload['primary_mx']}"
                else:
                    args["domainBackupMX"] = ""
                    args["mtaTransport"] = "dovecot"
            # NOTE: throttle
            if any(k in payload for k in ['throttle_inb', 'throttle_out']):
                _account = f'@{self.domain}'

                def _apply_throttle(direction_key, direction_enum):
                    if payload.get(direction_key):
                        throttle = lib_throttle.Throttle(_account, payload[direction_key], direction_enum)
                        ok, msg, *rest = throttle.update_throttle_settings()
                        action = "updating"
                    else:
                        throttle = lib_throttle.Throttle(_account, {}, direction_enum)
                        throttle.remove_throttle_tracking()
                        ok, msg, *rest = throttle.remove_throttle_settings()
                        action = "removing"

                    if not ok:
                        errors.setdefault('throttle', []).append(
                            f"⚠️ Error {action} throttle {direction_enum.value} for {_account}: {msg}"
                        )
                # NOTE: Executar per INBOUND i OUTBOUND
                _apply_throttle('throttle_inb', Direction.INBOUND)
                _apply_throttle('throttle_out', Direction.OUTBOUND)
            # NOTE: greylist
            if any(k in payload for k in ['whitelists','whitelist_domains','rdns_whitelist','rdns_blacklist','greylisting']):
                _account = f'@{self.domain}'
                ok, msg, *rest = lib_greylist.update_greylisting(account=_account, payload=payload)
                if not ok:
                    errors.setdefault('greylist', []).append(
                        f"⚠️ Error update_greylisting for {_account}: {msg}"
                    )
            # NOTE: 'wblist'
            if any(k in payload for k in ['whitelistSender','blacklistSender','whitelistRecipient','blacklistRecipient']):
                _account = f'@{self.domain}'
                ok, msg , *rest = lib_wblist.update_wblist(_account, payload)
                if not ok:
                    errors.setdefault('wblist', []).append(
                        f"⚠️ Error update_wblist for {_account}: {msg}"
                    )                    
            # NOTE: 'spampolicy'
            if any(k in payload for k in [
                'policy_name',
                'effectivebypriority',
                'enable_spam_checks',
                'enable_virus_checks',
                'enable_banned_checks',
                'enable_header_checks',
                'quarantine_spam',
                'quarantine_virus',
                'quarantine_banned',
                'quarantine_bad_header',
                'prefix_spam_in_subject',
                'always_insert_x_spam_headers',
                'spam_score',
                'spam_kill_level',
                'spam_tag_level',
                'banned_rulenames',
                'message_size_limit',
                ]): 
                _account = f'@{self.domain}'
                ok, msg , *rest = lib_spampolicy.SpamPolicy(account=_account).update_spam_policy(payload)
                if not ok:
                    errors.setdefault('spampolicy', []).append(
                        f"⚠️ Error update_spam_policy for {_account}: {msg}"
                    )

            # NOTE: 7. Verificació de propietat (Ownership)
            # aquí enforced `accountStatus=disabled` i
            # eliminació de servei `mail` quan el domini no està verificat.
            # La reactivació final depèn del flux de `DomainOwnershipManager`.
            if settings.REQUIRE_DOMAIN_OWNERSHIP_VERIFICATION:
                from libs.m_system.domain_ownership import is_single_domain_verified
                if not is_single_domain_verified(self.domain):
                    # NOTE: si s'intenta activar, rebutgem
                    if args.get('accountStatus') == 'active':
                        return (False, 'DOMAIN_NOT_VERIFIED') 
                    # NOTE: treure mail, payload ja porta enabledService? si no, recuperar des del perfil existent
                    args['enabledService'] = [x for x in args.get('enabledService', old_enabled_service) if x != 'mail']
                    # NOTE: posar compte desactivat
                    args['accountStatus'] = 'disabled'
                    qr_user_status = self.update_domain_status_for_all_accounts(self.domain, status=args["accountStatus"])
                    if not qr_user_status[0]: errors['domain_ownership'] = qr_user_status[1]

            # NOTE: 8. EMPAQUETAR PER A LDAP
            if updates_in_as:
                args['accountSetting'] = self.account_setting_dict_to_list(current_account_settings)

            for k, v in args.items():
                mod_attrs += self.mod_replace(k, v)

            # NOTE: 9. EXECUCIÓ FINAL
            if mod_attrs:
                try:
                    self.conn.modify_s(self.dn_domain, mod_attrs)
                except Exception as e:
                    log_traceback()
                    errors['modify_s'] = repr(e)

            if args_db:
                if any(v == 0 for v in args_db.values()):
                    try:
                        self.conn_iredadmin.delete(
                            "settings",
                            vars={"account": self.domain},
                            where="account=$account"
                        )
                    except Exception as e:
                        errors['store_settings_in_db'] = repr(e)
                else:
                    qr_db = iredutils.store_settings_in_db(args_db, account=self.domain, flush=True)
                    if not qr_db[0]:
                        errors['store_settings_in_db'] = qr_db[1]

            if not errors :
                log_activity(event='update',
                    admin=session.get('username'),
                    domain=self.domain,
                    msg=f"Update domain profile: {self.domain}."
                    )
                return (True, "UPDATED")

            return (False, errors)

        def delete(self, domain:str=None, keep_mailbox_days:int = 0) -> Tuple[bool, Union[str, None]]:
            errors: List[str] = []
            deleted_mailboxes = []
            if not domain:
                return (False, "NO_DOMAIN_SELECTED")

            dn_domain = self.rdn_value_to_domain_dn(domain)
            try:
                qr_del_quota = self.conn.search_s(
                        self.rdn_value_to_ou_users_dn(domain),
                        ldap.SCOPE_ONELEVEL,
                        "(objectClass=mailUser)",
                        ['mail', 'homeDirectory'])
            except Exception as e:
                log_traceback()
                errors.append(f"LDAP search failed for {domain}: {e!r}")

            sql_keep_days = None
            if keep_mailbox_days > 0:
                # NOTE: Converteix els dies de conservació a cadena
                expiry = datetime.now() + timedelta(days=keep_mailbox_days)
                sql_keep_days = expiry.strftime("%Y-%m-%d") # NOTE: expiry.strftime("%Y-%m-%d %H:%M:%S")

            for (_dn, _ldif) in qr_del_quota:
                _ldif = iredutils.bytes2str(_ldif) # NOTE: pendent revisar si necessari
                del_maildir = _ldif.get('homeDirectory', [''])[0]
                del_mail = _ldif.get('mail')[0]

                if del_mail:
                    deleted_mailboxes.append({
                        'maildir': del_maildir,
                        'username': del_mail,
                        'domain': domain,
                        'admin': session.get('username') if session else None,
                        'delete_date': sql_keep_days
                    })

            if deleted_mailboxes:
                try:
                    self.conn_iredadmin.multiple_insert('deleted_mailboxes', values=deleted_mailboxes)
                except Exception as e:
                    errors.append(f"SQL insert failed for {domain}: {e!r}")

            # NOTE: Elimina l'objecte de domini i les seves fulles.
            qr_del = self.subtree_delete_by_dn(dn_domain)
            if not qr_del[0]:
                errors.append(f'delete -> .profile_delete_by_dn failed for {domain}: {qr_del[1]}')

            log_activity(event='delete',
                admin=session.get('username'),
                domain=domain,
                msg=f"Delete domain: {domain} (mailboxes={len(deleted_mailboxes)})."
                )

            qr_del_quota = self.delete_domain_used_quota(domain)
            if not qr_del_quota[0]:
                errors.append(f'delete -> .delete_domain_used_quota:{domain} ={qr_del_quota[1]}')

            qr_purge_ownership = self.delete_domain_ownership(domain)
            if not qr_purge_ownership[0]:
                errors.append(f"delete -> .purge_domain_ownership:{domain}={qr_purge_ownership[1]}")

            if errors:
                return (False, "; ".join(errors))
            return (True, )    

        def delete_domains(self, domains: List=None, keep_mailbox_days:int=0) -> Tuple[bool, Union[str, None]]:
            """
                Elimina els dominis indicats, opcionalment, 
                conserva totes les bústies de correu durant els dies especificats.

                :param domains: una llista/tupla/conjunt de noms de dominis de correu.
                :param keep_mailbox_days: conserva les bústies de correu dels dominis eliminats durant els dies indicats. 0 significa per sempre (en realitat, es conserven durant 100 anys).
            """

            if not (domains and isinstance(domains, (list, tuple, set))):
                return (False, 'NO_DOMAIN_SELECTED')

            domains = [str(d).lower() for d in domains if self.is_domain(d)]
            if not domains:
                return (False, 'INVALID_DOMAIN_NAME' )

            errors: List[str] = []

            for _d in domains:
                qr = self.delete(_d, keep_mailbox_days)
                if not qr[0]:
                    errors.append(f'delete_domains:{_d}={qr[1]}')

            if errors:
                return (False, repr(errors))
            return (True, 'DELETED')

        def enable_disable_domains(self, values, action):
            return self.enable_disable_accounts(values, action, 'domain')


        def get_domain_account_settings(self):
            accs = self._get_domain_account_settings(self.domain, profile=None)
            if accs is False:
                return (False, 'FAILED_TO_GET_DOMAIN_SETTINGS')
            if not isinstance(accs, dict):
                return (False, 'INVALID_DOMAIN_SETTINGS')
            return (True, accs)

        def get_filtered_account_setting(self, key):
            # NOTE: Solventat: implementació comuna pujada a DomainBasic.
            return super().get_filtered_account_setting(key)


        def get_catchall_addresses(self):
            """
                Retorna la llista d'adreces mailForwardingAddress de l'entrada catch-all.
                Si no existeix la entrada mail=domain, retorna [].
            """
            dn_catchall = f"mail={self.domain},{self.rdn_value_to_ou_aliases_dn(self.domain)}"
            search_attr = ["mailForwardingAddress"]
            ok, profile, *rest = self.profile_get_by_dn(dn_catchall, attributes=search_attr,raw=True)
            if ok:
                return ok, profile['ldif']
            return ok, profile

        @LibDecorators.safe_ldap_method
        def update_catchall_addresses(self, addresses: List[str]) -> Tuple[bool, str]:
            """
                Actualitza les adreces catch-all per al domini.
                addresses = [] → Esborra l'entrada catch-all.
            """
            dn_catchall = f"mail={self.domain},{self.rdn_value_to_ou_aliases_dn(self.domain)}"

            # NOTE: Si la llista està buida → esborrem l'entrada catch-all
            if not addresses:
                try:
                    self.conn.delete_s(dn_catchall)
                except ldap.NO_SUCH_OBJECT:
                    pass
                return (True, "CATCHALL_REMOVED")

            # NOTE: Si hi ha adreces, cal assegurar que existeix l'entrada
            exists = False
            try:
                self.conn.search_s(dn_catchall, ldap.SCOPE_BASE)
                exists = True
            except ldap.NO_SUCH_OBJECT:
                exists = False

            # NOTE: Crear entrada si no existeix
            if not exists:
                ldif = self.ldif_alias(mail=self.domain)
                self.conn.add_s(dn_catchall, ldif)

            self.conn.modify_s(
                dn_catchall, 
                self.mod_replace("mailForwardingAddress", addresses)
                )

            return (True, "UPDATED")

        @LibDecorators.safe_ldap_method
        def get_domain_aliases(self) -> Tuple[bool, List[str]]:
            """
                Retorna els alias del domini en format homogeni amb SQL:
                (True, [alias1, alias2, ...])
            """
            qr = self.get_profile(attributes=['domainAliasName'])
            if not qr[0]:
                return qr

            raw_aliases = qr[1].get('domainAliasName', [])
            if isinstance(raw_aliases, str):
                raw_aliases = [raw_aliases]
            elif not isinstance(raw_aliases, list):
                raw_aliases = []

            aliases = []
            for item in raw_aliases:
                alias = str(item).strip().lower()
                if not alias or alias == self.domain:
                    continue
                if self.is_domain(alias):
                    aliases.append(alias)

            return (True, sorted(set(aliases)))

        @LibDecorators.safe_ldap_method
        def set_domain_alias_status(self, alias_domain: str, active: bool = True) -> Tuple[bool, str]:
            # NOTE: En LDAP no hi ha estat separat per a `alias_domain` com en SQL.
            # NOTE: L'alias viu a `domainAliasName`, així que mantenim API homogènia com a no-op.
            alias = str(alias_domain or '').strip().lower()
            if not self.is_domain(alias):
                return (False, 'INVALID_ALIAS_DOMAIN')
            return (True, 'NOOP')


        @LibDecorators.safe_ldap_method(no_tuple=True)
        def _num_accounts_under_domain_helper(self,
                                        account_type='user',
                                        increase=False,
                                        decrease=False,
                                        step_number=1):
            '''
            Get number of accounts under specified domain.
            
            :param account_type: one of `user`, `maillist`, `alias`.
            '''
            if not self.domain:
                return (False, 'INVALID_DOMAIN_NAME')
            if not isinstance(step_number, int) or step_number <= 0:
                step_number = 1

            attr_map = {
                'user': {
                    'attr':'domainCurrentUserNumber',
                    # 'filter':f'(&(objectClass=mailUser)(!(mail=@{self.domain})))'
                    'filter':f'(&(objectClass=mailUser)(mail=*@{self.domain}))'
                    },
                'maillist': {
                    'attr':'domainCurrentListNumber',
                    'filter': f'(&(objectClass=mailList)(mail=*@{self.domain}))'
                    },
                'alias': {
                    'attr':'domainCurrentAliasNumber',
                    # 'filter':f'(&(objectClass=mailDomain)(domainName={self.domain}))'
                    'filter':f'(&(objectClass=mailAlias)(mail=*@{self.domain}))'
                    },
            }
            if account_type not in attr_map:
                return (False, 'INVALID_ACCOUNT_TYPE')

            statistics_attr = attr_map[account_type]['attr']
            search_filter = attr_map[account_type]['filter']

            if not increase and not decrease: 
                qr = self.conn.search_s(
                    self.dn_domain,
                    ldap.SCOPE_SUBTREE,
                    search_filter,
                    ['dn'])
                return len(qr)

            qr = self.conn.search_s(
                self.dn_domain,
                ldap.SCOPE_BASE,
                f'(&(objectClass=mailDomain)(domainName={self.domain}))',
                [statistics_attr])

            if not qr:
                current = 0
            else:
                stats = qr[0][1] or {}
                raw_values = stats.get(statistics_attr) or []
                if raw_values:
                    try:
                        current = int(raw_values[0])
                    except (TypeError, ValueError):
                        current = 0
                else:
                    current = 0

            if increase:
                new_value = current + step_number
            elif decrease:
                new_value = max(current - step_number, 0)

            self.update_attr_with_single_value_by_dn(
                dn=self.dn_domain,
                attr=statistics_attr,
                value=new_value)

            return new_value

        def num_users_under_domain(self, increase=False, decrease=False, step_number=1):
            return self._num_accounts_under_domain_helper(account_type='user', increase=increase, decrease=decrease, step_number=step_number)

        def num_maillists_under_domain(self, increase=False, decrease=False, step_number=1):
            return self._num_accounts_under_domain_helper(account_type='maillist', increase=increase, decrease=decrease, step_number=step_number)

else:
    raise RuntimeError(f"Backend not supported: {settings.backend}")
