#!/usr/bin/python3
# -*- coding: utf-8 -*-

import os
import sys

# # Executa la sincronització cada 5 minuts
# sudo crontab -e
# */5 * * * * /usr/bin/python3 /opt/www/iredadmin/libs/m_fail2ban/sync_f2b.py > /dev/null 2>&1

# Afegim l'arrel de iredadmin al path per poder importar les libs
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))

from libs.m_fail2ban.fail2ban import F2BManager
from libs.logger import log_error

def main():
    try:
        # NOTE: Executem la sincronització amb lockfile integrat al manager.
        manager = F2BManager()
        result = manager.sync_banned_to_db_with_lock()

        if result and not result.get("locked"):
            print(f"Sincronització completada: +{result['added']} nous, -{result['removed']} eliminats.")

    except Exception as e:
        log_error(f"Error en la sincronització programada de Fail2Ban: {e}")

if __name__ == "__main__":
    main()
