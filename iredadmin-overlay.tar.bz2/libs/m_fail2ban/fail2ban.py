# NOTE: libs/m_fail2ban/fail2ban.py
import web
import os
import subprocess
import re
import base64
import binascii
import datetime
import time
from typing import List, Dict, Optional, Any

from libs.logger import log_traceback
import settings

try:
    import geoip2.database as geoip2_database
except ImportError:
    geoip2_database = None

from libs.m_fail2ban import WarpF2B
from libs.m_system.decorators import LibDecorators
from libs.m_system.mixins import SQLWhereBuilder, PaginationMixin

FAIL2BAN_LOG = "/var/log/fail2ban.log"
GEOIP_COUNTRY_DB = os.path.join(os.path.dirname(__file__), "GeoLite2-Country.mmdb")
GEOIP_ASN_DB = os.path.join(os.path.dirname(__file__), "GeoLite2-ASN.mmdb")

class F2BRuntime:
    def __init__(self):
        self.bin = "/usr/bin/fail2ban-client"

    def _call(self, args):
        cmd = ["sudo", self.bin] + args
        return subprocess.check_output(cmd, text=True).strip()

    def get_runtime_jails(self):
        out = self._call(["status"])
        return [j.strip() for j in out.split(":")[-1].split(",")]

    def get_banned_ips(self, jail):
        raw = self._call(["get", jail, "banned"])
        # Netejar: treure cometes, claudàtors, espais
        cleaned = raw.replace("'", "").strip("[]").strip()
        if not cleaned:
            return []
        return [ip.strip() for ip in cleaned.split(", ") if ip.strip()]
    
    def jail_start(self, jail: str) -> bool:
        self._call(["reload", "--if-exists", jail])
        return True

    def jail_stop(self, jail: str) -> bool:
        self._call(["stop", jail])
        return True

class GeoService:
    def __init__(self):
        # NOTE: geoip2 és opcional en entorns lab; mantenim funcionals les pàgines de fail2ban
        #fins i tot quan falten les bases GeoIP o el mòdul de Python.
        if geoip2_database is None:
            self.reader = None
            self.asn_reader = None
            return

        try:
            self.reader = geoip2_database.Reader(GEOIP_COUNTRY_DB)
        except Exception:
            self.reader = None

        try:
            self.asn_reader = geoip2_database.Reader(GEOIP_ASN_DB)
        except Exception:
            self.asn_reader = None

    def get_country(self, ip):
        if not self.reader: return "XX"
        try:
            return self.reader.country(ip).country.iso_code
        except:
            return "??"

    def get_asn_info(self, ip):
        if not self.asn_reader: return ""
        try:
            res = self.asn_reader.asn(ip)
            return f"AS{res.autonomous_system_number} ({res.autonomous_system_organization})"
        except:
            return ""

class F2BManager(WarpF2B, PaginationMixin):
    def __init__(self, jail=None):
        super().__init__()
        self.system = F2BRuntime()
        self.geo = GeoService()
        self.jail = jail
        self.logfile = FAIL2BAN_LOG

    def _normalize_pagination(self, page=1, page_size=None):
        page = self.normalize_current_page(current_page=page, default=1, min_page=1)
        page_size = self.normalize_page_size(
            page_size=page_size,
            default=settings.PAGE_SIZE_LIMIT,
            min_size=1,
        )
        offset = self.get_page_offset(current_page=page, page_size=page_size)
        return page, page_size, offset

    def _normalize_banned_filters(self, payload: Optional[Dict] = None) -> Dict[str, str]:
        payload = payload or {}
        query = str(payload.get("query_string") or "").strip()
        date_from = str(payload.get("date_from") or "").strip()

        if date_from:
            try:
                datetime.datetime.strptime(date_from, "%Y-%m-%d")
            except Exception:
                date_from = ""

        return {
            "query_string": query,
            "date_from": date_from,
        }

    def _build_banned_where(self, payload: Optional[Dict] = None):
        filters = self._normalize_banned_filters(payload=payload)

        # NOTE: 🧱 Construcció de la clàusula WHERE
        builder = SQLWhereBuilder()
        builder.add_equals("remove", 0)

        # NOTE: Filtre per text lliure (IP, Host, País, Jail)
        if filters["query_string"]:
            search_val = f"%{filters['query_string'].lower()}%"
            # # @TODO Afegim 'asn' si ja hem creat la columna
            # builder.add_or_like(["ip", "hostname", "country", "jail", "asn"], search_val)
            builder.add_or_like(["ip", "hostname", "country", "jail"], search_val)

        # NOTE: Filtre per data d'inici
        if filters["date_from"]:
            builder.add("timestamp >= $start_date", "start_date", f"{filters['date_from']} 00:00:00")

        where_clause, sql_vars = builder.build()
        return where_clause, sql_vars, filters

    def _get_log_context(self, ip, jail, lines_count=15):
        """
        Recupera les darreres línies del log on apareix la IP i el Jail.
        Útil per omplir la columna 'loglines' de la taula de iRedMail.
        Si Linux estàs usant Journald,si el fitxer /var/log/fail2ban.log 
        no tingués prou informació, podries fer un "fallback" al journalctl
        """
        out = ""
        # NOTE: Intent prioritari: el log de fail2ban (sense shell=True, evitem injecció)
        try:
            # Pattern segur: usem re.escape per si jail o ip tenen caràcters especials
            pattern = rf"\[{re.escape(jail)}\].*{re.escape(ip)}"
            cmd = ["grep", "-E", pattern, self.logfile]
            result = subprocess.run(
                cmd, capture_output=True, text=True, timeout=10
            )
            out = "\n".join(result.stdout.strip().splitlines()[-lines_count:])
        except Exception:
            log_traceback()

        # NOTE: Fallback a journalctl si el log està buit
        if not out:
            try:
                cmd = [
                    "journalctl",
                    "_SYSTEMD_UNIT=sshd.service",
                    "--grep", str(ip),
                    "-n", str(lines_count),
                    "--no-pager",
                ]
                result = subprocess.run(
                    cmd, capture_output=True, text=True, timeout=10
                )
                out = result.stdout.strip()
            except Exception:
                log_traceback()

        return out

    def _parse_jail_status(self, jail_name):
        out = self.system._call(["status", jail_name])
        data = {}
        # NOTE: Busquem els números amb regex per no dependre de si hi ha ":" o " "
        pairs = {
            "currently_banned": r"Currently banned:\s+(\d+)",
            "total_banned": r"Total banned:\s+(\d+)",
            "currently_failed": r"Currently failed:\s+(\d+)",
            "total_failed": r"Total failed:\s+(\d+)"
        }

        for key, pattern in pairs.items():
            match = re.search(pattern, out)
            data[key] = int(match.group(1)) if match else 0
            
        file_match = re.search(r"File list:\s+(.*)", out)
        if file_match:
            data["log_files"] = file_match.group(1).strip().split()
            
        return data

    def _ensure_jail_row(self, jail_name: str):
        existing = self.db.select("jails", what="id", where="name=$n", vars={"n": jail_name}, limit=1)
        if not existing:
            self.db.insert("jails", name=jail_name, enabled=0)

    @LibDecorators.safe_sql_method(no_tuple=True)
    def _add_ban_to_db(self, ip, jail):
        """
        Afegeix una IP nova o recupera dades per a una existent.
        per ASN cal modificar la taula(SQL)
        ALTER TABLE banned ADD COLUMN asn VARCHAR(255) DEFAULT NULL AFTER country;
        """
        # NOTE: Obtenir context del log
        log_context = self._get_log_context(ip, jail)
        # NOTE: Codifiquem el log a Base64
        if log_context:
            # NOTE: Convertim string a bytes -> base64 -> string per a SQL
            log_b64 = base64.b64encode(log_context.encode('utf-8')).decode('utf-8')
        else:
            log_b64 = ""

        country = self.geo.get_country(ip)
        # # @TODO: pendent: Descomentar quan la columna ASN estigui creada
        # # asn_info = self.geo.get_asn_info(ip)

        # # NOTE: Intentem trobar si ja existeix (per fer update en lloc d'insert si cal)
        # # Però el teu sync ja gestiona l'update per a les existents amb remove=1.
        # # Aquest mètode només l'usarem per a IPs realment NOVES a la taula.
        # return self.db.insert(
        #     "banned",
        #     ip=ip,
        #     jail=jail,
        #     loglines=log_b64,
        #     country=country,
        #     #asn=asn_info,
        #     failures=0,
        #     protocol='tcp',
        #     ports='all',
        #     remove=0,
        #     timestamp=web.SQLLiteral('NOW()')
        # )
        self.db.query(
            """
            INSERT INTO banned
                (ip, ports, protocol, jail, country, failures, loglines, remove, timestamp)
            VALUES
                ($ip, 'all', 'tcp', $jail, $country, 0, $loglines, 0, NOW())
            ON DUPLICATE KEY UPDATE
                jail = VALUES(jail),
                country = VALUES(country),
                loglines = VALUES(loglines),
                remove = 0,
                timestamp = NOW()
            """,
            vars={
                'ip': ip,
                'jail': jail,
                'country': country,
                'loglines': log_b64,
            }
        )

    @LibDecorators.safe_sql_method(no_tuple=True)
    def sync_jails_to_db(self):
        """
            Sincronitza quins jails estan actius al runtime i actualitza la taula 'jails'.
        """
        runtime_active = self.system.get_runtime_jails()

        # NOTE: Posem tots a disabled=0 primer (o podríem fer-ho un a un)
        self.db.update("jails", enabled=0, where="1=1")

        for j_name in runtime_active:
            # NOTE: Si el jail existeix a la BD, posem enabled=1
            # NOTE: Si no existeix, el podríem insertar aquí
            self.db.update("jails", 
                            enabled=1, 
                            where="name=$n", 
                            vars={'n': j_name})
        return True

    @LibDecorators.safe_sql_method(no_tuple=True)
    def sync_all_defined_jails_to_db(self):
        """
            Executa 'fail2ban-client -d' per trobar TOTS els jails definits al sistema.
            Alimenta la taula 'jails' de SQL.
        """
        out = self.system._call(["-d"])
        
        # NOTE: Compatibilitat amb sortides antigues i noves de fail2ban-client -d.
        found_jails = set(re.findall(r"jail '([^']+)'", out))
        found_jails.update(re.findall(r"\['add', '([^']+)', '[^']+'\]", out))
        
        # NOTE: NETEJA CRÍTICA:
        # 1. strip() per treure espais
        # 2. Comprovar que j no sigui buit
        # 3. set() per evitar duplicats
        defined_jails = set()
        for j in found_jails:
            name = j.strip()
            if name and name != "None": # NOTE: Fail2ban a vegades escup 'None'
                defined_jails.add(name)

        # NOTE: Abans d'insertar, netegem la porqueria que ja hi hagi a la DB
        self.db.delete("jails", where="name = '' OR name IS NULL")
        db_jails = {row.name for row in self.db.select("jails")}

        stale_jails = db_jails - defined_jails
        if stale_jails:
            self.db.delete("jails", where="name IN $names", vars={"names": list(stale_jails)})
            db_jails -= stale_jails
        
        for j_name in defined_jails:
            if j_name not in db_jails:
                self.db.insert("jails", name=j_name, enabled=0)
                
        self.sync_jails_to_db()
        return True

    @LibDecorators.safe_sql_method(no_tuple=True)
    def sync_banned_to_db(self):
        # 1. Obtenir l'estat del runtime
        jails = self.system.get_runtime_jails()
        
        # runtime_bans: dict { (ip, ports, protocol): jail }
        # La clau és el que MySQL considera únic, el valor és el jail (per si cal)
        runtime_bans = {}
        for j in jails:
            for ip in self.system.get_banned_ips(j):
                key = (ip, 'all', 'tcp')
                # Si la mateixa IP està a dos jails, ens quedem amb el primer
                # (o podries prioritzar un jail concret)
                if key not in runtime_bans:
                    runtime_bans[key] = j

        # 2. Obtenir l'estat de la BD
        db_records = self.db.select("banned")
        # db_bans: dict { (ip, ports, protocol): (id, jail, remove) }
        db_bans = {
            (r.ip, r.ports, r.protocol): (r.id, r.jail, r.remove)
            for r in db_records
        }

        # 3. ACCIÓ A: IPs al runtime que no estan actives a la BD
        count_added = 0
        for key, jail in runtime_bans.items():
            ip, ports, protocol = key
            if key in db_bans:
                db_id, db_jail, db_remove = db_bans[key]
                if db_remove == 1:
                    # Existia però estava marcada com a eliminada → reactivar
                    self.db.update(
                        "banned",
                        where="id=$id",
                        vars={'id': db_id},
                        remove=0,
                        jail=jail,          # actualitzem el jail al runtime actual
                        timestamp=web.SQLLiteral('NOW()'),
                    )
            else:
                # IP nova → inserir
                self._add_ban_to_db(ip, jail)
            count_added += 1

        # 4. ACCIÓ B: IPs a la BD actives que ja no estan al runtime
        count_removed = 0
        for key, (db_id, db_jail, db_remove) in db_bans.items():
            if db_remove == 0 and key not in runtime_bans:
                self.db.update(
                    "banned",
                    where="id=$id",
                    vars={'id': db_id},
                    remove=1,
                )
                count_removed += 1

        return {"added": count_added, "removed": count_removed}

    def sync_banned_to_db_with_lock(self, lock_file: str = "/tmp/iredadmin_f2b_sync.lock", stale_seconds: int = 600):
        """
            Sincronitza bans amb lockfile per evitar execucions simultànies des de cron.
            Si hi ha lock recent, no executa i retorna estat de lock.
        """
        try:
            stale_seconds = max(int(stale_seconds or 0), 1)
        except (TypeError, ValueError):
            stale_seconds = 600

        if os.path.exists(lock_file):
            if (time.time() - os.path.getmtime(lock_file)) < stale_seconds:
                return {"locked": True, "added": 0, "removed": 0}

        try:
            with open(lock_file, "w") as f:
                f.write(str(os.getpid()))

            result = self.sync_banned_to_db()
            if isinstance(result, dict):
                result["locked"] = False
                return result

            return {"locked": False, "added": 0, "removed": 0}
        finally:
            if os.path.exists(lock_file):
                os.remove(lock_file)

    @LibDecorators.safe_sql_method(no_tuple=True)
    def list_banned(self, page=1, page_size=None, payload=None):
        """
            Ara list_banned és molt més ràpid perquè només llegeix la taula.
            Podem cridar a sync_runtime_to_db() abans si volem dades en temps real,
            o fer-ho mitjançant un cron/task separat.
        """
        self.sync_banned_to_db()
        page, page_size, offset = self._normalize_pagination(page=page, page_size=page_size)
        where_clause, sql_vars, filters = self._build_banned_where(payload=payload)

        # NOTE: Obtenim els ítems filtrats
        items = self.db.select(
            "banned",
            where=where_clause,
            vars=sql_vars,
            order="timestamp DESC",
            limit=page_size,
            offset=offset
        )

        # NOTE: Comptem el total per a la paginació (mantenint els filtres!)
        total_res = self.db.query(
            f"SELECT COUNT(*) as count FROM banned WHERE {where_clause}",
            vars=sql_vars
        )
        total = total_res[0].count if total_res else 0

        return {
            "total": total,
            "page": page,
            "page_size": page_size,
            "pages": self.get_total_pages(total=total, size_limit=page_size),
            "items": list(items),
            "filters": filters,
        }

    @LibDecorators.safe_sql_method(no_tuple=True)
    def list_jails(self, page=1, page_size=None ):
        """
            Llegeix la taula 'jails' de SQL i, per als que estan actius, 
            demana la info extra al runtime.
        """
        page, page_size, offset = self._normalize_pagination(page=page, page_size=page_size)

        # NOTE: 1. Sincronitzem l'estat d'activació abans de llegir
        self.sync_all_defined_jails_to_db()

        # NOTE: 2. Consulta paginada
        db_jails = self.db.select(
            "jails", 
            order="name ASC", 
            limit=page_size, 
            offset=offset
        )

        # NOTE: 3. Comptador total per a la paginació
        total_res = self.db.query("SELECT COUNT(*) as count FROM jails")
        total = total_res[0].count if total_res else 0

        result = []
        for row in db_jails:
            info = {
                "name": row.name,
                "enabled": bool(row.enabled),
                "currently_banned": 0, "total_banned": 0,
                "currently_failed": 0, "total_failed": 0,
                "log_files": [], "backend": ""
            }
            if row.enabled:
                try:
                    # NOTE: Això fa crides a sistema, si falla ho capturem localment 
                    # o deixem que el decorador ho capturi tot (però llavors no veuriem el jail)
                    status = self._parse_jail_status(row.name)
                    info.update(status)
                except:
                    info["enabled"] = False
            result.append(info)
        return {
            "items": result,
            "total": total,
            "page": page,
            "page_size": page_size,
            "pages": self.get_total_pages(total=total, size_limit=page_size),
        }

    @LibDecorators.safe_sql_method(no_tuple=True)
    def enable_jail(self, jails: List[str]) -> bool:
        """
            Activa una llista de jails al runtime i actualitza la SQL.
        """
        errors = False
        for jail in jails:
            try:
                self._ensure_jail_row(jail)
                # NOTE: 1. Runtime
                self.system.jail_start(jail)
                # NOTE: 2. SQL
                self.db.update("jails", where="name=$n", vars={'n': jail}, enabled=1)
            except Exception as e:
                log_traceback()
                errors = True
        return not errors

    @LibDecorators.safe_sql_method(no_tuple=True)
    def disable_jail(self, jails: List[str]) -> bool:
        """
            Atura una llista de jails al runtime i actualitza la SQL.
        """
        errors = False
        for jail in jails:
            try:
                self._ensure_jail_row(jail)
                # NOTE: 1. Runtime
                self.system.jail_stop(jail)
                # NOTE: 2. SQL
                self.db.update("jails", where="name=$n", vars={'n': jail}, enabled=0)
            except Exception:
                log_traceback()
                errors = True
        return not errors
    
    def reload_jails(self) -> bool:
        """
            Fa un reload global de fail2ban i resincronitza tota la taula de jails.
        """
        try:
            self.system._call(["reload"])
            self.sync_all_defined_jails_to_db()
            return True
        except Exception:
            log_traceback()
            return False

    @LibDecorators.safe_sql_method(no_tuple=True)
    def unban_by_ids(self, ids: List[int]) -> List[str]:
        """
            Gestiona el procés complet d'unban:
            1. Consulta les dades a la DB.
            2. Executa l'ordre al sistema (Fail2Ban).
            3. Actualitza l'estat a la DB (remove=1).
        """
        errors = []
        for tid in ids:
            try:
                # NOTE: 1. Recuperem info de la IP i el Jail
                res = self.db.select("banned", where="id=$id", vars={'id': tid}, limit=1)
                if not res:
                    errors.append(f"ID {tid} no trobat.")
                    continue
                
                item = res[0]
                # NOTE: 2. Unban al sistema
                # Useu 'unbanip' per a IPs individuals. 
                # En algunes versions de F2B també pots usar 'unban --all <ip>'
                self.system._call(["set", item.jail, "unbanip", item.ip])
                # NOTE: 3. Marcar com a eliminat a la DB
                self.db.update("banned", where="id=$id", vars={'id': tid}, remove=1)
            except Exception as e:
                errors.append(f"Error unbanning IP (ID {tid}): {str(e)}")
        return errors

    @LibDecorators.safe_sql_method(no_tuple=True)
    def get_log(self, ban_id) -> Optional[Dict]:
        """
            Recupera el registre complet de la BD i intenta descodificar 
            el camp 'loglines' si està en Base64.
            Retorna l'objecte row complet (diccionari-like).
        """
        res = self.db.select("banned", where="id=$id", vars={'id': ban_id}, limit=1)
        if not res:
            return None # NOTE: Retornem None per que el controlador pugui detectar el 404
        # El decorador convertirà 'res[0]' (web.storage) a dict al final, 
        # però aquí dins encara treballem amb l'objecte original o el manipulem.
        # NOTA: Com que el decorador converteix a dict al sortir, 
        # hem d'assegurar-nos que el que retornem sigui serialitzable.
        row = dict(res[0])  # Això és un objecte web.Storage (com un dict)
                            # que convertim manualment per manipular-ho segur

        if row.get('loglines'):
            try:
                # NOTE: Intentem descodificar assumint que és UTF-8
                decoded = base64.b64decode(row['loglines']).decode('utf-8')
                row['loglines'] = decoded
            except (binascii.Error, UnicodeDecodeError, Exception):
                # NOTE: Si falla (perquè era text pla o binaris rars), deixem l'original
                pass

        # NOTE: 3. Retornem TOTA la fila (amb la IP, Jail i el log processat)
        return row

    @LibDecorators.safe_sql_method(no_tuple=True)
    def get_counts(self, days: Optional[int] = None) -> Dict[str, Any]:
        """
            📊 Obté estadístiques agregades de Fail2Ban.
                active_bans: Compta les IPs que estan realment bloquejades ara mateix (remove=0).
                total_history: Compta tots els registres de la taula (útil per veure el volum total d'atacs rebuts en X dies).
                top_jails: Et diu quina presó està treballant més (ex: sshd, postfix-iredmail, etc.). Això ajuda a identificar on es concentra l'atac.
                top_countries: Gràcies a que ja tens implementat el GeoService, aquesta consulta et donarà un rànquing de països atacants (codis ISO com ES, CN, US, etc.).
                active_jails: Simplement informa de quants mòduls de protecció tens engegats.
            
            Returns:
                Dict: Comptadors actius, totals, top jails i top països.
        """
        # NOTE: 1. Construir el filtre de temps si es demana
        where_time = "1=1"
        sql_vars = {}
        if days:
            # NOTE: Calculem la data de tall
            where_time = "timestamp >= $start_date"
            sql_vars['start_date'] = web.SQLLiteral(f"DATE_SUB(NOW(), INTERVAL {int(days)} DAY)")

        # NOTE: 2. Comptadors Generals (Actualment actius vs Històrics)
        # NOTE: Actius (remove=0)
        res_active = self.db.query(
            f"SELECT COUNT(*) as count FROM banned WHERE remove=0 AND {where_time}",
            vars=sql_vars
        )
        count_active = res_active[0].count if res_active else 0

        # NOTE: Totals històrics en el període
        res_total = self.db.query(
            f"SELECT COUNT(*) as count FROM banned WHERE {where_time}",
            vars=sql_vars
        )
        count_total = res_total[0].count if res_total else 0

        # NOTE: 3. Top Jails amb més activitat
        top_jails = self.db.query(
            f"SELECT jail as name, COUNT(*) as count FROM banned "
            f"WHERE {where_time} GROUP BY jail ORDER BY count DESC LIMIT 5",
            vars=sql_vars
        )

        # NOTE: 4. Top Països amb més bans
        top_countries = self.db.query(
            f"SELECT country, COUNT(*) as count FROM banned "
            f"WHERE {where_time} GROUP BY country ORDER BY count DESC LIMIT 5",
            vars=sql_vars
        )

        # NOTE: 5. Estat dels Jails (Quants n'hi ha actius al sistema ara mateix)
        res_jails = self.db.query("SELECT COUNT(*) as count FROM jails WHERE enabled=1")
        active_jails_count = res_jails[0].count if res_jails else 0

        return {
            "active_bans": count_active,
            "total_history": count_total,
            "active_jails": active_jails_count,
            "top_jails": list(top_jails),
            "top_countries": list(top_countries),
            "period_days": days
        }
