import web

from libs.logger import log_traceback
import settings

session = web.config.get('_session')

class WarpF2B(object):
    def __del__(self):
        try:
            self.db.ctx.db.close()
        except:
            pass
    
    def __init__(self):
        session_dbn = "mysql"
        if settings.backend == "pgsql":
            session_dbn = "postgres"

        try:
            self.db = web.database(
                host=settings.fail2ban_db_host,
                port=int(settings.fail2ban_db_port),
                dbn=session_dbn,
                db=settings.fail2ban_db_name,
                user=settings.fail2ban_db_user,
                pw=settings.fail2ban_db_password,
            )
            self.db.supports_multiple_insert = True
        except Exception as e:
            log_traceback()

    def reconnect_if_needed(self):
        try:
            self.db.ctx.db.query("SELECT 1")
        except Exception as e:
            self.__init__()
