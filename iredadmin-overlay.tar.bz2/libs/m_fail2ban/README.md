# Mòdul `fail2ban`

Integració de Fail2Ban dins iRedMailMyAdmin (llibreria, controlador web i plantilles UI).

## Què cobreix aquest mòdul

- Llistar i gestionar `jails` de Fail2Ban des de la UI.
- Llistar IPs bloquejades (`banned`) amb filtres i paginació.
- Fer `unban` manual (individual o massiu).
- Mostrar context de log d'un ban concret.
- Sincronitzar estat runtime de Fail2Ban cap a SQL (`jails` i `banned`).
- Enriquir IPs noves amb GeoIP (país).
- Exposar mètriques agregades per al dashboard (top jails, top països, etc.).

## Components

### 1) Llibreria

Fitxer principal: `libs/m_fail2ban/fail2ban.py`

- `F2BRuntime`: crides a `fail2ban-client` via `sudo`, llistat de jails/IPs i accions start/stop/reload.
- `GeoService`: càrrega de `GeoLite2-Country.mmdb` i `GeoLite2-ASN.mmdb` (ASN pendent d’usar a DB) i resolució de país per IP.
- `F2BManager` (classe principal):
- Sincronització: `sync_all_defined_jails_to_db()`, `sync_jails_to_db()`, `sync_banned_to_db()`.
- Consultes: `list_jails(page, page_size)`, `list_banned(page, page_size, payload)`, `get_log(ban_id)`, `get_counts(days)`.
- Accions: `enable_jail(jails)`, `disable_jail(jails)`, `reload_jails()`, `unban_by_ids(ids)`.

Connexió DB: `libs/m_fail2ban/__init__.py` (`WarpF2B`) amb settings `fail2ban_db_*`.

Script de sincronització opcional:
- `libs/m_fail2ban/sync_f2b.py`

### 2) Controlador web

Fitxers:
- `controllers/m_fail2ban/urls.py`
- `controllers/m_fail2ban/fail2ban.py`

Rutes:
- `GET /activities/fail2ban/jails`
- `GET /activities/fail2ban/banned`
- `POST /activities/fail2ban/jails`
- `POST /activities/fail2ban/banned`
- `GET /activities/fail2ban/log/<id>`

Comportament:
- `GET`: carrega jails + banned + comptadors (`get_counts(days=1)`).
- `POST` jails: `action=reload` o `bulk_action=enable|disable` amb `jail[]`.
- `POST` banned: `action=unban` amb `single_id=<id>` o `id[]`.
- `GET /log/<id>`: retorna modal amb context de log.

Accés:
- Decorador `require_admin_login` al controlador.
- Les opcions de menú “Banned IP Addresses” es mostren només a global admin a les macros de navegació.

### 3) Plantilles UI

Fitxers:
- `templates/classic/fail2ban/fail2ban.html`
- `templates/codyframe/fail2ban/fail2ban.html`

Funcionalitats visibles:
- Pestanyes `Jails` i `Banned IPs`.
- Taules amb paginació.
- Accions massives i individuals.
- Modal “About Fail2Ban”.
- Modal de filtres amb `query_string` (ip/hostname/country/jail) i `date_from`.
- Missatgeria via macro `fail2ban_msg_handler`.

## Flux de sincronització

### Jails

1. `list_jails()` executa `sync_all_defined_jails_to_db()`.
2. Es detecten jails definits (`fail2ban-client -d`) i es guarden a SQL.
3. Es marca `enabled` segons runtime real.
4. Si un jail és actiu, s’enriqueix amb:
- `currently_failed`, `total_failed`.
- `currently_banned`, `total_banned`.

### Banned IPs

1. `list_banned()` executa `sync_banned_to_db()`.
2. Runtime actual (`jail`, `ip`) es compara amb taula `banned`.
3. Si una IP és nova:
- s’insereix amb `remove=0`, timestamp i `country`.
- es guarda context de log (base64) a `loglines`.
4. Si una IP ja no és al runtime:
- es marca `remove=1`.

## Filtres i paginació de bans

`list_banned(payload=...)` admet:
- `query_string`: cerca lliure a `ip`, `hostname`, `country`, `jail`.
- `date_from`: filtra per `timestamp >= <date_from> 00:00:00`.

Retorna:
- `total`
- `page`
- `page_size`
- `items`
- `filters`

## Mètriques dashboard

`get_counts(days=1)` retorna:
- `active_bans`
- `total_history`
- `active_jails`
- `top_jails` (top 5)
- `top_countries` (top 5)
- `period_days`

Aquestes dades alimenten el dashboard (`libs/m_crudlib/admin.py`).

## Requisits tècnics

- Fail2Ban instal·lat i operatiu.
- Binari disponible a `/usr/bin/fail2ban-client`.
- Permisos `sudo` per l’usuari del servei web (sense prompt) per executar `fail2ban-client` i, si cal, `journalctl`.
- Base de dades Fail2Ban accessible amb `fail2ban_db_host`, `fail2ban_db_port`, `fail2ban_db_name`, `fail2ban_db_user`, `fail2ban_db_password`.
- Taules SQL esperades: `jails`, `banned`.
- Fitxers GeoIP presents a `libs/m_fail2ban/GeoLite2-Country.mmdb` i `libs/m_fail2ban/GeoLite2-ASN.mmdb`.

## Cron recomanat (opcional)

Si la pàgina de bans és pesada en entorns amb molt volum, es pot desplaçar part de la sincronització a cron:

```bash
*/5 * * * * /usr/bin/python3 /opt/www/iredadmin/libs/m_fail2ban/sync_f2b.py > /dev/null 2>&1
```
El contingut del script **sync_f2b.py** podria ser:
```python
    #!/usr/bin/python3
    # -*- coding: utf-8 -*-
    
    import os
    import sys
    
    # # Executa la sincronització cada 5 minuts
    # sudo crontab -e
    # */5 * * * * /usr/bin/python3 /opt/www/iredadmin/libs/m_fail2ban/sync_f2b.py > /dev/null 2>&1
    
    # Afegim l'arrel de iredadmin al path per poder importar les libs
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))
    
    from libs.m_fail2ban.fail2ban import F2BManager
    from libs.logger import log_error
    
    def main():
        # Creem un fitxer de bloqueig temporal per evitar execucions simultànies
        lock_file = "/tmp/iredadmin_f2b_sync.lock"
        
        if os.path.exists(lock_file):
            # Si el fitxer de lock té més de 10 minuts, el considerem orfe i continuem
            import time
            if (time.time() - os.path.getmtime(lock_file)) < 600:
                return
        
        try:
            # Creem el fitxer de lock
            with open(lock_file, 'w') as f:
                f.write(str(os.getpid()))
    
            # Executem la sincronització
            manager = F2BManager()
            result = manager.sync_banned_to_db()
            
            if result:
                print(f"Sincronització completada: +{result['added']} nous, -{result['removed']} eliminats.")
                
        except Exception as e:
            log_error(f"Error en la sincronització programada de Fail2Ban: {e}")
        finally:
            # Eliminem el fitxer de lock
            if os.path.exists(lock_file):
                os.remove(lock_file)
    
    if __name__ == "__main__":
        main()
```

## Notes importants

- El mètode correcte de sincronització és `sync_banned_to_db()` (no `sync_runtime_to_db()`).
- El camp ASN és previst però pendent de desplegar completament a SQL.
- `get_log()` intenta descodificar `loglines` en base64; si no és base64 vàlid, deixa el contingut original.

## Validació ràpida

```bash
# Estat de fail2ban runtime
sudo /usr/bin/fail2ban-client status

# Sincronització manual des de Python
python3 -c "from libs.m_fail2ban.fail2ban import F2BManager; print(F2BManager().sync_banned_to_db())"
```

# 📦 Llicència
Aquest projecte s’ofereix sota la llicència [MIT](https://choosealicense.com/licenses/mit/). Pots modificar-lo, distribuir-lo i integrar-lo lliurement.

# 🤝 Contribucions
Les contribucions són benvingudes! Si tens idees, millores o correccions, obre un issue o envia un pull request.
[![PayPal - Donate](https://img.shields.io/badge/PayPal-Donate-005EA6?logo=paypal&logoColor=white)](https://www.paypal.me/cuquet74)
