# m_maillist Technical Notes

Document tecnic de `libs/m_maillist/ml.py`.

## Index

- 1. Arquitectura interna
- 2. `MailList` per backend (SQL/LDAP)
- 3. `MailList_API` (mlmmjadmin)
- 4. Flux newsletter amb confirmacio
- 5. `ConfirmManager` i taula SQL
- 6. Mapeig controller -> lib
- 7. Mapeig API -> lib
- 8. Taula UI: endpoint -> metode -> missatges
- 9. Taula API: endpoint -> metode -> missatges
- 10. Notes practiques

## 1. Arquitectura interna

Fitxer principal:

- `libs/m_maillist/ml.py`

Classes:

- `MaillistBase`: helpers comuns (`_build_profile`, `_update_members`, `_post_newsletter_common`, ...)
- `MailList` (variant SQL o LDAP segons `settings.backend`)
- `ConfirmManager`: cua de confirmacions
- `MailList_API`: client HTTP cap a mlmmjadmin

Dependencia de runtime:

- SQL/LDAP de iRedAdmin
- mlmmjadmin API (`MLMMJADMIN_API_BASE_URL` + token)

## 2. `MailList` per backend (SQL/LDAP)

### 2.1 Metodes principals

Comuns a ambdos backends:

- `list(...)`
- `get_profile()`
- `add(payload)`
- `update(payload, profile_type)`
- `delete(mails, archive='yes')`
- `enable_or_disable_accounts(mails, action)`
- `get_newsletter_subscription(ml_id)`
- `post_newsletter_subscription(subscriber, kind, ml_id)`

### 2.2 Diferencies SQL/LDAP

SQL:

- persisteix metadata a taules (`maillists`, `moderators`, `maillist_owners`)
- sincronitza camps amb mlmmj (`_sync_profile`)

LDAP:

- usa `modify_s` sobre atributs (`listOwner`, `listModerator`, `maxMessageSize`, `enabledService`, ...)
- sincronitza estat newsletter (`enabledService=newsletter`)

## 3. `MailList_API` (mlmmjadmin)

Wrapper HTTP de endpoints mlmmjadmin.

Metodes rellevants:

- `info()`
- `create(args)`
- `delete(args)`
- `update(args)`
- `subscribers()`
- `subscribed(query_all_lists=True)`
- `add_subscribers([...])`
- `remove_subscribers([...])`
- `has_subscriber(mail)`

Inicialitzacio:

- headers amb `settings.MLMMJADMIN_API_AUTH_HEADER`
- token de `settings.mlmmjadmin_api_auth_token`
- SSL segons `settings.MLMMJADMIN_API_VERIFY_SSL`

## 4. Flux newsletter amb confirmacio

L'entrada funcional esta a:

- `MaillistBase._post_newsletter_common(...)`

Regles principals:

1. carrega flags de llista via `MailList_API.info()`
2. bloqueja si `close_list=yes`
3. bloqueja si newsletter no habilitat (`enable_newsletter_subscription!=yes`)
4. en subscribe, bloqueja si `disable_subscription=yes`
5. si `disable_subscription_confirm=yes`, executa directament
6. si cal confirmacio:
- evita duplicats amb `ConfirmManager.exists_pending(mail, subscriber, kind)`
- crea token (`ConfirmManager.create(...)`)
- envia email amb URL `<NEWSLETTER_BASE_URL>/confirm?token=...`

Consum del token:

- `NewsletterConfirm.GET` (controller)
- `ConfirmManager.get_by_token(token)`
- aplica accio via `MailList_API.add_subscribers/remove_subscribers`
- invalida token amb `ConfirmManager.mark_expired(token)`

## 5. `ConfirmManager` i taula SQL

Constants a `ml.py`:

- `TABLE = 'newsletter_subunsub_confirms'`
- `EXPIRE_AFTER = 86400` (24h)

Metodes:

- creacio: `create(...)`
- consulta: `get_by_token(...)`, `get_by_ids(...)`, `get_queue_by_mail(...)`
- control duplicates: `exists_pending(...)`
- manteniment: `mark_expired(...)`, `purge_expired()`
- operacions massives: `delete_by_ids(...)`, `delete_all(mail)`, `delete_expired(mail)`
- execucio pendent: `post_record(record)`, `post_records(records)`

Schema SQL:

- snippets: `SQL/snippets/newsletter_subunsub_confirms.pgsql`
- snippets: `SQL/snippets/newsletter_subunsub_confirms.mysql`

Caracteristiques importants:

- unic `(mlid, subscriber, kind)`
- index per `token` i `expired` per confirmacio/purga eficient

## 6. Mapeig controller -> lib

UI controllers a `controllers/m_maillist/controller.py`.

- `List.GET/POST` -> `MailList.list`, `MailList.delete`, `MailList.enable_or_disable_accounts`
- `Profile.GET/POST` -> `MailList.get_profile`, `MailList.update`
- `Create.GET/POST` -> `Domain.*` (limits) + `MailList.add`
- `NewsletterSubscription.GET/POST` -> `MailList.get_newsletter_subscription`, `MailList.post_newsletter_subscription`
- `NewsletterConfirm.GET` -> `ConfirmManager.get_by_token`, `ConfirmManager.mark_expired`, `MailList_API.*_subscribers`
- `NewsletterQueue.POST` -> `ConfirmManager.delete_*`, `ConfirmManager.post_records`

## 7. Mapeig API -> lib

API controller: `api/maillist/controller.py`.

- `GET /api/mls/<domain>` -> `MailList(domain).list(...)`
- `GET /api/ml/<mail>` -> `MailList(mail).get_profile()`
- `POST /api/ml/<mail>` -> normalitzacio payload + `MailList.add(...)`
- `PUT /api/ml/<mail>` -> deteccio `profile_type` + `MailList.update(...)`
- `DELETE /api/ml/<mail>` -> `MailList.delete([mail], archive=...)`

Nota:

- l'API reaprofita normalitzadors de `controllers/m_maillist/utils.py`.
- camps yes/no es normalitzen abans d'enviar a lib.

## 8. Taula UI: endpoint -> metode -> missatges

| Ruta | HTTP | Mètode lib principal | Missatges d'èxit típics | Missatges d'error típics |
|---|---|---|---|---|
| `/ml/<domain>` | `GET` | `MailList.list(...)` | render llistat (sense codi fix) | `msg=<error retornat per list>` |
| `/ml/<domain>` | `POST` (`delete`) | `MailList.delete(...)` | `DELETED` o `DELETED_WITHOUT_ARCHIVE` (LDAP) | `NO_ACCOUNT_SELECTED`, `repr(errors)` |
| `/ml/<domain>` | `POST` (`enable/disable`) | `MailList.enable_or_disable_accounts(...)` | depèn backend (`ENABLED/DISABLED` o sense text) | `NO_ACCOUNT_SELECTED`, `INVALID_ACTION` |
| `/profile/ml/<profile_type>/<mail>` | `GET` | `MailList.get_profile()` | render perfil | `msg=<error get_profile>` |
| `/profile/ml/<profile_type>/<mail>` | `POST` | `MailList.update(payload, profile_type)` | `UPDATED` | `repr(msg)` |
| `/create/ml[/<domain>]` | `POST` | `MailList.add(payload)` | `CREATED` | missatge retornat per `add` |
| `<NEWSLETTER_BASE_URL>/<kind>/<ml_id>` | `GET` | `MailList.get_newsletter_subscription(ml_id)` | render formulari subscribe/unsubscribe | `NOT_FOUND` |
| `<NEWSLETTER_BASE_URL>/<kind>/<ml_id>` | `POST` | `MailList.post_newsletter_subscription(...)` | `A confirmation email has been sent...` o alta/baixa directa (no-confirm) | `INVALID_MAIL`, `Newsletter subscription disabled.`, `Subscription disabled.`, errors mlmmjapi |
| `<NEWSLETTER_BASE_URL>/confirm` | `GET` | `ConfirmManager.get_by_token(...)`, `MailList_API.add/remove_subscribers(...)` | `status=ok` | `Invalid or expired token.`, `INVALID_ACTION`, error de subscripcio |
| `/profile/ml/queue/<mail>` | `POST` | `ConfirmManager.delete_* / post_records(...)` | `DELETED_QUEUE`, `DELETED_QUEUE_ALL`, `DELETED_QUEUE_EXPIRED`, `Posted X/Y successfully` | `No IDs provided`, `Unknown action: ...`, `UNKNOWN_ERROR` |

Notes:

- En molts fluxos UI, el controller redirigeix amb `?msg=<string>` tal com retorna la lib.
- Alguns errors es propaguen com `repr(dict)`; convé mantenir `msg_handlers` robustos a aquest format.

## 9. Taula API: endpoint -> metode -> missatges

| Endpoint | HTTP | Mètode lib principal | Missatges d'èxit típics | Missatges d'error típics |
|---|---|---|---|---|
| `/api/mls/<domain>` | `GET` | `MailList(domain).list(...)` | `_success=true` amb llista o payload paginat | `PERMISSION_DENIED`, error de parse payload, error backend |
| `/api/ml/<mail>` | `GET` | `MailList(mail).get_profile()` | `_success=true` amb `ldif/account_setting/subscribers/queue` | `NO_SUCH_ACCOUNT`, errors de `MailList_API.info/subscribers`, `get_queue_by_mail` |
| `/api/ml/<mail>` | `POST` | `MailList.add(...)` | `CREATED` | `ALREADY_EXISTS`, `INVALID_MAIL`, errors mlmmjadmin (`Error: ...`) |
| `/api/ml/<mail>` | `PUT` | `MailList.update(...)` (segons `profile_type`) | `UPDATED` | `INVALID_ACTION`, `repr(msg)`, errors mlmmjadmin |
| `/api/ml/<mail>` | `DELETE` | `MailList.delete([mail], archive=...)` | `DELETED` o `DELETED_WITHOUT_ARCHIVE` (LDAP) | `NO_ACCOUNT_SELECTED`, `repr(errors)` |

Notes:

- L'API admet `application/x-www-form-urlencoded` i JSON (via `_parse_api_payload`).
- `profile_type` a `PUT` es pot inferir automàticament (`general/members/aliases/owners/newsletter`).

## 10. Notes practiques

- `expired` guarda unix timestamp (no boolea). Això permet purga simple per SQL:
  `DELETE FROM newsletter_subunsub_confirms WHERE expired < UNIX_TIMESTAMP();`
- El control de duplicats pendents es basa en `mail+subscriber+kind` (`ConfirmManager.exists_pending`) i en l'índex únic SQL `(mlid, subscriber, kind)`.
- Purga recomanada via script:
  `tools/purge_expired_confirms.py`
- Exemple cron (diari):
  `0 */24 * * * python3 /opt/www/iRedMailMyAdmin/tools/purge_expired_confirms.py >/dev/null`
- Script `/opt/iredadmin/tools/purge_expired_confirms.py` amb contingut similar a:

```python
#!/usr/bin/env python3
#
# Author: Àngel <cuquet@gmail.com>
# Purpose: Purge expired records from SQL table "newsletter_subunsub_confirms"
#          to keep the confirmation queue clean.
#

import os
import sys
import time

os.environ['LC_ALL'] = 'C'

rootdir = os.path.abspath(os.path.dirname(__file__)) + '/../'
sys.path.insert(0, rootdir)

import web
from tools import ira_tool_lib

# Setup
web.config.debug = ira_tool_lib.debug
logger = ira_tool_lib.logger
conn = ira_tool_lib.get_db_conn('iredadmin')

# Constants
TABLE = 'newsletter_subunsub_confirms'

def purge_expired():
    now = int(time.time())
    try:
        n = conn.delete(TABLE, where="expired < $now", vars={'now': now})
        logger.info(f"Purged {n} expired confirmation records from {TABLE}.")
    except Exception as e:
        logger.error(f"Error purging expired confirmations: {repr(e)}")

if __name__ == '__main__':
    purge_expired()
```

