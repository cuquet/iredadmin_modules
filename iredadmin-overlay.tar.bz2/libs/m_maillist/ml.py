# libs/m_maillist/ml.py
import time
from urllib.parse import urlencode
import requests
import web
import secrets
import simplejson as json
from typing import Dict, List, Tuple, Union, Literal, Any

import settings
from libs.iredutils import is_email, get_gmttime, sendmail, bytes2str
from libs.logger import log_activity

from libs.m_system.decorators import LibDecorators
from libs.m_crudlib import domain as lib_domain
from libs.m_system import utils 

session = web.config.get('_session')
mapper = utils.KeyMap()

class MaillistBase:
    def __init__(self, domain=None, mail=None):
        self.domain = domain
        self.mail = mail
        self.backend = Wrap()
        self.conn = self.backend.conn
        self.size_limit = settings.PAGE_SIZE_LIMIT

    def _build_profile(self, ldif: dict) -> Tuple[bool, Union[dict, str]]:
            """Ajuda comuna per construir el perfil d'una llista de correu"""
            maillist_api = MailList_API(domain=self.domain, mail=self.mail)
            qr, msg = {}, {}

            # NOTE: Normalitza ldif
            if ldif:
                ldif = mapper.remap_dict(ldif, reverse=True)
                # NOTE: ldif["enabledService"] = ["newsletter"] if ldif.get("is_newsletter") in ("1", 1, True) else []
                qr["ldif"] = ldif
            else:
                qr["ldif"] = {}

            # NOTE: Afegeix subs
            _sub = maillist_api.subscribers()
            if not _sub[0]:
                msg[".subscribers()"] = _sub[1]
            qr["subscribers"] = _sub[1]

            # NOTE: Afegeix info
            _info = maillist_api.info()
            if not _info[0]:
                msg[".info()"] = _info[1]
            qr["account_setting"] = {i[0]: i[1] for i in _info[1]}
            
            # NOTE: Afegeix queue
            _queue = ConfirmManager().get_queue_by_mail(self.mail, include_expired=True)
            if not _queue[0]:
                msg[".get_queue_by_mail()"] = _queue[1]
            qr["queue"] = _queue[1]

            if not msg:
                return True, qr
            return False, str(msg)

    def _update_members(self, payload):
        """Gestiona afegir i eliminar subscriptors d'una llista."""
        errors: dict[str, list[str]] = {}
        subs = payload.get("subscriber", {})

        # NOTE: 🔽 Subscriptors a eliminar
        remove_list = utils._normalize_list_mails(subs.get("remove", ""))
        if remove_list:
            qr = MailList_API(domain=self.domain, mail=self.mail).remove_subscribers(remove_list)
            if not qr[0]:
                errors["remove_subscribers"] = str(qr[1])
            log_activity(event="update",
                admin=session.get("username"),
                username=self.mail,
                domain=self.domain,
                msg=f"Remove subscribers maillist profile (members): {self.mail}.",
                )

        # NOTE: ➕ Nous subscriptors 
        new_list = utils._normalize_list_mails(subs.get("add", ""))
        if new_list:
            qr = MailList_API(domain=self.domain, mail=self.mail).add_subscribers(new_list)
            if not qr[0]:
                errors["add_subscribers"] = str(qr[1])
            log_activity(event="update",
                admin=session.get("username"),
                username=self.mail,
                domain=self.domain,
                msg=f"Add subscribers maillist profile (members): {self.mail}.",
                )

        return errors

    def _prepare_add_args(self, payload: dict) -> tuple[dict, str]:
        """
        Helper per preparar dades per crear una nova mailing list.
        Retorna: (args, full_mail_address)
        """
        mail = f"{payload['username']}@{self.domain}"
        args = {
            "only_moderator_can_post": "yes" if "moderatorsonly" in payload.get("accessPolicy", "") else "no",
            "only_subscriber_can_post": "yes" if "membersonly" in payload.get("accessPolicy", "") else "no",
            "name": payload.get("name"),
        }
        return args, mail

    def _delete_maillists_api(self, mails: Union[List[str], None], archive: Literal['yes', 'no'] ='yes') -> Tuple[int, Dict[str, str]]:
            """
            Elimina múltiples llistes via MailList_API.
            Retorna: (deleted_count:int, errors:dict[mail:str, error:str])
            """
            args = {'archive': archive}
            errors: Dict[str, str] = {}
            deleted = 0

            for mail in (mails or []):
                qr = MailList_API(domain=self.domain, mail=mail).delete(args)
                if qr and qr[0]:
                    deleted += 1
                else:
                    # NOTE: protegeix si qr és None o no porta missatge
                    errors[mail] = str(qr[1]) if (qr and len(qr) > 1) else 'UNKNOWN_ERROR'

            return (deleted, errors)

    def _post_newsletter_common(self, subscriber: str, kind: str, mail: str, ml_id: str):
        """
            Lògica comuna per subscribe/unsubscribe de newsletter.
        """
        from email.mime.text import MIMEText
        from email.utils import formataddr

        try:
            # NOTE: --- API INFO
            api = MailList_API(domain=self.domain, mail=mail)
            ok, info = api.info()
            if not ok:
                return False, f"MailList_API().info(): {repr(info)}"

            info_dict = {k: v for k, v in info}

            # NOTE: Flags interessants de MLMMJ
            close_list                     = info_dict.get("close_list") == "yes"
            disable_subscription           = info_dict.get("disable_subscription") == "yes"
            disable_nomail_subscription    = info_dict.get("disable_nomail_subscription") == "yes"
            disable_subscription_confirm   = info_dict.get("disable_subscription_confirm") == "yes"
            enable_newsletter_subscription = info_dict.get("enable_newsletter_subscription") == "yes"

            # NOTE: --- 1) Si la llista està tancada
            if close_list:
                return False, "This mailing list is closed."

            # NOTE: --- 2) Newsletter no habilitat
            # NOTE: (ja sigui per SQL/LDAP enabledService o MLMMJ flag)
            if not enable_newsletter_subscription:
                return False, "Newsletter subscription disabled."

            # NOTE: --- 3) SUBSCRIBE rules
            if kind == "subscribe":
                if disable_subscription:
                    return False, "Subscription disabled."

            # NOTE: --- 3b) Unsubscribe rules
            # per ara: sempre permès
            # (si vols limitar al futur → ho poses aquí)
            if kind == "unsubscribe":
                pass

            # NOTE: --- 4) Confirmació no necessària?
            no_confirm = disable_subscription_confirm

            if kind == "unsubscribe" and no_confirm:
                ok, *rest = api.remove_subscribers([subscriber])
                if not ok:
                    return False, rest[0] if rest else "Unsubscribe error"
                return True, f"{subscriber} unsubscribed (no-confirm)."

            if kind == "subscribe" and no_confirm:
                ok, *rest = api.add_subscribers([subscriber])
                if not ok:
                    return False, rest[0] if rest else "Subscribe error"
                return True, f"{subscriber} subscribed (no-confirm)."

            # NOTE: --- 5) Confirmació necessària
            if ConfirmManager.exists_pending(mail, subscriber, kind):
                return False, (
                    f"Subscriber {subscriber} already has pending confirmation for {kind}."
                )

            token = ConfirmManager.create(mail, ml_id, subscriber, kind)
            if not token:
                return False, "Could not create confirmation entry in DB"

            confirm_url = f"{web.ctx.home}{settings.NEWSLETTER_BASE_URL}/confirm?token={token}"

            subject = f"Confirm your {kind} request for {mail}"
            body = (
                f"Hello,\n\n"
                f"Please confirm your {kind} request for {mail} by clicking this link:\n"
                f"{confirm_url}\n\n"
                f"This link will expire in 24 hours.\n"
            )

            # NOTE: Headers de subscribe/unsubscribe segons RFC
            listname, domain = mail.split("@", 1)
            list_sub   = f"<mailto:{listname}+subscribe@{domain}?subject=Subscribe>"
            list_unsub = f"<mailto:{listname}+unsubscribe@{domain}?subject=Unsubscribe>"

            msg = MIMEText(body, "plain", "utf-8")
            msg["Subject"] = subject
            msg["From"] = formataddr(
                ("Mailing List", settings.NOTIFICATION_SMTP_USER or "no-reply@localhost")
            )
            msg["To"] = subscriber
            msg["List-Subscribe"]   = list_sub
            msg["List-Unsubscribe"] = list_unsub

            ok, *err = sendmail(
                recipients=[subscriber],
                message_text=msg.as_string().encode("utf-8"),
                from_address=msg["From"],
            )

            if not ok:
                return False, f"Failed to send confirmation email: {err}"

            return (True, f"A confirmation email has been sent to {subscriber}.")

        except Exception as e:
            return False, repr(e)

if settings.backend in ["mysql", "pgsql"]:
    from libs.m_crudlib import SQLWrap as Wrap
    from libs.m_system.mixins import SQLCRUDMixin, SQLWhereBuilder

    class MailList(MaillistBase, SQLCRUDMixin):
        def __init__(self, domain=None, mail=None):
            super().__init__(domain=domain, mail=mail)

            # NOTE: SQL-specific init
            self.attrlist_all = 'address, domain, accesspolicy, maxmsgsize, name, description, mlid, is_newsletter, settings, expired, active'

        def _sync_profile(self):
            def __reset_moderators():
                self.conn.delete(
                    'moderators',
                    vars={'address': self.mail},
                    where='address=$address'
                    )
                if moderators_list:
                    records = []
                    for _addr in moderators_list:
                        params = {
                            'address': self.mail,
                            'domain': self.domain,
                            'moderator': _addr,
                            'dest_domain': _addr.split('@', 1)[-1],
                        }
                        records.append(params)
                    self.conn.multiple_insert('moderators', records)

            def __reset_owners():
                self.conn.delete(
                    "maillist_owners",
                    vars={'mail': self.mail},
                    where="address=$mail")
                if owners_list:
                    records = []
                    for _addr in owners_list:
                        params = {
                            'address': self.mail,
                            'domain': self.domain,
                            'owner': _addr,
                            'dest_domain': _addr.split('@', 1)[-1],
                        }
                        records.append(params)
                    self.conn.multiple_insert('maillist_owners', records)

            msg = {}
            params = {}

            ADVANCED = {
                "owners": __reset_owners,
                "moderators": __reset_moderators,
            }
            SIMPLE = {
                'name':'name',
                "max_message_size":'maxmsgsize',
            }
            api = MailList_API(domain=self.domain, mail=self.mail)
            ok, info = api.info()
            if not ok:
                return False, {"MailList_API().info()": repr(info)}

            info_dict = {k: v for k, v in info if k in (set(ADVANCED) | set(SIMPLE) | {"enable_newsletter_subscription"})}
            owners_list = info_dict.get("owners") or []
            moderators_list = info_dict.get("moderators") or []

            for api_key, sync_func in ADVANCED.items():
                if api_key in info_dict:
                    try:
                        sync_func()
                    except Exception as e:
                        msg[api_key] = repr(e)

            for api_key, column in SIMPLE.items():
                if api_key in info_dict:
                    params[column] = info_dict[api_key]
            news_flag = info_dict.get("enable_newsletter_subscription", "no")
            params['is_newsletter'] = 1 if news_flag == "yes" else 0

            if params:
                try:
                    self.conn.update(
                        "maillists",
                        vars={'mail': self.mail},
                        where="address=$mail",
                        **params
                    )
                except Exception as e:
                    msg['maillists sync'] = repr(e)

            if msg:
                return (False, msg)
            return (True, None)

        @LibDecorators.safe_sql_method
        def list(self, current_page=0, subscriber: str = None, email_only: bool = False, all_domains: bool = False):
            # NOTE: Contracte:
            # NOTE: - current_page <= 0: mode heretat, retorna la llista completa.
            # NOTE: - current_page > 0 : càrrega paginada per UI/API.
            if subscriber and is_email(subscriber) and all_domains:
                ok, subscribed = MailList_API(domain=self.domain, mail=subscriber).subscribed()
                if not ok:
                    return (False, subscribed)
                subscribed = [str(i).lower() for i in (subscribed or []) if i]
                if email_only:
                    return (True, sorted(set(subscribed)))
                return (True, [{"address": i} for i in subscribed])
            sql_what = self.attrlist_all
            sql_order = 'address ASC, name ASC'

            builder = SQLWhereBuilder()
            builder.add_equals("maillists.domain", self.domain)
            # if disabled:
            #     builder.add_equals("maillists.active", 0)
            
            # if starts_with:
            #     builder.add("maillists.address LIKE $addr", "addr", f"{starts_with}%")

            sql_where, sql_vars = builder.build()

            # NOTE: 📝 Sense paginació
            try:
                cur_page = int(current_page or 0)
            except Exception:
                cur_page = 0

            if cur_page <= 0:
                qr = self.conn.select(
                    "maillists",
                    vars=sql_vars,
                    what=sql_what,
                    where=sql_where,
                    order=sql_order,
                )
                _list = [mapper.remap_dict(i) for i in qr]

                if subscriber and is_email(subscriber):
                    ok, subscribed = MailList_API(domain=self.domain, mail=subscriber).subscribed()
                    if ok and subscribed:
                        subscribed_set = {str(i).lower() for i in subscribed}
                        filtered = [ml for ml in _list if str(ml.get("address", "")).lower() in subscribed_set]
                        _list = filtered
                    else:
                        _list = []

                if email_only:
                    emails = sorted({str(i.get("address")).lower() for i in _list if i.get("address")})
                    return True, emails

                return True, _list

            # NOTE: 📄 Amb paginació
            sql_limit = self.size_limit
            sql_offset = (cur_page - 1) * self.size_limit

            # NOTE: 🔥 Consulta combinada: registres + total
            qr = self.conn.query(f"""
                SELECT *,
                    (SELECT COUNT(*) FROM maillists WHERE {sql_where}) AS total_count
                FROM maillists
                WHERE {sql_where}
                ORDER BY {sql_order}
                LIMIT $limit OFFSET $offset
            """, vars={**sql_vars, "limit": sql_limit, "offset": sql_offset})

            _list = [mapper.remap_dict(i) for i in qr]
            _total = _list[0].total_count if _list else 0
            _pages = (_total + self.size_limit - 1) // self.size_limit

            result = {
                "total": _total,
                "account_profiles": _list,
                "pages": _pages,
            }
            if email_only:
                emails = sorted({str(i.get("address")).lower() for i in _list if i.get("address")})
                return True, emails
            return True, result

        @LibDecorators.safe_sql_method
        def get_profile(self):
            sql_what = self.attrlist_all # NOTE: attrlist

            builder = SQLWhereBuilder()
            builder.add_equals("maillists.address", self.mail)	
            builder.add_equals("maillists.domain", self.domain)
            sql_where, sql_vars = builder.build()

            qr = self.conn.select(
                "maillists",
                vars=sql_vars, 
                what=sql_what,
                where=sql_where,
                limit=1
            )                   

            return self._build_profile(qr[0] if qr else None)

        @LibDecorators.safe_sql_method
        def update(self, payload, profile_type):
            msg = {}

            updates = {'modified': get_gmttime()}
            if profile_type == 'general':
                # NOTE: "max_message_size" -> "maxmsgsize"
                # NOTE: "name" -> "name"
                updates['active'] = 1 if payload['accountStatus'] in ['enable', 'active'] else 0

            elif profile_type == 'members':
                errors = self._update_members(payload)
                msg.update(errors)

            elif profile_type == 'newsletter':
                updates['is_newsletter'] = 1 if 'is_newsletter' in payload else 0
                updates['description'] = payload.get('description', '')

            try:
                self.conn.update(
                    'maillists',
                    vars={'mail': self.mail},
                    where='maillists.address=$mail',
                    **updates
                )
            except Exception as e:
                msg['update_profile update_sql'] = repr(e)

            qr = MailList_API(domain=self.domain, mail=self.mail).update(payload)
            if not qr[0]:
                msg['MailList_API().update()'] = repr(qr[1])

            if msg == {}:
                log_activity(event='update',
                    admin=session.get('username'),
                    username=self.mail,
                    domain=self.domain,
                    msg=f'Update maillist profile ({profile_type}): {self.mail}.',
                    )
                return (True,"UPDATED")
            else:
                return (False, repr(msg))

        @LibDecorators.safe_sql_method
        def add(self, payload: dict):
            args, self.mail = self._prepare_add_args(payload)
            qr = MailList_API(domain=self.domain, mail=self.mail).create(args)
            if not qr[0]:
                return qr
            return (True, 'CREATED')

        @LibDecorators.safe_sql_method
        def delete(self, mails, archive='yes'):
            if mails is None or len(mails) == 0:
                return (False, 'NO_ACCOUNT_SELECTED')

            _, errors = self._delete_maillists_api(mails, archive=archive)
            if errors:
                return (False, repr(errors))
            return (True, )

        @LibDecorators.safe_sql_method
        def enable_or_disable_accounts(self, mails, actions):
            if not (mails and isinstance(mails, (list, tuple, set))):
                return (False, 'NO_ACCOUNT_SELECTED')
            # if mails is None or len(mails) == 0:
            #     return (False, 'NO_ACCOUNT_SELECTED')
            
            actions = actions.lower()
            if actions not in ['enable', 'disable']:
                return (False, 'INVALID_ACTION')

            # NOTE: Delegate to shared SQLCRUDMixin implementation (avoid recursion).
            qr = super().enable_disable_accounts(mails, actions, 'maillist')
            if not qr[0]:
                return qr
            return(True,)

        @LibDecorators.safe_sql_method
        def get_newsletter_subscription(self, ml_id ):
            sql_what = self.attrlist_all
            builder = SQLWhereBuilder()
            builder.add_equals("maillists.mlid", ml_id)	
            #builder.add_equals("maillists.active", 1)

            sql_where, sql_vars = builder.build()

            qr = self.conn.select(
                'maillists',
                vars=sql_vars, 
                what=sql_what,
                where=sql_where,
                limit=1)
            if not qr:
                return False, "NOT_FOUND"
            row=qr[0]
            return (True, {
                "name": row["name"],
                "description": row["description"],
                "newsletter_enabled": bool(int(row.get("is_newsletter", 0)) == 1 and int(row.get("active", 0)) == 1)
            })

        @LibDecorators.safe_sql_method
        def post_newsletter_subscription(self, subscriber: str, kind: str, ml_id: str):
            if not subscriber:
                return False, "INVALID_MAIL"
            
            sql_what = 'address, domain, description'	

            builder = SQLWhereBuilder()
            builder.add_equals("maillists.mlid", ml_id)	
            builder.add_equals("maillists.active", 1)
            sql_where, sql_vars = builder.build()

            _qr = self.conn.select('maillists',
                    vars=sql_vars, 
                    what=sql_what,
                    where=sql_where,
                    limit=1)
            if _qr:
                self.mail = _qr[0]['address']
                self.domain = _qr[0]['domain']
                
            return self._post_newsletter_common(
                subscriber=subscriber,
                kind=kind.lower(),
                mail=self.mail,
                ml_id=ml_id,
            )  

elif settings.backend == "ldap":
    import ldap
    from libs.ldaplib import attrs
    from libs.m_crudlib import  LDAPWrap as Wrap
    from libs.m_system.mixins import  LdapCRUDMixin

    class MailList(MaillistBase, LdapCRUDMixin):
        def __init__(self, domain=None, mail=None):
            super().__init__(domain=domain, mail=mail)

            # NOTE: LDAP-specific init
            self.attrlist_all = [*attrs.MAILLIST_ATTRS_ALL, 'maxMessageSize', 'listModerator', 'listOwner', 'mailingListID', 'description']

            if self.mail and self.is_email(self.mail):
                self.dn = self.rdn_value_to_maillist_dn(self.mail)
            else:
                self.dn = None
            if self.domain and self.is_domain(self.domain):
                self.dn_domain = self.rdn_value_to_domain_dn(self.domain)
                self.dn_groups = self.rdn_value_to_ou_maillist_dn(self.domain)    

        def _sync_profile(self):
            mod_attrs = []
            FILTER = {
                "owners": "listOwner",
                "moderators": "listModerator",
                "max_message_size": "maxMessageSize",
                "listAllowedUser": "listAllowedUser",
                "name":"cn",
            }
            api = MailList_API(domain=self.domain, mail=self.mail)
            ok, info = api.info()
            if not ok:
                return False, {"MailList_API().info()": repr(info)}

            info_dict = {k: v for k, v in info if k in FILTER or k == "enable_newsletter_subscription"}

            owners_list = info_dict.get("owners") or []
            moderators_list = info_dict.get("moderators") or []

            # NOTE: eliminem duplicats
            allowed_users = sorted(set(owners_list + moderators_list))
            info_dict["listAllowedUser"] = allowed_users
            for api_key, ldap_key in FILTER.items():
                if api_key in info_dict:
                    mod_attrs += self.mod_replace(ldap_key, info_dict[api_key])

            news_flag = info_dict.get("enable_newsletter_subscription")
            if news_flag in ("yes", "no"):
                self.add_or_remove_attr_values_by_dn(
                    dn=self.dn,
                    attr='enabledService',
                    values='newsletter',
                    action='add' if news_flag == "yes" else 'remove'
                )

            try:
                self.conn.modify_s(self.dn, mod_attrs)
            except Exception as e:
                return False, {"modify_s": repr(e)}
            return (True, None)

        @LibDecorators.safe_ldap_method
        def list(self, current_page=0, subscriber: str = None, email_only: bool = False, all_domains: bool = False):
            if subscriber and is_email(subscriber) and all_domains:
                ok, subscribed = MailList_API(domain=self.domain, mail=subscriber).subscribed()
                if not ok:
                    return (False, subscribed)
                subscribed = [str(i).lower() for i in (subscribed or []) if i]
                if email_only:
                    return (True, sorted(set(subscribed)))
                return (True, [{"mail": i} for i in subscribed])
            _list = []

            attrlist = list(attrs.MAILLIST_SEARCH_ATTRS)
            _filter = '(&(objectClass=mailList)(enabledService=mlmmj))'

            try:
                _qr = self.conn.search_s(
                    self.dn_groups,
                    ldap.SCOPE_ONELEVEL,
                    _filter,
                    attrlist,
                )
            except ldap.NO_SUCH_OBJECT:
                # NOTE: En alguns entorns LDAP no existeix encara `ou=Groups` per domini
                # NOTE: (o no hi ha cap `mailList` LDAP tot i existir la llista via mlmmj API).
                # NOTE: En llistat ho tractem com a resultat buit, no com error fatal.
                _qr = []
            if _qr:
                for (_dn, _ldif) in _qr:
                    _list.append(_ldif)

            if subscriber and is_email(subscriber):
                ok, subscribed = MailList_API(domain=self.domain, mail=subscriber).subscribed()
                if ok and subscribed:
                    subscribed_set = {str(i).lower() for i in subscribed}
                    filtered = []
                    for ml in _list:
                        ml_mail = bytes2str(ml.get("mail")[0]) if ml.get("mail") else ""
                        if ml_mail and ml_mail.lower() in subscribed_set:
                            filtered.append(ml)
                    _list = filtered
                else:
                    _list = []

            if email_only:
                emails = []
                for item in _list:
                    if isinstance(item, dict) and 'mail' in item:
                        v = item.get('mail')
                        if isinstance(v, list):
                            v = v[0] if v else ''
                        if v:
                            emails.append(v)
                _list = sorted({str(i).lower() for i in emails if i})

            sl = self.get_accounts_paged_list(_list, current_page=current_page, size_limit=self.size_limit)
            return True, sl

        def get_profile(self):
            _filter = f'(&(objectClass=mailList)(mail={self.mail}))'
            qr = self.profile_get_by_dn(self.dn, query_filter=_filter, attributes=self.attrlist_all)
            if not qr[0]:
                return self._build_profile(None)
            return self._build_profile(qr[1]["ldif"])

        def update(self, payload, profile_type):
            args = {}
            msg = {}
            mod_attrs = []
            ldap_entry_exists = False

            # NOTE: En alguns despliegues la llista pot existir només a MLMMJ (API),
            # sense entrada LDAP `mailList`. En aquest cas hem de poder actualitzar
            # membres/config via API sense fallar amb NO_SUCH_OBJECT.
            if self.dn and isinstance(self.dn, str) and not self.dn.startswith("INVALID_"):
                _q_exist = self.profile_get_by_dn(
                    self.dn,
                    query_filter=f'(&(objectClass=mailList)(mail={self.mail}))',
                    attributes=['mail'],
                )
                ldap_entry_exists = bool(_q_exist[0])

            if profile_type == 'general':
                for k, v in payload.items():
                    if k in ["accessPolicy", "accountStatus"]:
                        if ldap_entry_exists:
                            mod_attrs += self.mod_replace(k, payload[k])
                        else:
                            # NOTE: Fallback: si no hi ha objecte LDAP, enviem també a API.
                            args[k] = payload[k]
                    else:
                        args[k]= v

            elif profile_type == 'aliases':
                if "shadowAddress" in payload:
                    raw_extra = payload.get("shadowAddress", {}).get("add", "")
                    extra_addresses = utils._normalize_list_mails(raw_extra)

                    allowed_domains = {str(self.domain or "").strip().lower()}
                    qr_aliases = lib_domain.Domain(self.domain).get_domain_aliases()
                    if qr_aliases[0] and isinstance(qr_aliases[1], list):
                        allowed_domains.update([str(d).strip().lower() for d in qr_aliases[1] if d])

                    # NOTE: Només permetem shadowAddress del domini principal i dels seus aliases.
                    filtered_extra_addresses = [
                        addr for addr in extra_addresses
                        if str(addr).split("@", 1)[-1].lower() in allowed_domains
                    ]

                    if ldap_entry_exists:
                        mod_attrs += self.mod_replace("shadowAddress", filtered_extra_addresses)
                    args['extra_addresses'] = filtered_extra_addresses

            elif profile_type == 'members':
                errors = self._update_members(payload)
                msg.update(errors)

            elif profile_type == 'owners':
                for k, v in payload.items():
                    # NOTE: Si NO és dict → còpia directa
                    if not isinstance(v, dict):
                        args[k] = v
                        continue
                    # NOTE: És dict → tractar add/remove
                    add = v.get("add", "")
                    remove = v.get("remove", "")
                    # NOTE: Si tots buits → ometre (no aplicar)
                    if not add and not remove:
                        continue
                    args[k] = add

            elif profile_type == 'newsletter':
                if ldap_entry_exists:
                    self.add_or_remove_attr_values_by_dn(
                        dn=self.dn,
                        attr='enabledService',
                        values='newsletter',
                        action='add' if 'is_newsletter' in payload else 'remove'
                    )
                args['enable_newsletter_subscription'] = "yes" if 'is_newsletter' in payload else "no"
                if "description"in payload:
                    if ldap_entry_exists:
                        mod_attrs += self.mod_replace("description", payload["description"])
                    else:
                        args["description"] = payload["description"]

            if ldap_entry_exists and mod_attrs:
                try:
                    self.conn.modify_s(self.dn, mod_attrs)
                except Exception as e:
                    msg['update_profile modify_s'] = repr(e)

            qr = MailList_API(domain=self.domain, mail=self.mail).update(args)
            if not qr[0]:
                msg['MailList_API().update()'] = repr(qr[1])

            if ldap_entry_exists:
                qr = self._sync_profile()
                if not qr[0]:
                    msg['sync'] = repr(qr[1])

            if not msg:
                log_activity(event='update',
                    admin=session.get('username'),
                    username=self.mail,
                    domain=self.domain,
                    msg=f'Update maillist profile ({profile_type}): {self.mail}.',
                    )
                return (True,'UPDATED')
            return (False, repr(msg))

        def add(self, payload: dict):
            args, new_mail = self._prepare_add_args(payload)

            qr = MailList_API(domain=self.domain, mail=new_mail).create(args)
            if not qr[0]:
                return qr
            lib_domain.Domain(self.domain).num_maillists_under_domain(increase=True)
            return (True, 'CREATED')

        def delete(self, mails: Union[List[str], None], archive: Literal['yes', 'no'] = 'yes') -> Tuple[bool, str]:
            if not mails:
                return (False, 'NO_ACCOUNT_SELECTED')

            deleted, errors = self._delete_maillists_api(mails, archive=archive)

            if deleted > 0:
                lib_domain.Domain(self.domain).num_maillists_under_domain(decrease=True , step_number=deleted)
            if errors:
                return (False, repr(errors))
            return (True, f"DELETED{'_WITHOUT_ARCHIVE' if archive != 'yes' else ''}")

        def enable_or_disable_accounts(self, mails: List[str], action: Literal["enable", "disable"]) -> Tuple[bool, str]:
            """
                Activa o desactiva comptes de correu.
                Retorna: (success: bool, message: str)
            """
            if not mails:
                return (False, "NO_ACCOUNT_SELECTED")

            return self.enable_disable_accounts(mails, action, 'maillist')

        @LibDecorators.safe_ldap_method
        def _get_newsletter_profile_by_ml_id(self, ml_id ):
            _filter = f'(&(objectClass=mailList)(mailingListID={ml_id}))'

            qr = self.conn.search_s(
                settings.ldap_basedn,
                ldap.SCOPE_SUBTREE,
                _filter,
                self.attrlist_all
            )
            if not qr:
                return (False, "NO_SUCH_ACCOUNT_WITH_ID")

            _dn, _ldif = qr[0]
            return (True, _ldif)

        def get_newsletter_subscription(self, ml_id ):
            """Obté la informació del newsletter (mailList) a partir del seu ID LDAP."""
            ok, data, *rest = self._get_newsletter_profile_by_ml_id(ml_id)
            if not ok or not data:
                return (False, "NOT_FOUND")

            # NOTE: Extract data amb seguretat
            description = data.get('description', [''])[0] if isinstance(data.get('description'), list) else data.get('description', '')
            enabled_services = data.get('enabledService', [])
            account_status = data.get('accountStatus', [''])[0] if isinstance(data.get('accountStatus'), list) else data.get('accountStatus', '')
            newsletter_enabled = 'newsletter' in enabled_services and account_status == 'active'

            return (True, {
                'description': description,
                'newsletter_enabled': newsletter_enabled,
                'name':data.get("cn")[0]
            })

        def post_newsletter_subscription(self, subscriber, kind, ml_id):
            from email.mime.text import MIMEText
            from email.utils import formataddr

            try:
                if not subscriber:
                    return (False, "INVALID_MAIL")

                ok, data, *rest = self._get_newsletter_profile_by_ml_id(ml_id)
                if not ok:
                    return (False, data )

                mail = data.get('mail', [None])[0]
                if not mail:
                    return (False, "INVALID_MAIL")
                return self._post_newsletter_common(
                    subscriber=subscriber,
                    kind=kind.lower(),
                    mail=mail,
                    ml_id=ml_id,
                )
            except Exception as e:
                return (False, repr(e))

else:
    raise RuntimeError(f"Backend not supported: {settings.backend}")

TABLE = 'newsletter_subunsub_confirms'
EXPIRE_AFTER = 86400  # NOTE: 24 h

class ConfirmManager:
    @staticmethod
    def _normalize_ids(ids):
        """Normalize ids used in IN clauses to avoid SQL string interpolation."""
        norm = []
        for v in (ids or []):
            try:
                iv = int(v)
            except Exception:
                continue
            if iv > 0:
                norm.append(iv)
        return tuple(sorted(set(norm)))

    @staticmethod
    def create(mail, mlid, subscriber, kind):
        token = secrets.token_urlsafe(32)
        now = int(time.time())
        expired = now + EXPIRE_AFTER

        web.conn_iredadmin.insert(
            TABLE,
            mail=mail,
            mlid=mlid,
            subscriber=subscriber,
            kind=kind,
            token=token,
            expired=expired)
        return token

    # NOTE: --- Getters -------------------------------------------------
    @staticmethod
    def get_by_token(token):
        now = int(time.time())
        row = web.conn_iredadmin.select(
            TABLE, 
            where="token=$token AND expired>$now",
            vars=dict(token=token, now=now))
        return row[0] if row else None

    @staticmethod
    def get_by_ids(ids: list[int]):
        """Obté múltiples registres per ID."""
        ids_norm = ConfirmManager._normalize_ids(ids)
        if not ids_norm:
            return []
        return list(
            web.conn_iredadmin.select(
                TABLE,
                where="id IN $ids",
                vars={'ids': ids_norm},
            )
        )

    @staticmethod
    def get_queue_by_mail(mail:str, include_expired: bool = False) -> Tuple[bool, Any]:
        """
            Retorna la cua de confirmacions associada a un mail.
            Si include_expired=False (per defecte), només inclou les actives.
        """
        now = int(time.time())
        try:
            where_clause = "mail=$mail"
            vars_dict = {"mail": mail}
            if not include_expired:
                where_clause += " AND expired > $now"
                vars_dict["now"] = now

            results = web.conn_iredadmin.select(
                TABLE, 
                where=where_clause,
                vars=vars_dict
            ) 
            return (True, [dict(row) for row in results])
        except Exception as e:
            return (False, repr(e))

    @staticmethod
    def exists_pending(mail: str, subscriber: str, kind: str) -> bool:
        """
            Comprova si ja existeix una confirmació pendent (no expirada)
            per aquest mail/subscriber/kind.
        """
        now = int(time.time())
        rows = web.conn_iredadmin.select(
            TABLE,
            where="mail=$mail AND subscriber=$subscriber AND kind=$kind AND expired>$now",
            vars=dict(mail=mail, subscriber=subscriber, kind=kind, now=now),
        )
        return len(rows) > 0

    # NOTE: --- Modificadors --------------------------------------------
    @staticmethod
    def mark_expired(token):
        web.conn_iredadmin.update(TABLE, where="token=$token", vars=dict(token=token), expired=0)

    @staticmethod
    def purge_expired():
        """
            NOTE: Edita el crontab de l’usuari `iredadmin` o `root`:
            ```
            sudo crontab -e
            ```
            ```bash
            # Purga confirmacions caducades cada 24 hores
                0 */24 * * * python3 /opt/iredadmin/tools/purge_expired_confirms.py >/dev/null
            ```
            crea /opt/iredadmin/tools/purge_expired_confirms.py amb:
            
            ```python
            #!/usr/bin/env python3
            #
            # Author: Angel <cuquet@gmail.com>
            # Purpose: Purge expired records from SQL table "newsletter_subunsub_confirms"
            #          to keep the confirmation queue clean.
            #

            import os
            import sys
            import time

            os.environ['LC_ALL'] = 'C'

            rootdir = os.path.abspath(os.path.dirname(__file__)) + '/../'
            sys.path.insert(0, rootdir)

            import web
            from tools import ira_tool_lib

            # Setup
            web.config.debug = ira_tool_lib.debug
            logger = ira_tool_lib.logger
            conn = ira_tool_lib.get_db_conn('iredadmin')

            # Constants
            TABLE = 'newsletter_subunsub_confirms'

            def purge_expired():
                now = int(time.time())
                try:
                    n = conn.delete(TABLE, where="expired < $now", vars={'now': now})
                    logger.info(f"Purged {n} expired confirmation records from {TABLE}.")
                except Exception as e:
                    logger.error(f"Error purging expired confirmations: {repr(e)}")

            if __name__ == '__main__':
                purge_expired()

            ```
        """
        now = int(time.time())
        web.conn_iredadmin.delete(TABLE, where="expired < $now", vars={'now': now})

    @staticmethod
    def delete_by_ids(ids: list[int]):
        ids_norm = ConfirmManager._normalize_ids(ids)
        if not ids_norm:
            return (False, "No IDs provided")
        web.conn_iredadmin.delete(
            TABLE,
            where="id IN $ids",
            vars={'ids': ids_norm},
        )
        return (True, "DELETED_QUEUE") #f"Deleted {len(ids)} records")

    @staticmethod
    def delete_all(mail):
        web.conn_iredadmin.delete(TABLE, where="mail=$mail", vars={'mail': mail})
        return (True, "DELETED_QUEUE_ALL")

    @staticmethod
    def delete_expired(mail):
        now = int(time.time())
        web.conn_iredadmin.delete(TABLE, where="mail=$mail AND expired<$now", vars=dict(mail=mail, now=now))
        return (True, "DELETED_QUEUE_EXPIRED")

    # NOTE: --- Accions -------------------------------------------------
    @staticmethod
    def post_record(record):
        """Executa una acció de 'subscribe' o 'unsubscribe' i marca com expirat."""
        mail, kind, subscriber = record.mail, record.kind, record.subscriber
        domain = mail.split('@', 1)[-1]

        api = MailList_API(domain=domain, mail=mail)
        fn = api.add_subscribers if kind == "subscribe" else api.remove_subscribers
        ok, *rest = fn([subscriber])

        if ok:
            ConfirmManager.mark_expired(record.token)
            return (True, f"{subscriber} {kind} success")
        return (False, rest[0] if rest else "UNKNOWN_ERROR")

    @staticmethod
    def post_records(records):
        results = [ConfirmManager.post_record(r) for r in records]
        oks = sum(1 for r in results if r[0])
        return (True, f"Posted {oks}/{len(records)} successfully")

class MailList_API():
    def __init__(self, domain = None, mail= None ):
        self.mail = mail
        self.domain = domain
        self.api_base_url = '' #'http://127.0.0.1:{0}/api'.format(settings.listen_port)
        self.api_auth_token = settings.mlmmjadmin_api_auth_token
        self.api_headers = ''
        self.api_url = ''
        self.api_subscriber_url = ''
        self.verify_ssl = False
        self.func_init()

    def func_init(self):
        if self.api_auth_token:
            self.api_headers = {settings.MLMMJADMIN_API_AUTH_HEADER: self.api_auth_token}
            self.api_base_url = settings.MLMMJADMIN_API_BASE_URL
            self.verify_ssl = settings.MLMMJADMIN_API_VERIFY_SSL
            self.api_url = self.api_base_url + '/' + self.mail
            self.api_subscriber_url = self.api_base_url + '/subscriber/' + self.mail

    def info(self):
        r = requests.get(self.api_url, headers=self.api_headers, verify=self.verify_ssl)
        _json = r.json()
        if _json['_success']:
            for (k, v) in list(_json['_data'].items()):
                if k in ['footer_text', 'footer_html', 'name', 'subject_prefix']:
                    v = v.encode('utf-8')

            return (True, list(_json['_data'].items()))
        else:
            return (False, 'Error: {0}'.format(_json['_msg']))

    def create(self, args):
        # NOTE: args ha de ser un dic {} -> args[k]=v
        r = requests.post(self.api_url, data=args, headers=self.api_headers, verify=self.verify_ssl)
        _json = r.json()
        if _json['_success']:
            return (True, )
        else:
            return (False, 'Error: {0}'.format(_json['_msg']))

    def delete(self, args):
        # NOTE: args ha de ser un dic {} -> args[k]=v
        api_url = self.api_url + '?' + urlencode(args)
        r = requests.delete(api_url, headers=self.api_headers, verify=self.verify_ssl)
        _json = r.json()
        if _json['_success']:
            if args.get('archive') in ['yes', None]:
                return (True, 'Removed {0} (archived).'.format(self.mail))
            else:
                return (True,'Removed {0} (without archive).'.format(self.mail))
        else:
            return (False, 'Error: {0}'.format(_json['_msg']))

    def update(self, args):
        # NOTE: args ha de ser un dic {} -> args[k]=v
        r = requests.put(self.api_url, data=args, headers=self.api_headers, verify=self.verify_ssl)
        try:
            _json = r.json()
        except json.errors.JSONDecodeError:
            # NOTE: Mostrar el contingut real del servidor per depuració
            return (False, f"Resposta no vàlida del servidor: {r.text}")

        # NOTE: Comprovem si la resposta indica èxit
        if _json.get('_success'):
            return (True, )
        else:
            return (False, 'Error: {0}'.format(_json.get('_msg', 'Sense missatge')))

    # NOTE: Comprova si la llista de correu té aquest subscriptor.
    def has_subscriber(self, _subscriber):
        url = self.api_url  + '/has_subscriber/' + _subscriber
        r = requests.get(url, headers=self.api_headers, verify=self.verify_ssl)
        _json = r.json()
        if _json['_success']:
            return (True, )
        else:
            if '_msg' in _json:
                return (False, 'Error: {0}'.format(_json['_msg']))
            else:
                return (False, )

    # NOTE: Show all subscribers
    def subscribers(self, ):
        url = self.api_url   + '/subscribers'
        r = requests.get(url, headers=self.api_headers, verify=self.verify_ssl)
        _json = r.json()
        if _json['_success']:
            subscribers  = []
            for i in _json['_data']:
                # subscribers.append((i['mail'], i['subscription']))
                subscribers.append(i['mail'])
            return (True, subscribers)         
        else:
            return (False, 'Error: {}'.format(_json['_msg']))

    # NOTE: Show all subscribed lists of a given subscriber.
    def subscribed(self, query_all_lists: bool = True):
        if not self.api_subscriber_url:
            return (False, 'No subscriber specified.')
        url = self.api_subscriber_url + '/subscribed'
        if query_all_lists:
            url += '?' + 'query_all_lists=yes'
        try:
            r = requests.get(url, headers=self.api_headers, verify=self.verify_ssl)
            _json = r.json()
        except Exception as e:
            return (False, f'Error: {e}')

        if _json.get('_success'):
            mails = []
            for i in _json.get('_data', []):
                mail = i.get('mail') if isinstance(i, dict) else None
                if mail:
                    mails.append(mail)
            return (True, mails)
        return (False, 'Error: {}'.format(_json.get('_msg')))

    # NOTE: Add new subscribers to mailing list.
    def add_subscribers(self, args):
        arg_kvs = {}
        _subscribers = set([str(i).lower() for i in args if is_email(i)])
        if not _subscribers:
            #return (True, 'Error add_subscribers: No subscribers given.')
            return (False, 'Error add_subscribers: No subscribers given.')

        url = self.api_url + '/subscribers'

        arg_kvs['add_subscribers'] = ','.join(_subscribers)
        r = requests.post(url, data=arg_kvs, headers=self.api_headers, verify=self.verify_ssl)
        _json = r.json()
        if _json['_success']:
            return (True,)
        else:
            return (False, 'Error add_subscribers: {}'.format(_json['_msg']))

    # NOTE: Elimina subscriptors existents de la llista de correu.
    def remove_subscribers(self, args):
        # NOTE: Convert args to a dict
        arg_kvs = {}
        # for arg in args:
        #     if '=' in arg:
        #         (k, v) = arg.split('=', 1)
        #         arg_kvs[k] = v
        _subscribers = set([str(i).lower() for i in args if is_email(i)])
        if not _subscribers:
            #return (True, 'Error remove_subscribers: No subscribers given.')
            return (False, 'Error remove_subscribers: No subscribers given.')

        url = self.api_url + '/subscribers'
        arg_kvs['remove_subscribers'] = ','.join(_subscribers)
        r = requests.post(url, data=arg_kvs, headers=self.api_headers, verify=self.verify_ssl)
        _json = r.json()
        if _json['_success']:
            return (True,)
        else:
            return (False, 'Error remove_subscribers: {}'.format(_json['_msg']))
