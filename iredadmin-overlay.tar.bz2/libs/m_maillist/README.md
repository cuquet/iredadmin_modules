# Mòdul `m_maillist`

Capa de negoci de mailing lists (mlmmj).

Inclou:

- CRUD de mailing lists (SQL i LDAP)
- sincronitzacio amb mlmmjadmin API (`MailList_API`)
- flux de newsletter subscribe/unsubscribe amb confirmacio per token
- cua de confirmacions (`newsletter_subunsub_confirms`)

## Components principals

- `libs/m_maillist/ml.py`
- `class MailList` (implementacio per backend)
- `class MailList_API` (client HTTP cap a mlmmjadmin)
- `class ConfirmManager` (gestio de tokens pendents)

## Integracio UI

Rutes de `controllers/m_maillist/urls.py`:

- `GET/POST /ml/<domain>`
- `GET/POST /profile/ml/<general|aliases|members|owners|newsletter>/<mail>`
- `GET/POST /create/ml[/<domain>]`
- `POST /profile/ml/queue/<mail>`
- `GET/POST <NEWSLETTER_BASE_URL>/<subscribe|unsubscribe>/<ml_id>`
- `GET <NEWSLETTER_BASE_URL>/confirm?token=...`

## Integracio API REST

Rutes de `api/maillist/urls.py`:

- `GET /api/mls/<domain>`
- `GET /api/ml/<mail>`
- `POST /api/ml/<mail>`
- `PUT /api/ml/<mail>`
- `DELETE /api/ml/<mail>`

## Flux de newsletter (confirmacio)

1. Usuari envia formulari a `<NEWSLETTER_BASE_URL>/<subscribe|unsubscribe>/<ml_id>`.
2. Es resol la llista per `ml_id` i es validen flags newsletter.
3. Si la confirmacio esta desactivada a mlmmj (`disable_subscription_confirm=yes`), s'aplica l'accio directament.
4. Si cal confirmacio, es crea registre a `newsletter_subunsub_confirms` i s'envia email amb token.
5. `GET <NEWSLETTER_BASE_URL>/confirm?token=...` executa `add_subscribers()` o `remove_subscribers()`.
6. El token queda invalidat (`expired=0`).

## SQL queue de confirmacions

Taula: `newsletter_subunsub_confirms` (snippets a `SQL/snippets/newsletter_subunsub_confirms.*`).

Camps principals:

- `mail`
- `mlid`
- `subscriber`
- `kind` (`subscribe` / `unsubscribe`)
- `token`
- `expired` (unix timestamp)

Indexos destacats:

- unic: `(mlid, subscriber, kind)`
- indexos per `mail`, `token`, `expired`

## Configuracio rellevant

`libs/default_settings.py`:

- `NEWSLETTER_BASE_URL`
- `MLMMJADMIN_API_BASE_URL`
- `MLMMJADMIN_API_AUTH_HEADER`
- `MLMMJADMIN_API_VERIFY_SSL`

i `settings.py`:

- `mlmmjadmin_api_auth_token`

## Manteniment

Neteja de tokens caducats:

- script existent: `tools/purge_expired_confirms.py`
- alternativa: `ConfirmManager.purge_expired()`

Exemple cron:

```bash
0 */24 * * * python3 /opt/www/iredadmin/tools/purge_expired_confirms.py >/dev/null
```

## Documentacio ampliada

Per detalls tecnics (mapatge de profile types, API mlmmjadmin, taules i flux intern), consulta:

- `libs/m_maillist/README.technical.md`

# 📦 Llicència
Aquest projecte s’ofereix sota la llicència [MIT](https://choosealicense.com/licenses/mit/). Pots modificar-lo, distribuir-lo i integrar-lo lliurement.

# 🤝 Contribucions
Les contribucions són benvingudes! Si tens idees, millores o correccions, obre un issue o envia un pull request.
[![PayPal - Donate](https://img.shields.io/badge/PayPal-Donate-005EA6?logo=paypal&logoColor=white)](https://www.paypal.me/cuquet74)
