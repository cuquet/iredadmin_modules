# libs/m_iredapd/greylist.py
from typing import Tuple, Dict, List, Any, Optional

import settings

from libs.m_iredapd import iRedAPDWrap
from libs.m_system.mixins import iRedAPDMixin
from libs.m_system.decorators import LibDecorators
from libs.m_system.mixins import SQLWhereBuilder

# Wrappers simples
def update_greylisting(account: str, payload) -> Tuple[bool, str]:
    """
        🔧 Actualitza la configuració global de greylisting a partir d’un formulari.

        Args:
            form (dict): Dades rebudes del formulari web o API.

        Returns:
            tuple: (True/False, missatge)
    """
    gl = Greylisting(account=account)
    account_type = gl.is_valid_amavisd_address(account)
    if not account_type in ['email', 'domain', 'catchall']:
        return False, 'INVALID_ACCOUNT'
    errors = []

    # 1️⃣ Activació/desactivació
    _status = payload.get('greylisting', 'inherit')
    actions = {
        "inherit": lambda: gl.delete_greylist_setting(),
        "enable":  lambda: gl.enable_disable_greylist_setting(enable=True),
        "disable": lambda: gl.enable_disable_greylist_setting(enable=False),
    }
    ok, msg, *rest = actions[_status]()
    if not ok:
        errors.append(f"⚠️ Error actualitzant estat greylisting: {msg}")

    # 2️⃣ Dominis whitelist
    if payload.get("whitelist_domains"):
        if payload["whitelist_domains"]["add"]:
            ok, msg, *rest = gl.reset_greylist_whitelists("global", payload["whitelist_domains"]["add"])
        else:
            ok, msg, *rest = gl.remove_greylist_whitelists("global", payload["whitelist_domains"]["remove"])
        if not ok:
            errors.append(f"⚠️ Error actualitzant dominis whitelist: {msg}")

    # 3️⃣ Remitents whitelist (IPs, correus, dominis @) SPF
    if payload.get("whitelists"):
        if payload["whitelists"]["add"]:
            ok, msg, *rest = gl.reset_greylist_whitelists_spf_domain(payload["whitelists"]["add"])
        else:
            ok, msg, *rest = gl.remove_greylist_whitelists_spf_domain(payload["whitelists"]["remove"])
        if not ok:
            errors.append(f"⚠️ Error afegint remitents whitelist: {msg}")

    # 4️⃣ Retorn final
    if errors:
        return (False, f'Update_greylisting(), "account"={account} : ' + ' | '.join(errors))
    return (True, 'UPDATED')

def get_greylisting(account: str) -> Tuple[bool, Dict[str, Any]]:
    """
        Retorna els paràmetres de greylisting per un compte.

        Format retornat:
        (
            ok: bool,
            {
                "setting": ...,
                "spf_domains": [...],
                "whitelists": [...],
                "errors": [ ... ]  # opcional
            }
        )
    """
    errors: List[str] = []
    gl = Greylisting(account)

    def _fetch(fn, label):
        ok, data, *rest = fn()
        if ok:
            return data
        errors.append(f"Failed greylisting {label}: {data}")
        return []

    result: Dict[str, Any] = {
        "setting":      _fetch(gl.get_greylist_setting,                 "setting"),
        "spf_domains":  _fetch(gl.get_greylist_whitelists_spf_domain,   "spf_domains"), 
        "whitelists":   _fetch(gl.get_greylist_whitelists,              "whitelists"),
    }

    if errors:
        result["errors"] = errors
        return(False, result)

    return (True, result)

class Greylisting(iRedAPDWrap, iRedAPDMixin):
    def __init__(self, account=''):
        super().__init__()
        self.account = self.safe_lower(account)
        self.account_type = False
        self.sql_where = ''
        self.vars = {}
        self.func_init()

    def func_init(self):
        if self.account and self.account != 'all':
            self.account_type = self.is_valid_amavisd_address(self.account)
            if not self.account_type:
                return False, 'INVALID_ACCOUNT'
            self.vars['account'] = self.account
            self.sql_where = 'account = $account'

    def _build_where(self, extra_sender=None):
        """
            Helper per preparar sql_where i vars sense modificar els originals.
        """
        # where_clauses = []
        # where_clauses.append("account=$account")
        # where_clauses.append("sender=$sender")
        # where = " AND ".join(where_clauses) if where_clauses else None
        sql_where = self.sql_where
        vars_ = dict(self.vars)
        if extra_sender:
            sql_where += " AND sender=$sender"
            vars_['sender'] = extra_sender
        return sql_where, vars_

    @staticmethod
    def _map_active_to_status(record_or_list):
        """
            Converteix camp 'active' (0/1) → 'status' (enabled/disabled).
            Si no hi ha dades, retorna status='inherit'.
        """
        def _convert(rec):
            if 'active' not in rec:
                return {**rec, 'status': 'inherit'}
            return {
                **{k: v for k, v in rec.items() if k != 'active'},
                'status': 'enabled' if str(rec['active']) == '1' else 'disabled'
            }

        if isinstance(record_or_list, dict):
            return _convert(record_or_list)
        elif isinstance(record_or_list, (list, tuple)):
            return [_convert(r) for r in record_or_list]
        else:
            return {"status": "inherit"}

    @LibDecorators.safe_sql_method
    def get_greylist_setting(self):
        """
            Retorna configuració greylisting segons el compte:
            - Si self.account == 'all' → tots els registres.
            - Si és domini/usuari → un registre o 'inherit' si no existeix.
        """

        if self.account == 'all':
            qr = self.db.select('greylisting', what='id, account, sender, active')
        elif self.account_type:
            qr = self.db.select(
                'greylisting',
                vars=self.vars,
                what='id, account, sender, active',
                where=self.sql_where,
                limit=1
            )
        else:
            # No hi ha cap configuració pròpia → "inherit"
            qr = []

        return True, self._map_active_to_status(list(qr))

    @LibDecorators.safe_sql_method
    def delete_greylist_setting(self):
        """
            Només elimina els registres del compte però mai el registre base @.
        """
        if not self.account_type:
            return False, 'INVALID_ACCOUNT'

        sql_where, vars_ = self._build_where('@.')
        
        # 🚫 No eliminar el registre base global
        if self.account == '@.':
            return True, {"account": self.account, "status": "inherit", "note": "base record preserved"}

        self.db.delete(
            'greylisting',
            vars=vars_,
            where=sql_where
        )
        self.func_init()
        return True, {"account": self.account, "status": "inherit"}

    @LibDecorators.safe_sql_method
    def enable_disable_greylist_setting(self, enable=False):
        if not self.account_type:
            return False, 'INVALID_ACCOUNT'

        active = 1 if enable else 0

        gl_setting = {
            'account': self.account,
            'priority': self.get_account_priority(self.account),
            'sender': '@.',
            'sender_priority': 0,
            'active': active}

        sql_where, vars_ = self._build_where(gl_setting['sender'])
        self.db.delete(
            'greylisting',
            vars=vars_,
            where=sql_where)

        self.db.insert('greylisting', **gl_setting)
        self.func_init()

        return True, self._map_active_to_status(gl_setting)

    @LibDecorators.safe_sql_method
    def get_greylist_whitelists(self, account_type=None):
        """
            Obté whitelists segons tipus.
            - global/all: retorna whitelist_domains
            - domain/user: retorna whitelists
        """
        _account_type = account_type or self.account_type

        if _account_type in ('global', 'all', 'catchall'):
            qr = self.db.select(
                'greylisting_whitelist_domains',
                what='domain',
                order='domain'
            )
            #data = {'whitelist_domains': [str(i.domain).lower() for i in qr]}
            data = [str(i.domain).lower() for i in qr]
            return (True, data)

        if _account_type in ('domain', 'user', 'email'):
            qr = self.db.select(
                'greylisting_whitelists',
                vars=self.vars,
                what='id, sender, comment',
                where=self.sql_where,
                order='sender'
            )
            #data = {'whitelists': list(qr)}
            data = list(qr)
            return (True, data)

        return (False, f"Invalid account_type: {account_type}")

    @LibDecorators.safe_sql_method
    def reset_greylist_whitelists(self, account_type, senders):
        """Reemplaça whitelists existents per la nova llista."""
        sender_list = self._normalize_list_domains_ips(senders)

        if account_type in ('global', 'all', 'catchall'):
            self.db.delete('greylisting_whitelist_domains', where="1=1")
            data = [{'domain': dom} for dom in sender_list]
            self.db.multiple_insert('greylisting_whitelist_domains', data)
        else:
            self.db.delete('greylisting_whitelists', where=self.sql_where, vars=self.vars)
            data = [{'account': self.account, 'sender': s} for s in sender_list]
            self.db.multiple_insert('greylisting_whitelists', data)
        ok, updated, *rest = self.get_greylist_whitelists(account_type)

        return (True, updated)

    @LibDecorators.safe_sql_method
    def add_greylist_whitelists(self, account_type, senders):
        """
            Afegeix nous remitents a la whitelist evitant duplicats.
        """
        sender_list = self._normalize_list_domains_ips(senders)
        for sender in map(lambda s: s.strip().lower(), sender_list):
            if account_type in ('global', 'all'):
                # Comprovar si ja existeix
                exists = self.db.select(
                    'greylisting_whitelist_domains',
                    what='id',
                    where='domain = $domain',
                    vars={'domain': sender}
                )
                if not exists:
                    self.db.insert(
                        'greylisting_whitelist_domains',
                        domain=sender
                    )

            elif account_type in ('domain', 'user'):
                self.sql_where += " AND sender=$sender"
                self.vars['sender'] = sender
                exists = self.db.select(
                    'greylisting_whitelists',
                    what='id',
                    where=self.sql_where,
                    vars=self.vars
                )
                if not exists:
                    self.db.insert(
                        'greylisting_whitelists',
                        account=self.account,
                        sender=sender,
                        comment=''
                    )
        ok, updated, *rest = self.get_greylist_whitelists(account_type)

        return (True, updated)

    @LibDecorators.safe_sql_method
    def remove_greylist_whitelists(self, account_type, senders):
        """
            Elimina remitents de la whitelist.
        """
        senders_norm = tuple(s.lower() for s in self._normalize_list_domains_ips(senders))

        if account_type in ('global', 'all') and senders_norm:
            self.db.delete(
                'greylisting_whitelist_domains',
                where='domain IN $domains',
                vars={'domains': senders_norm}
            )

        elif account_type in ('domain', 'user') and senders_norm:
            self.sql_where += " AND sender IN $senders"
            self.vars['senders'] = senders_norm
            self.db.delete(
                'greylisting_whitelists',
                where=self.sql_where,
                vars=self.vars
            )
        ok, updated, *rest = self.get_greylist_whitelists(account_type)

        return (True, updated)

    @LibDecorators.safe_sql_method
    def get_greylist_whitelists_spf_domain(self, sender=None):
        sql_where, vars_ = self._build_where(sender)
        results = self.db.select(
            'greylisting_whitelist_domain_spf',
            where=sql_where,
            vars=vars_,
            order='account, sender'
        )

        return (True, [dict(r) for r in results])

    @LibDecorators.safe_sql_method
    def reset_greylist_whitelists_spf_domain(self, domains):
        _domains = self._normalize_list_senders_comments(domains)
        self.db.delete('greylisting_whitelist_domain_spf', where=self.sql_where, vars=self.vars)

        data = [{'account': self.account, 'sender': d['sender'], 'comment': d['comment']} for d in _domains]
        if data:
            self.db.multiple_insert('greylisting_whitelist_domain_spf', data)

        return (True, {'domains': _domains})

    @LibDecorators.safe_sql_method
    def add_greylist_whitelists_spf_domain(self, domains):
        _domains = self._normalize_list_senders_comments(domains)
        added = []
        for d in _domains:
            sql_where, vars_ = self._build_where(d['sender'])
            existing = self.db.select(
                'greylisting_whitelist_domain_spf',
                where=sql_where,
                vars=vars_
            )
            if not existing:
                self.db.insert(
                    'greylisting_whitelist_domain_spf',
                    account=self.account,
                    sender=d['sender'],
                    comment=d['comment']
                )
                added.append(d)

        return (True, {'addDomains': added})

    @LibDecorators.safe_sql_method
    def remove_greylist_whitelists_spf_domain(self, domains):
        _domains = self._normalize_list_senders_comments(domains)
        removed = []
        for d in _domains:
            sql_where, vars_ = self._build_where(d['sender'])
            deleted_count = self.db.delete(
                'greylisting_whitelist_domain_spf',
                where=sql_where,
                vars=vars_
            )
            if deleted_count:
                removed.append(d)

        return (True, {'removeDomains': removed})

    @LibDecorators.safe_sql_method
    def get_tracking_data(self, page:int=1,payload:Optional[Dict[str, Any]] = None)-> Tuple[bool, dict]:
        """
            Retorna registres de greylisting segons el tipus de compte:
                - email:       filtre per sender=... OR recipient=...
                - domain:      filtre per sender_domain=... OR rcpt_domain=...
                - catchall:@.  sense filtre (retorna tot)
        """
        def normalize_partial_ip(q: str) -> str:
            """
            Si q és una IP parcial amb dígits i punts, afegeix .* fins completar 4 octets.
            Exemples:
                '203' -> '203.*.*.*'
                '203.0' -> '203.0.*.*'
                '203.0.113' -> '203.0.113.*'
                '203.0.113.*' -> '203.0.113.*'
            """
            # Només processar si conté només dígits i punts, amb o sense '*'
            if not all(c.isdigit() or c == '.' or c == '*' for c in q):
                return q

            octets = q.split('.')
            # Compte amb '*'
            octets = [o if o else '*' for o in octets]
            while len(octets) < 4:
                octets.append('*')
            return '.'.join(octets[:4])

        if not self.account_type:
            return (True, [])

        builder = SQLWhereBuilder()

        acc_type = self.account_type   # 'email', 'domain', 'catchall', ...
        acc_value = self.account       # raw account: 'user@dom', '@dom', '@.'

        # 1) FILTRAT segons tipus d’account original
        if acc_type == 'catchall':
            sql_where = None
            sql_vars = {}
        elif acc_type == 'email':
            builder.add_equals("recipient", acc_value)
        elif acc_type == 'domain':
            domain = acc_value.lstrip("@")
            builder.add_equals("rcpt_domain", domain)
        else:
            return (False, 'INVALID_ACCOUNT')

        # 2) FILTRES extra: cerca general q=...
        payload = payload or {}
        q = payload.get("query_string")
        date_from = payload.get("date_from")
        date_to = payload.get("date_to")
        passed = payload.get('passed')

        if q:
            q_normalized = normalize_partial_ip(q)
            addr_type = self.is_valid_amavisd_address(q_normalized)
            # podria ser un domini
            if not addr_type and "." in q: 
                addr_type = self.is_valid_amavisd_address("@" + q)

            if addr_type in ("email",):
                builder.add_or([("sender", q), ("recipient", q)])
            elif addr_type in ("ip", ):
                builder.add_or_like(["client_address"], "%{}%".format(q))
            elif addr_type == "wildcard_ip":
                builder.add_or_like(["client_address"], q_normalized.replace("*", "%"))
            elif addr_type in ("domain", "subdomain", "tld_domain"):
                domain = q.lstrip("@.")
                builder.add_or([
                    ("sender_domain", domain),
                    ("rcpt_domain", domain),
                ])
            else:
                # NOTA: no funciona amb f"%{q}%"
                # pot invocar internament el vell motor de format tipus printf, 
                # i alguns patrons després d’un % activen seqüències especials, 
                # convertint el resultat en caràcters de control (\x19, \x02, etc.).
                # Això passa si el contingut dins {q} acaba formant una seqüència que 
                # Python intenta interpretar com format specifier, encara que estigui 
                # dins una f-string.
                like = "%{}%".format(q)
                builder.add_or_like(
                        ["sender", "recipient", "sender_domain", "rcpt_domain", "client_address"],
                        like
                    )

        # FILTRE D'ESTAT (Greylisting vs Passed)
        # El controller envia '0', '1' o 'all'. Només filtrem si és 0 o 1.
        if passed in ('0', '1'):
            builder.add_equals("passed", int(passed))

        # 3) FILTRE DE DATES
        if date_from or date_to:
            import datetime

            # Convertim les dates a timestamps (epoch)
            ts_from = None
            ts_to = None

            if date_from:
                try:
                    d = datetime.datetime.strptime(date_from, "%Y-%m-%d")
                    ts_from = int(d.replace(hour=0, minute=0, second=0).timestamp())
                except:
                    pass

            if date_to:
                try:
                    d = datetime.datetime.strptime(date_to, "%Y-%m-%d")
                    ts_to = int(d.replace(hour=23, minute=59, second=59).timestamp())
                except:
                    pass

            if ts_from and ts_to:
                builder.add_between("init_time", ts_from, ts_to)
            elif ts_from:
                builder.add("init_time >= $from", "from", ts_from)
            elif ts_to:
                builder.add("init_time <= $to", "to", ts_to)

        sql_where, sql_vars = builder.build()

        total = (self.db.select(
            'greylisting_tracking',
            vars=sql_vars or None,
            what='COUNT(id) AS total',
            where=sql_where or None,
        )[0].total) or 0

        sql_limit = None
        sql_offset = None
        if page > 0:
            sql_limit = settings.PAGE_SIZE_LIMIT
            sql_offset = (page - 1) * settings.PAGE_SIZE_LIMIT

        qr = self.db.select(
            'greylisting_tracking',
            vars=sql_vars or None,
            where=sql_where or None,
            offset=sql_offset,
            limit=sql_limit,
            order='init_time DESC'
        )

        return (True,{
            'total':total, 
            'records': list(qr),
            'page':page,
            })

    @LibDecorators.safe_sql_method
    def delete_tracking_data(self, payload:Optional[Dict[str, Any]] = None, delete_all:bool=False) -> tuple[bool, Optional[str]]:
        builder = SQLWhereBuilder()

        if delete_all:
            # 👈 sense condicions, elimina tot
            self.db.delete('greylisting_tracking', where="1=1")
        else:
            ids = payload.get('id', [])
            if ids:
                builder.add_in("id", ids)

            sql_where, sql_vars = builder.build()
            if sql_where:  # 👈 només elimina si hi ha condicions
                self.db.delete('greylisting_tracking', where=sql_where, vars=sql_vars)

        return (True, 'DELETED')
