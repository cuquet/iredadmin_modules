# libs/m_iredapd/__init__.py
import web
import settings
from libs.logger import log_traceback

# Initialize database connection.
class iRedAPDWrap(object):
    def __del__(self):
        try:
            self.db.ctx.db.close()
        except:
            pass

    def __init__(self):
        if settings.backend == 'pgsql':
            try:
                self.db = web.database(
                    dbn='postgres',
                    host=settings.iredapd_db_host,
                    port=int(settings.iredapd_db_port),
                    db=settings.iredapd_db_name,
                    user=settings.iredapd_db_user,
                    pw=settings.iredapd_db_password)
            except Exception as e:
                log_traceback()
        else:
            try:
                self.db = web.database(
                    dbn='mysql',
                    host=settings.iredapd_db_host,
                    port=int(settings.iredapd_db_port),
                    db=settings.iredapd_db_name,
                    user=settings.iredapd_db_user,
                    pw=settings.iredapd_db_password,
                    charset='utf8')
            except Exception as e:
                log_traceback()

        self.db.supports_multiple_insert = True


