# libs/m_iredapd/smtp.py
import time
from typing import Dict, Any, List, Optional, Tuple

import settings

from libs.m_iredapd import iRedAPDWrap
from libs.m_system.decorators import LibDecorators
from libs.m_system.mixins import SQLWhereBuilder

class SMTPStats(iRedAPDWrap):
    """
        Classe per gestionar les consultes estadístiques de les sessions SMTP
        emmagatzemades a la taula 'smtp_sessions' de la DB iredapd.
        La columna action a la taula smtp_sessions de la base de dades iredapd emmagatzema 
        la resposta final que el servidor de polítiques (iRedAPD) envia a Postfix. 
        Aquestes respostes segueixen el protocol SMTP Access Policy de Postfix.
    """
    def __init__(self) -> None:
        super().__init__()
        self.sql_where = ''
        self.sql_vars = {}

    @LibDecorators.safe_sql_method
    def list(self, page: int = 1, payload: Optional[Dict] = None) -> Tuple[bool, Any]:
        """
            🔍 Llista sessions SMTP aplicant filtres des del payload.
            
            El payload pot incloure:
            - session_type: 'all', 'outbound', 'rejected', 'greylisted'
            - q: cerca per string (IP, sender, recipient, reason)
            - date_from: string de data (YYYY-MM-DD)
        """
        builder = SQLWhereBuilder()
        payload = payload or {}

        session_type = payload.get('session_type', 'all')

        if session_type == 'outbound':
            # Usuaris autenticats que envien correu
            builder.add("sasl_username != ''")
        elif session_type == 'rejected':
            # Errors permanents (5xx)
            builder.add_like("action", "5%")
        elif session_type == 'greylisted':
            # Bloquejos temporals típics del Greylisting
            builder.add_equals("action", "451")
        # 'all' no afegeix cap condició extra d'estat

        query = payload.get('query_string')
        # Cerca general (IP, sender, recipient)
        if query:
            like_val = f"%{query}%"
            builder.add_or_like(['client_address', 'sender', 'recipient', 'reason', 
                'sasl_username', 
                'helo_name'], like_val)

        date_from = payload.get('date_from')
        if date_from:
            try:
                import datetime
                # Convertim la data "YYYY-MM-DD" a l'inici del dia en Unix Timestamp
                dt = datetime.datetime.strptime(date_from, "%Y-%m-%d")
                ts_start = int(dt.replace(hour=0, minute=0, second=0).timestamp())
                builder.add("time_num >= $ts_start", "ts_start", ts_start)
            except Exception:
                pass # Si la data és invàlida, ignorem el filtre

        self.sql_where, self.sql_vars = builder.build()

        total = (self.db.select(
            'smtp_sessions', 
            vars=self.sql_vars,
            what='COUNT(id) AS total', 
            where=self.sql_where or None, 
        )[0].total ) or 0

        sql_limit = None
        sql_offset = None
        if page > 0:
            sql_limit = settings.PAGE_SIZE_LIMIT
            sql_offset = (page - 1) * settings.PAGE_SIZE_LIMIT

        qr = self.db.select(
            'smtp_sessions',
            where=self.sql_where or None,
            vars=self.sql_vars,
            order='time_num DESC',
            limit=sql_limit,
            offset=sql_offset
        )

        return (True, {
            'total': total,
            'records': list(qr),
            'page': page,
            'session_type': session_type
        })

    @LibDecorators.safe_sql_method(no_tuple=True)
    def get_counts(self, days: int = 1) -> Dict[str, int]:
        """
        📊 Calcula el recompte d'enviaments autenticats (outbound) i rebutjats.
        """
        results: Dict[str, int] = {'outbound': 0, 'rejected': 0}

        # 1️⃣ Calculem el timestamp límit (ara mateix - n dies)
        start_timestamp = int(time.time()) - (days * 24 * 60 * 60)

        # Base comuna: filtre per temps usant time_num (indexat i ràpid)
        base_builder = SQLWhereBuilder()
        base_builder.add("time_num >= $start_ts", "start_ts", start_timestamp)

        # 2️⃣ Sessions Outbound: sasl_username != ''
        # Quan sasl_username té valor, és un usuari del sistema enviant correu.
        out_builder = base_builder.clone()
        out_builder.add("sasl_username != ''") 

        where_out, vars_out = out_builder.build()
        qr_out = self.db.select('smtp_sessions', what='COUNT(*) as total', where=where_out, vars=vars_out)
        if qr_out:
            results['outbound'] = int(qr_out[0].get('total', 0))

        # 3️⃣ Rejected Messages: action comença per 5 (errors permanents)
        # Segons el teu dump, action pot ser '451', 'DUNNO', etc.
        # Els rebuigs reals solen ser 5xx.
        rej_builder = base_builder.clone()
        rej_builder.add_like("action", "5%") 

        where_rej, vars_rej = rej_builder.build()
        qr_rej = self.db.select('smtp_sessions', what='COUNT(*) as total', where=where_rej, vars=vars_rej)
        if qr_rej:
            results['rejected'] = int(qr_rej[0].get('total', 0))

        return results

    @LibDecorators.safe_sql_method(no_tuple=True)
    def get_rejection_reasons(self, days: int = 1, limit: int = 5) -> List[Dict[str, Any]]:
        """
        📉 Top de motius de rebuig (columna 'reason').
        """
        start_timestamp = int(time.time()) - (days * 24 * 60 * 60)

        builder = SQLWhereBuilder()
        builder.add("time_num >= $start_ts", "start_ts", start_timestamp)
        builder.add_like("action", "5%")

        self.sql_where, self.sql_vars = builder.build()

        qr = self.db.select(
            'smtp_sessions',
            what='reason, COUNT(*) as total',
            where=self.sql_where,
            vars=self.sql_vars,
            group='reason',
            order='total DESC',
            limit=limit
        )
        return [dict(r) for r in qr]
