# libs/m_iredapd/throttle.py
from libs.iredutils import MAILADDR_PRIORITIES
from libs.m_iredapd import iRedAPDWrap
from libs.m_system.mixins import iRedAPDMixin, Direction
from libs.m_system.decorators import LibDecorators

# condicions de creació 

DEFAULT_DB_THROTTLE = {
    "kind": None,       # inbound/outbound/external
    "priority": 0,
    "period": 86400,
    "max_msgs": -1,
    "max_quota": -1,
    "msg_size": -1,
    "max_rcpts": -1,    # només outbound
}

# Wrappers simples
def get_throttle_setting(account):
    """
        Retorna una tupla (ok, result)
        
        ok = True  → cap error
        ok = False → algun error
        
        result = {
            'inbound':  data | {}
            'outbound': data | {}
            'errors': {
                'inbound': err_msg | None,
                'outbound': err_msg | None
            }
        }
        
        ✅ Cas normal (sense errors):
        (True,
            {
                "inbound":  {...},
                "outbound": {...}
            }
        )
        
        ❌ Cas mixt (inbound error, outbound OK):
        (False,
            {
                "inbound":  {},
                "outbound": {...},
                "errors": {
                    "inbound":  "INVALID_ACCOUNT",
                    "outbound": None
                }
            }
        )
    """
    def _fetch(direction):
        ok, data, *rest = Throttle(account, {}, direction).get_throttle_settings()
        return ok, data

    in_ok, in_data   = _fetch(Direction.INBOUND)
    out_ok, out_data = _fetch(Direction.OUTBOUND)
    ok = in_ok and out_ok

    result = {
        Direction.INBOUND.value:  in_data   if in_ok else {},
        Direction.OUTBOUND.value: out_data  if out_ok else {},
    }
    if not ok:
        result["errors"] = {
            Direction.INBOUND.value:  None if in_ok  else in_data,
            Direction.OUTBOUND.value: None if out_ok else out_data,
        }  

    return (ok, result)

class Throttle(iRedAPDWrap, iRedAPDMixin):
    def __init__(self, account, settings, inout_type=Direction.OUTBOUND):
        """
            Inicialitza l'objecte Throttle per gestionar límits d'enviament o recepció.

            Args:
                account (str): '@.' per global, '@domini.com' per domini, 'usuari@domini.com' per usuari.
                settings (dict): Configuració de límits (max_msgs, max_size, etc.)
                inout_type (str): 'inbound' o 'outbound'
        """
        #iRedAPDWrap.__init__(self)
        super().__init__()
        self.account = self.safe_lower(account)
        self.account_type = self.is_valid_amavisd_address(self.account)
        self.inout_type = self.val_enum(inout_type, Direction) or False
        self.settings = settings or {}
        self.func_init()

    def func_init(self):
        """
            Carrega la configuració actual des de la base de dades si no s'ha passat cap configuració.
            També actualitza el tipus d'entrada/sortida si està definit a la base de dades.
        """
        if not self.account_type:
            return False, 'INVALID_ACCOUNT'
        if not self.inout_type:
            return False, 'INVALID_INOUT_TYPE'
        if not self.settings:
            ok, settings, *rest = self.get_throttle_settings()
            if ok:
                self.settings = settings
                kind = self.settings.get('kind')
                self.inout_type = self.val_enum(kind, Direction) if kind else self.inout_type

    def _get_throttle_id(self):
        """
            Obté l'identificador intern del registre de límit (throttle.id) per aquest compte i tipus.
            
            Retorna:
                int or None
        """
        qr = self.db.select(
            'throttle',
            vars={'account': self.account, 'inout_type': self.inout_type.value},
            where='account=$account AND kind=$inout_type',
            limit=1)
        return qr[0].id if qr else None

    def _normalize_throttle_payload(self):
        """
            🔧 Normalitza la configuració de throttle abans d'inserir/actualitzar.

            - Omple buits amb DEFAULT_DB_THROTTLE
            - Força valors bàsics (account, kind, period, priority)
            - Cas especial catchall '@.' → no pot heretar (-1), si no definit → 0
            - Si no és outbound → elimina max_rcpts
        """
        payload = DEFAULT_DB_THROTTLE.copy()
        payload.update(self.settings or {})

        # Forçar valors bàsics
        payload["account"] = self.account
        payload["kind"] = self.inout_type.value
        payload["priority"] = MAILADDR_PRIORITIES.get(self.account_type, 0) * 10

        # Cas especial: catchall '@.' → no pot heretar
        if self.account == "@.":
            for key in ["max_msgs", "max_quota", "msg_size"]:
                if int(payload.get(key, -1)) < 0:
                    payload[key] = 0

            if self.inout_type == Direction.OUTBOUND:
                if int(payload.get("max_rcpts", -1)) < 0:
                    payload["max_rcpts"] = 0
            else:
                payload.pop("max_rcpts", None)

            return payload

        # Si no és outbound → eliminar max_rcpts
        if self.inout_type != Direction.OUTBOUND:
            payload.pop("max_rcpts", None)

        return payload

    @LibDecorators.safe_sql_method
    def get_throttle_settings(self):
        """
            📥 Obté la configuració de límit per al compte indicat.

            Retorna:
                (True/False, dict amb configuració, meta)
        """
        qr = self.db.select(
            'throttle',
            vars={'account': self.account, 'inout_type': self.inout_type.value},
            where='kind=$inout_type AND account=$account',
            limit=1)
        return True, qr[0] if qr else {}

    @LibDecorators.safe_sql_method
    def update_throttle_settings(self):
        """
            🔄 Crea o actualitza la configuració de límit per al compte.

            Returns:
                (True/False, missatge)
        """
        ok, settings, *rest = self.get_throttle_settings()
        if ok: 
            settings.update(self.settings or {})
        self.settings = settings

        payload = self._normalize_throttle_payload()

        # Comprovar que hi ha algun límit vàlid
        has_limits = any(
            int(payload.get(k, -1)) > -1
            for k in ["max_msgs", "max_quota", "msg_size"]
        ) or (self.inout_type == Direction.OUTBOUND and int(payload.get("max_rcpts", -1)) > -1)

        # Si period no té valor (el camp de la taula és period	int(10) unsigned [0]) o no hi ha límits → eliminar
        if not payload.get("period", 0) and not has_limits :
            self.remove_throttle_tracking()
            self.remove_throttle_settings()
            return True, "NO_LIMITS_DEFINED"

        tid = self._get_throttle_id()
        if tid:
            self.db.update(
                "throttle",
                vars={"tid": tid},
                where="id=$tid",
                **payload
            )
            return True, "UPDATED"
        else:
            self.db.insert("throttle", **payload)
            return True, "CREATED"

    @LibDecorators.safe_sql_method
    def remove_throttle_settings(self):
        """
            🗑️ Elimina la configuració de límit per al compte indicat.

            Retorna:
                (True/False, missatge)
        """
        self.db.delete(
            'throttle',
            vars={'account': self.account, 'inout_type': self.inout_type.value},
            where='account=$account AND kind=$inout_type')
        #self.remove_throttle_tracking()
        return True, 'DELETED'

    @LibDecorators.safe_sql_method(on_error_pass=True)
    def remove_throttle_tracking(self):
        """
            🧹 Elimina el registre de seguiment (tracking) associat al límit del compte.

            Returns:
                (True/False, missatge)
        """

        tid = self._get_throttle_id()
        if tid:
            self.db.delete(
                'throttle_tracking',
                vars={'tid': tid},
                where='tid=$tid')
        return True, 'DELETED'

    @LibDecorators.safe_sql_method
    def create_throttle_settings(self):
        """
            ➕ Crea una nova configuració de límit per al compte.

            Returns:
                (True/False, missatge)
        """
        payload = self._normalize_throttle_payload()

        # Comprovar que hi ha algun límit vàlid
        has_limits = any(
            int(payload.get(k, -1)) > -1
            for k in ["max_msgs", "max_quota", "msg_size"]
        ) or (self.inout_type == Direction.OUTBOUND and int(payload.get("max_rcpts", -1)) > -1)

        if not has_limits:
            return False, "NO_LIMITS_DEFINED"

        # Evitar duplicats
        tid = self._get_throttle_id()
        if tid:
            return False, "ALREADY_EXISTS"

        self.db.insert("throttle", **payload)
        return True, "CREATED"

    @LibDecorators.safe_sql_method
    def remove_throttle_settings_for_removed_users(self, mails):
        """
            🗑️ Elimina configuracions de límit per a usuaris eliminats.

            Args:
                mails (list): Llista d'adreces de correu electrònic

            Returns:
                (True/False, missatge)
        """
        mails = [str(v).lower() for v in mails if self.is_email(v)]
        if not mails:
            return True, 'Cap usuari vàlid'

        self.db.delete(
            'throttle',
            vars={'mails': mails},
            where="account IN $mails")

        self.db.delete(
            'throttle_tracking',
            vars={'mails': mails},
            where="account IN $mails")

        return True, 'Configuracions eliminades per usuaris eliminats'

    @LibDecorators.safe_sql_method
    def remove_throttle_settings_for_removed_domain(self):
        """
            🗑️ Elimina configuracions de límit per a un domini eliminat i els seus usuaris.

            Args:
                domain (str): Nom de domini

            Returns:
                (True/False, missatge)
        """

        self.db.delete(
            'throttle',
            vars={'domain': self.account},
            where='account=$domain')

        self.db.delete(
            'throttle',
            vars={'domain': '%' + self.account},
            where="account LIKE $domain")

        self.db.delete(
            'throttle_tracking',
            vars={'domain': '%' + self.account},
            where="account LIKE $domain")

        return True, 'DELETED'
