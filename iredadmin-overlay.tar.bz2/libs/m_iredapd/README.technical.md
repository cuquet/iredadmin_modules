# m_iredapd Technical Notes

Aquest document conserva i ordena notes tècniques extenses (SQL i comportaments) del mòdul `m_iredapd`.

## Index

- [1. Greylisting iRedAPD](#1-greylisting-iredapd)
- [2. Throttle iRedAPD](#2-throttle-iredapd)
- [3. SMTP](#3-smtp)

# 1. Greylisting iRedAPD
## Inserts SQL d’exemple a Greylisting iRedAPD

📌 _NOTA_: no tinc clar si el sender pot ser '' o '@.' perquè `get_greylist_setting()` sempre filtra aquest sender
```SQL
-- Greylisting principals per melindro.org
INSERT INTO greylisting (account, priority, sender, sender_priority, comment, active)
VALUES
('postmaster@melindro.org', 2, 'friend@example.net', 0, 'Amic personal', 1),
('baldufa@melindro.org', 2, 'vip@example.net', 0, 'Usuari VIP', 1),
('@melindro.org', 1, 'newsletter@example.org', 0, 'Permetre newsletter', 1),
('@melindro.org', 5, '', 0, 'Greylisting per domini', 1),
('postmaster@melindro.org', 10, '', 0, 'Greylisting per usuari', 1),
('baldufa@melindro.org', 10, '', 0, 'Greylisting per usuari', 1);

-- Tracking de connexions greylist
INSERT INTO greylisting_tracking (
    sender,
    recipient,
    client_address,
    sender_domain,
    rcpt_domain,
    init_time,
    block_expired,
    record_expired,
    blocked_count,
    passed
) VALUES
('vip@example.net', 'baldufa@melindro.org', '203.0.113.50', 'example.net', 'melindro.org',
 UNIX_TIMESTAMP(), UNIX_TIMESTAMP() + (15*60), UNIX_TIMESTAMP() + (4*3600), 0, 1),
('spam@example.com', 'postmaster@melindro.org', '198.51.100.99', 'example.com', 'melindro.org',
 UNIX_TIMESTAMP(), UNIX_TIMESTAMP() + (15*60), UNIX_TIMESTAMP() + (4*3600), 2, 0),
('trusted@amic.com', 'postmaster@melindro.org', '1.2.3.4', 'amic.com', 'melindro.org',
 UNIX_TIMESTAMP() - (2*24*3600), UNIX_TIMESTAMP() - (1*24*3600), UNIX_TIMESTAMP() + (30*24*3600), 0, 1),
('unknown@spam.com', 'baldufa@melindro.org', '5.6.7.8', 'spam.com', 'melindro.org',
 UNIX_TIMESTAMP() - (1*3600), UNIX_TIMESTAMP() + (4*3600), UNIX_TIMESTAMP() + (30*24*3600), 2, 0);

-- Llista blanca per remitents
INSERT INTO greylisting_whitelists (account, sender, comment)
VALUES
('postmaster@melindro.org', 'trusted@example.org', 'Remitent de confiança'),
('baldufa@melindro.org', 'vip@example.net', 'Usuari VIP'),
('@melindro.org', 'trusted@amic.com', 'Remitent de confiança per domini'),
('postmaster@melindro.org', 'vip@client.com', 'Remitent de confiança per usuari');

-- Llista blanca per dominis
INSERT INTO `greylisting_whitelist_domains` (`id`, `domain`) VALUES
(1,	'amazon.com'),
(2,	'aol.com'),
(3,	'cloudfiltering.com'),
(4,	'cloudflare.com'),
(48,	'confiança.com'),
(5,	'constantcontact.com'),
(6,	'craigslist.org'),
(7,	'cust-spf.exacttarget.com'),
(8,	'ebay.com'),
(9,	'exacttarget.com'),
(10,	'facebook.com'),
(11,	'facebookmail.com'),
(12,	'fbmta.com'),
(13,	'fishbowl.com'),
(14,	'github.com'),
(15,	'gmx.com'),
(16,	'google.com'),
(17,	'hotmail.com'),
(18,	'icloud.com'),
(19,	'icontact.com'),
(20,	'inbox.com'),
(21,	'instagram.com'),
(22,	'iredmail.org'),
(23,	'linkedin.com'),
(24,	'mail.com'),
(25,	'mailchimp.com'),
(26,	'mailgun.com'),
(27,	'mailjet.com'),
(28,	'messagelabs.com'),
(29,	'microsoft.com'),
(30,	'outlook.com'),
(47,	'partners.net'),
(31,	'paypal.com'),
(32,	'pinterest.com'),
(33,	'reddit.com'),
(34,	'salesforce.com'),
(35,	'sbcglobal.net'),
(36,	'sendgrid.com'),
(37,	'sendgrid.net'),
(38,	'serverfault.com'),
(39,	'stackoverflow.com'),
(46,	'trusted.org'),
(40,	'tumblr.com'),
(41,	'twitter.com'),
(42,	'yahoo.com'),
(43,	'yandex.ru'),
(44,	'zendesk.com'),
(45,	'zoho.com');

-- Llista blanca per SPF
INSERT INTO greylisting_whitelist_domain_spf (account, sender, comment)
VALUES
('@melindro.org', 'spf-trusted@example.org', 'Permetre per SPF'),
('@melindro.org', 'spfdomain.com', 'Dominis amb SPF vàlid per melindro.org');

-- Llista negra/blanca per rDNS
INSERT INTO wblist_rdns (rdns, wb)
VALUES
('bad.spammer.net', 'B'),  -- b = block
('mail.goodpartner.com', 'W'); -- w = whitelist
```

## Consulta SQL per saber si passa el greylisting
Aquesta consulta comprova si un correu enviat per un remitent concret a un destinatari concret passaria el greylisting, tenint en compte:

* Coincidència en greylisting_whitelists
* Coincidència en greylisting_whitelist_domains
* Coincidència en greylisting_whitelist_domain_spf
* Coincidència en wblist_rdns
* Estat registrat en greylisting_tracking
* Coincidència en configuració de greylisting per usuari, domini o global (@.)

```sql
    WITH params AS (
        SELECT
            'vip@example.net'::text    AS sender_email,
            'baldufa@melindro.org'::text AS recipient_email,
            'mail.goodpartner.com'::text AS rdns
    )
    SELECT
        p.sender_email,
        p.recipient_email,
        CASE
            WHEN gw.sender IS NOT NULL THEN 'WHITELIST: sender'
            WHEN gwd.domain IS NOT NULL THEN 'WHITELIST: domain'
            WHEN gwspf.sender IS NOT NULL THEN 'WHITELIST: SPF'
            WHEN wr.wb = 'w' THEN 'WHITELIST: rDNS'
            WHEN wr.wb = 'b' THEN 'BLOCK: rDNS'
            WHEN gt.passed = 1 THEN 'PASSED: already allowed in tracking'
            WHEN g.active = 1 THEN 'GREYLIST: apply policy'
            ELSE 'NO MATCH: default block'
        END AS decision
    FROM params p
    LEFT JOIN greylisting_whitelists gw
        ON gw.account IN (p.recipient_email, '@' || split_part(p.recipient_email, '@', 2), '@.')
        AND gw.sender = p.sender_email
    LEFT JOIN greylisting_whitelist_domains gwd
        ON gwd.domain = split_part(p.sender_email, '@', 2)
    LEFT JOIN greylisting_whitelist_domain_spf gwspf
        ON gwspf.account IN (p.recipient_email, '@' || split_part(p.recipient_email, '@', 2), '@.')
        AND gwspf.sender = p.sender_email
    LEFT JOIN wblist_rdns wr
        ON wr.rdns = p.rdns
    LEFT JOIN greylisting_tracking gt
        ON gt.sender = p.sender_email
        AND gt.recipient = p.recipient_email
    LEFT JOIN greylisting g
        ON g.account IN (p.recipient_email, '@' || split_part(p.recipient_email, '@', 2), '@.')
        AND g.sender = p.sender_email
    LIMIT 1;
```

### Funcionament
* Canvies els valors a WITH params per provar diferents remitents, destinataris i rDNS.
* La prioritat és:
    1. Llista blanca de remitent
    1. Llista blanca de domini
    1. Llista blanca per SPF
    1. Llista blanca rDNS
    1. Llista negra rDNS
    1. Ja ha passat tracking
    1. Aplica política greylist
    1. Bloqueig per defecte


## Consulta SQL que combini les taules per saber si un correu concret passaria el greylisting.
Suposem que volem comprovar si el missatge de vip@client.com a postmaster@melindro.org passaria el greylisting:

```SQL
    SELECT
        r.recipient,
        r.sender,
        CASE
            WHEN w.sender IS NOT NULL THEN 'PASS (whitelist sender)'
            WHEN wd.domain IS NOT NULL THEN 'PASS (whitelist domain)'
            WHEN wspf.sender IS NOT NULL THEN 'PASS (whitelist SPF)'
            WHEN t.passed = 1 THEN 'PASS (ja ha passat abans)'
            ELSE 'BLOCK (greylisting actiu)'
        END AS greylisting_result
    FROM
        (SELECT 'postmaster@melindro.org' AS recipient,
                'vip@client.com' AS sender,
                SUBSTRING_INDEX('vip@client.com', '@', -1) AS sender_domain,
                SUBSTRING_INDEX('postmaster@melindro.org', '@', -1) AS rcpt_domain
        ) AS r
    LEFT JOIN greylisting_whitelists w
        ON (w.account = r.recipient OR w.account = CONCAT('@', r.rcpt_domain))
       AND w.sender = r.sender
    LEFT JOIN greylisting_whitelist_domains wd
        ON wd.domain = r.sender_domain
    LEFT JOIN greylisting_whitelist_domain_spf wspf
        ON (wspf.account = r.recipient OR wspf.account = CONCAT('@', r.rcpt_domain))
       AND wspf.sender = r.sender_domain
    LEFT JOIN greylisting_tracking t
        ON t.sender = r.sender
       AND t.recipient = r.recipient;
```
#### 🔍 Explicació
* greylisting_whitelists → si el remitent està permès explícitament per usuari o domini.
* greylisting_whitelist_domains → si el domini del remitent està permès globalment.
* greylisting_whitelist_domain_spf → si el domini té SPF validat i està permès.
* greylisting_tracking → si ja ha passat el greylisting anteriorment.

Si no troba cap condició favorable, el resultat serà BLOCK.

#### 🔍 Camps de la taula `greylisting_tracking`
| Camp               | Tipus                             | Significat / ús                                                                                                                                                                                                                                                          |
| ------------------ | --------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **id**             | `bigint unsigned`, auto_increment | Identificador únic de cada registre de seguiment.                                                                                                                                                                                                                        |
| **sender**         | `varchar(255)`                    | El remitente (adreça “From:” o el sender que es fa servir en la negociació SMTP). Permet rastrejar per qui envia. En alguns informes dels usuaris, aquest camp pot arribar a ser molt llarg, i si és més de 255 caràcters pot donar problemes. ([forum.iredmail.org][1]) |
| **recipient**      | `varchar(255)`                    | El destinatari (l’adreça a qui es vol enviar). Permet registrar per a quina adreça local s’està provant l’enviament.                                                                                                                                                     |
| **client_address** | `varchar(40)`                     | L’adreça IP del client (el servidor que està intentant connectar-se com a client SMTP). “Client_address” normalment és l’IP des d’on ve l’enviament.                                                                                                                     |
| **sender_domain**  | `varchar(255)`                    | El domini del sender (extracció del sender, per exemple “gmail.com” d’enviaments com “[usuari@gmail.com](mailto:usuari@gmail.com)”). Aquest camp és útil per agrupar per dominis d’enviadors.                                                                            |
| **rcpt_domain**    | `varchar(255)`                    | El domini del destinatari (“rcpt” = recipient), per exemple “domini-local.com” si l’usuari destinatari està a un domini que gestiones.                                                                                                                                   |
| **init_time**      | `int(10) unsigned`                | Marca de temps (timestamp) de quan es va crear el registre (quan es va fer el primer intent), probablement en format Unix (segons l’exemple). Serveix per saber “quan va començar aquest triplet a ser rastrejat”.                                                       |
| **block_expired**  | `int(10) unsigned`                | Timestamp fins quan la regla de bloqueig (“greylist”) expira. És a dir, la primera fase de bloqueig: passat aquest moment, teòricament s’hauria de permetre el retry, si tot està bé.                                                                                    |
| **record_expired** | `int(10) unsigned`                | Timestamp de caducitat del registre complet: quan ja no cal mantenir aquest “triplet” perquè ja ha passat, o ja no és rellevant, i es pot netejar la base de dades.                                                                                                      |
| **blocked_count**  | `bigint(20)`                      | Nombre d’intents bloquejats (“greylisting”) que s’han fet per aquest “triplet”: quant ha intentat el servidor client enviar però ha estat rebutjat temporalment.                                                                                                         |
| **passed**         | `tinyint(1)`                      | Indica si el “triplet” ja ha passat el greylisting (“1” = sí, ha fet reintents acceptats; “0” = encara no ha passat). Aquest camp serveix per diferenciar entre trànsit que està en fase de bloqueig i trànsit que ja ha “superat” el greylisting.                       |

[1]: https://forum.iredmail.org/topic15536-iredapd-error-error-while-initializing-greylisting-tracking.html?utm_source=chatgpt.com "iredapd ERROR: Error while initializing greylisting tracking"


# 2. Throttle iRedAPD

## Detalls tècnics del connector throttle
Actualment pots limitar segons:
- Quantitat de correus enviats en un període de temps
- Mida acumulada dels correus enviats en un període de temps
- Mida d’un sol missatge
- Nombre de destinataris en un sol missatge

Exemple: pots fer que l’usuari `user@domain.com` no pugui enviar més de 1000 correus i/o 1 GB en 5 minuts. El primer límit que s’assoleixi és el que s’aplica.

## Formats vàlids d’adreça per al throttling:
* Adreça completa: `user@domain.com`
* Nom de domini (amb `@` prefixat): `@domain.com`
* Subdomini (amb `@.` prefixat): `@.domain.com`
* Adreça IP: `192.168.1.1`
* Xarxa IP: `192.168.1.*`
* Captura general per correu: `@.` (cal incloure el punt)
* Captura general per IP: `@ip` (s’aplica per IP individual)

## Prioritats de les adreces de throttle (més alt = més prioritat):
Tenia aquesta llista 
* `email`: 100 — ex: `user@domain.com`
* `wildcard_addr`: 90 — ex: `user@*`
* `ip`: 80 — ex: `173.254.22.21`
* `wildcard_ip`: 70 — ex: `173.254.22.*`
* `cidr`: 70 — ex: `173.254.22.0/24`
* `domain`: 60 — ex: `@domain.com`
* `subdomain`: 50 — ex: `@.domain.com`
* `tld_domain`: 40 — ex: `@com`, `@org`
* `catchall`: 0 — `@.`

📌 _NOTA_: he passat a usar `MAILADDR_PRIORITIES` de `iredutils.py` multiplicat per __10__

## Paràmetres vàlids de throttle:
* `msg_size`: mida màxima d’un sol missatge
* `max_msgs`: nombre màxim de missatges enviats
* `max_quota`: mida acumulada màxima dels missatges
* `max_rcpts`: nombre màxim de destinataris en un sol missatge

## Valors vàlids per als paràmetres:
* `XX` (enter): límit explícit. Ex: `max_msgs=100` → fins a 100 missatges
* `0`: il·limitat
* `-1`: hereta el valor d’una configuració amb prioritat inferior. Ex: `msg_size=-1` per a `user@domain.com` farà que iRedAPD consulti la configuració de `msg_size` a nivell de domini (`@domain.com`) o global (`@.`)

## Tipus de throttle (`throttle.kind`):
- `inbound`: correus rebuts des de servidors externs
- `outbound`: correus enviats per usuaris autenticats
- `external`: correus enviats des de servidors externs

## Diferència entre `inbound` i `external`:
- `inbound`: basat en adreces d’origen que són usuaris locals
- `external`: basat en adreces d’origen que **no** són usuaris locals

## Condicions de creació de registres a la taula `throttle`
* `kind`: pot ser `['inbound', 'outbound', 'external']`
només definir si `max_msgs`, `max_quota`, `msg_size` o `max_rcpts` (aquest darrer, només **outbound**) te valor diferent de `-1`
* `priority`: es defineix segons el **account_type** que verifica `is_valid_amavisd_address`
només definir si `max_msgs`, `max_quota`, `msg_size` o `max_rcpts` (aquest darrer, només **outbound**) te valor diferent de `-1`.
Tenia aquesta llista: 
    - `email`: 100
    - `wildcard_addr`: 90
    - `ip`: 80
    - `wildcard_ip`: 70
    - `cidr`: 70
    - `domain`: 60
    - `subdomain`: 50
    - `tld_domain`: 40
    - `catchall`: 0
📌 _NOTA_: he passat a usar `MAILADDR_PRIORITIES` a `iredutils.py` multiplicat per __10__
* `period`: 86400 segons (1 dia) si `max_msgs`, `max_quota`, `msg_size` o `max_rcpts` (aquest darrer, només **outbound**) te valor diferent de `-1`.  Acceptem `0` si volem desactivar el throttle però no eliminar les dades.
period sempre int ≥ 0.
    - 0 → throttle desactivat (config guardada).
    - >0 → throttle actiu.
    - <0 → no hauria de sortir mai al payload, només com a “sentinel” intern.
* `max_msgs`: Nombre màxim de missatges, per defecte: `-1`; si és catchall (`@.`), per defecte sense limit, `0`. 
* `max_quota`: Quota màxima (bytes), per defecte: `-1`; si és catchall (`@.`), per defecte sense limit, `0`. 
* `msg_size`: Mida màxima del missatge, per defecte: `-1`; si és catchall (`@.`), per defecte sense limit, `0`. 
* `max_rcpts`: Nombre màxim de destinataris, per defecte: `-1`; si és catchall (`@.`), per defecte sense limit, `0`. , només vàlid per kind `outbound`.

### Exemple de configuració de throttle per enviament:
1. Permetre que l’usuari local `user@domain.com` enviï correus en 6 minuts (`period=360`):

```sql
    INSERT INTO throttle (account, kind, priority, period, msg_size, max_msgs, max_quota, max_rcpts)
                   VALUES ('user@domain.com',
                           'outbound',
                           10,
                           360,
                           10240000,
                           100,
                           4096000000,
                           12);
```

1. Permetre que l’usuari extern `user@not-my-domain.com` enviï correus en 6 minuts (period=360):
  * value of sql column `throttle.kind` is `external`

```sql
    INSERT INTO throttle (account, kind, priority, period, msg_size, max_msgs, max_quota)
                VALUES ('user@not-my-domain.com',
                        'external',
                        10,
                        360,
                        10240000,
                        100,
                        4096000000);
```

### Exemple de configuració de throttle per recepció:
1. Permetre que l’usuari local `user@domain.com` rebi correus en 6 minuts (període=360):
* el valor de la columna SQL `throttle.kind` és `inbound`
* mida màxima d’un sol missatge: 10.240.000 bytes (`msg_size`)
* màxim 100 missatges (`max_msgs`)
* màxim 4.096.000.000 bytes (`max_quota`)
```sql
    INSERT INTO throttle (account, kind, priority, period, msg_size, max_msgs, max_quota)
                   VALUES ('user@domain.com',
                           'inbound',
                           10,
                           360,
                           10240000,
                           100,
                           4096000000);
```

## Inserts SQL d'exemple a Throttle iRedAPD 

```sql
    INSERT INTO throttle (
        account,
        kind,
        priority,
        period,
        msg_size,
        max_msgs,
        max_quota,
        max_rcpts
    ) VALUES
    -- Configuració global
    ('@.', 'outbound', 0, 86400, 10485760, 500, 1073741824, 100),
    -- Configuració per domini
    ('@melindro.org', 'outbound', 1, 3600, 5242880, 200, 536870912, 50),
    -- Configuració per usuari
    ('postmaster@melindro.org', 'outbound', 2, 3600, 1048576, 50, 104857600, 10),
    ('baldufa@melindro.org', 'outbound', 2, 3600, 1048576, 50, 104857600, 10),
    ('baldufa@melindro.org', 'inbound', 2, 3600, 1048576, 50, 104857600, 10);
    
    
    INSERT INTO throttle_tracking (
        tid,
        account,
        period,
        cur_msgs,
        cur_quota,
        init_time,
        last_time,
        last_notify_time
    ) VALUES
    -- Tracking per configuració global
    (1, '@.', 86400, 120, 80000000, UNIX_TIMESTAMP() - 80000, UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),
    -- Tracking per domini
    (2, '@melidro.org', 3600, 80, 40000000, UNIX_TIMESTAMP() - 3000, UNIX_TIMESTAMP(), UNIX_TIMESTAMP()),
    -- Tracking per usuari
    (3, 'postmaster@melindro.org', 3600, 30, 10000000, UNIX_TIMESTAMP() - 1800, UNIX_TIMESTAMP(), UNIX_TIMESTAMP());
```

## Què és wblist_rdns?
És una funcionalitat del sistema iRedAPD que permet gestionar llistes blanca i negra basades en el reverse DNS (rDNS) del client que intenta enviar correu. Això ajuda a bloquejar correu sospitós o spam basant-se en el nom de domini associat a la IP del remitent.

# 3. SMTP
La columna action a la taula smtp_sessions de la base de dades iredapd emmagatzema la resposta final que el servidor de polítiques (iRedAPD) envia a Postfix. Aquestes respostes segueixen el protocol SMTP Access Policy de Postfix.

1. DUNNO (El més freqüent)
    * Significat: Literalment "I don't know" (No ho sé).
    * Què fa: iRedAPD diu a Postfix: "Jo no tinc cap objecció amb aquest correu, continua consultant altres regles o accepta'l si ningú més s'hi oposa".
    * Resultat: El correu continua el seu camí cap al següent filtre (com Amavisd o SpamAssassin).

2. OK
    * Significat: Acceptació explícita.
    * Què fa: iRedAPD ordena a Postfix acceptar el correu immediatament, saltant-se altres restriccions de Postfix que poguessin venir després.
    * Ús: Se sol veure quan un remitent està en una Whitelist (Llista blanca).

3. REJECT (i codis 5xx)
    * Significat: Rebuig permanent.
    * Exemple: REJECT Policy rejection; SPF fail o 554 5.7.1 Service unavailable.
    * Què fa: El servidor tanca la connexió i el remitent rep un error conforme el correu no s'ha lliurat. No es tornarà a intentar.
Codi 550 / 554: Són els codis d'estat SMTP estàndard per a errors fatals.

4. DEFER_IF_PERMIT (i codis 4xx com 451)
    * Significat: Rebuig temporal (Greylisting).
    * Exemple: 451 4.7.1 Greylisting in action, please come back later.
    * Què fa: Li diu al servidor remitent: "Ara mateix no puc, torna-ho a intentar d'aquí a una estona".
Codi 451 / 450: Indica un error temporal. Si el servidor remitent és legítim, reintentarà l'enviament automàticament passats uns minuts. Si és un bot de spam simple, normalment no reintenta.

5. DISCARD
    * Significat: Descartar silenciosament.
    * Què fa: Postfix respon al remitent que el correu s'ha acceptat correctament, però en realitat l'elimina sense lliurar-lo a la bústia i sense avisar a ningú. Es fa servir per "negar el pa" a spammers molt agressius.

| Acció | Codi SMTP | Comportament |
|-------|-----------|--------------|
| DUNNO | — | Passa al següent filtre de Postfix |
| OK | 250 | Acceptat (ignora altres filtres) |
| REJECT | 5xx | Error permanent (Rebuig) |
| DEFER_IF_PERMIT | 4xx | Error temporal (Reintentar) - Greylisting |
| DISCARD | — | Descartat silenciosament |
| PREPEND | — | Afegeix una capçalera (header) al correu |
