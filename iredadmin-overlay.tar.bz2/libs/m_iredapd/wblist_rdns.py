# libs/m_iredapd/wblist_rdns.py
from libs.m_iredapd import iRedAPDWrap
from libs.m_system.mixins import iRedAPDMixin
from libs.m_system.decorators import LibDecorators


class WblistRDNS(iRedAPDWrap, iRedAPDMixin):
    def __init__(self):
        super().__init__()

    def _prepare_insert_data(self, rdns_data, wb_flag):
        return [{'rdns': i, 'wb': wb_flag} for i in self._normalize_list_domains_ips(rdns_data)]

    @LibDecorators.safe_sql_method
    def get_wblist_rdns(self):
        """
            Obté la llista de rDNS whitelisted i blacklisted.
            Retorna un diccionari amb dues claus:
            - whitelists: llista d’rDNS permesos
            - blacklists: llista d’rDNS bloquejats
        """

        whitelists, blacklists = [], []

        qr = self.db.select(
            'wblist_rdns',
            what='rdns,wb',
            order='rdns')
        for i in qr:
            _rdns = str(i.rdns).lower()
            if i.wb == 'W':
                whitelists.append(_rdns)
            elif i.wb == 'B':
                blacklists.append(_rdns)

        return (True, {
            'rdns_whitelist': whitelists,
            'rdns_blacklist': blacklists
            }
        )

    @LibDecorators.safe_sql_method
    def reset_wblist_rdns(self, whitelists=None, blacklists=None):
        """
            Reinicia la llista d’rDNS whitelisted i blacklisted.

            Semàntica:
            None → no aporta valors (però pot rebre modificacions per consistència global)
            []   → establir la llista buida
            list → establir la llista passada

            Política:
            Es garanteix consistència global: cap rDNS pot estar tant a WL com a BL.
            En cas de conflicte, BL perd la prioritat → BL = BL - WL
        """
        _, cur, *rest = self.get_wblist_rdns()
        cur_wl = set(cur.get("rdns_whitelist", []))
        cur_bl = set(cur.get("rdns_blacklist", []))

        new_wl = set(cur_wl)
        new_bl = set(cur_bl)

        if whitelists is not None:
            wl = set(self._normalize_list_domains_ips(whitelists or []))
            new_wl = wl

        if blacklists is not None:
            bl = set(self._normalize_list_domains_ips(blacklists or []))
            new_bl = bl

        # deduplicació WL té prioritat → BL = BL - WL
        new_bl -= new_wl

        # ✅ processar whitelist
        if new_wl != cur_wl:
            self.db.delete('wblist_rdns', where='wb=$wb', vars={'wb': 'W'})
            if new_wl:
                self.db.multiple_insert('wblist_rdns', self._prepare_insert_data(new_wl, 'W'))

        # ✅ processar blacklist
        if new_bl != cur_bl:
            self.db.delete('wblist_rdns', where='wb=$wb', vars={'wb': 'B'})
            if new_bl:
                self.db.multiple_insert('wblist_rdns', self._prepare_insert_data(new_bl, 'B'))

        _, final, *rest  = self.get_wblist_rdns()
        final['_msg'] = 'RESET'
        return (True, final)

    @LibDecorators.safe_sql_method
    def add_wblist_rdns(self, whitelists=None, blacklists=None):
        """
            Afegeix entrades noves a la llista d’rDNS.
            Evita duplicats amb registres ja existents.
        """
        ok, current, *rest = self.get_wblist_rdns()
        if not ok :
            return (False, current)

        inserts = []
        for (_list, _wb, _key) in [
            (whitelists, 'W', 'rdns_whitelist'),
            (blacklists, 'B', 'rdns_blacklist')
        ]:
            normalized = set(self._normalize_list_domains_ips(_list or []))
            new_items = normalized - set(current[_key])
            inserts.extend(self._prepare_insert_data(new_items, _wb))

        if inserts:
            self.db.multiple_insert('wblist_rdns', inserts)

        _, current, *rest = self.get_wblist_rdns()
        current['_msg'] = 'ADDED'
        return (True, current)

    @LibDecorators.safe_sql_method
    def remove_wblist_rdns(self, whitelists=None, blacklists=None):
        """
            Elimina entrades de la llista de rDNS.
        """
        for (_list, _wb) in [(whitelists, 'W'), (blacklists, 'B')]:
            normalized = self._normalize_list_domains_ips(_list or [])
            self.db.delete(
                'wblist_rdns',
                vars={'wb': _wb, 'rdns_list': normalized},
                where='wb=$wb AND rdns IN $rdns_list'
            )
        _, current, *rest = self.get_wblist_rdns()
        current['_msg'] = 'REMOVED'
        return (True, current)
