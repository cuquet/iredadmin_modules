# Mòdul `m_iredapd`

Integracio de funcionalitats d'iRedAPD dins iRedMailMyAdmin:

- Greylisting (settings, whitelists, tracking)
- Throttling (global, domini, usuari)
- SMTP sessions (consulta i export)
- rDNS whitelist/blacklist

## Documentacio ampliada

Per conservar notes tècniques extenses (SQL detallat, exemples i explicacions llargues), consulta:

- `libs/m_iredapd/README.technical.md`

## Objectiu

Aquest modul centralitza logica SQL d'iRedAPD i la reutilitza des de:

- UI (`controllers/m_system`, `controllers/m_iredapd`, `controllers/m_crud`)
- API REST (`api/greylist`, `api/throttle`)
- Dashboard (`libs/m_crudlib/admin.py` via comptadors SMTP)

## Estructura

- `libs/m_iredapd/__init__.py`
- `iRedAPDWrap`: connexio DB `iredapd` (mysql/postgres segons settings).
- `libs/m_iredapd/greylist.py`
- `Greylisting`: settings + whitelists + tracking.
- `libs/m_iredapd/throttle.py`
- `Throttle`: limitacions per `inbound/outbound/external`.
- `libs/m_iredapd/smtp.py`
- `SMTPStats`: sessions SMTP, filtres, comptadors i top raons.
- `libs/m_iredapd/wblist_rdns.py`
- `WblistRDNS`: whitelist/blacklist de reverse DNS.

## Taules SQL implicades

- `greylisting`
- `greylisting_whitelist_domains`
- `greylisting_whitelists`
- `greylisting_whitelist_domain_spf`
- `greylisting_tracking`
- `throttle`
- `throttle_tracking`
- `smtp_sessions`
- `wblist_rdns`

## Greylisting

### Nivells de compte

- Global: `@.`
- Domini: `@example.com`
- Usuari: `user@example.com`

### Metodes principals (`libs/m_iredapd/greylist.py`)

- `get_greylist_setting()`
- `enable_disable_greylist_setting(enable=True|False)`
- `delete_greylist_setting()` (semantica "inherit")
- `get_greylist_whitelists(account_type)`
- `reset_greylist_whitelists(account_type, senders)`
- `add_greylist_whitelists(account_type, senders)`
- `remove_greylist_whitelists(account_type, senders)`
- `get_greylist_whitelists_spf_domain()`
- `reset_greylist_whitelists_spf_domain(domains)`
- `add_greylist_whitelists_spf_domain(domains)`
- `remove_greylist_whitelists_spf_domain(domains)`
- `get_tracking_data(page, payload)`
- `delete_tracking_data(payload, delete_all=False)`

### Whitelists disponibles

- `greylisting_whitelist_domains`
- Llista simple global (dominis/IPs), sense comentaris.
- `greylisting_whitelists`
- Llista per compte (usuari/domini), legacy.
- `greylisting_whitelist_domain_spf`
- Llista amb `sender + comment`, usada per UI i API per domini/usuari.

### Tracking

`get_tracking_data()` admet filtres:

- `query_string`
- `date_from`
- `date_to`
- `passed` (`0`, `1`, `all`)

I aplica el filtre per tipus de compte:

- email -> `recipient=<mail>`
- domain -> `rcpt_domain=<domain>`
- catchall -> tot (`@.`)

## Throttle

### Metodes principals (`libs/m_iredapd/throttle.py`)

- `get_throttle_settings()`
- `update_throttle_settings()`
- `create_throttle_settings()`
- `remove_throttle_settings()`
- `remove_throttle_tracking()`
- `remove_throttle_settings_for_removed_users()` (helper)
- `remove_throttle_settings_for_removed_domain()` (helper)

### Camps clau

- `kind`: `inbound`, `outbound`, `external`
- `period`
- `max_msgs`
- `max_quota`
- `msg_size`
- `max_rcpts` (nomes outbound)

### Semantica important

- `-1`: herencia (nivell inferior)
- `0`: unlimited (limits) o desactivat (si `period=0`)
- `period>0`: throttle actiu

Prioritat:

- es calcula amb `MAILADDR_PRIORITIES * 10` segons tipus de compte.

## SMTP sessions

### Metodes principals (`libs/m_iredapd/smtp.py`)

- `list(page, payload)`
- `get_counts(days=1)`
- `get_rejection_reasons(days=1, limit=5)`

### Filtres disponibles

- `session_type`: `all`, `outbound`, `rejected`, `greylisted` (intern)
- `query_string`
- `date_from`

`get_counts()` s'usa al dashboard per:

- outbound
- rejected (accions `5xx`)

## rDNS whitelist/blacklist

### Metodes principals (`libs/m_iredapd/wblist_rdns.py`)

- `get_wblist_rdns()`
- `reset_wblist_rdns(whitelists, blacklists)`
- `add_wblist_rdns(whitelists, blacklists)`
- `remove_wblist_rdns(whitelists, blacklists)`

Regla de consistencia:

- whitelist te prioritat sobre blacklist (`BL = BL - WL`).

## Integracio UI

### Controllers

- `controllers/m_system/controller.py`
- `SystemGreylisting` -> `/system/greylisting`
- `SystemThrottle` -> `/system/throttle`
- `SystemWBlist` (tab `rdns`) -> `/system/wblist/rdns`
- `controllers/m_iredapd/controller.py`
- `GreylistingTrackingData` -> `/activities/greylisting`, `/system/greylisting/tracking`
- `GreylistingTrackingDataExport` -> `/activities/greylisting/export`
- `smtpSessions` -> `/activities/smtp/sessions`
- `smtpSessionsExport` -> `/activities/smtp/sessions/export`

### Templates

Classic:

- `templates/classic/iredapd/greylist.html`
- `templates/classic/iredapd/throttle.html`
- `templates/classic/iredapd/greylisting_tracking_records.html`
- `templates/classic/iredapd/smtp.html`
- `templates/classic/macros/iredapd.html`

Responsive:

- `templates/codyframe/iredapd/greylist.html`
- `templates/codyframe/iredapd/throttle.html`
- `templates/codyframe/iredapd/greylisting_tracking_records.html`
- `templates/codyframe/iredapd/smtp.html`
- `templates/codyframe/macros/iredapd.html`

## Integracio API REST

### Greylisting (`api/greylist`)

Rutes principals:

- `GET/POST /api/greylisting/(all|global)`
- `GET/POST /api/greylisting/<domain>`
- `GET/POST /api/greylisting/<mail>`
- `GET/POST /api/greylisting/global/whitelists`
- `GET/POST /api/greylisting/<domain>/whitelists`
- `GET/POST /api/greylisting/<mail>/whitelists`
- `GET/POST /api/greylisting/whitelist_spf_domains`

Comportament actual (important):

- `.../global/whitelists` -> llista global simple (`greylisting_whitelist_domains`).
- `.../<domain>/whitelists` i `.../<mail>/whitelists` -> llista SPF amb comentaris (`greylisting_whitelist_domain_spf`), alineat amb UI.
- Alias acceptats per domini/usuari:
- `senders/addSenders/removeSenders` es mapeja a `domains/addDomains/removeDomains`.

### Throttle (`api/throttle`)

Rutes:

- `GET/POST /api/throttle/global/(inbound|outbound)`
- `GET/POST /api/throttle/<domain>/(inbound|outbound)`
- `GET/POST /api/throttle/<mail>/(inbound|outbound)`

Payload (`POST`) suportat:

- `enable` (`yes/no`, `true/false`, etc.)
- `period`
- `max_msgs`
- `max_quota`
- `msg_size`
- `max_rcpts` (outbound)

## Exemples CLI (iredapi_manager.py)

Greylisting:

```bash
./iredapi_manager.py call -e '/greylisting/global'
./iredapi_manager.py call -e '/greylisting/melindro.org'
./iredapi_manager.py call -e '/greylisting/baldufa@melindro.org'
./iredapi_manager.py call -e '/greylisting/global/whitelists' -m POST -d 'addSenders=google.tv'
./iredapi_manager.py call -e '/greylisting/melindro.org/whitelists' -m POST -d 'domains=@spfdomain.com # trusted'
```

Throttle:

```bash
./iredapi_manager.py call -e '/throttle/global/inbound'
./iredapi_manager.py call -e '/throttle/global/inbound' -m POST -d 'period=3600&max_msgs=20&max_quota=1048576000&msg_size=10485760'
./iredapi_manager.py call -e '/throttle/melindro.org/outbound' -m POST -d 'max_msgs=100'
./iredapi_manager.py call -e '/throttle/baldufa@melindro.org/inbound' -m POST -d 'enable=no'
```

## Permisos i seguretat

- UI de sistema (`/system/*`) requereix global admin.
- Activitats (`/activities/greylisting`, `/activities/smtp/sessions`) passen per decoradors de login/permis.
- API usa `require_login` + comprovacio de privilegis (`api/utils.py::_check_privilege`).

## Notes operatives

- Aquest modul depen del schema SQL d'iRedAPD.
- Si canvien taules/camps d'iRedAPD, cal revisar:
- select/where dels metodes de `greylist.py`, `throttle.py`, `smtp.py`, `wblist_rdns.py`.
- mapeigs API<->DB a `controllers/m_iredapd/utils.py`.
- rutes API a `api/greylist/urls.py` i `api/throttle/urls.py`.

# 📦 Llicència
Aquest projecte s’ofereix sota la llicència [MIT](https://choosealicense.com/licenses/mit/). Pots modificar-lo, distribuir-lo i integrar-lo lliurement.

# 🤝 Contribucions
Les contribucions són benvingudes! Si tens idees, millores o correccions, obre un issue o envia un pull request.
[![PayPal - Donate](https://img.shields.io/badge/PayPal-Donate-005EA6?logo=paypal&logoColor=white)](https://www.paypal.me/cuquet74)
